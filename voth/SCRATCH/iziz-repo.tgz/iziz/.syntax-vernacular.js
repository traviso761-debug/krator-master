
// ---------------------------------------------------------------- error panel
const ERRS=document.getElementById('errs');
function reportErr(m){ERRS.style.display='block';ERRS.textContent+=m+'\n';}
window.onerror=(m,s,l,c,e)=>reportErr((e&&e.stack)||(m+' @'+l+':'+c));
window.addEventListener('unhandledrejection',e=>reportErr('promise: '+(e.reason&&e.reason.stack||e.reason)));

// ---------------------------------------------------------------- rng + noise
let _seed=1234567;
function reseed(s){_seed=s>>>0;}
function rng(){_seed|=0;_seed=_seed+0x6D2B79F5|0;let t=Math.imul(_seed^_seed>>>15,1|_seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}
function rr(a,b){return a+(b-a)*rng();}
function h3(x,y,z){const s=Math.sin(x*12.9898+y*78.233+z*37.719)*43758.5453;return s-Math.floor(s);}
function vnoise(x,y,z){const xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),xf=x-xi,yf=y-yi,zf=z-zi;
 const sm=t=>t*t*(3-2*t);const u=sm(xf),v=sm(yf),w=sm(zf);const l=(a,b,t)=>a+(b-a)*t;
 return l(l(l(h3(xi,yi,zi),h3(xi+1,yi,zi),u),l(h3(xi,yi+1,zi),h3(xi+1,yi+1,zi),u),v),
          l(l(h3(xi,yi,zi+1),h3(xi+1,yi,zi+1),u),l(h3(xi,yi+1,zi+1),h3(xi+1,yi+1,zi+1),u),v),w);}
function fbm(x,y,z,o){o=o||3;let a=0,f=1,s=0;for(let i=0;i<o;i++){a+=vnoise(x*f,y*f,z*f)/f;s+=1/f;f*=2.03;}return a/s;}
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t, TAU=Math.PI*2;

// GROUND HEIGHT HOOK. Flat everywhere for now — the whole kit stands on y=0 —
// but every piece of code that meets the ground asks here instead of assuming
// zero, so the Krator terrain pass replaces this one function and the aprons,
// the trees and the fallen fragments all follow the ground without a builder
// being touched. Keep it cheap: it is called per tree and per rubble block.
function terrainH(x,z){return 0;}

// ---------------------------------------------------------------- per-type accounting
// One global tally, filled while the builders run. 90-scene.js sets TSTAT.cur
// to the site key ('skyA/1' = Skyscraper A, ruined) before each builder call
// and clears it after, so every mesh and every instanced item is charged to the
// type that made it. This is what makes the per-type triangle budgets in
// verify.py --assert measurable at all: the kit shares one InstancedMesh per
// item across all 33 types, so after kbake() there is no way to tell whose
// triangles are whose.
//
// Nothing here emits geometry or draws from the PRNG, so switching it on does
// not move a single rock. Keep it that way.
const TSTAT={cur:null,by:{},bad:[]};
function tcur(){const k=TSTAT.cur;if(k==null)return null;return TSTAT.by[k]||(TSTAT.by[k]={tris:0,inst:0,meshes:0});}
function triOf(g){if(!g)return 0;if(g.index)return g.index.count/3;const p=g.attributes&&g.attributes.position;return p?p.count/3:0;}
const _KTRI={};
function ktri(name){if(_KTRI[name]===undefined){const def=KIT.defs[name];_KTRI[name]=def?triOf(def.geo):0;}return _KTRI[name];}
function finite3(a){return !!a&&isFinite(a[0])&&isFinite(a[1])&&isFinite(a[2]);}
// ---------------------------------------------------------------- textures
// All procedural, all generated once at load, all in world-ish units: a texture
// tile is about 8 m across, because `lathe` sets uS = rFn(0)*TAU/8 and vS = cut/8.
// At 512 px that is 64 px per metre, which is what the panel and board sizes
// below are picked against — change the tile size and they stop meaning anything.
function canvasTex(w,h,fn,rep){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');fn(g,w,h);
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=8;t.encoding=THREE.sRGBEncoding;if(rep)t.repeat.set(rep,rep);return t;}
// A roughness/metalness map is DATA, not colour. Leaving it sRGB-encoded (which
// canvasTex does, correctly, for albedo) bends every value through a gamma curve
// and the surface comes back wrong.
//
// r128's MeshStandardMaterial reads roughnessMap from the GREEN channel and
// metalnessMap from the BLUE, so one texture assigned to both slots carries
// both. Both MULTIPLY the material's scalar `roughness`/`metalness`, so those
// are set to 1 and the map does all the work.
//
// This is the single biggest thing missing from the first-pass materials: with
// one flat roughness value, every panel on a 420 m tower has an identical
// highlight and the whole thing reads as moulded plastic. Breaking roughness up
// per panel and along the seams is what makes it read as metal.
function rmTex(w,h,fn){const t=canvasTex(w,h,(g,W,H)=>{const id=g.createImageData(W,H),d=id.data;
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4;const v=fn(x,y);
  d[i]=0;d[i+1]=clamp(v[0],0,1)*255|0;d[i+2]=clamp(v[1],0,1)*255|0;d[i+3]=255;}
 g.putImageData(id,0,0);});
 t.encoding=THREE.LinearEncoding;return t;}

// Panel grid: 2 m x 1 m sheets at 64 px/m.
const PANW=128,PANH=64;
function panTone(x,y){return h3(Math.floor(x/PANW)*1.7,Math.floor(y/PANH)*2.3,5.1);}
function panSeam(x,y){const fx=x%PANW,fy=y%PANH;return Math.min(fx,PANW-1-fx,fy,PANH-1-fy);}
function panBolt(x,y){const fx=x%PANW,fy=y%PANH;
 return Math.hypot(Math.min(fx,PANW-1-fx)-7,Math.min(fy,PANH-1-fy)-7);}

const TEX={};
TEX.panel=canvasTex(512,512,(g,w,h)=>{ // white metal: panel sheets, recessed seams, fasteners
 const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  let v=228+(panTone(x,y)-.5)*13;                       // sheet-to-sheet tone
  v+=(fbm(x/70,y/70,1.7,3)-.5)*15;                      // slow weathering drift
  v+=(fbm(x/3,y/30,4.4,2)-.5)*7;                        // brushed grain, running vertically
  const sd=panSeam(x,y);
  if(sd<1)v-=54; else if(sd<2)v-=25; else if(sd<4)v+=7; // groove, then its lit lip
  const bd=panBolt(x,y);
  if(bd<1.7)v-=28; else if(bd<2.7)v+=11;                // fastener at each sheet corner
  d[i]=v;d[i+1]=v-1;d[i+2]=v-7;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.panelRM=rmTex(512,512,(x,y)=>{
 const t=panTone(x,y),sd=panSeam(x,y);
 let r=.30+(t-.5)*.11+(fbm(x/60,y/60,9.2,2)-.5)*.14;
 let m=.38+(t-.5)*.10;                                  // NOTE: modest. There is no
 if(sd<2){r+=.40;m-=.22;}                               // envMap in this scene, so a
 r+=(fbm(x/8,y/42,3.3,2)-.5)*.10;                       // near-1 metalness renders
 return[r,m];});                                        // almost black.

TEX.rust=canvasTex(512,512,(g,w,h)=>{ // tarnished steel, rust running down from every ledge
 const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  // t is 0 at the top of the tile and 1 at the bottom. With world-unit UVs a
  // tile is roughly a storey, so the bottom of the tile is the underside of a
  // ledge: where water collects and where the staining is always worst. That is
  // how "keyed to overhangs" is approximated without knowing the geometry.
  const t=y/h;
  const base=fbm(x/70,y/70,4.2,3), streak=fbm(x/10,y/190,9.1,3);
  const run=clamp((streak-.40)*3,0,1)*clamp(t*1.7,0,1); // runs widen downward
  const ledge=clamp((t-.74)/.26,0,1);                   // the dark band under the ledge
  let r=126+(base-.5)*52,gg=118+(base-.5)*48,b=108+(base-.5)*44;   // dull tarnished silver
  const ru=clamp(run+ledge*.75,0,1);
  r=lerp(r,114+streak*52,ru);gg=lerp(gg,60+streak*30,ru);b=lerp(b,38+streak*16,ru);
  const dark=ledge*.42+clamp((fbm(x/40,y/150,2.2,2)-.62)*3,0,1)*.22;
  r*=1-dark;gg*=1-dark;b*=1-dark;
  if(panSeam(x,y)<1){r*=.74;gg*=.74;b*=.74;}            // the panel grid still ghosts through
  d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.rustRM=rmTex(512,512,(x,y)=>{const t=y/512;
 const ru=clamp(clamp((fbm(x/10,y/190,9.1,2)-.40)*3,0,1)*clamp(t*1.7,0,1)+clamp((t-.74)/.26,0,1)*.75,0,1);
 return[lerp(.55,.97,ru)+(fbm(x/25,y/25,6.6,2)-.5)*.12,lerp(.30,.04,ru)];});

// Verdigris is its own material now. It used to be blended into the rust map,
// which put copper patina on rusting STEEL everywhere in the kit — two metals
// that do not weather alike. Use MAT.verdigris only on parts meant to read as
// copper or bronze.
TEX.verdigris=canvasTex(256,256,(g,w,h)=>{
 const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const p=fbm(x/34,y/34,3.7,3),run=fbm(x/8,y/90,6.1,2),t=y/h;
  const a=clamp(clamp((p-.34)*2.4,0,1)*.72+clamp((run-.45)*2.6,0,1)*clamp(t*1.4,0,1)*.5,0,1);
  const sh=clamp((fbm(x/12,y/12,8.8,2)-.5)*.42,-.2,.2);
  d[i]=lerp(150,68,a)*(1+sh);d[i+1]=lerp(98,152,a)*(1+sh);d[i+2]=lerp(62,130,a)*(1+sh);d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.verdigrisRM=rmTex(256,256,(x,y)=>{const t=y/256;
 const a=clamp(clamp((fbm(x/34,y/34,3.7,2)-.34)*2.4,0,1)*.72+clamp((fbm(x/8,y/90,6.1,2)-.45)*2.6,0,1)*clamp(t*1.4,0,1)*.5,0,1);
 return[lerp(.32,.90,a),lerp(.34,.05,a)];});

// Water-staining decal. Grayscale and MULTIPLY-blended, so it darkens whatever
// wall it lands on rather than painting a grey rectangle over it — the same
// streak has to work on white metal, rust, concrete and brick.
TEX.stain=canvasTex(64,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const t=y/h;                                     // 0 at the ledge, 1 at the bottom
  const run=fbm(x/7,y/40,5.3,3);
  const edge=1-Math.abs(x/w*2-1);                  // fade out at the sides
  const a=clamp(edge*1.6,0,1)*clamp(1.25-t,0,1)*clamp((run-.30)*2.2,0,1);
  const v=255-a*118;
  d[i]=v;d[i+1]=v-3;d[i+2]=v-8;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.ground=canvasTex(1024,1024,(g,w,h)=>{ // painted later, once the sites are known
 g.fillStyle='#8a4a34';g.fillRect(0,0,w,h);});
// ---------------------------------------------------------------- materials
const DS=THREE.DoubleSide;
const MAT={
 // metalness/roughness come from the packed map (G=rough, B=metal); the scalars
 // are 1 so the map is not scaled down. See rmTex in 20-textures.js.
 white:new THREE.MeshStandardMaterial({map:TEX.panel,roughnessMap:TEX.panelRM,metalnessMap:TEX.panelRM,color:0xffffff,metalness:1,roughness:1,side:DS}),
 rust:new THREE.MeshStandardMaterial({map:TEX.rust,roughnessMap:TEX.rustRM,metalnessMap:TEX.rustRM,color:0xffffff,metalness:1,roughness:1,side:DS}),
 verdigris:new THREE.MeshStandardMaterial({map:TEX.verdigris,roughnessMap:TEX.verdigrisRM,metalnessMap:TEX.verdigrisRM,color:0xffffff,metalness:1,roughness:1,side:DS}),
 glass:new THREE.MeshStandardMaterial({color:0x3f9fe6,transparent:true,opacity:.48,metalness:.2,roughness:.08,emissive:0x0b2c4e,emissiveIntensity:.6,side:DS,depthWrite:false}),
 winIntact:new THREE.MeshStandardMaterial({color:0x143a5c,metalness:.6,roughness:.15,emissive:0x0a2238,emissiveIntensity:.8}),
 winDead:new THREE.MeshStandardMaterial({color:0x07090c,roughness:1}),
 dark:new THREE.MeshStandardMaterial({color:0x1a1d22,roughness:.95,side:DS}),
 guts:new THREE.MeshStandardMaterial({color:0x2a2622,roughness:.9,metalness:.4,side:DS}),
 pipe:new THREE.MeshStandardMaterial({color:0x7a4a2a,roughness:.55,metalness:.7}),
 pipeRust:new THREE.MeshStandardMaterial({color:0x4e3324,roughness:.9,metalness:.3}),
 strip:new THREE.MeshBasicMaterial({color:0xffffff}),
 dot:new THREE.MeshBasicMaterial({color:0xffffff}),
 moss:new THREE.MeshStandardMaterial({color:0xffffff,roughness:1}),
 vine:new THREE.MeshStandardMaterial({color:0x2c4a22,roughness:1}),
 rubble:new THREE.MeshStandardMaterial({color:0xffffff,roughness:.95}),
 fig:new THREE.MeshStandardMaterial({color:0xffffff,roughness:.9}),
 ground:new THREE.MeshStandardMaterial({map:TEX.ground,roughness:1}),
 slab:new THREE.MeshStandardMaterial({color:0xffffff,roughness:.9}),
 stain:new THREE.MeshBasicMaterial({map:TEX.stain,transparent:true,blending:THREE.MultiplyBlending,depthWrite:false,side:DS}),
};
// GLASS FRESNEL. Real glass turns reflective and pale at grazing angles; a flat
// transparent colour reads as blue plastic, which is what these curtain walls
// were doing. Injected into the stock standard-material shader rather than
// replacing it, so lights, fog and tone mapping all still apply.
//
// r128 has no <output_fragment> chunk — that arrived later — so the anchor is
// the literal final assignment. Verified against the pinned three.min.js.
//
// The cube is written out rather than pow(): a negative base in pow() yields NaN,
// and SwiftShader silently swallows it, so it would look perfect in verify.py
// and blow up on a real GPU. Everything feeding it is clamped anyway.
MAT.glass.onBeforeCompile=sh=>{
 sh.fragmentShader=sh.fragmentShader.replace(
  'gl_FragColor = vec4( outgoingLight, diffuseColor.a );',
  ['float _fr = 1.0 - clamp( abs( dot( normalize( normal ), normalize( vViewPosition ) ) ), 0.0, 1.0 );',
   '_fr = clamp( _fr, 0.0, 1.0 );',
   '_fr = _fr * _fr * _fr;',
   'vec3 _lit = outgoingLight + vec3( 0.30, 0.44, 0.58 ) * _fr * 0.85;',
   'gl_FragColor = vec4( _lit, clamp( diffuseColor.a + _fr * 0.42, 0.0, 1.0 ) );'].join('\n'));};
const SHELL=d=>d>0?MAT.rust:MAT.white;      // exterior skin by decay
const WIN=d=>d>0?MAT.winDead:MAT.winIntact;
const CYAN=new THREE.Color(0x7ff4ff), WARM=new THREE.Color(0xffd28a), DEAD=new THREE.Color(0x0a0c0e);

// ---------------------------------------------------------------- instancing kit
const KIT={defs:{},items:{},order:[]};
function kdef(name,geo,mat){KIT.defs[name]={geo,mat};KIT.items[name]=[];KIT.order.push(name);}
let KOFF=[0,0,0],KXF=null; // builder offset; optional {m,q} transform (leaning spire)
function kput(name,p,q,s,c){let P=p,Q=q;if(KXF){const v=new THREE.Vector3(p[0],p[1],p[2]).applyMatrix4(KXF.m);P=[v.x,v.y,v.z];Q=(q?q.clone():new THREE.Quaternion()).premultiply(KXF.q);}
 const w=[P[0]+KOFF[0],P[1]+KOFF[1],P[2]+KOFF[2]];
 const t=tcur();if(t){t.inst++;t.tris+=ktri(name);}
 // A NaN here is invisible: the instance renders nowhere and takes the whole
 // InstancedMesh's bounding sphere with it. Catch it at the source, where we
 // still know which type and which kit item produced it.
 if(!finite3(w)||!(typeof s==='number'?isFinite(s):finite3(s)))TSTAT.bad.push({type:TSTAT.cur,item:name,p:w,s:s});
 KIT.items[name].push({p:w,q:Q,s,c});}
let KIT_BAKED=false;
function kbake(parent){KIT_BAKED=true;const m=new THREE.Matrix4(),pos=new THREE.Vector3(),sc=new THREE.Vector3(),q0=new THREE.Quaternion();let tot=0;
 for(const name of KIT.order){const it=KIT.items[name];if(!it.length)continue;const def=KIT.defs[name];
  // one material clone per InstancedMesh (r128 needs it for instanceColor), but
  // Material.copy() does NOT carry onBeforeCompile, so the glass fresnel has to
  // be re-attached by hand or every instanced pane and finial loses it.
  const _m=def.mat.clone();if(def.mat.onBeforeCompile)_m.onBeforeCompile=def.mat.onBeforeCompile;
  const im=new THREE.InstancedMesh(def.geo,_m,it.length);
  it.forEach((o,i)=>{pos.set(o.p[0],o.p[1],o.p[2]);const s=typeof o.s==='number'?sc.set(o.s,o.s,o.s):sc.set(o.s[0],o.s[1],o.s[2]);
   m.compose(pos,o.q||q0,s);im.setMatrixAt(i,m);if(o.c)im.setColorAt(i,o.c);});
  if(im.instanceColor){const W=new THREE.Color(0xffffff);it.forEach((o,i)=>{if(!o.c)im.setColorAt(i,W);});}
  if(im.instanceColor)im.instanceColor.needsUpdate=true;im.instanceMatrix.needsUpdate=true;im.frustumCulled=false;parent.add(im);tot+=it.length;}
 window._instances=tot;}
// orientation helpers
const _M=new THREE.Matrix4(),_V0=new THREE.Vector3(),_UP=new THREE.Vector3(0,1,0),_X=new THREE.Vector3(1,0,0);
function qFacing(dir){ // quaternion whose local +z points along dir (dir horizontal-ish)
 const d=new THREE.Vector3(dir[0],dir[1],dir[2]).normalize();const up=Math.abs(d.y)>.95?_X:_UP;
 _M.lookAt(d,_V0,up);return new THREE.Quaternion().setFromRotationMatrix(_M);}
function qEuler(x,y,z){return new THREE.Quaternion().setFromEuler(new THREE.Euler(x,y,z));}
function qAxis(ax,ay,az,a){return new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(ax,ay,az).normalize(),a);}

// ---------------------------------------------------------------- surfaces
// fn(u,v)->[x,y,z]; opt.hole(u,v)->bool drops that quad. UVs scaled by opt.uS/vS (world-ish units).
function gridSurface(fn,nu,nv,opt){opt=opt||{};const pos=[],uv=[],idx=[];const cols=nu+1;
 for(let j=0;j<=nv;j++)for(let i=0;i<=nu;i++){const u=i/nu,v=j/nv;const p=fn(u,v);pos.push(p[0],p[1],p[2]);uv.push(u*(opt.uS||1),v*(opt.vS||1));}
 for(let j=0;j<nv;j++)for(let i=0;i<nu;i++){if(opt.hole&&opt.hole((i+.5)/nu,(j+.5)/nv))continue;const a=j*cols+i,b=a+1,c=a+cols,d=c+1;idx.push(a,c,b,b,c,d);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
 g.setIndex(idx);g.computeVertexNormals();return g;}
// Lathe with flutes, twist, jagged cut and holes.  o:{rFn(y),H,cut,jag,flutes,amp,sharp,twist,nu,nv,hole(u,y),seed}
function lathe(o){const H=o.H,cut=o.cut!=null?o.cut:H,seed=o.seed||0,nu=o.nu||64,nv=o.nv||48;
 const fn=(u,v)=>{const th=u*TAU;let top=cut;if(o.cut!=null&&o.jag)top=cut+o.jag*(fbm(u*7+seed,2.3,seed*.7,3)*2-1);
  const yy=v*top;let r=o.rFn(Math.min(yy,H));if(o.flutes)r*=1+(o.amp||.08)*Math.pow(.5+.5*Math.cos(th*o.flutes+(o.twist||0)*yy),o.sharp||2);
  return[r*Math.cos(th),yy,r*Math.sin(th)];};
 const opt={uS:o.rFn(0)*TAU/8,vS:cut/8};if(o.hole)opt.hole=(u,v)=>o.hole(u,v*cut);return gridSurface(fn,nu,nv,opt);}
// generic decay hole: more holes near a cut, controlled by d (0..1)
// HOLES scales every decay hole in the kit at once. Decay level 3 (repaired)
// wants the same builders with the same rusted materials but a fabric that is
// only part-eaten, and threading that through 33 builders would be 33 edits
// and 33 chances to miss one. The scene loop sets it per decay level.
let HOLES=1;
function holeFn(d,seed,cut,scale){d*=HOLES;if(!(d>0))return null;scale=scale||1;
 return(u,y)=>{const n=fbm(u*4.5*scale+seed*.31,y*.028*scale,seed,3);const near=cut!=null?clamp((y-(cut-45))/45,0,1):0;return n<.34*d+.4*near*d;};}
function mesh(geo,mat,parent,x,y,z){const m=new THREE.Mesh(geo,mat);if(x!==undefined)m.position.set(x,y,z);if(parent)parent.add(m);
 const t=tcur();if(t){t.meshes++;t.tris+=triOf(geo);}
 return m;}
// Merge geometries that share a material and a parent into one mesh.
//
// Draw calls are per mesh, and the close-up views are dominated by towers built
// one storey at a time - a 60-storey tower emitting two bands per floor is 120
// draw calls on its own. Merging is triangle-neutral and, because the per-vertex
// normals are copied rather than recomputed, pixel-neutral too.
//
// Only for OPAQUE materials: transparent meshes are depth-sorted per mesh, so
// merging glass would change the order things blend in.
function meshMerged(geos,mat,parent,x,y,z){
 const keep=geos.filter(g=>g&&g.attributes&&g.attributes.position&&g.attributes.position.count);
 if(!keep.length)return null;
 if(keep.length===1)return mesh(keep[0],mat,parent,x,y,z);
 let nv=0,ni=0;
 for(const g of keep){nv+=g.attributes.position.count;ni+=g.index?g.index.count:g.attributes.position.count;}
 const P=new Float32Array(nv*3),N=new Float32Array(nv*3),U=new Float32Array(nv*2);
 const I=nv>65535?new Uint32Array(ni):new Uint16Array(ni);
 let vo=0,io=0;
 for(const g of keep){const A=g.attributes,c=A.position.count;
  P.set(A.position.array,vo*3);
  if(A.normal)N.set(A.normal.array,vo*3);
  if(A.uv)U.set(A.uv.array,vo*2);
  if(g.index){const ix=g.index.array;for(let i=0;i<ix.length;i++)I[io+i]=ix[i]+vo;io+=ix.length;}
  else{for(let i=0;i<c;i++)I[io+i]=vo+i;io+=c;}
  vo+=c;}
 const G=new THREE.BufferGeometry();
 G.setAttribute('position',new THREE.BufferAttribute(P,3));
 G.setAttribute('normal',new THREE.BufferAttribute(N,3));
 G.setAttribute('uv',new THREE.BufferAttribute(U,2));
 G.setIndex(new THREE.BufferAttribute(I,1));
 return mesh(G,mat,parent,x,y,z);}
// Bounding box of an object and its children, measured in its PARENT's frame.
function fragBox(o,acc,bb){o.updateMatrix();const m=acc.clone().multiply(o.matrix);
 if(o.isMesh&&o.geometry){const g=o.geometry;if(!g.boundingBox)g.computeBoundingBox();
  if(g.boundingBox&&isFinite(g.boundingBox.min.x))bb.union(g.boundingBox.clone().applyMatrix4(m));}
 for(const c of o.children)fragBox(c,m,bb);
 return bb;}
// Drop a broken-off fragment so it rests where it actually fell.
//
// These geometries almost never have their origin at their own centre. The
// satellite dish's fallen panel is a patch of a paraboloid whose origin is the
// dish axis — 25 m to one side and 30 m below the panel itself — so no
// hand-picked y could put it on the ground, and it hung in the air. The fuel
// lobes, the government petal and the lab's broken spire had the same trap.
//
// Call it AFTER setting rotation. It measures the rotated piece, centres its
// footprint on the position the builder asked for, and sets the height so its
// lowest point sits just under `groundY` (default 0, the world floor).
function dropFragment(o,groundY,bury){const gy=groundY||0,b=bury===undefined?.4:bury;
 const bb=fragBox(o,new THREE.Matrix4(),new THREE.Box3());
 if(!isFinite(bb.min.y)||!isFinite(bb.min.x))return o;
 o.position.x+=o.position.x-(bb.min.x+bb.max.x)/2;
 o.position.z+=o.position.z-(bb.min.z+bb.max.z)/2;
 o.position.y+=gy-b-bb.min.y;
 return o;}
function arcShape(W,Hh,t,D){ // parabolic (catenary-ish) arch, origin at centre bottom, +z depth centred
 const s=new THREE.Shape();const N=24;const outer=[],inner=[];
 for(let i=0;i<=N;i++){const x=-W/2+W*i/N;outer.push([x,Hh*(1-Math.pow(2*x/W,2))]);}
 const Wi=W-2*t,Hi=Hh-t;for(let i=0;i<=N;i++){const x=-Wi/2+Wi*i/N;inner.push([x,Hi*(1-Math.pow(2*x/Wi,2))]);}
 s.moveTo(outer[0][0],0);outer.forEach(p=>s.lineTo(p[0],p[1]));s.lineTo(W/2,0);s.lineTo(Wi/2,0);
 for(let i=N;i>=0;i--)s.lineTo(inner[i][0],inner[i][1]);s.lineTo(-Wi/2,0);s.lineTo(-W/2,0);
 const g=new THREE.ExtrudeGeometry(s,{depth:D,bevelEnabled:false});g.translate(0,0,-D/2);return g;}
function paraFill(W,Hh,holeW,holeH){ // parabolic wall with an arched opening (ShapeGeometry, in xy plane)
 const s=new THREE.Shape();const N=24;s.moveTo(-W/2,0);for(let i=0;i<=N;i++){const x=-W/2+W*i/N;s.lineTo(x,Hh*(1-Math.pow(2*x/W,2)));}s.lineTo(W/2,0);
 if(holeW){const h=new THREE.Path();h.moveTo(-holeW/2,0);for(let i=0;i<=N;i++){const x=-holeW/2+holeW*i/N;h.lineTo(x,holeH*(1-Math.pow(2*x/holeW,2)));}h.lineTo(holeW/2,0);s.holes.push(h);}
 return new THREE.ShapeGeometry(s);}
function arcWindowGeo(w,h,dep){const s=new THREE.Shape();s.moveTo(-w/2,-h/2);s.lineTo(w/2,-h/2);s.lineTo(w/2,h/2-w/2);s.absarc(0,h/2-w/2,w/2,0,Math.PI,false);s.lineTo(-w/2,-h/2);
 const g=new THREE.ExtrudeGeometry(s,{depth:dep,bevelEnabled:false});g.translate(0,0,-dep/2);return g;}
function hyperGeo(r0,h,k){return lathe({rFn:y=>r0*Math.sqrt(1+k*Math.pow((y-h/2)/(h/2),2)),H:h,nu:24,nv:10});}

// ---------------------------------------------------------------- kit definitions (shared geometry)
kdef('winI',arcWindowGeo(2.2,4.2,.7),MAT.winIntact); kdef('winD',arcWindowGeo(2.2,4.2,.7),MAT.winDead);
kdef('winBigI',arcWindowGeo(3,3.6,.7),MAT.winIntact); kdef('winBigD',arcWindowGeo(3,3.6,.7),MAT.winDead);
kdef('ovalI',new THREE.CylinderGeometry(1,1,.6,14).rotateX(Math.PI/2),MAT.winIntact); kdef('ovalD',new THREE.CylinderGeometry(1,1,.6,14).rotateX(Math.PI/2),MAT.winDead);
kdef('archOpen',arcWindowGeo(6,9,1.2),MAT.dark);
kdef('mullW',new THREE.BoxGeometry(.5,1,.5),MAT.white); kdef('mullR',new THREE.BoxGeometry(.5,1,.5),MAT.rust);
kdef('finW',new THREE.BoxGeometry(1,1,1),MAT.dark);kdef('pierW',new THREE.BoxGeometry(1,1,1),MAT.white);kdef('pierR',new THREE.BoxGeometry(1,1,1),MAT.rust);
kdef('dot',new THREE.BoxGeometry(1.4,.7,.4),MAT.dot);
kdef('strip',new THREE.BoxGeometry(1,.18,.18),MAT.strip);
kdef('colW',hyperGeo(1,1,1.6),MAT.white); kdef('colR',hyperGeo(1,1,1.6),MAT.rust);
// A PLAIN POST. `colW`/`colR` are 480-triangle fluted lathes, which is right
// for a monumental column and ruinous for a stanchion, a railing upright or a
// specimen tank. The Forest Tower already carried a private 32-triangle post
// for exactly this reason, and Dalab's lab fit-out was spending 1.4M triangles
// on three colW per room. Eight sides, 32 triangles, same materials.
kdef('postW',new THREE.CylinderGeometry(1,1,1,8),MAT.white); kdef('postR',new THREE.CylinderGeometry(1,1,1,8),MAT.rust);
kdef('arch',arcShape(16,27,2.2,4),MAT.white); kdef('archR',arcShape(16,27,2.2,4),MAT.rust);
kdef('vaultRib',arcShape(92,56,2.6,3),MAT.white); kdef('vaultRibR',arcShape(92,56,2.6,3),MAT.rust);
kdef('pipe',new THREE.CylinderGeometry(1,1,1,10),MAT.pipe); kdef('pipeR',new THREE.CylinderGeometry(1,1,1,10),MAT.pipeRust);
kdef('slab',new THREE.CylinderGeometry(1,1,1,48),MAT.slab);
// The decorative bands read as a copper/bronze alloy, so their ruined form is
// the one part of the kit that goes verdigris. Everything else rusts. Keeping
// patina off the steel is the whole reason verdigris became its own material.
kdef('ringW',new THREE.TorusGeometry(1,.09,6,40),MAT.white); kdef('ringR',new THREE.TorusGeometry(1,.09,6,40),MAT.verdigris);
kdef('stain',new THREE.PlaneGeometry(1,1),MAT.stain);
// detail 0, not 1: 20 triangles instead of 80. A moss blob is ground cover a
// metre or two across, it is always squashed flat by its instance scale, and
// nothing in the kit ever gets close enough to count its facets. At detail 1
// it was the single heaviest line item in two types.
kdef('moss',new THREE.IcosahedronGeometry(1,0),MAT.moss);

// ---------------------------------------------------------------- THE LEAF CARD
// One shared tree, because four types independently failed to make one.
//
// The kit's canopy has always been a displaced icosahedron — `moss` at detail 1,
// which is EIGHTY triangles for one blob, and `VEG.tree` hangs three or four of
// them off a trunk. That is 240-320 triangles a tree, it is the top budget line
// in two types, and at ten metres it still reads as a bag of marbles, because a
// faceted ball is a faceted ball however you texture it. The Forest Tower and
// the Forest Ring each wrote their own displaced icosahedron and each logged the
// same complaint against it; Arcbeam duplicated the kit default rather than
// reach into a neighbour's fragment. Raising the displacement amplitude was
// tried twice and is not the answer.
//
// The answer is to stop making the silhouette out of geometry. Three quads
// crossed about the vertical axis, plus one laid near-flat for the view from
// above, carry an alpha-mapped leaf mass: EIGHT triangles
// instead of eighty, and the outline comes from the texture's alpha, which can
// be as ragged as a real canopy for free. `alphaTest`, never `transparent` —
// transparent would put every clump into the sorted pass and cost more in draw
// order than it ever saved in triangles.
//
// Normals point OUT FROM THE CENTRE, not along each quad's own face. Face
// normals light the three cards independently and the clump reads as three flat
// sheets; radial normals light it as one soft volume, which is the whole trick.
TEX.leafCard=canvasTex(128,128,(g,w,h)=>{
 g.clearRect(0,0,w,h);                       // alpha 0 outside the leaf mass
 const cx=w/2,cy=h/2;
 for(let i=0;i<150;i++){
  // biased toward the middle so the card has a dense heart and a ragged edge
  const a=Math.random()*TAU,rad=Math.pow(Math.random(),.62)*w*.47;
  const x=cx+Math.cos(a)*rad,y=cy+Math.sin(a)*rad;
  const L=w*(.10-.045*rad/(w*.47));          // leaves shrink toward the fringe
  g.save();g.translate(x,y);g.rotate(Math.random()*TAU);
  const lit=.55+.45*(1-rad/(w*.5));          // a crude self-shading gradient
  g.fillStyle='rgb('+Math.round(48*lit+26)+','+Math.round(104*lit+30)+','+Math.round(38*lit+18)+')';
  g.beginPath();g.ellipse(0,0,L,L*.52,0,0,TAU);g.fill();g.restore();}});
MAT.leafCard=new THREE.MeshStandardMaterial({map:TEX.leafCard,alphaTest:.45,
 roughness:1,metalness:0,side:DS});
function leafCardGeo(){
 const P=[],N=[],U=[],v=new THREE.Vector3();
 // unit RADIUS, matching IcosahedronGeometry(1,n), so this is a drop-in
 // replacement anywhere the kit used to place a `moss` blob
 for(let q=0;q<3;q++){const a=q*Math.PI/3,c=Math.cos(a),s=Math.sin(a);
  const V=[[-c,-1,-s],[c,-1,s],[c,1,s],[-c,-1,-s],[c,1,s],[-c,1,-s]];
  const T=[[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]];
  for(let i=0;i<6;i++){P.push(V[i][0],V[i][1],V[i][2]);
   v.set(V[i][0],V[i][1]*.55,V[i][2]).normalize();N.push(v.x,v.y,v.z);
   U.push(T[i][0],T[i][1]);}}
 // A fourth quad, laid near-flat. Three vertical cards are fine in elevation
 // but from above — off a terrace, or anywhere the camera looks down into a
 // canopy — they present edge-on and the clump reads as a three-pointed star.
 // This one is what the viewer sees from overhead. Two more triangles.
 {const V=[[-1,.34,-1],[1,.34,-1],[1,.1,1],[-1,.34,-1],[1,.1,1],[-1,.1,1]];
  const T=[[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]];
  for(let i=0;i<6;i++){P.push(V[i][0],V[i][1],V[i][2]);
   v.set(V[i][0]*.25,1,V[i][2]*.25).normalize();N.push(v.x,v.y,v.z);
   U.push(T[i][0],T[i][1]);}}
 const g=new THREE.BufferGeometry();
 g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));
 g.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));
 g.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));
 return g;}
kdef('leafCard',leafCardGeo(),MAT.leafCard);
kdef('vine',new THREE.CylinderGeometry(.05,.16,1,5).translate(0,-.5,0),MAT.vine);
kdef('rubble',new THREE.DodecahedronGeometry(1,0),MAT.rubble);
kdef('trunk',new THREE.CylinderGeometry(.18,.4,1,6).translate(0,.5,0),MAT.vine);
kdef('figB',new THREE.CylinderGeometry(.24,.2,1.5,6).translate(0,.75,0),MAT.fig);
kdef('figH',new THREE.SphereGeometry(.13,6,5).translate(0,1.62,0),MAT.fig);
kdef('finial',new THREE.IcosahedronGeometry(1,0),MAT.glass);

// ---------------------------------------------------------------- decoration helpers
function windowsOnLathe(o,d,yFrom,yTo,step,n,gx,gy,gz,big){ // arched windows in flute troughs
 const name=(big?'winBig':'win')+(d>0?'D':'I');
 for(let y=yFrom;y<yTo;y+=step)for(let k=0;k<n;k++){const u=(k+.5)/n;if(o.hole&&o.hole(u,y))continue;if(o.cut!=null&&y>o.cut-4)continue;
  const th=u*TAU,r=o.rFn(y)+.05;kput(name,[gx+r*Math.cos(th),gy+y,gz+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),1,null);}}
// Ring of light-strip segments (all lit intact; few lit in ruin).
//
// TANGENT, not radial. `strip` is a BoxGeometry(1,.18,.18) scaled to [L,1,1],
// so its long axis is local +X — and qEuler(0,-th,0), which every other ring
// helper in this kit uses, points local +X straight OUT along the radius. Each
// segment is `L = arc length per bay` long, so a ring of them laid radially
// renders as a comb of spokes pointing at the camera rather than a line
// following the ring. The tangent is -th-PI/2.
//
// This was found independently by two builders, each of which wrote its own
// private tangential copy rather than touch the shared function (the Forest
// Tower's `TAN`/`lring`, Plymouth's `lring`). Fixing it here changes all 47
// call sites across 32 fragments, which is the point: they were all wrong.
function stripRing(gx,gy,gz,r,d,n){
 n=n||28;const L=TAU*r/n*.92;for(let k=0;k<n;k++){const th=(k+.5)/n*TAU;const lit=d>0?(rng()<.10):true;
  kput('strip',[gx+r*Math.cos(th),gy,gz+r*Math.sin(th)],qEuler(0,-th-Math.PI/2,0),[L,1,1],lit?(d>0&&rng()<.5?CYAN.clone().multiplyScalar(.5):CYAN):DEAD);}}
function mullions(gx,gy,gz,r,h,n,d){for(let k=0;k<n;k++){const th=k/n*TAU;kput(d>0?'mullR':'mullW',[gx+r*Math.cos(th),gy+h/2,gz+r*Math.sin(th)],qEuler(0,-th,0),[1,h,1],null);}}
function glassBand(parent,rFn,y0,h,d,gx,gy,gz,n){ // gallery ring: glass drum (intact) or bare mullions round a dark drum (ruin)
 const o={rFn:y=>rFn(y0+y)*(1.09+.05*Math.sin(Math.PI*y/h)),H:h,nu:48,nv:6};
 if(d===0){mesh(lathe(o),MAT.glass,parent,0,y0,0);}
 mesh(lathe({rFn:y=>rFn(y0+y)*.97,H:h,nu:32,nv:2}),MAT.dark,parent,0,y0,0);
 mullions(gx,gy+y0,gz,rFn(y0+h/2)*1.1,h,n||36,d);
 stripRing(gx,gy+y0+h*.55,gz,rFn(y0+h/2)*.95,d,n||28);
 // ledge slab under the band
 kput('slab',[gx,gy+y0-.4,gz],null,[rFn(y0)*1.16,.8,rFn(y0)*1.16],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));}
function floorSlabs(gx,gy,gz,rFn,y0,y1,step,d,cut){for(let y=y0;y<y1;y+=step){if(cut!=null&&y>cut+3)break;kput('slab',[gx,gy+y,gz],null,[rFn(y)*.93,.5,rFn(y)*.93],new THREE.Color(0x2a2c30));}}
function scatterMoss(gx,gy,gz,rMin,rMax,n,sMax){for(let i=0;i<n;i++){const a=rng()*TAU,r=rr(rMin,rMax);const s=rr(.5,sMax);
 kput('moss',[gx+r*Math.cos(a),gy+s*.25,gz+r*Math.sin(a)],qEuler(0,rng()*TAU,0),[s*rr(.8,1.4),s*.38,s*rr(.8,1.4)],new THREE.Color().setHSL(rr(.22,.32),rr(.3,.5),rr(.05,.12)));}}
function mossOnRing(gx,gy,gz,r,n,sMax){for(let i=0;i<n;i++){const a=rng()*TAU,s=rr(.6,sMax);kput('moss',[gx+r*Math.cos(a)*rr(.85,1.02),gy+s*.2,gz+r*Math.sin(a)*rr(.85,1.02)],null,[s*1.3,s*.4,s*1.3],new THREE.Color().setHSL(rr(.2,.3),rr(.3,.5),rr(.05,.12)));}}
function vinesOnRing(gx,gy,gz,r,n,lMax){for(let i=0;i<n;i++){const a=rng()*TAU,L=rr(4,lMax);kput('vine',[gx+r*Math.cos(a),gy,gz+r*Math.sin(a)],qEuler(rr(-.12,.12),0,rr(-.12,.12)),[rr(.8,1.6),L,rr(.8,1.6)],null);}}
// Rubble piles AGAINST the wall it fell from. The radius is biased hard toward
// rMin, blocks are largest there, and they bank up into a talus slope that
// thins to a scatter at the outer edge. A uniform annulus reads as a decorative
// ring laid round the building, which is exactly what this used to be.
function rubbleRing(gx,gy,gz,rMin,rMax,n,sMax){for(let i=0;i<n;i++){const a=rng()*TAU;
 const q=Math.pow(rng(),2.4);                       // 0 at the wall, 1 at the outer edge
 const r=rMin+(rMax-rMin)*q, s=rr(.6,sMax)*(1.25-.55*q);
 const bank=(1-q)*(1-q)*sMax*.55;
 kput('rubble',[gx+r*Math.cos(a),gy+bank+s*.4,gz+r*Math.sin(a)],qEuler(rng()*3,rng()*3,rng()*3),[s*rr(.7,1.5),s*rr(.5,1),s*rr(.7,1.5)],new THREE.Color().setHSL(rr(.05,.09),rr(.1,.35),rr(.3,.55)));}}

// --- sampling a structure's own surfaces -------------------------------------
// Moss belongs on what faces the sky and vines hang off real ledges, so both
// need to know where a structure's horizontal surfaces actually are. This walks
// the triangles of geometries the builder has already made, keeps the ones
// lying flat, and samples points on them weighted by area.
//
// It tests |ny| rather than ny: these shells are DoubleSide and their winding is
// not reliably outward, so a balcony floor can come back with a downward normal
// while being visibly a floor. The cost is that a true soffit can be sampled
// too, which is rare in these shapes and cheaper than missing every ledge.
// `src` may be a geometry, an array of them, or a whole Object3D — in which
// case it is traversed and each mesh's transform is baked relative to the root,
// so a finished structure can be sampled without the builder handing anything
// over. That is what lets the repaired pass dress all 33 types from one place.
// Keeps faces whose |normal.y| lands in [lo,hi]; returns points and normals.
function faceSamples(src,count,lo,hi){
 const tri=[],cum=[],v=new THREE.Vector3();let tot=0;
 const add=(g,M)=>{const A=g&&g.attributes&&g.attributes.position;if(!A)return;
  const P=A.array,I=g.index?g.index.array:null,nT=I?I.length/3:A.count/3;
  for(let f=0;f<nT;f++){
   const a=(I?I[f*3]:f*3)*3,b=(I?I[f*3+1]:f*3+1)*3,c=(I?I[f*3+2]:f*3+2)*3;
   let ax=P[a],ay=P[a+1],az=P[a+2],bx=P[b],by=P[b+1],bz=P[b+2],cx=P[c],cy=P[c+1],cz=P[c+2];
   if(M){v.set(ax,ay,az).applyMatrix4(M);ax=v.x;ay=v.y;az=v.z;
         v.set(bx,by,bz).applyMatrix4(M);bx=v.x;by=v.y;bz=v.z;
         v.set(cx,cy,cz).applyMatrix4(M);cx=v.x;cy=v.y;cz=v.z;}
   const ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az;
   const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,L=Math.hypot(nx,ny,nz);
   if(!(L>1e-9))continue;const up=Math.abs(ny/L);
   if(up<lo||up>hi)continue;
   tot+=L*.5;tri.push([ax,ay,az,bx,by,bz,cx,cy,cz,nx/L,ny/L,nz/L]);cum.push(tot);}};
 if(src&&src.isObject3D){src.updateMatrixWorld(true);
  const inv=new THREE.Matrix4().copy(src.matrixWorld).invert();
  src.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh)add(o.geometry,new THREE.Matrix4().multiplyMatrices(inv,o.matrixWorld));});}
 else for(const g of (Array.isArray(src)?src:[src]))add(g,null);
 const out=[];if(!(tot>0))return out;
 for(let i=0;i<count;i++){const t=rng()*tot;let a=0,b=cum.length-1;
  while(a<b){const m=(a+b)>>1;if(cum[m]<t)a=m+1;else b=m;}
  const T=tri[a];let u=rng(),w=rng();if(u+w>1){u=1-u;w=1-w;}
  const x=T[0]+u*(T[3]-T[0])+w*(T[6]-T[0]),y=T[1]+u*(T[4]-T[1])+w*(T[7]-T[1]),z=T[2]+u*(T[5]-T[2])+w*(T[8]-T[2]);
  out.push({p:[x,y,z],n:[T[9],T[10],T[11]],r:Math.hypot(x,z)});}
 return out;}
function upFaces(src,count,minNY){return faceSamples(src,count,minNY,1.01);}
// The near-vertical faces: walls. Where patches get riveted on.
function sideFaces(src,count){return faceSamples(src,count,0,.34);}
// The outer band of the flat surfaces is where a ledge is: water leaves the
// building there, so that is where vines root and where stains start.
function ledgePoints(geos,n,frac){const s=upFaces(geos,n*4,.5);if(!s.length)return[];
 s.sort((a,b)=>b.r-a.r);return s.slice(0,Math.max(1,Math.round(s.length*(frac||.3))));}
function mossOnSurface(geos,gx,gy,gz,n,sMax){for(const f of upFaces(geos,n,.55)){const s=rr(.5,sMax);
 kput('moss',[gx+f.p[0],gy+f.p[1]+s*.15,gz+f.p[2]],qEuler(0,rng()*TAU,0),[s*rr(.8,1.5),s*rr(.22,.42),s*rr(.8,1.5)],new THREE.Color().setHSL(rr(.22,.32),rr(.3,.5),rr(.05,.12)));}}
function vinesFromLedge(geos,gx,gy,gz,n,lMax){for(const f of ledgePoints(geos,n,.3)){const L=rr(4,lMax);
 kput('vine',[gx+f.p[0],gy+f.p[1],gz+f.p[2]],qEuler(rr(-.14,.14),rng()*TAU,rr(-.14,.14)),[rr(.8,1.7),L,rr(.8,1.7)],null);}}
// Water-staining below each ledge: a multiply-blended streak, so it darkens
// whatever wall it lands on instead of painting a grey rectangle over it.
function stainsFromLedge(geos,gx,gy,gz,n,lMax){for(const f of ledgePoints(geos,n,.45)){
 const L=rr(5,lMax),a=Math.atan2(f.p[2],f.p[0]),o=1.004;
 kput('stain',[gx+f.p[0]*o,gy+f.p[1]-L*.5,gz+f.p[2]*o],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(1.4,4.5),L,1],null);}}

// VEGETATION HAND-OFF. The Krator flora pass is a separate project and will
// replace VEG.tree wholesale; everything in this kit that plants anything goes
// through it, so that swap is one assignment and touches no builder.
// y is the ground height at (x,z) — ask terrainH, do not assume 0.
// The hand-off point for flora. Every planting call in the kit goes through
// this, so changing it changes the forest everywhere at once — which is the
// point: see the LEAF CARD note in 34-kitdefs.js for why the four-icosahedra
// version had to go. Trunk + two or three crossed leaf cards is 36-42 triangles
// against the old 240-320, and it reads as foliage at eye level instead of as a
// bag of marbles. `species` picks the habit: odd is a narrow spire, even a
// broad dome, so a scatter of `i%3` gives a mixed stand rather than one tree
// repeated.
const VEG={
 tree(x,y,z,species,h){
  const spire=!!(species%2);
  kput('trunk',[x,y,z],null,[h*.20,h*(spire?.74:.62),h*.20],null);
  const n=spire?2:3;
  for(let k=0;k<n;k++){
   const s=h*(spire?rr(.22,.32):rr(.30,.44))*(1-k*.13);
   kput('leafCard',[x+rr(-.13,.13)*h,y+h*((spire?.66:.58)+k*.15),z+rr(-.13,.13)*h],
    qEuler(rr(-.07,.07),rng()*TAU,rr(-.07,.07)),
    [s,s*(spire?rr(1.0,1.35):rr(.70,.95)),s],
    // The instance colour MULTIPLIES an already mid-green sRGB map, so the two
   // compound: .15-.30 lightness — the value the old icosahedra used against
   // no texture at all — came back as near-black shrubs.
   new THREE.Color().setHSL(rr(.22,.34),rr(.30,.52),rr(.40,.68)));}},
};
function trees(gx,gz,rMin,rMax,n){for(let i=0;i<n;i++){const a=rng()*TAU,r=rr(rMin,rMax),h=rr(6,14);
 const x=gx+r*Math.cos(a),z=gz+r*Math.sin(a);VEG.tree(x,terrainH(x,z),z,i%3,h);}}
// APRON. Every structure meets the ground on a hard line without one. This lays
// a graded skirt from the foot of the mass out to the ground, so the two blend.
// cx,cz are local to the builder's group, like everything else a builder does.
function apron(parent,cx,cz,rIn,rOut,d,hIn){
 const wx=KOFF[0]+cx,wz=KOFF[2]+cz;
 mesh(gridSurface((u,v)=>{const th=u*TAU,r=lerp(rIn,rOut,v)*(1+.07*fbm(u*7,1.3,17,2));
  const x=r*Math.cos(th),z=r*Math.sin(th);
  return[x,lerp(hIn,0,Math.pow(v,.6))+terrainH(wx+x,wz+z),z];},64,6,{uS:rIn/6,vS:3}),
  d>0?MAT.mud:MAT.rock,parent,cx,0,cz);}
function figures(gx,gz,n,spread){for(let i=0;i<n;i++){const x=gx+rr(-spread,spread),z=gz+rr(-spread,spread);const c=new THREE.Color().setHSL(rr(0,.1),rr(.2,.5),rr(.25,.5));
 kput('figB',[x,0,z],qEuler(0,rng()*TAU,0),1,c);kput('figH',[x,0,z],null,1,new THREE.Color(0xc9a17e));}}
function stats(){}

// ---------------------------------------------------------------- v2 helpers
kdef('strutW',new THREE.BoxGeometry(1,1,1),MAT.white); kdef('strutR',new THREE.BoxGeometry(1,1,1),MAT.rust);
kdef('cell',new THREE.BoxGeometry(1,1,.5),MAT.dot);
kdef('winSmI',arcWindowGeo(1.1,2,.4),MAT.winIntact); kdef('winSmD',arcWindowGeo(1.1,2,.4),MAT.winDead);
function beam(name,a,b,w,dp,color){const dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2];const L=Math.sqrt(dx*dx+dy*dy+dz*dz);
 const q=new THREE.Quaternion().setFromUnitVectors(_UP,new THREE.Vector3(dx,dy,dz).normalize());kput(name,[(a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2],q,[w,L,dp],color||null);}
function hexR(R,th){const a=R*Math.cos(Math.PI/6);const f=((th%(Math.PI/3))+Math.PI/3)%(Math.PI/3);return a/Math.cos(f-Math.PI/6);}
// petal shell: base on +x at radius Rb, rises Hp, tip leans outward by `lean`, cupped by `curl`
function petalGeo(Rb,Hp,W,lean,curl,hole){return gridSurface((u,v)=>{const s=u*2-1;const w=W*(.3+.7*Math.sin(Math.PI*Math.pow(v,.9)))*.5;
 const x=Rb+lean*v-curl*s*s*w;return[x,Hp*v,s*w];},14,22,{uS:2,vS:4,hole});}
function petalRing(parent,n,Rb,Hp,W,lean,curl,y,d,seed,mat,skipFn){for(let i=0;i<n;i++){if(skipFn&&skipFn(i))continue;const g=petalGeo(Rb,Hp,W,lean,curl,d>0?(u,v)=>fbm(u*3+i,v*5,seed+i,2)<.3*d:null);
 const m=mesh(g,mat,parent,0,y,0);m.rotation.y=-i/n*TAU;}}
// Luce-style hypar shell pair: two warped sheets leaning together over a glass gable
function luceShells(parent,xc,zc,Wb,Hs,Dd,d,seed,skin){[-1,1].forEach(side=>{const g=gridSurface((u,v)=>{const x=xc+(u-.5)*Wb*(1-.55*v);const z=zc+side*(Dd*(1-v)*(1-.35*Math.pow(u-.5,2)*4)+.6*(1-v)+.5*v);return[x,Hs*v*(1-.15*Math.pow((u-.5)*2,2)),z];},20,16,{uS:4,vS:3,hole:holeFn(d*.7,seed+side,null,2)});
 mesh(g,skin,parent);});
 if(d===0){const s=new THREE.Shape();s.moveTo(-Wb/2,0);s.lineTo(Wb/2,0);s.lineTo(0,Hs*.98);s.lineTo(-Wb/2,0);const gl=mesh(new THREE.ShapeGeometry(s),MAT.glass,parent,xc,0,zc+.2);}
 kput('archOpen',[xc,3,zc-Dd*.05],qFacing([0,0,1]),[.45,.45,1],null);}
function ribCurveGeo(pts,r){return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p=>new THREE.Vector3(p[0],p[1],0))),28,r,8,false);}

// ================================================================= factory additions (called from buildFactory)
function factoryExtras(G,d,skin){
 // three lattice cooling hyperboloids (Babel skins) west of the hall
 [[-150,40],[-150,95],[-105,95]].forEach((p,i)=>{const Hc=70,cut=d>0&&i===1?Hc*.42:null;
  const lat=(u,y)=>{const a=u*TAU*10,b=y*.28;return Math.abs(Math.sin(a+b))>.28&&Math.abs(Math.sin(a-b))>.28;};
  const hole=(u,y)=>lat(u,y)||(d>0&&fbm(u*4,y*.05,60+i,2)<.3*d);
  const rFn=y=>13+9*Math.pow(Math.abs(y/Hc-.6)/.6,1.6);
  mesh(lathe({rFn,H:Hc,cut,jag:cut?4:0,nu:80,nv:40,hole,seed:60+i}),skin,G,p[0],6,p[1]);
  mesh(lathe({rFn:y=>rFn(y)*.88,H:Hc,cut,jag:cut?4:0,nu:32,nv:6,seed:60+i}),MAT.dark,G,p[0],6,p[1]);
  kput(d>0?'ringR':'ringW',[p[0],6+(cut||Hc),p[1]],qEuler(Math.PI/2,0,0),[rFn(cut||Hc)*1.02,rFn(cut||Hc)*1.02,10],null);
  for(let k=0;k<3;k++){const th=k/3*TAU+.3;kput(d>0?'pipeR':'pipe',[p[0]+rFn(0)*.7*Math.cos(th),6,p[1]+rFn(0)*.7*Math.sin(th)],null,[1.2,10,1.2],null);}
  if(cut)rubbleRing(p[0],6,p[1],10,30,60,2.5);});
 // pipe rack from the cooling towers to the hall
 for(let i=0;i<5;i++){const z=30+i*4;kput(d>0?'pipeR':'pipe',[-118,15+i%2*3,z],qEuler(0,0,Math.PI/2),[.9,60,.9],null);}
 for(let x=-140;x<=-95;x+=15)for(let i=0;i<2;i++)kput(d>0?'colR':'colW',[x,6,26+i*20],null,[1,10,1],null);
 kput(d>0?'strutR':'strutW',[-118,16.5,38],null,[50,.6,26],null);
 // tank farm + gantry crane east of the silos
 for(let i=0;i<6;i++){const tx=135+(i%2)*32,tz=10+Math.floor(i/2)*34;const R=11;const gone=d>0&&i===3;
  for(let k=0;k<4;k++){const th=(k+.5)*Math.PI/2;kput(d>0?'colR':'colW',[tx+7*Math.cos(th),6,tz+7*Math.sin(th)],null,[1.2,9,1.2],null);}
  if(!gone)mesh(lathe({rFn:y=>R*Math.sqrt(clamp(1-Math.pow((y-R)/R,2),0,1))+.01,H:2*R,nu:32,nv:14,hole:holeFn(d*.8,70+i,null,2)}),skin,G,tx,15-R*.15,tz);
  else{const fm=mesh(lathe({rFn:y=>R*Math.sqrt(clamp(1-Math.pow((y-R)/R,2),0,1))+.01,H:2*R,nu:32,nv:14,hole:holeFn(1,70+i,null,1.5)}),MAT.rust,G,tx+9,6,tz+6);fm.rotation.set(0.6,0,1.2);dropFragment(fm);}
  kput(d>0?'pipeR':'pipe',[tx,15,tz-R-2],qEuler(Math.PI/2,0,0),[.8,8,.8],null);}
 kput(d>0?'pipeR':'pipe',[150,10,-10],qEuler(0,0,Math.PI/2),[1,90,1],null);kput(d>0?'pipeR':'pipe',[105,10,0],qEuler(Math.PI/2,0,0),[1,60,1],null);
 [[112,-8],[112,96],[184,-8],[184,96]].forEach(p=>{beam(d>0?'strutR':'strutW',[p[0]-6,6,p[1]],[p[0],52,p[1]],3,3);beam(d>0?'strutR':'strutW',[p[0]+6,6,p[1]],[p[0],52,p[1]],3,3);});
 [-8,96].forEach(z=>kput(d>0?'strutR':'strutW',[148,53,z],null,[84,3.5,4],null));
 const cz=d>0?70:30;kput(d>0?'strutR':'strutW',[148,55.5,cz],null,[6,3,110],null);kput(d>0?'strutR':'strutW',[d>0?128:160,53,cz],null,[8,5,8],null);
 factorySilo(G,d,skin);
 // twin hypar furnace shells on the south apron
 luceShells(G,-40,96,60,42,24,d,90,skin);
 if(d>0)rubbleRing(-40,6,96,20,40,40,2.5);}

// ================================================================= OFFICES (two variants)
function buildOffices(scene,gx,gz,d){reseed(d>0?9501:9500);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 // A — flared ring (Tange mushroom)
 {REGISTER({name:'Office A — flared ring ('+STATE(d)+')',x:0,z:0,r:55,h:42});const stem=y=>y<12?11+.04*Math.pow(12-y,2):(y<21?11+32*Math.pow((y-12)/9,1.6):43);
  mesh(lathe({rFn:stem,H:32,nu:72,nv:32,hole:holeFn(d*.7,201,null,1.4)}),skin,G);
  if(d>0)mesh(lathe({rFn:y=>stem(y)*.92,H:32,nu:32,nv:6}),MAT.dark,G);
  for(let k=0;k<32;k++){const th=k/32*TAU;if(d>0&&rng()<.35)continue;beam(d>0?'strutR':'strutW',[Math.cos(th)*20,20,Math.sin(th)*20],[Math.cos(th)*45,40,Math.sin(th)*45],2.6,2);
   for(let r=0;r<2;r++){const rr0=43.7;const t2=th+.1;kput(d>0?'winSmD':'winSmI',[Math.cos(t2)*rr0,25+r*5,Math.sin(t2)*rr0],qFacing([Math.cos(t2),0,Math.sin(t2)]),[5.5,2,1],null);}}
  kput('slab',[0,38.5,0],null,[44,1.2,44],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));stripRing(0,30,0,41,d,48);stripRing(0,35,0,41,d,48);
  for(let k=0;k<20;k++){const th=k/20*TAU;if(d>0&&rng()<.2)continue;kput(d>0?'colR':'colW',[Math.cos(th)*36,0,Math.sin(th)*36],null,[1.4,19,1.4],null);}
  mesh(lathe({rFn:()=>52,H:1.2,nu:64,nv:1}),skin,G);kput('slab',[0,1.2,0],null,[52,.4,52],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  kput('archOpen',[11.5,4.8,0],qFacing([1,0,0]),[.6,.6,1],null);
  if(d>0){mossOnRing(0,1.6,0,48,50,2);vinesOnRing(0,38,0,44,30,18);rubbleRing(0,1.2,0,14,50,30,2);}}
 // B — lobed tower (Marina / Hilliard scallops)
 {const bx=190;REGISTER({name:'Office B — lobed tower ('+STATE(d)+')',x:bx,z:0,r:20,h:60});const B=new THREE.Group();B.position.set(bx,0,0);G.add(B);const R=13,H=52,cut=d>0?H*.72:null;
  const lobe=th=>R*(1+.32*(.5+.5*Math.cos(8*th)));
  mesh(lathe({rFn:()=>6,H:12,nu:24,nv:2}),skin,B);for(let k=0;k<16;k++){const th=k/16*TAU;if(d>0&&(k===4||k===11))continue;kput(d>0?'colR':'colW',[bx+Math.cos(th)*13.5,0,Math.sin(th)*13.5],null,[1.3,12,1.3],null);}
  const hole=holeFn(d,210,cut,1.8);
  mesh(lathe({rFn:()=>R,H:H-12,cut:cut?cut-12:null,jag:cut?3:0,flutes:8,amp:.32,sharp:1,nu:96,nv:40,hole,seed:210}),skin,B,0,12,0);
  if(d>0){mesh(lathe({rFn:()=>R*.88,H:H-12,cut:cut-12,jag:3,nu:32,nv:6,seed:210}),MAT.guts,B,0,12,0);floorSlabs(bx,12,0,()=>R*.95,4,(cut||H)-12,4,d,cut?cut-12:null);}
  const bBands=[];   // ten storeys of lobed banding in one mesh
  for(let s=0;s<Math.floor(((cut||H)-12)/4);s++){const y=12+s*4;
   const bh=d>0?(u,v)=>fbm(u*10+s,2,211+s,2)<.24*d:null;
   bBands.push(lathe({rFn:()=>R*1.09,H:1,flutes:8,amp:.34,sharp:1,nu:96,nv:1,hole:bh}).translate(0,y+3,0));
   bBands.push(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(lobe(th)*.97,lobe(th)*1.09,v);return[r*Math.cos(th),y+3.9,r*Math.sin(th)];},96,2,{hole:bh}));
   for(let k=0;k<8;k++)for(let j=-1;j<=1;j+=2){const th=k/8*TAU+j*.16;const u=((th%TAU)+TAU)%TAU/TAU;if(hole&&hole(u,y-12))continue;const r=lobe(th)+.1;
    kput(d>0?'winSmD':'winSmI',[bx+r*Math.cos(th),y+1.9,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1.9,1.5,1],null);}
   if(s%3===0)stripRing(bx,y+2.5,0,R*.85,d,24);}
  meshMerged(bBands,skin,B);
  if(!cut){kput('slab',[bx,H+.2,0],null,[R*1.1,.6,R*1.1],new THREE.Color(0xd8d4cc));mesh(lathe({rFn:y=>7*Math.sqrt(clamp(1-Math.pow(y/6,2),0,1)),H:6,nu:24,nv:6}),skin,B,0,H+.5,0);}
  else{rubbleRing(bx,0,0,15,40,60,2.5);mossOnRing(bx,cut,0,R,10,1.5);}
  if(d>0){vinesOnRing(bx,12,0,R*1.05,20,10);scatterMoss(bx,0,0,15,45,40,2);}}
 officeC(G,d);figures(60,50,5,5);figures(190,22,3,3);KOFF=[0,0,0];return G;}

// ================================================================= MILITARY BUNKER — "the Redoubt"
function buildBunker(scene,gx,gz,d){reseed(d>0?9701:9700);KOFF=[gx,0,gz];REGISTER({name:'Bunker — the Redoubt ('+STATE(d)+')',x:0,z:0,r:90,h:60});const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 // earth berm (hex), cyclopean hex mass, casemates
 const berm=lathe({rFn:y=>78-2.2*y,H:10,nu:6,nv:2});mesh(berm,MAT.mud,G);kput('slab',[0,10,0],null,[56,.4,56],new THREE.Color(0x7a4a34));
 const R0=54,R1=46,HM=16;const hole=holeFn(d*.9,400,null,1.2);
 mesh(lathe({rFn:y=>R0-(R0-R1)*y/HM,H:HM,nu:6,nv:8,hole:(u,y)=>hole&&hole(u,y)&&(u>.62&&u<.85)}),skin,G,0,10,0);
 if(d>0)mesh(lathe({rFn:y=>(R0-(R0-R1)*y/HM)*.9,H:HM,nu:6,nv:2}),MAT.guts,G,0,10,0);
 kput('slab',[0,26,0],null,[R1*.98,.8,R1*.98],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
 for(let f=0;f<6;f++){const fa=f/6*TAU+Math.PI/6;const n=[Math.cos(fa),0,Math.sin(fa)];const tang=[-n[2],0,n[0]];
  for(let k=-1;k<=1;k++){const y=20;const rr0=hexR(R0-(R0-R1)*(y-10)/HM,fa)+.3;const px=n[0]*rr0+tang[0]*k*13,pz=n[2]*rr0+tang[2]*k*13;
   kput('finW',[px,y,pz],qFacing(n),[6,1.8,1.6],null);}
  // cliff-face sawtooth ribs (Soleri)
  for(let k=-2;k<=2;k++){const rr0=hexR(R0,fa)+1.2;const px=n[0]*rr0+tang[0]*k*9.5,pz=n[2]*rr0+tang[2]*k*9.5;
   if(d>0&&rng()<.25)continue;beam(d>0?'strutR':'strutW',[px,10,pz],[px-n[0]*7,10+HM,pz-n[2]*7],3,2.5);}}
 // gate + ramp on face 0 (facing +z)
 const ga=Math.PI/2;kput('archOpen',[Math.cos(ga)*(hexR(R0,ga)-1),15,Math.sin(ga)*(hexR(R0,ga)-1)],qFacing([Math.cos(ga),0,Math.sin(ga)]),[1.6,1.6,4],null);
 kput(d>0?'strutR':'strutW',[0,5,hexR(R0,ga)+22],qEuler(-.2,0,0),[14,1.5,44],null);
 // observation cupola + gun-bay portico of leaning struts + petal sensor clusters
 const CH=22,ccut=d>0?CH*.6:null;
 mesh(lathe({rFn:y=>5*Math.sqrt(1+1.6*Math.pow((y-CH*.55)/(CH*.55),2))+(y>CH-6?7*Math.pow((y-(CH-6))/6,1.5):0),H:CH,cut:ccut,jag:ccut?2:0,nu:36,nv:20,hole:holeFn(d*.7,410,ccut,1.5)}),skin,G,0,26,0);
 if(!ccut){kput('slab',[0,26+CH,0],null,[13,1,13],new THREE.Color(0xd8d4cc));stripRing(0,26+CH-2.5,0,11,d,24);for(let k=0;k<8;k++){const th=k/8*TAU;kput('finW',[Math.cos(th)*12.3,26+CH-3,Math.sin(th)*12.3],qEuler(0,-th,0),[5,1.4,1],null);}}
 for(let k=0;k<5;k++){const th=(k/5)*TAU+.9;const fallen=d>0&&(k===1||k===3);
  const a=[Math.cos(th)*38,26.4,Math.sin(th)*38],b=[Math.cos(th)*9,26+CH*(ccut?.5:.85),Math.sin(th)*9];
  if(!fallen)beam(d>0?'strutR':'strutW',a,b,3.2,2.4);else beam('strutR',[a[0],27.6,a[2]],[a[0]*.3+rr(-6,6),28,a[2]*.3+rr(-6,6)],3.2,2.4);}
 if(!ccut){kput('slab',[0,26+CH+.6,0],null,[22,1.2,22],new THREE.Color(0xd8d4cc));aaBattery(G,d,0,26+CH+1.2,0,2.6);}else{aaBattery(G,d,0,26+ccut-2,0,2.6);}
 aaBattery(G,d,26,26.4,-24,3.2);aaBattery(G,d,-30,26.4,-10,3.2);
 if(d>0){mossOnRing(0,10.4,0,50,60,2.5);mossOnRing(0,26.3,0,30,30,2);vinesOnRing(0,26,0,R1*1.02,30,12);rubbleRing(0,10,0,50,72,60,2.5);trees(0,0,90,150,14);}
 figures(0,110,6,8);KOFF=[0,0,0];return G;}

// ================================================================= LIBRARY — "the Crown"
function buildLibrary(scene,gx,gz,d){reseed(d>0?9801:9800);KOFF=[gx,0,gz];REGISTER({name:'Library — the Crown ('+STATE(d)+')',x:0,z:0,r:60,h:65});REGISTER({name:'Library — reading hall',x:74,z:0,r:22,h:16});const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 mesh(lathe({rFn:()=>42,H:2,nu:80,nv:1}),skin,G);kput('slab',[0,2,0],null,[42,.5,42],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
 const pts=[[34,0],[27,12],[19,25],[15.5,34],[17.5,42],[23,50],[27,54]];
 kdef('ribLib'+(d>0?'R':'W'),ribCurveGeo(pts,1.5),d>0?MAT.rust:MAT.white);
 const NR=16;for(let k=0;k<NR;k++){const th=k/NR*TAU;const fallen=d>0&&(k===2||k===3||k===9||k===13);
  if(!fallen)kput('ribLib'+(d>0?'R':'W'),[0,2,0],qEuler(0,-th,0),1,null);
  else{kput('ribLib'+(d>0?'R':'W'),[Math.cos(th)*60,1.4,Math.sin(th)*60],qEuler(Math.PI/2,0,-th),[.9,.9,.9],null);rubbleRing(Math.cos(th)*45,2,Math.sin(th)*45,3,16,30,1.8);}}
 const rib=y=>{for(let i=1;i<pts.length;i++)if(y<=pts[i][1]){const t=(y-pts[i-1][1])/(pts[i][1]-pts[i-1][1]);return lerp(pts[i-1][0],pts[i][0],t);}return pts[pts.length-1][0];};
 if(d===0)mesh(lathe({rFn:y=>rib(y)-1.6,H:44,nu:64,nv:30}),MAT.glass,G,0,2,0);
 else mesh(lathe({rFn:y=>rib(y)-1.8,H:44,nu:48,nv:20,hole:(u,y)=>fbm(u*4,y*.06,500,2)<.55}),MAT.dark,G,0,2,0);
 kput(d>0?'ringR':'ringW',[0,36,0],qEuler(Math.PI/2,0,0),[16,16,10],null);
 kput('slab',[0,2.3,0],null,[30,.6,30],new THREE.Color(0x2a2c30));stripRing(0,6,0,28,d,40);stripRing(0,20,0,18,d,32);
 if(d===0)kput('finial',[0,60,0],null,[3,6,3],null);
 // reading-hall wing: low six-lobed block with arched windows, joined by a covered walk
 const wx=74;mesh(lathe({rFn:()=>15,H:9,flutes:6,amp:.35,sharp:1,nu:72,nv:6,hole:holeFn(d,510,null,2)}),skin,G,wx,0,0);
 if(d>0)mesh(lathe({rFn:()=>13,H:9,nu:24,nv:1}),MAT.dark,G,wx,0,0);
 kput('slab',[wx,9.2,0],null,[15.5,.5,15.5],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));mesh(lathe({rFn:y=>16*Math.sqrt(clamp(1-Math.pow(y/5,2),0,1)),H:5,flutes:6,amp:.3,sharp:1,nu:72,nv:6,hole:holeFn(d*.8,511,null,2)}),skin,G,wx,9.4,0);
 for(let k=0;k<12;k++){const th=(k+.5)/12*TAU;const r=15*(1+.35*(.5+.5*Math.cos(6*th)))+.1;kput(d>0?'winBigD':'winBigI',[wx+r*Math.cos(th),4.5,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.8,.9,1],null);}
 for(let x=44;x<58;x+=6)for(let s=-1;s<=1;s+=2)kput(d>0?'colR':'colW',[x,2,s*4],null,[.7,5,.7],null);
 mesh(gridSurface((u,v)=>[42+u*18,7.2+.4*Math.sin(u*9),(v-.5)*10],16,4,{hole:d>0?(u,v)=>fbm(u*5,v*2,520,2)<.35:null}),skin,G);
 kput('archOpen',[34.5,4,0],qFacing([1,0,0]),[.5,.5,1],null);
 if(d>0){mossOnRing(0,2.4,0,36,40,2);scatterMoss(0,0,0,44,110,90,2);trees(0,0,60,120,12);vinesOnRing(0,36,0,16,12,20);}
 figures(0,60,6,8);KOFF=[0,0,0];return G;}

// ---------------------------------------------------------------- v3: inspector registry + group transforms
const REG=[];function REGISTER(o){REG.push({name:o.name,x:o.x+KOFF[0],y:o.y||0,z:o.z+KOFF[2],r:o.r,h:o.h});}
function useGroupXF(P){P.updateMatrix();KXF={m:P.matrix.clone(),q:P.quaternion.clone()};}
function endGroupXF(){KXF=null;}
kdef('tube',new THREE.CylinderGeometry(1,1,1,8),MAT.dark);
kdef('boxD',new THREE.BoxGeometry(1,1,1),MAT.dark);
kdef('boxW',new THREE.BoxGeometry(1,1,1),MAT.white);kdef('boxR',new THREE.BoxGeometry(1,1,1),MAT.rust);
const STATE=d=>d===3?'repaired':d>0?'ruined':'intact';

// ================================================================= SKYSCRAPERS — three variants, d: 0 intact, 1 ruined, 2 toppled
// each variant = plinth(G,d) + body(P,d,y0,y1) in local coords (local y=0 ⇔ absolute y0)
// `dir` is which way the upper body goes down: +1 (default) east, -1 west. It
// matters when a tower shares its plinth with something else — Skyscraper G's
// drum used to fall straight into its own block stack.
function toppledUpper(G,cx,cz,hc,r0,bodyFn,d,dir){const s=dir===-1?-1:1;const U=new THREE.Group();const ang=rr(-.5,.5);
 U.position.set(cx+s*Math.cos(ang)*(r0*1.6),r0*.82,cz+s*Math.sin(ang)*(r0*1.6));U.rotation.set(0,-ang,-s*Math.PI/2*.94);G.add(U);useGroupXF(U);bodyFn(U,1,hc,null,true);endGroupXF();
 rubbleRing(cx+s*Math.cos(ang)*(r0*2),0,cz+s*Math.sin(ang)*(r0*2),r0*.5,r0*3,140,3.5);}
function skyPlinth(G,d,R){mesh(lathe({rFn:()=>R,H:5,nu:96,nv:1}),SHELL(d),G);kput('slab',[0,5,0],null,[R,.6,R],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
 for(let k=0;k<48;k++){const th=k/48*TAU,r=R*.93;if(d>0&&rng()<.2)continue;kput(d>0?'colR':'colW',[r*Math.cos(th),5,r*Math.sin(th)],null,[1.8,12,1.8],null);}
 kput(d>0?'ringR':'ringW',[0,17.3,0],qEuler(Math.PI/2,0,0),[R*.94,R*.94,8],null);
 apron(G,0,0,R*1.02,R*1.5,d,1.4);   // graded skirt: the plinth met the ground on a hard line
 if(d>0){mossOnRing(0,5.3,0,R*.85,120,3);vinesOnRing(0,17.3,0,R*.94,40,14);scatterMoss(0,0,0,R+2,R+100,220,3.5);rubbleRing(0,0,0,R+2,R+80,120,3);trees(0,0,R+30,R+160,30);}}
// --- A: the Conocylinder (Soleri Babel IID) ---------------------------------------------------
function buildSkyA(scene,gx,gz,d){reseed(9100+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const dd=d>0?1:0;const skin=SHELL(dd);
 const H=420,Y0=64;const rFn=y=>{const t=clamp((y-Y0)/(H-Y0),0,1);return 40+26*Math.pow(Math.abs(t-.42)/.58,1.7)*(t<.42?1:1.15);};
 REGISTER({name:'Skyscraper A — the Conocylinder ('+(d===2?'toppled':STATE(d))+')',x:0,z:0,r:130,h:H+60});
 skyPlinth(G,dd,120);
 mesh(lathe({rFn:y=>22-4*y/Y0,H:Y0,nu:48,nv:6,hole:holeFn(dd*.5,3,null,1.5)}),skin,G,0,5,0);
 const NS=24;for(let k=0;k<NS;k++){const th=(k+.5)/NS*TAU;const gone=dd>0&&(k===5||k===13||k===19);
  const a=[Math.cos(th)*98,5,Math.sin(th)*98],b=[Math.cos(th)*rFn(Y0)*.96,Y0+6,Math.sin(th)*rFn(Y0)*.96];
  if(!gone)beam(dd>0?'strutR':'strutW',a,b,5.5,4);else{beam('strutR',[a[0],2.6,a[2]],[(a[0]+b[0])/2+rr(-8,8),3.2,(a[2]+b[2])/2+rr(-8,8)],5.5,4);}
  kput(dd>0?'strutR':'strutW',[b[0],b[1]-3,b[2]],qEuler(0,-th,0),[7,9,6],null);}
 kput('slab',[0,Y0+1,0],null,[rFn(Y0)*.97,3,rFn(Y0)*.97],new THREE.Color(dd>0?0x4a3f38:0xcfcac2));kput(dd>0?'ringR':'ringW',[0,Y0+3,0],qEuler(Math.PI/2,0,0),[rFn(Y0),rFn(Y0),10],null);
 const body=(P,dx,y0,y1,upper)=>{const top=y1!=null?y1:H;const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*.86:null);const L=(cut!=null?cut:H)-y0;const hole=holeFn(dx,7+(upper?1:0),cut!=null?L:null,1.1);
  const oo={rFn:y=>rFn(y+y0),H:H-y0,cut:cut!=null?L:null,jag:cut!=null?10:0,flutes:32,amp:.07,sharp:2.5,nu:160,nv:110,hole,seed:7};
  mesh(lathe(oo),SHELL(dx),P,0,0,0);
  if(dx>0){mesh(lathe({rFn:y=>rFn(y+y0)*.9,H:H-y0,cut:oo.cut,jag:oo.jag,nu:64,nv:40,seed:7}),MAT.guts,P);for(let y=8;y<L-2;y+=8)kput('slab',[0,y,0],null,[rFn(y+y0)*.93,.5,rFn(y+y0)*.93],new THREE.Color(0x2a2c30));
   for(let k=0;k<60;k++){const th=rng()*TAU,yy=rr(10,L-10),r=rFn(yy+y0)*.86;kput('pipeR',[r*Math.cos(th),yy,r*Math.sin(th)],null,[.5,rr(8,30),.5],null);}}
  for(let y=6;y<L-14;y+=4.2){for(let k=0;k<32;k++){const u=(k+.5)/32;if(hole&&hole(u,y))continue;if(rng()<.1)continue;const th=u*TAU,r=rFn(y+y0)+.1;
   const lit=dx>0?rng()<.03:rng()<.85;kput('cell',[r*Math.cos(th),y,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[2.8,2.3,1],lit?WARM.clone().multiplyScalar(rr(.5,1)):(dx>0?DEAD:new THREE.Color(0x14283c)));}}
  for(let yy=25;yy<L-20;yy+=25)stripRing(0,yy,0,rFn(yy+y0)*.9,dx,32);
  [.3,.62].forEach(f=>{const ya=Y0+(H-Y0)*f;const yl=ya-y0;if(yl<8||yl>L-10)return;glassBand(P,y=>rFn(y+y0),yl,7,dx,0,0,0,48);});
  if(cut==null){const NR=32;for(let k=0;k<NR;k++){const th=k/NR*TAU;const r0=rFn(H)*1.02;beam(dx>0?'strutR':'strutW',[Math.cos(th)*r0,L-6,Math.sin(th)*r0],[Math.cos(th)*(r0+25),L-6+41,Math.sin(th)*(r0+25)],3.2,2.4);}
   if(dx===0){mesh(lathe({rFn:y=>rFn(H)*(1+.35*y/40)*(1-.15*Math.pow(y/40,3)),H:40,nu:64,nv:12}),MAT.glass,P,0,L-4,0);mesh(lathe({rFn:y=>12*Math.sqrt(clamp(1-Math.pow(y/16,2),0,1)),H:16,nu:32,nv:8}),SHELL(dx),P,0,L+34,0);kput('finial',[0,L+56,0],null,[5,9,5],null);}}
  else if(!upper){for(let k=0;k<32;k++){const th=k/32*TAU;if(rng()<.5)continue;beam('strutR',[Math.cos(th)*rFn(cut)*1.02,L-6,Math.sin(th)*rFn(cut)*1.02],[Math.cos(th)*rFn(cut)*1.3,L-6+rr(8,26),Math.sin(th)*rFn(cut)*1.3],3.2,2.4);}}};
 const P=new THREE.Group();P.position.set(0,Y0,0);G.add(P);useGroupXF(P);
 if(d<2)body(P,dd,Y0,null,false);else body(P,1,Y0,Y0+70,false);endGroupXF();
 if(d===2)toppledUpper(G,0,0,Y0+70,rFn(Y0+70),(U,dx,y0)=>body(U,1,Y0+70,null,true),d);
 if(dd>0)vinesOnRing(0,Y0,0,rFn(Y0)*.98,60,40);
 figures(-110,140,7,6);KOFF=[0,0,0];return G;}
// --- B: the Scallop Stack (Goldberg lobes, widening upward) -------------------------------------
function buildSkyB(scene,gx,gz,d){reseed(9110+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const dd=d>0?1:0;const skin=SHELL(dd);
 const H=300,NL=12;const rFn=y=>26+10*Math.pow(clamp(y/H,0,1),1.4);const lobe=(th,y)=>rFn(y)*(1+.3*(.5+.5*Math.cos(NL*th)));
 REGISTER({name:'Skyscraper B — the Scallop Stack ('+(d===2?'toppled':STATE(d))+')',x:0,z:0,r:120,h:H+40});
 skyPlinth(G,dd,110);
 // core + 12 lobed legs spreading out to the plinth
 mesh(lathe({rFn:y=>16,H:30,nu:32,nv:2}),skin,G,0,5,0);
 for(let k=0;k<NL;k++){const th=k/NL*TAU;const gone=dd>0&&(k===3||k===8);const a=[Math.cos(th)*70,5,Math.sin(th)*70],b=[Math.cos(th)*rFn(30)*1.15,32,Math.sin(th)*rFn(30)*1.15];
  if(!gone){kput(dd>0?'colR':'colW',[a[0],5,a[2]],null,[4.5,27,4.5],null);beam(dd>0?'strutR':'strutW',[a[0],31,a[2]],b,5,4);}else rubbleRing(a[0],5,a[2],2,16,30,2.2);}
 const body=(P,dx,y0,y1,upper)=>{const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*.8:null);const L=(cut!=null?cut:H)-y0;const hole=holeFn(dx,17+(upper?1:0),cut!=null?L:null,1.5);
  mesh(lathe({rFn:y=>rFn(y+y0),H:H-y0,cut:cut!=null?L:null,jag:cut?4:0,flutes:NL,amp:.3,sharp:1,nu:144,nv:60,hole,seed:17}),SHELL(dx),P);
  if(dx>0){mesh(lathe({rFn:y=>rFn(y+y0)*.85,H:H-y0,cut:cut!=null?L:null,jag:cut?4:0,nu:48,nv:12,seed:17}),MAT.guts,P);for(let y=5;y<L-2;y+=5)kput('slab',[0,y,0],null,[rFn(y+y0)*.9,.5,rFn(y+y0)*.9],new THREE.Color(0x2a2c30));}
  const bands=[];   // one mesh for the whole stack, not two per storey
  for(let s=0;s*5<L-4;s++){const y=s*5;const bh=dx>0?(u,v)=>fbm(u*10+s,2,18+s,2)<.25*dx:null;
   bands.push(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(lobe(th,y+y0)*.97,lobe(th,y+y0)*1.1,v);return[r*Math.cos(th),y+3.9,r*Math.sin(th)];},144,2,{hole:bh}));
   bands.push(gridSurface((u,v)=>{const th=u*TAU;const r=lobe(th,y+y0)*1.1;return[r*Math.cos(th),y+3.2+v*1.1,r*Math.sin(th)];},144,1,{uS:30,hole:bh}));
   for(let k=0;k<NL;k++)for(let j=-1;j<=1;j+=2){const th=k/NL*TAU+j*.13;const u=((th%TAU)+TAU)%TAU/TAU;if(hole&&hole(u,y))continue;const r=lobe(th,y+y0)+.1;
    kput(dx>0?'winSmD':'winSmI',[r*Math.cos(th),y+2,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[2.6,2.2,1],null);}
   if(s%4===0)stripRing(0,y+2.6,0,rFn(y+y0)*.85,dx,36);}
  meshMerged(bands,SHELL(dx),P);
  if(cut==null){const Q=new THREE.Group();Q.position.set(0,L,0);P.add(Q);kput('slab',[0,L,0],null,[rFn(H)*1.1,1,rFn(H)*1.1],new THREE.Color(dx>0?0x5a4a40:0xd8d4cc));
   const CX=KXF;useGroupXF(Q);KXF={m:CX.m.clone().multiply(Q.matrix),q:CX.q.clone().multiply(Q.quaternion)};petalRing(Q,NL,rFn(H)*.75,42,16,6,1,0,dx,19,SHELL(dx),dx>0?(i=>i%4===1):null);endGroupXF();/*Iziz: was KXF=CX, which left an entry on the nested-transform stack*/
   if(dx===0){mesh(lathe({rFn:y=>rFn(H)*.72*Math.pow(clamp(1-Math.pow(y/30,2),0,1),.6),H:30,nu:48,nv:14}),MAT.glass,P,0,L+1,0);kput('finial',[0,L+38,0],null,[4,7,4],null);}}};
 const P=new THREE.Group();P.position.set(0,32,0);G.add(P);useGroupXF(P);if(d<2)body(P,dd,32,null,false);else body(P,1,32,32+55,false);endGroupXF();
 if(d===2)toppledUpper(G,0,0,87,rFn(87)*1.3,(U,dx,y0)=>body(U,1,87,null,true),d);
 figures(-100,130,6,6);KOFF=[0,0,0];return G;}
// --- C: the Tripod (three hyperboloid legs fusing into one fluted shaft) ---------------------------
function buildSkyC(scene,gx,gz,d){reseed(9120+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const dd=d>0?1:0;const skin=SHELL(dd);
 const H=380,YM=150;REGISTER({name:'Skyscraper C — the Tripod ('+(d===2?'toppled':STATE(d))+')',x:0,z:0,r:130,h:H+30});
 skyPlinth(G,dd,115);
 const legR=y=>15*Math.sqrt(1+1.2*Math.pow((y-YM*.5)/(YM*.5),2));
 for(let k=0;k<3;k++){const th=k/3*TAU+Math.PI/6;const Lg=new THREE.Group();Lg.position.set(Math.cos(th)*62,5,Math.sin(th)*62);const tilt=Math.atan2(62-20,YM);Lg.rotation.set(0,-th,0);Lg.rotateZ(tilt);G.add(Lg);useGroupXF(Lg);
  const LL=YM/Math.cos(tilt);mesh(lathe({rFn:legR,H:LL,flutes:10,amp:.1,sharp:2,nu:60,nv:30,hole:holeFn(dd*.8,27+k,null,1.5)}),skin,Lg);
  if(dd>0)mesh(lathe({rFn:y=>legR(y)*.85,H:LL,nu:24,nv:4}),MAT.guts,Lg);
  for(let y=8;y<LL-8;y+=6)for(let j=0;j<10;j++){const u=(j+.5)/10;const a=u*TAU,r=legR(y)+.1;kput(dd>0?'winSmD':'winSmI',[r*Math.cos(a),y,r*Math.sin(a)],qFacing([Math.cos(a),0,Math.sin(a)]),[1.6,2.4,1],null);}
  for(let yy=20;yy<LL-10;yy+=30)stripRing(0,yy,0,legR(yy)*.9,dd,20);endGroupXF();}
 // sky bridges between legs
 for(const yb of [60,110]){for(let k=0;k<3;k++){const t1=k/3*TAU+Math.PI/6,t2=(k+1)/3*TAU+Math.PI/6;const r=62-42*yb/YM;const gone=dd>0&&yb===60&&k===1;
  const a=[Math.cos(t1)*r,yb+5,Math.sin(t1)*r],b=[Math.cos(t2)*r,yb+5,Math.sin(t2)*r];if(!gone){beam(dd>0?'strutR':'strutW',a,b,3,4);beam('tube',[a[0],a[1]+2.5,a[2]],[b[0],b[1]+2.5,b[2]],2.6,2.6);}}}
 const rFn=y=>{const t=clamp((y-YM)/(H-YM),0,1);return 34*(1-.35*t)*(1+.12*Math.sin(Math.PI*t));};
 const body=(P,dx,y0,y1,upper)=>{const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*.9:null);const L=(cut!=null?cut:H)-y0;const hole=holeFn(dx,37+(upper?1:0),cut!=null?L:null,1.2);
  const o={rFn:y=>rFn(y+y0),H:H-y0,cut:cut!=null?L:null,jag:cut?8:0,flutes:15,amp:.22,sharp:3,nu:120,nv:80,hole,seed:37};mesh(lathe(o),SHELL(dx),P);
  if(dx>0){mesh(lathe({rFn:y=>rFn(y+y0)*.88,H:H-y0,cut:o.cut,jag:o.jag,nu:48,nv:16,seed:37}),MAT.guts,P);for(let y=7;y<L-2;y+=7)kput('slab',[0,y,0],null,[rFn(y+y0)*.9,.5,rFn(y+y0)*.9],new THREE.Color(0x2a2c30));}
  windowsOnLathe({rFn:y=>rFn(y+y0),hole,cut:o.cut},dx,6,L-14,7,15,0,0,0,false);
  for(let yy=14;yy<L-16;yy+=21)stripRing(0,yy,0,rFn(yy+y0)*.9,dx,24);
  [.35,.7].forEach(f=>{const yl=(H-YM)*f-(y0-YM);if(yl<8||yl>L-10)return;glassBand(P,y=>rFn(y+y0),yl,8,dx,0,0,0,36);});
  if(cut==null){mesh(lathe({rFn:y=>rFn(H)*(1+.5*y/26)*Math.sqrt(clamp(1-Math.pow(y/26,2),0,1)),H:26,nu:48,nv:12,hole:(u,y)=>Math.cos(u*TAU*15)<.2&&y>3}),SHELL(dx),P,0,L-1,0);
   if(dx===0){mesh(lathe({rFn:y=>rFn(H)*.95*(1+.5*y/26)*Math.sqrt(clamp(1-Math.pow(y/26,2),0,1)),H:26,nu:48,nv:12}),MAT.glass,P,0,L-1,0);kput('finial',[0,L+30,0],null,[4,8,4],null);}}};
 kput('slab',[0,YM+4,0],null,[42,4,42],new THREE.Color(dd>0?0x4a3f38:0xcfcac2));kput(dd>0?'ringR':'ringW',[0,YM+6,0],qEuler(Math.PI/2,0,0),[42,42,10],null);
 const P=new THREE.Group();P.position.set(0,YM+6,0);G.add(P);useGroupXF(P);if(d<2)body(P,dd,YM+6,null,false);else body(P,1,YM+6,YM+40,false);endGroupXF();
 if(d===2)toppledUpper(G,0,0,YM+40,rFn(YM+40),(U,dx,y0)=>body(U,1,YM+40,null,true),d);
 figures(-100,130,6,6);KOFF=[0,0,0];return G;}

// ---------------------------------------------------------------- v4: concrete, brick, glass panes
// Board-formed concrete: horizontal boards ~0.65 m deep, each poured a shade
// different, with the joint standing proud, a form-tie hole grid, a rust weep
// below each tie, and damp running down from every joint.
const BOARD=42;
TEX.concrete=canvasTex(512,512,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const bi=Math.floor(y/BOARD),fy=y%BOARD;
  let v=186+(h3(bi*3.1,0,2.2)-.5)*13;                       // board-to-board pour variation
  v+=(fbm(x/40,y/40,5.5,3)-.5)*24;                          // slow blotching
  v+=(fbm(x/4,y/4,8.1,1)-.5)*13;                            // aggregate speckle
  v+=Math.sin(x/9+bi*2.1)*2.2;                              // grain of the board itself
  if(fy<2)v-=46; else if(fy<4)v-=15; else if(fy>BOARD-3)v+=9;   // joint groove + lit lip
  const tx=(x+28)%128,ty=y%(BOARD*2),td=Math.hypot(tx-64,ty-BOARD);
  if(td<3.4)v-=44; else if(td<5)v-=16;                      // recessed form-tie hole
  if(td<10&&ty>BOARD)v-=clamp((10-td)/10,0,1)*15;           // rust weep below it
  v-=clamp((fbm(x/26,y/200,2.2,2)-.52)*4,0,1)*clamp(fy/BOARD*1.3,0,1)*30;   // damp under the joint
  d[i]=v;d[i+1]=v-2;d[i+2]=v-7;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.concreteRM=rmTex(256,256,(x,y)=>{const B=BOARD/2,fy=y%B;
 let r=.90+(fbm(x/20,y/20,4.1,2)-.5)*.10;
 if(fy<1)r=.97;                                             // the joint holds dirt
 return[clamp(r-clamp((fbm(x/13,y/100,2.2,2)-.52)*4,0,1)*clamp(fy/B*1.3,0,1)*.24,0,1),0];});
// Brick in common bond: five stretcher courses, then a header course. The old
// map was a plain running bond of randomly-toned rectangles with the background
// showing through as "mortar".
TEX.brick=canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 const CH=16,MJ=2.5;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const course=Math.floor(y/CH),header=(course%6)===5,BW=header?16:32;
  const off=header?((course%2)?8:0):((course%2)*BW/2);
  const bx=(x+off)%BW,by=y%CH,grain=(fbm(x/3,y/3,9.9,1)-.5);
  let r,gg,b;
  if(bx<MJ||by<MJ){const m=176+(fbm(x/5,y/5,7.7,1)-.5)*16;r=m;gg=m-4;b=m-10;}   // mortar
  else{const t=h3(Math.floor((x+off)/BW)*1.3,course*2.7,4.4);
   r=118+t*46+grain*16;gg=70+t*28+grain*10;b=54+t*22+grain*8;
   if(Math.min(bx-MJ,BW-1-bx,by-MJ,CH-1-by)<1.5){r*=.9;gg*=.9;b*=.9;}}          // arris shadow
  d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;}
 g.putImageData(id,0,0);});
MAT.concrete=new THREE.MeshStandardMaterial({map:TEX.concrete,roughnessMap:TEX.concreteRM,color:0xd2cec6,roughness:1,metalness:0,side:DS});
MAT.concreteR=new THREE.MeshStandardMaterial({map:TEX.concrete,roughnessMap:TEX.concreteRM,color:0x7c746c,roughness:1,metalness:0,side:DS});
MAT.brick=new THREE.MeshStandardMaterial({map:TEX.brick,color:0xffffff,roughness:.95,metalness:0,side:DS});
const CONC=d=>d>0?MAT.concreteR:MAT.concrete;
kdef('boxC',new THREE.BoxGeometry(1,1,1),MAT.concrete);kdef('boxCR',new THREE.BoxGeometry(1,1,1),MAT.concreteR);
kdef('brick',new THREE.BoxGeometry(1,1,1),MAT.brick);
kdef('pane',new THREE.BoxGeometry(1,1,.12),MAT.glass);kdef('paneD',new THREE.BoxGeometry(1,1,.12),MAT.winDead);
kdef('slabC',new THREE.CylinderGeometry(1,1,1,48),MAT.concrete);kdef('slabCR',new THREE.CylinderGeometry(1,1,1,48),MAT.concreteR);
const BOXC=d=>d>0?'boxCR':'boxC', SLABC=d=>d>0?'slabCR':'slabC';
function se(th,n){return 1/Math.pow(Math.pow(Math.abs(Math.cos(th)),n)+Math.pow(Math.abs(Math.sin(th)),n),1/n);}
function bodyGroup(G,y0,d,dd,build,cutY,topR){const P=new THREE.Group();P.position.set(0,y0,0);G.add(P);useGroupXF(P);if(d<2)build(P,dd,y0,null,false);else build(P,1,y0,cutY,false);endGroupXF();
 if(d===2)toppledUpper(G,0,0,cutY,topR,(U)=>build(U,1,cutY,null,true),d);}

// ================================================================= SKYSCRAPER D — "the Monolith" (bare concrete, Torre Velasca head)
function buildSkyD(scene,gx,gz,d){reseed(9130+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const dd=d>0?1:0;
 const H=340,Y0=14;REGISTER({name:'Skyscraper D — the Monolith ('+(d===2?'toppled':STATE(d))+')',x:0,z:0,r:120,h:H+20});
 skyPlinth(G,dd,110);
 const rFn=y=>{const t=clamp(y/H,0,1);return 30*(1-.12*t)+(t>.84?9*Math.pow((t-.84)/.16,.7):0);};
 const build=(P,dx,y0,y1,upper)=>{const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*.76:null);const L=(cut!=null?cut:H)-y0;const hole=holeFn(dx,47+(upper?1:0),cut!=null?L:null,1.2);
  const skin=gridSurface((u,v)=>{const th=u*TAU,y=v*L;const fy=((y+y0)%12)/12;const rec=fy>.62&&fy<.92?.94:1;const r=rFn(y+y0)*se(th,3.2)*rec;return[r*Math.cos(th),y,r*Math.sin(th)];},96,Math.round(L/2),{uS:16,vS:L/8,hole:hole?(u,v)=>hole(u,v*L):null});
  mesh(skin,CONC(dx),P);
  if(dx>0){mesh(lathe({rFn:y=>rFn(y+y0)*.86,H:H-y0,cut:cut!=null?L:null,jag:6,nu:32,nv:8,seed:47}),MAT.guts,P);for(let y=6;y<L-2;y+=6)kput('slab',[0,y,0],null,[rFn(y+y0)*.9,.5,rFn(y+y0)*.9],new THREE.Color(0x2a2c30));}
  const dRib=[];   // the ruined ribbons merge; the intact ones are glass, which does not
  for(let y=12-((y0)%12);y<L-4;y+=12){const yy=y+y0;const r0=rFn(yy)*.95; // glass ribbon in each recess
   if(dx===0)mesh(gridSurface((u,v)=>{const th=u*TAU;const r=r0*se(th,3.2);return[r*Math.cos(th),y+7.4+v*3.6,r*Math.sin(th)];},96,1,{}),MAT.glass,P);
   else dRib.push(gridSurface((u,v)=>{const th=u*TAU;const r=r0*se(th,3.2)*.98;return[r*Math.cos(th),y+7.4+v*3.6,r*Math.sin(th)];},96,1,{hole:(u,v)=>hole&&hole(u,y)}));
   if(((yy/12)|0)%3===0)stripRing(0,y+9,0,r0*.9,dx,28);}
  meshMerged(dRib,MAT.dark,P);
  // lift-core spine on +x, Velasca props under the head
  kput(BOXC(dx),[rFn(y0+L*.5)*.9+2.5,L/2,0],null,[5,L,9],null);
  if(cut==null){const yh=H*.84-y0;for(let k=0;k<16;k++){const th=(k+.5)/16*TAU;const r1=rFn(H*.8)*se(th,3.2),r2=rFn(H*.9)*se(th,3.2)*1.02;
    beam(dx>0?'strutR':'strutW',[Math.cos(th)*r1*.98,yh-14,Math.sin(th)*r1*.98],[Math.cos(th)*r2,yh+8,Math.sin(th)*r2],2.4,2);}
   mesh(gridSurface((u,v)=>{const th=u*TAU;const r=(rFn(H)+1.2)*se(th,3.2)*(1-v*.02);return[r*Math.cos(th),L+v*4,r*Math.sin(th)];},96,1,{uS:16}),CONC(dx),P);
   kput(BOXC(dx),[0,L+2,0],null,[rFn(H)*1.9,.8,rFn(H)*1.9],null);
   for(let k=0;k<6;k++){const a=k/6*TAU;kput(BOXC(dx),[Math.cos(a)*14,L+7,Math.sin(a)*14],qEuler(0,-a,0),[3,10,8],null);}
   if(dx===0)mesh(lathe({rFn:y=>9*Math.sqrt(clamp(1-Math.pow(y/8,2),0,1)),H:8,nu:24,nv:6}),MAT.glass,P,0,L+4,0);}};
 bodyGroup(G,Y0,d,dd,build,Y0+60,rFn(Y0+60));
 if(dd>0)vinesOnRing(0,Y0+12,0,rFn(Y0)*1.0,30,20);
 figures(-100,130,6,6);KOFF=[0,0,0];return G;}

// ================================================================= SKYSCRAPER E — "the Sail" (shaped glass lens, diagrid, twisting)
// NON-GROUND PLACEMENT. gy lifts the whole tower, noPlinth drops the ground
// plinth and apron, and hcut (decay 1) cuts the body at that fraction of H
// instead of 0.8. kput adds all three components of KOFF and bodyGroup already
// routes the instanced pieces through useGroupXF, so lifting both KOFF and the
// group moves merged meshes and instances together. See buildPerch for a
// worked example -- a tower standing on a podium 90 m up.
function buildSkyE(scene,gx,gz,d,gy,noPlinth,hcut){reseed(9140+d);gy=gy||0;KOFF=[gx,gy,gz];const G=new THREE.Group();G.position.set(gx,gy,gz);scene.add(G);const dd=d>0?1:0;
 const H=360,Y0=10;REGISTER({name:'Skyscraper E — the Sail ('+(d===2?'toppled':STATE(d))+')',x:0,y:gy,z:0,r:120,h:H+40});
 if(!noPlinth)skyPlinth(G,dd,105);
 const aF=y=>34*(1-.45*Math.pow(clamp(y/H,0,1),1.3)),bF=y=>13*(1-.3*clamp(y/H,0,1)),rot=y=>.8*clamp(y/H,0,1);
 const PT=(u,y,s)=>{const a=aF(y),b=bF(y),r=rot(y);const x=(u-.5)*2*a,z=s*b*(1-Math.pow(u*2-1,2));return[x*Math.cos(r)-z*Math.sin(r),y,x*Math.sin(r)+z*Math.cos(r)];};
 const build=(P,dx,y0,y1,upper)=>{const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*.82:null);const L=(cut!=null?cut:H)-y0;const hole=holeFn(dx*.8,57+(upper?1:0),cut!=null?L:null,1.5);
  for(const s of [-1,1]){if(dx===0)mesh(gridSurface((u,v)=>{const p=PT(u,v*L+y0,s);return[p[0],v*L,p[2]];},40,Math.round(L/6),{}),MAT.glass,P);
   else mesh(gridSurface((u,v)=>{const p=PT(u,v*L+y0,s);return[p[0]*.93,v*L,p[2]*.93];},40,Math.round(L/6),{hole:(u,v)=>hole&&hole(u+s,v*L)}),MAT.guts,P);
   // diagrid mullions
   const step=12;for(let y=0;y<L-1;y+=step){const y2=Math.min(y+step,L);for(let j=0;j<8;j++){const u1=j/8,u2=(j+1)/8;if(dx>0&&hole&&hole((u1+u2)/2+s,y))continue;
    const A=PT(u1,y+y0,s),B=PT(u2,y2+y0,s),C=PT(u2,y+y0,s),D=PT(u1,y2+y0,s);
    beam(dx>0?'strutR':'strutW',[A[0],y,A[2]],[B[0],y2,B[2]],1.1,.9);beam(dx>0?'strutR':'strutW',[C[0],y,C[2]],[D[0],y2,D[2]],1.1,.9);}}}
  // concrete edge fins and floor slabs
  for(let y=0;y<L;y+=8){const y2=Math.min(y+8,L);const A=PT(0,y+y0,1),B=PT(0,y2+y0,1),C=PT(1,y+y0,1),D=PT(1,y2+y0,1);
   beam(BOXC(dx),[A[0],y,A[2]],[B[0],y2,B[2]],3.5,6);beam(BOXC(dx),[C[0],y,C[2]],[D[0],y2,D[2]],3.5,6);}
  for(let y=4;y<L-1;y+=4){const yy=y+y0;if(hole&&rng()<.15*dx)continue;kput('slab',[0,y,0],qEuler(0,-rot(yy),0),[aF(yy)*.95,.35,bF(yy)*.92],new THREE.Color(dx>0?0x2a2c30:0x8a8f98));if(y%24===4)stripRing(0,y+1.5,0,bF(yy)*.6,dx,12);}
  if(cut==null){for(const uu of [0,1]){const A=PT(uu,H,1);beam(BOXC(dx),[A[0],L,A[2]],[A[0]*1.1,L+34,A[2]*1.1],3,5);}
   if(dx===0){mesh(gridSurface((u,v)=>{const p=PT(u,H,1);const q=PT(u,H,-1);const z=lerp(q[2],p[2],v),x=lerp(q[0],p[0],v);return[x,L+.5,z];},20,6,{}),MAT.glass,P);kput('finial',[0,L+36,0],null,[3,6,3],null);}}};
 bodyGroup(G,Y0,d,dd,build,Y0+70,aF(Y0+70));
 if(!noPlinth)figures(-100,130,6,6);
 KOFF=[0,0,0];return G;}

// ================================================================= SKYSCRAPER F — "the Trays" (stacked concrete trays, glass between)
// NON-GROUND PLACEMENT. gy lifts the whole tower, noPlinth drops the ground
// plinth and apron, and hcut (decay 1) cuts the body at that fraction of H
// instead of 0.8. kput adds all three components of KOFF and bodyGroup already
// routes the instanced pieces through useGroupXF, so lifting both KOFF and the
// group moves merged meshes and instances together. See buildPerch for a
// worked example -- a tower standing on a podium 90 m up.
function buildSkyF(scene,gx,gz,d,gy,noPlinth,hcut){reseed(9150+d);gy=gy||0;KOFF=[gx,gy,gz];const G=new THREE.Group();G.position.set(gx,gy,gz);scene.add(G);const dd=d>0?1:0;
 const H=290,Y0=10,TS=12;REGISTER({name:'Skyscraper F — the Trays ('+(d===2?'toppled':STATE(d))+')',x:0,y:gy,z:0,r:120,h:H+20});
 if(!noPlinth)skyPlinth(G,dd,105);
 const RT=y=>28*(1-.2*clamp(y/H,0,1))+6*Math.sin(Math.PI*clamp(y/H,0,1));
 const build=(P,dx,y0,y1,upper)=>{const cut=(dx>0&&!upper&&y1!=null)?y1:(dx>0&&d===1?H*(hcut||.8):null);const L=(cut!=null?cut:H)-y0;
  mesh(lathe({rFn:()=>11,H:L,nu:32,nv:4,hole:holeFn(dx*.6,67,null,2)}),CONC(dx),P);if(dx>0)mesh(lathe({rFn:()=>9.5,H:L,nu:16,nv:1}),MAT.guts,P);
  const trays=[],darks=[];   // one mesh for the whole stack, not three per tray
  let k0=Math.round(y0/TS);for(let y=0;y+2<L;y+=TS){const k=k0+((y/TS)|0);const yy=y+y0;const R=RT(yy);const ang=k*.14;const fallen=dx>0&&(k%7===3);
   const trayR=th=>R*(1+.22*Math.cos(3*(th-ang)));
   if(!fallen){
    trays.push(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(11,trayR(th),v);return[r*Math.cos(th),y+TS-2.6,r*Math.sin(th)];},96,4,{uS:16,vS:2,hole:holeFn(dx*.7,68+k,null,2)}));
    trays.push(gridSurface((u,v)=>{const th=u*TAU;const r=trayR(th);return[r*Math.cos(th),y+TS-2.6+v*2.6,r*Math.sin(th)];},96,1,{uS:16}));
    trays.push(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(11,trayR(th),v);return[r*Math.cos(th),y+TS,r*Math.sin(th)];},96,2,{}));
    if(dx===0)mesh(gridSurface((u,v)=>{const th=u*TAU;const r=trayR(th)*.82;return[r*Math.cos(th),y+.2+v*(TS-2.9),r*Math.sin(th)];},96,1,{}),MAT.glass,P);
    else darks.push(gridSurface((u,v)=>{const th=u*TAU;const r=trayR(th)*.72;return[r*Math.cos(th),y+.2+v*(TS-2.9),r*Math.sin(th)];},64,1,{hole:(u,v)=>fbm(u*6,k,69,2)<.3}));
    for(let j=0;j<18;j++){const th=j/18*TAU;const r=trayR(th)*.82;kput(dx>0?'mullR':'mullW',[r*Math.cos(th),y+TS/2-1.3,r*Math.sin(th)],qEuler(0,-th,0),[.8,TS-2.9,.8],null);}
    stripRing(0,y+TS-3.3,0,R*.7,dx,20);}
   else{const fm=mesh(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(11,trayR(th),v);return[r*Math.cos(th),0,r*Math.sin(th)];},64,3,{uS:16,vS:2,hole:holeFn(1,68+k,null,1.5)}),MAT.concreteR,P,6,y+TS-6,4);fm.rotation.set(.35,0,.25);}}
  meshMerged(trays,CONC(dx),P);meshMerged(darks,MAT.dark,P);
  if(cut==null){mesh(lathe({rFn:y=>13*Math.sqrt(clamp(1-Math.pow(y/10,2),0,1)),H:10,nu:32,nv:6}),CONC(dx),P,0,L,0);kput(dx>0?'ringR':'ringW',[0,L+3,0],qEuler(Math.PI/2,0,0),[15,15,4],null);if(dx===0)kput('finial',[0,L+13,0],null,[3,5,3],null);}};
 bodyGroup(G,Y0,d,dd,build,Y0+TS*5,RT(Y0+60));
 if(!noPlinth)figures(-100,130,6,6);
 KOFF=[0,0,0];return G;}

// ================================================================= HOUSES D/E/F
function buildHouses2(scene,gx,gz,d){reseed(9410+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);
 // D — apse house (Arcosanti): concrete quarter-sphere open to +z, glass front wall
 {REGISTER({name:'House D — apse house ('+STATE(d)+')',x:0,z:0,r:14,h:12});kput(SLABC(d),[0,.3,0],null,[12,.6,12],null);
  const R=9;mesh(lathe({rFn:y=>R*Math.sqrt(clamp(1-Math.pow(y/R,2),0,1)),H:R,nu:48,nv:16,hole:(u,y)=>Math.sin(u*TAU)>.05||(d>0&&fbm(u*6,y*.3,150,2)<.3)||(Math.hypot(u-.75,y/R-.5)<.07)}),CONC(d),G,0,.6,0);
  mesh(lathe({rFn:y=>R*.94*Math.sqrt(clamp(1-Math.pow(y/R,2),0,1)),H:R,nu:24,nv:8,hole:(u,y)=>Math.sin(u*TAU)>.05}),MAT.dark,G,0,.6,0);
  if(d===0)mesh(gridSurface((u,v)=>{const x=(u-.5)*R*1.9;const y=v*R*.95*Math.sqrt(clamp(1-Math.pow(x/R,2),0,1));return[x,.6+y,0];},20,6,{}),MAT.glass,G);
  for(let k=-3;k<=3;k++){const x=k*2.4;const h=R*.95*Math.sqrt(clamp(1-Math.pow(x/R,2),0,1));kput(d>0?'mullR':'mullW',[x,.6+h/2,0],null,[.6,h,.6],null);}
  kput('archOpen',[3,2.2,.1],qFacing([0,0,1]),[.35,.45,1],null);kput(SLABC(d),[3,.2,8],null,[2.5,.4,2.5],null);
  kput(BOXC(d),[-7,1.6,3],null,[4,.5,5],null);for(let k=0;k<6;k++){const a=Math.PI+(k+.5)/6*Math.PI;const lit=d>0?rng()<.15:true;kput('strip',[Math.cos(a)*4.5,5,Math.sin(a)*4.5],qEuler(0,-a,0),[2,1,1],lit?CYAN:DEAD);}if(d>0){mossOnRing(0,.7,0,9,14,1.2);vinesOnRing(0,7,0,5,6,6);}}
 // E — bridge house: a glass box spanning two concrete piers
 {const bx=60;REGISTER({name:'House E — bridge house ('+STATE(d)+')',x:bx,z:0,r:16,h:12});
  for(const s of [-1,1]){mesh(lathe({rFn:y=>2.6*Math.sqrt(1+1.2*Math.pow((y-4)/4,2)),H:8,nu:20,nv:6,hole:holeFn(d*.5,160+s,null,3)}),CONC(d),G,bx+s*9,0,0);}
  kput(BOXC(d),[bx,8.3,0],null,[26,.7,8],null);kput(BOXC(d),[bx,12.2,0],null,[27,.7,9],null);
  if(d===0){for(const s of [-1,1])kput('pane',[bx,10.2,s*4],null,[24,3.2,1],null);for(const s of [-1,1])kput('pane',[bx+s*12.5,10.2,0],qEuler(0,Math.PI/2,0),[8,3.2,1],null);}
  else{kput('boxD',[bx,10.2,0],null,[22,3,6],null);}
  for(let k=-2;k<=2;k++)kput(d>0?'mullR':'mullW',[bx+k*6,10.2,4.1],null,[.5,3.4,.5],null);
  // stair up the east pier, door at the top
  for(let k=0;k<8;k++){const a=Math.PI/2-(7-k)*.7;kput(BOXC(d),[bx+9+4.5*Math.cos(a),k*1.05+.5,4.5*Math.sin(a)],qEuler(0,-a,0),[3,.4,1.6],null);}kput(BOXC(d),[bx+9,8.7,4.6],null,[3,.4,1.6],null);kput('archOpen',[bx+9,9.9,4.3],qFacing([0,0,1]),[.3,.36,1],null);
  stripRing(bx,11.6,0,3,d,8);if(d>0){mossOnRing(bx,.3,0,10,10,1.2);vinesOnRing(bx,12.5,0,12,8,8);}}
 // F — terrace house: three stepped concrete trays into a slope, glass fronts, planters
 {const fx=130;REGISTER({name:'House F — terrace house ('+STATE(d)+')',x:fx,z:0,r:16,h:12});
  mesh(lathe({rFn:y=>16-1.4*y,H:9,nu:6,nv:2}),MAT.rock,G,fx,0,-8);
  for(let t=0;t<3;t++){const y=t*3.6,z=6-t*5,w=16-t*3;kput(BOXC(d),[fx,y+.3,z],null,[w,.6,9],null);kput(BOXC(d),[fx,y+3.4,z-1],null,[w+1,.5,8],null);
   if(d===0)kput('pane',[fx,y+1.9,z+3.8],null,[w-2,2.6,1],null);else kput('boxD',[fx,y+1.9,z+1],null,[w-3,2.6,5],null);
   for(let k=-1;k<=1;k++)kput(d>0?'mullR':'mullW',[fx+k*(w/2-1.5),y+1.9,z+3.9],null,[.5,2.8,.5],null);
   kput('brick',[fx,y+1.9,z-3.6],null,[w,2.8,.5],null);for(const s of [-1,1])kput('brick',[fx+s*(w/2-.25),y+1.9,z],null,[.5,2.8,8.4],null);kput(BOXC(d),[fx-w/2+1.5,y+3.9,z+3],null,[3,.8,2],null);
   for(let k=0;k<3;k++)kput('moss',[fx-w/2+1+k*.8,y+4.4,z+3],null,[1,.5,1],new THREE.Color().setHSL(.28,.5,.2));}
  kput('archOpen',[fx+4,1.9,10.6],qFacing([0,0,1]),[.3,.36,1],null);for(let k=0;k<4;k++)kput(BOXC(d),[fx-7,1.2+k*.9,9-k*1.4],null,[2,.3,1.4],null);
  stripRing(fx,3,6,4,d,8);if(d>0){mossOnRing(fx,.6,6,8,14,1.3);}}
 figures(30,14,4,4);KOFF=[0,0,0];return G;}

// ================================================================= OFFICE C — "the Comb" (concrete brise-soleil bar)
function officeC(G,d){const cx=330;REGISTER({name:'Office C — the Comb ('+STATE(d)+')',x:cx,z:0,r:50,h:24});
 const R=60,a0=-.7,a1=.7,NS=4,SH=4.4;
 const cDeck=[],cBrick=[],cDark=[];   // the brise-soleil bar in three meshes, not thirteen
 for(let f=0;f<=NS;f++){const y=f*SH;cDeck.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(R-14,R+1,v);return[cx+Math.sin(a)*r,y+.3,Math.cos(a)*r-R*.6];},60,2,{hole:d>0?(u,v)=>fbm(u*10,f,1500+f,2)<.15:null}));}
 for(let k=0;k<=30;k++){const a=lerp(a0,a1,k/30);const x=cx+Math.sin(a)*(R+1.5),z=Math.cos(a)*(R+1.5)-R*.6;if(d>0&&rng()<.15)continue;kput(BOXC(d),[x,NS*SH/2,z],qEuler(0,a,0),[1.2,NS*SH+1,3.6],null);}
 for(let k=0;k<6;k++){const a=lerp(a0,a1,(k+.5)/6);kput(BOXC(d),[cx+Math.sin(a)*(R-12),NS*SH/2,Math.cos(a)*(R-12)-R*.6],null,[1.4,NS*SH,1.4],null);}
 for(let f=0;f<NS;f++){const y=f*SH;if(d===0)mesh(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=R-1.2;return[cx+Math.sin(a)*r,y+.6+v*(SH-.9),Math.cos(a)*r-R*.6];},60,1,{}),MAT.glass,G);
  else cDark.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=R-3;return[cx+Math.sin(a)*r,y+.6+v*(SH-.9),Math.cos(a)*r-R*.6];},40,1,{hole:(u,v)=>fbm(u*8,f,1510,2)<.35}));
  cBrick.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=R-13;return[cx+Math.sin(a)*r,y+.6+v*(SH-.9),Math.cos(a)*r-R*.6];},40,1,{uS:20}));
  for(let k=0;k<8;k++){const a=lerp(a0,a1,(k+.5)/8);const lit=d>0?rng()<.15:true;kput('strip',[cx+Math.sin(a)*(R-7),y+SH-.6,Math.cos(a)*(R-7)-R*.6],qEuler(0,a,0),[8,1,1],lit?CYAN:DEAD);}}
 // end walls: the bar was open along both end elevations, showing four floor
 // slabs in section from the side.
 for(let s=0;s<2;s++){const a=lerp(a0,a1,s);
  cDeck.push(gridSurface((u,v)=>{const r=lerp(R-14,R+1,u);return[cx+Math.sin(a)*r,v*NS*SH+.3,Math.cos(a)*r-R*.6];},8,18,{uS:6,vS:8,hole:d>0?(u,v)=>fbm(u*4+s*3,v*5,1520+s,2)<.25:null}));}
 meshMerged(cDeck,CONC(d),G);meshMerged(cBrick,MAT.brick,G);meshMerged(cDark,MAT.dark,G);
 // roof pergola
 for(let k=0;k<12;k++){const a=lerp(a0,a1,(k+.5)/12);if(d>0&&rng()<.3)continue;beam(BOXC(d),[cx+Math.sin(a)*(R-14),NS*SH+.5,Math.cos(a)*(R-14)-R*.6],[cx+Math.sin(a)*(R+2),NS*SH+3.5,Math.cos(a)*(R+2)-R*.6],1,1.2);}
 kput('archOpen',[cx,3.8,R*.4-1],qFacing([0,0,1]),[.6,.6,1],null);
 if(d>0){mossOnRing(cx,NS*SH+.5,-R*.6,R*.7,20,2);vinesOnRing(cx,NS*SH,-R*.6,R-2,16,12);rubbleRing(cx,.3,-R*.6+R*.9,5,30,30,2);}}


// ---------------------------------------------------------------- v5 materials
MAT.rock=new THREE.MeshStandardMaterial({map:TEX.concrete,color:0x8a5a42,roughness:1,side:DS});
MAT.lawn=new THREE.MeshStandardMaterial({color:0x4f7a30,roughness:1,side:DS});
MAT.water=new THREE.MeshStandardMaterial({color:0x2a6a8a,roughness:.15,metalness:.3,transparent:true,opacity:.85,side:DS});
MAT.mud=new THREE.MeshStandardMaterial({map:TEX.concrete,color:0x6a4a34,roughness:1,side:DS});
MAT.turf=new THREE.MeshStandardMaterial({map:TEX.concrete,color:0x3a5a2a,roughness:1,side:DS});
MAT.turfR=new THREE.MeshStandardMaterial({map:TEX.concrete,color:0x2c4a24,roughness:1,side:DS});
MAT.spray=new THREE.MeshStandardMaterial({color:0xdaf0ff,transparent:true,opacity:.75,roughness:.2,side:DS});
MAT.darkGlass=new THREE.MeshStandardMaterial({color:0x0c1418,metalness:.7,roughness:.25,side:DS});
kdef('plateW',new THREE.BoxGeometry(1,1,1),MAT.white);kdef('plateR',new THREE.BoxGeometry(1,1,1),MAT.rust);
kdef('darkPane',new THREE.BoxGeometry(1,1,.3),MAT.darkGlass);
kdef('hedge',new THREE.BoxGeometry(1,1,1),MAT.vine);
const PLATE=d=>d>0?'plateR':'plateW';

// ---------------------------------------------------------------- salvage (decay level 3)
// Everything a later people could cut, carry and nail up. It must never be
// mistaken for ancient fabric: the ancients built in panelled white metal,
// board-formed concrete and shaped glass, so salvage is corrugated sheet, sawn
// timber, torn tarpaulin and flat scrap — cruder, warmer, and visibly newer
// than the thing it is bolted to.
TEX.corrugate=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const rib=Math.cos(x/128*TAU*10);                     // ~0.8 m corrugations
  let v=150+rib*34;                                     // the profile's own shading
  v+=(fbm(x/9,y/9,3.3,2)-.5)*22;                        // galvanising mottle
  const dent=clamp((fbm(x/17,y/13,7.1,2)-.60)*4,0,1);v-=dent*26;
  const rust=clamp((fbm(x/6,y/40,5.5,3)-.42)*2.6,0,1)*clamp(y/h*1.5,0,1);
  d[i]=lerp(v,116+rust*40,rust);d[i+1]=lerp(v-2,62+rust*20,rust);d[i+2]=lerp(v-6,44,rust);d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.timber=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const bd=Math.floor(y/16);                            // 0.25 m sawn boards
  let v=132+(h3(bd*2.7,0,1.9)-.5)*26;
  v+=(fbm(x/26,y/3,4.8,2)-.5)*30;                       // grain, running along the board
  if(y%16<1)v-=34;                                      // the gap between boards
  d[i]=v;d[i+1]=v*.78;d[i+2]=v*.56;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.tarp=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const weave=((x%3)<1?-1:0)+((y%3)<1?-1:0);
  let v=158+weave*9+(fbm(x/21,y/21,6.4,2)-.5)*38;       // sun-bleached in patches
  d[i]=v*1.02;d[i+1]=v*.86;d[i+2]=v*.66;d[i+3]=255;}
 g.putImageData(id,0,0);});
MAT.corrugate=new THREE.MeshStandardMaterial({map:TEX.corrugate,color:0xffffff,roughness:.72,metalness:.30,side:DS});
MAT.timber=new THREE.MeshStandardMaterial({map:TEX.timber,color:0xffffff,roughness:.94,metalness:0,side:DS});
MAT.tarp=new THREE.MeshStandardMaterial({map:TEX.tarp,color:0xc8b08a,roughness:.88,metalness:0,side:DS});
kdef('patchSheet',new THREE.PlaneGeometry(1,1),MAT.corrugate);
kdef('patchPlate',new THREE.PlaneGeometry(1,1),MAT.rust);
kdef('patchBoard',new THREE.PlaneGeometry(1,1),MAT.timber);
kdef('patchTarp',new THREE.PlaneGeometry(1,1),MAT.tarp);
kdef('shantyBox',new THREE.BoxGeometry(1,1,1),MAT.corrugate);
kdef('shantyRoof',new THREE.BoxGeometry(1,.09,1),MAT.tarp);
kdef('spipe',new THREE.CylinderGeometry(1,1,1,7),MAT.rust);
kdef('waterButt',new THREE.CylinderGeometry(1,1,1,10),MAT.corrugate);
kdef('planter',new THREE.BoxGeometry(1,1,1),MAT.timber);
kdef('plank',new THREE.BoxGeometry(1,1,1),MAT.timber);

// THE REPAIRED PASS.
//
// Runs over a FINISHED structure — the group the builder returned — rather than
// inside the builder, so all 33 types get rehabilitated from one function and
// not one edit each. `faceSamples` walks the group and bakes each mesh's
// transform, so nothing has to be handed over.
//
// Two populations: patches riveted onto the near-vertical faces, and accretion
// standing on anything flat. Every piece goes through the kit, so the whole
// pass costs draw calls in the low tens rather than thousands.
function repairPass(G,d){
 // Scale the dressing to the structure. A fixed count buries a 12 m house under
 // the same amount of salvage it takes to read on a 420 m tower, and the brief
 // is "slightly worn": the ancient form has to stay the thing you see first.
 const bb=new THREE.Box3().setFromObject(G);
 if(!isFinite(bb.min.x))return;
 const sz=clamp(bb.max.distanceTo(bb.min),18,620);
 const nSide=Math.round(clamp(sz*.62,16,340)),nUp=Math.round(clamp(sz*.40,12,240));
 const PATCH=['patchSheet','patchPlate','patchBoard','patchTarp'];
 for(const f of sideFaces(G,nSide)){
  if(rng()<.42)continue;
  const n=f.n,w=rr(2,7.5),h=rr(1.6,5);
  // proud of the shell and a few degrees off the panel grid: salvage is never
  // flush and never square with what it is covering
  const q=qFacing(n).multiply(qEuler(0,0,rr(-.24,.24)));
  kput(PATCH[(rng()*4)|0],[f.p[0]+n[0]*.25,f.p[1]+n[1]*.25,f.p[2]+n[2]*.25],q,[w,h,1],null);
  // a warm lamp by one patch in ten. The ancient cyan strips stay dead — that
  // contrast is the whole point: new light, old building.
  if(rng()<.09)kput('dot',[f.p[0]+n[0]*.6,f.p[1]+n[1]*.6+h*.35,f.p[2]+n[2]*.6],q,[1.2,1.2,1],WARM);}
 for(const f of upFaces(G,nUp,.62)){
  const p=f.p,r=rng();
  if(r<.32){const w=rr(2.5,6.5),hh=rr(2,3.8),dp=rr(2.5,6);const yaw=rng()*TAU;
   kput('shantyBox',[p[0],p[1]+hh/2,p[2]],qEuler(0,yaw,0),[w,hh,dp],null);
   kput('shantyRoof',[p[0],p[1]+hh+.2,p[2]],qEuler(rr(.08,.26),yaw,0),[w*1.3,1,dp*1.3],null);
   if(rng()<.45)kput('spipe',[p[0]+w*.28,p[1]+hh+1.4,p[2]],null,[.28,3,.28],null);}
  else if(r<.50)kput('waterButt',[p[0],p[1]+1.15,p[2]],null,[1.15,2.3,1.15],null);
  else if(r<.73){kput('planter',[p[0],p[1]+.35,p[2]],qEuler(0,rng()*TAU,0),[rr(1.6,4.2),.7,rr(1,2.2)],null);
   for(let k=0;k<3;k++)kput('moss',[p[0]+rr(-1.3,1.3),p[1]+.95,p[2]+rr(-.9,.9)],null,[.75,.5,.75],new THREE.Color().setHSL(rr(.26,.34),.55,.28));}
  else if(r<.87)kput('plank',[p[0],p[1]+.12,p[2]],qEuler(0,rng()*TAU,0),[rr(2,6),.22,rr(.5,1.3)],null);
  else if(rng()<.5)kput('dot',[p[0],p[1]+1.7,p[2]],qEuler(0,rng()*TAU,0),[1.2,1.2,1],WARM);}}
// ================================================================= IZIZ VERNACULAR — materials + kit items
// What the Izani build today, in timber, reclaimed metal and (for the rich)
// stone. Every texture here is painted NEAR-GREY and WARM so that the per-
// instance colour does the tinting — one wood map serves grey driftwood and
// oiled dark hardwood alike, one stone map serves sand and orange ashlar. The
// exceptions are the salvage maps (corrugate/panel/rust), which come from the
// Ancients kit and carry their own colour: salvage is not tinted, it is what it is.
//
// Instance colours: hex values below are sRGB as a painter would pick them, and
// vC() converts once to linear at the write — r128 does not convert instance
// colours (lesson from the biome kit), so without this every tint renders pale.
function vC(hex,k){const c=new THREE.Color(hex).convertSRGBToLinear();if(k!==undefined)c.multiplyScalar(k);return c;}

// The old Iziz palette (sands and oranges) and the timber/adobe tones of the set.
const VPAL={
 sand:[0xe9cb8c,0xdcb474,0xcf9d5b,0xe2ab5e,0xf1dba6,0xe6bd7e,0xd4a05a,0xc8a26a],   // plaster, stone tints
 orange:[0xe07a2a,0xc4641e,0xf2a24a,0xd8893c],                                     // the wall colour of Iziz; stone accents, banners
 adobe:[0xc98f5c,0xd6a06a,0xb87d4c,0xe0b07a,0xa9713f],
 woodPoor:[0x9a8c78,0x8a7a66,0xa89a86,0x7c6e5e],                                   // grey, weathered
 woodMid:[0x9a6a42,0x8a5a36,0xa87a4e,0x7a4e30],                                    // sawn, some oil
 woodRich:[0x5a3a24,0x6a4630,0x4a2e1c,0x7a4e34],                                   // dark hardwood
 awning:[0xe07a2a,0xe07a2a,0xf2a24a,0xd8893c,0xc9442a,0xe0a030,0x2f8f8a,0xb8552a,0xe07a2a],   // orange-led (Travis): 5 of 9 draws are Iziz orange, teal is the accent
 trim:[0xe07a2a,0xd8893c,0xc4641e,0xb8552a],                                                   // painted timber trim: fascias, shutters, doors on middle/rich houses
 thatch:[0xb89a5a,0xa88a4e,0xc4a66a,0x9a7e46],
 stone:[0xd8b58a,0xcfa872,0xe0c096,0xc89a62],                                      // rich house ashlar (sandstone)
 stoneDark:[0xb07a48,0xa86e3e,0xc0885a],                                           // string courses / plinths
};
const vPick=a=>a[(rng()*a.length)|0];

// ---------------------------------------------------------------- textures (world units: a 128px tile = 2 m)
TEX.wood=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const bd=Math.floor(y/16);                                  // 0.25 m boards
  let v=178+(h3(bd*2.7,0,1.9)-.5)*34;                         // board-to-board tone
  v+=(fbm(x/22,y/2.5,4.8,2)-.5)*34;                           // grain along the board
  v+=(fbm(x/5,y/5,7.7,1)-.5)*8;
  if(y%16<1)v-=60;else if(y%16<2)v-=22;                       // shadow gap between boards
  if(((x+bd*37)%128)<2&&y%16>2)v-=30;                         // butt joints, staggered
  const knot=fbm(x/9,y/9,bd*1.3,2);if(knot>.72)v-=(knot-.72)*160;
  d[i]=v;d[i+1]=v*.93;d[i+2]=v*.84;d[i+3]=255;}
 g.putImageData(id,0,0);});
// the same boards turned upright, for posts, staves and barrels (grain must run along the member)
TEX.woodV=canvasTex(128,128,(g,w,h)=>{g.save();g.translate(w/2,h/2);g.rotate(Math.PI/2);g.drawImage(TEX.wood.image,-w/2,-h/2);g.restore();});
TEX.stone=canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // ashlar: 4 m tile, blocks 1.2 x 0.6 m, coursed
 const CH=38,BW=76,MJ=3;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const course=Math.floor(y/CH),off=(course%2)*BW/2,bx=Math.floor((x+off)/BW);
  const fx=(x+off)%BW,fy=y%CH;
  const joint=fx<MJ||fy<MJ;
  let v=196+(h3(bx*1.7,course*2.3,4.4)-.5)*30;                // block-to-block tone
  v+=(fbm(x/18,y/18,2.2,3)-.5)*22;                            // weathering mottle
  v+=(fbm(x/3,y/3,9.1,1)-.5)*10;                              // grit
  if(joint)v=118+(fbm(x/4,y/4,1.1,1)-.5)*20;                  // recessed mortar
  else if(fx<MJ+2||fy<MJ+2)v+=10;                             // lit arris
  const damp=clamp((fbm(x/20,y/120,5.5,2)-.5)*3,0,1)*clamp(fy/CH*1.2,0,1);v-=damp*18;
  d[i]=v;d[i+1]=v*.95;d[i+2]=v*.87;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.plaster=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  let v=208+(fbm(x/30,y/30,3.3,3)-.5)*26+(fbm(x/4,y/4,6.6,1)-.5)*12;   // trowelled render
  const crack=fbm(x/12,y/12,2.1,2);if(Math.abs(crack-.5)<.006)v-=70;    // hairline cracks
  const patch=fbm(x/40,y/40,8.8,2);if(patch>.68)v-=14;                  // repaired patches a shade off
  d[i]=v;d[i+1]=v*.96;d[i+2]=v*.9;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.thatch=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const row=Math.floor(y/43),fy=y%43;                          // ~0.67 m courses of frond
  let v=172+(h3(Math.floor(x/2)*1.3,row,2.2)-.5)*52;           // strand to strand
  v+=(fbm(x/1.6,y/18,3.1,2)-.5)*36;                            // fibres running down
  v+=(fbm(x/20,y/20,7.7,2)-.5)*18;                             // patchy fading
  v-=clamp((fy-30)/13,0,1)*34;                                 // soft shadow under each course
  if(fy<2)v+=10;                                               // the lit edge of the course above
  d[i]=v;d[i+1]=v*.9;d[i+2]=v*.7;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.shingle=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // split timber shingles, 0.25 x 0.5 m
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
  const row=Math.floor(y/16),off=(row%2)*16,sx=Math.floor((x+off)/32),fx=(x+off)%32,fy=y%16;
  let v=170+(h3(sx*2.1,row*1.7,3.3)-.5)*46+(fbm(x/3,y/9,5.2,1)-.5)*16;
  if(fx<2)v-=40;if(fy>13)v-=50;else if(fy<1)v+=14;
  d[i]=v;d[i+1]=v*.92;d[i+2]=v*.8;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.stripes=canvasTex(128,64,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // awning cloth: 6 stripes, tinted colour alternates with off-white
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const on=Math.floor(x/(w/6))%2;
  const weave=((x%3)<1?-1:0)+((y%3)<1?-1:0);const v=(on?250:120)+weave*8+(fbm(x/20,y/20,4,2)-.5)*16;
  d[i]=v;d[i+1]=v;d[i+2]=v;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.dirt=canvasTex(512,512,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // ground: packed red-brown earth with grass, for the showcase
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const n=fbm(x/60,y/60,.7,3),n2=fbm(x/7,y/7,3.2,2),gr=clamp((fbm(x/40,y/40,5.5,2)-.5)*3,0,1);
  let r=118+(n-.5)*50+(n2-.5)*22,gg=82+(n-.5)*36+(n2-.5)*14,b=58+(n-.5)*26;
  r=lerp(r,70+n2*30,gr);gg=lerp(gg,98+n2*36,gr);b=lerp(b,40,gr);d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;}
 g.putImageData(id,0,0);});

// ---------------------------------------------------------------- world-unit UVs
// Instances share one geometry, so a box's 0..1 UVs would stretch one texture
// tile over a 20 m wall and squash it on a 0.2 m beam. This hook reads the
// instance scale in the vertex shader and picks, per face normal, the two axes
// that face spans, so every map tiles in metres whatever the instance size.
// K = 1 / (metres per texture tile). kbake() carries onBeforeCompile across
// its material clone.
function vWorldUV(mat,K){mat.userData.uvK=K;mat.onBeforeCompile=sh=>{sh.vertexShader=sh.vertexShader.replace('#include <uv_vertex>',
`#ifdef USE_UV
#ifdef USE_INSTANCING
mat4 _im=instanceMatrix;
vec3 _sc=vec3(length(_im[0].xyz),length(_im[1].xyz),length(_im[2].xyz));
vec3 _an=abs(normal);
vec2 _sw=(_an.y>0.5)?vec2(_sc.x,_sc.z):((_an.x>0.5)?vec2(_sc.z,_sc.y):vec2(_sc.x,_sc.y));
vUv=uv*_sw*${K.toFixed(4)};
#else
vUv=uv;
#endif
#endif`);};return mat;}
// A plain mesh keeps the UVs its geometry carries (the kit's lathes and grids are drawn in 8 m tile units, the
// vernacular ones in the material's own tile); only INSTANCES are re-tiled by their scale. Before this the hook
// re-scaled the kit's skyscraper shells by K too, so their panels tiled every 64 m and read as untextured.

// ---------------------------------------------------------------- materials
MAT.wood=new THREE.MeshStandardMaterial({map:TEX.wood,color:0xffffff,roughness:.92,metalness:0,side:DS});
MAT.woodV=new THREE.MeshStandardMaterial({map:TEX.woodV,color:0xffffff,roughness:.92,metalness:0,side:DS});
MAT.void=new THREE.MeshBasicMaterial({color:0x0b0907});   // openings: unlit so a doorway reads as a doorway in any light
MAT.stone=new THREE.MeshStandardMaterial({map:TEX.stone,color:0xffffff,roughness:.96,metalness:0,side:DS});
MAT.plaster=new THREE.MeshStandardMaterial({map:TEX.plaster,color:0xffffff,roughness:.97,metalness:0,side:DS});
MAT.thatch=new THREE.MeshStandardMaterial({map:TEX.thatch,color:0xffffff,roughness:1,metalness:0,side:DS});
MAT.shingle=new THREE.MeshStandardMaterial({map:TEX.shingle,color:0xffffff,roughness:.95,metalness:0,side:DS});
MAT.cloth=new THREE.MeshStandardMaterial({map:TEX.stripes,color:0xffffff,roughness:.9,metalness:0,side:DS});
MAT.iron=new THREE.MeshStandardMaterial({color:0x2e2a26,roughness:.62,metalness:.55});
MAT.clay=new THREE.MeshStandardMaterial({color:0x9a5a38,roughness:.9,metalness:0});
MAT.warmPane=new THREE.MeshBasicMaterial({color:0xffcf8a});          // an electrically lit window: rich + civic only
MAT.bulb=new THREE.MeshBasicMaterial({color:0xfff3d6});
MAT.dirt=new THREE.MeshStandardMaterial({map:TEX.dirt,roughness:1});
vWorldUV(MAT.wood,.5);vWorldUV(MAT.woodV,.5);vWorldUV(MAT.stone,.25);vWorldUV(MAT.plaster,.5);vWorldUV(MAT.thatch,.5);vWorldUV(MAT.shingle,.5);vWorldUV(MAT.cloth,.5);
vWorldUV(MAT.corrugate,.5);vWorldUV(MAT.tarp,.5);vWorldUV(MAT.timber,.5);vWorldUV(MAT.white,.125);vWorldUV(MAT.rust,.125);vWorldUV(MAT.verdigris,.25);vWorldUV(MAT.clay,.5);

// ---------------------------------------------------------------- geometry
// Wedge: base 1x1 at y=0, top (tx x tz) at y=1. tz≈0 gives a gable roof with
// its ridge along local x; tx=tz≈0 gives a pyramid; 0.6/0.6 a battered block.
function vnWedgeGeo(tx,tz){const p=[],uv=[],idx=[];const c=[[-.5,0,-.5],[.5,0,-.5],[.5,0,.5],[-.5,0,.5],[-tx/2,1,-tz/2],[tx/2,1,-tz/2],[tx/2,1,tz/2],[-tx/2,1,tz/2]];
 const faces=[[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7],[3,2,1,0]];
 faces.forEach(f=>{const b=p.length/3;f.forEach((vi,i)=>{p.push(...c[vi]);uv.push(i===1||i===2?1:0,i>=2?1:0);});idx.push(b,b+1,b+2,b,b+2,b+3);});
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();return g;}
// A roof SLAB with world-ish UVs so the shingle/thatch courses run across it:
// 1 x 1 x 1 box whose uv is scaled by the caller through the instance? No —
// instances share one geometry, so the texture tiles per unit of scale; the
// maps are drawn at 2 m per tile so a 6 m slab shows 3 courses. Good enough.
const VBOX=new THREE.BoxGeometry(1,1,1);
const VPOST=new THREE.CylinderGeometry(1,1,1,8).translate(0,.5,0);           // base at y=0
const VPOSTB=new THREE.CylinderGeometry(.85,1,1,8).translate(0,.5,0);        // tapering
const VDOME=new THREE.SphereGeometry(1,20,10,0,TAU,0,Math.PI/2);
const VBALL=new THREE.SphereGeometry(1,10,7);
const VCONE=new THREE.ConeGeometry(1,1,10).translate(0,.5,0);
const VPLANE=new THREE.PlaneGeometry(1,1);
const VGABLE=vnWedgeGeo(1,.02), VPYR=vnWedgeGeo(.04,.04), VBATTER=vnWedgeGeo(.86,.86), VHIP=vnWedgeGeo(.5,.04);

// ---------------------------------------------------------------- kit items
kdef('vWood',VBOX,MAT.wood);kdef('vStone',VBOX,MAT.stone);kdef('vPlaster',VBOX,MAT.plaster);kdef('vCorr',VBOX,MAT.corrugate);
kdef('vIron',VBOX,MAT.iron);kdef('vThatchB',VBOX,MAT.thatch);kdef('vShingleB',VBOX,MAT.shingle);kdef('vCopperB',VBOX,MAT.verdigris);
kdef('vPanelB',VBOX,MAT.white);kdef('vRustB',VBOX,MAT.rust);kdef('vClothB',VBOX,MAT.cloth);kdef('vTarpB',VBOX,MAT.tarp);kdef('vClayB',VBOX,MAT.clay);kdef('vDarkB',VBOX,MAT.void);
kdef('vSheet',VPLANE,MAT.corrugate);kdef('vBoard',VPLANE,MAT.wood);kdef('vPlate',VPLANE,MAT.rust);kdef('vPlateW',VPLANE,MAT.white);kdef('vTarp',VPLANE,MAT.tarp);kdef('vCloth',VPLANE,MAT.cloth);
kdef('vPost',VPOST,MAT.woodV);kdef('vPostB',VPOSTB,MAT.woodV);kdef('vPostS',VPOST,MAT.stone);kdef('vPipe',VPOST,MAT.iron);kdef('vPipeR',VPOST,MAT.rust);kdef('vPipeC',VPOST,MAT.verdigris);kdef('vClayPot',VPOSTB,MAT.clay);kdef('vBarrel',new THREE.CylinderGeometry(1,.9,1,10).translate(0,.5,0),MAT.woodV);kdef('vTank',VPOST,MAT.corrugate);kdef('vTankW',new THREE.CylinderGeometry(1,1,1,24).translate(0,.5,0),MAT.white);kdef('vTankR',new THREE.CylinderGeometry(1,1,1,24).translate(0,.5,0),MAT.rust);kdef('vStave',new THREE.CylinderGeometry(1,1,1,14).translate(0,.5,0),MAT.woodV);
kdef('vDomeS',VDOME,MAT.stone);kdef('vDomeC',VDOME,MAT.verdigris);kdef('vDomeP',VDOME,MAT.plaster);kdef('vBall',VBALL,MAT.iron);kdef('vGourd',VBALL,MAT.clay);kdef('vSack',VBALL,MAT.tarp);kdef('vLeaf',VBALL,MAT.moss);
kdef('vConeT',VCONE,MAT.thatch);kdef('vConeC',VCONE,MAT.verdigris);kdef('vConeI',VCONE,MAT.iron);
kdef('vGableS',VGABLE,MAT.shingle);kdef('vGableT',VGABLE,MAT.thatch);kdef('vGableC',VGABLE,MAT.corrugate);kdef('vGableCu',VGABLE,MAT.verdigris);kdef('vGableP',VGABLE,MAT.white);kdef('vGableW',VGABLE,MAT.wood);kdef('vGableSt',VGABLE,MAT.stone);kdef('vGablePl',VGABLE,MAT.plaster);
kdef('vPyrS',VPYR,MAT.stone);kdef('vPyrCu',VPYR,MAT.verdigris);kdef('vPyrT',VPYR,MAT.thatch);kdef('vPyrSh',VPYR,MAT.shingle);kdef('vPyrC',VPYR,MAT.corrugate);
kdef('vBatterS',VBATTER,MAT.stone);kdef('vBatterP',VBATTER,MAT.plaster);kdef('vBatterW',VBATTER,MAT.wood);
kdef('vHipS',VHIP,MAT.shingle);kdef('vHipT',VHIP,MAT.thatch);kdef('vHipCu',VHIP,MAT.verdigris);kdef('vHipC',VHIP,MAT.corrugate);
MAT.ember=new THREE.MeshBasicMaterial({color:0xff7a2a});               // forge/kiln fire — not electric, so allowed anywhere
kdef('vEmber',VBALL,MAT.ember);
kdef('vWinLit',VBOX,MAT.warmPane);kdef('vWinGlass',VBOX,MAT.darkGlass);kdef('vBulb',VBALL,MAT.bulb);kdef('vHoop',new THREE.TorusGeometry(1,.06,5,16),MAT.iron);
kdef('vRope',new THREE.CylinderGeometry(1,1,1,5).translate(0,.5,0),MAT.tarp);
kdef('vFlag',VBOX,MAT.stone);   // paving slabs, tinted
kdef('vRock',VBALL,MAT.stone);kdef('vFinial',VBALL,MAT.verdigris);kdef('vBallW',VBALL,MAT.slab);
// ================================================================= IZIZ VERNACULAR — registry + building blocks
// Every vernacular building is a named function build*(G,o) registered with
// VERN.def(). It builds in a LOCAL frame: origin at the plot centre on the
// ground, +z is the front (door side), y up, metres. VERN.place() sets up the
// group transform (position + yaw) and the kit transform (useGroupXF), so a
// builder never sees world coordinates and the same function serves a
// showcase row and a city lot.
//
// o = {w: 0 poor | 1 middle | 2 rich, v: variant index, lit: override}
const VERN={defs:{},order:[],cur:null,
 def(D){if(!D.key||!D.build)throw new Error('VERN.def needs key+build');D.tags=Object.assign({culture:'iziz-vernacular'},D.tags||{});D.cls=D.cls||'building';VERN.defs[D.key]=D;VERN.order.push(D.key);return D;},
 // key, world x/z, yaw, options. Returns the group. Registers nothing itself:
 // the builder calls vnReg() for its inspector volume(s).
 place(scene,key,x,z,ry,o){const D=VERN.defs[key];if(!D){reportErr('VERN.place: no such key '+key);return null;}
  o=Object.assign({w:1,v:0,scale:1,y:0},o||{});const G=new THREE.Group();G.position.set(x,o.y,z);G.rotation.y=ry||0;if(o.scale!==1)G.scale.setScalar(o.scale);scene.add(G);G.updateMatrix();
  KOFF=[0,0,0];useGroupXF(G);if(o.scale!==1)KXF.s=o.scale;VERN.cur={D,G,x,z,ry:ry||0,o,r0:REG.length};
  try{D.build(G,o);}catch(e){reportErr(key+' '+e.stack);}
  endGroupXF();VERN.cur=null;return G;},
 wealthName:w=>['poor','middle','rich','civic'][w]||'poor',
};
// Inspector volume in the building's local frame (x,z = centre, r radius, h height). Honours o.scale.
function vnReg(name,lx,lz,r,h,tags){const c=VERN.cur;const s=c.o.scale||1;const p=loc(c.x,c.z,lx*s,lz*s,c.ry);
 REG.push({name,x:p[0],y:c.o.y||0,z:p[1],r:r*s,h:h*s,cls:c.D.cls,key:c.D.key,tags:Object.assign({},c.D.tags,tags||{})});}
// A builder that wraps an Ancients-kit builder (which calls REGISTER in its own local frame with KOFF) hands the
// REG entries it produced to this, which moves them into the world frame and stamps the project tags on them.
function vnAdoptREG(r0,nameFn,tags){const c=VERN.cur;const s=c.o.scale||1;for(let i=r0;i<REG.length;i++){const r=REG[i];const p=loc(c.x,c.z,r.x*s,r.z*s,c.ry);
 r.x=p[0];r.z=p[1];r.y=(r.y||0)*s+(c.o.y||0);r.r*=s;r.h*=s;r.cls=c.D.cls;r.key=c.D.key;r.tags=Object.assign({},c.D.tags,tags||{});if(nameFn)r.name=nameFn(r.name);}}
// kput with a uniform scale in the group transform (KXF.s): the vendored kit scales positions through the matrix
// but not the per-instance size, so the size is scaled here. Assignment, not redeclaration — build.py's rule.
// Nested group transforms. The vendored kit's useGroupXF/endGroupXF assume one level: several kit builders open a
// body group of their own (bodyGroup, the sky builders), which REPLACED the placer's transform and then nulled it,
// so a skyscraper placed at a plot rebuilt itself at the world origin at full size. Assignment, not redeclaration:
// the same functions, now a stack that composes the child's local matrix onto the parent's.
const _XFSTACK=[];
useGroupXF=function(P){P.updateMatrix();const parent=KXF;_XFSTACK.push(parent);
 if(parent){KXF={m:parent.m.clone().multiply(P.matrix),q:parent.q.clone().multiply(P.quaternion),s:(parent.s||1)*P.scale.x};if(KXF.s===1)delete KXF.s;}
 else{KXF={m:P.matrix.clone(),q:P.quaternion.clone()};if(P.scale.x!==1)KXF.s=P.scale.x;}};
endGroupXF=function(){KXF=_XFSTACK.length?_XFSTACK.pop():null;};
// Run a kit builder as if the ground were flat at the group's origin. Kit builders ask terrainH() for their aprons and
// fallen fragments in THEIR local frame; in a world with real terrain that returned the ground at the world origin
// (the city plateau, 18 m up) and floated every apron that far above the building.
function withFlatGround(fn){const t=terrainH;terrainH=function(){return 0;};try{return fn();}finally{terrainH=t;}}
const _kputBase=kput;
kput=function(name,p,q,s,c){if(KXF&&KXF.s&&KXF.s!==1){s=typeof s==='number'?s*KXF.s:[s[0]*KXF.s,s[1]*KXF.s,s[2]*KXF.s];}return _kputBase(name,p,q,s,c);};
// local (lx,lz) rotated by ry about Y, then translated — same convention as THREE's rotation.y
function loc(x,z,lx,lz,ry){return[x+lx*Math.cos(ry)+lz*Math.sin(ry),z-lx*Math.sin(ry)+lz*Math.cos(ry)];}
// yaw, then a tilt about the piece's own x, then a roll about its own z
function vQ(ry,tx,rz){const q=qEuler(0,ry||0,0);if(tx)q.multiply(qEuler(tx,0,0));if(rz)q.multiply(qEuler(0,0,rz));return q;}
const vLit=()=>{const c=VERN.cur;return !!(c&&(c.o.lit!==undefined?c.o.lit:c.D.tags.lit));};   // the lighting rule: a def is tagged lit:true only if rich or civic

// ---------------------------------------------------------------- primitives (local frame; y = BASE of the piece)
function vB(item,x,y,z,w,h,d,ry,c){kput(item,[x,y+h/2,z],ry?qEuler(0,ry,0):null,[w,h,d],c||null);}          // box standing on y
function vBq(item,x,y,z,w,h,d,q,c){kput(item,[x,y,z],q||null,[w,h,d],c||null);}                                // box centred at y, any quaternion
function vPst(item,x,y,z,r,h,c,q){kput(item,[x,y,z],q||null,[r,h,r],c||null);}                                 // post/cylinder, base at y
function vPl(item,x,y,z,w,h,ry,c,tilt){kput(item,[x,y,z],vQ(ry,tilt||0,0),[w,h,1],c||null);}                   // plane centred at y, facing local +z
function vBall(item,x,y,z,r,c,sy){kput(item,[x,y,z],null,[r,sy||r,r],c||null);}
// a beam from a to b (local), timber unless another item is named
function vBeam(a,b,w,c,item){beam(item||'vWood',a,b,w,w,c||null);}

// ---------------------------------------------------------------- walls, frames, plinths
// Timber frame: corner posts, intermediate posts every ~2.4 m, sill and head rails on all four faces.
function vnFrame(x,y,z,w,h,d,ry,c,pr){pr=pr||.14;const nx=Math.max(1,Math.round(w/2.4)),nz=Math.max(1,Math.round(d/2.4));
 for(let i=0;i<=nx;i++){const lx=-w/2+w*i/nx;for(const s of[-1,1]){const p=loc(x,z,lx,s*d/2,ry);vPst('vPost',p[0],y,p[1],pr,h,c);}}
 for(let j=1;j<nz;j++){const lz=-d/2+d*j/nz;for(const s of[-1,1]){const p=loc(x,z,s*w/2,lz,ry);vPst('vPost',p[0],y,p[1],pr,h,c);}}
 for(const yy of[y+.12,y+h-.12]){   // sill and head rails on all four faces
  for(const s of[-1,1]){const p=loc(x,z,0,s*d/2,ry);vB('vWood',p[0],yy-.1,p[1],w+pr*2,.2,pr*2.2,ry,c);const q=loc(x,z,s*w/2,0,ry);vB('vWood',q[0],yy-.1,q[1],pr*2.2,.2,d+pr*2,ry,c);}}}
// Stilts under a raised floor: posts at the corners and along the long sides, with a diagonal brace on each face.
function vnStilts(x,y,z,w,d,h,ry,c,pr){pr=pr||.18;const nx=Math.max(1,Math.round(w/2.6)),nz=Math.max(1,Math.round(d/2.6));const pts=[];
 for(let i=0;i<=nx;i++)for(let j=0;j<=nz;j++){if(i>0&&i<nx&&j>0&&j<nz&&rng()<.5)continue;const p=loc(x,z,-w/2+w*i/nx,-d/2+d*j/nz,ry);vPst('vPostB',p[0],y-.3,p[1],pr,h+.3,c);pts.push(p);}
 for(const s of[-1,1]){const a=loc(x,z,-w/2,s*d/2,ry),b=loc(x,z,w/2*.6,s*d/2,ry);vBeam([a[0],y+.2,a[1]],[b[0],y+h-.2,b[1]],.1,c);}
 // pad stones under the posts
 for(const p of pts)vB('vStone',p[0],y-.35,p[1],pr*3.2,.35,pr*3.2,ry,vC(0x9a8a78));}
// Battered stone/plaster plinth the wealthy build on (item vBatterS / vBatterP).
function vnPlinth(item,x,y,z,w,h,d,ry,c){kput(item,[x,y,z],ry?qEuler(0,ry,0):null,[w,h,d],c||null);vB(item==='vBatterS'?'vStone':'vPlaster',x,y+h-.05,z,w*.86+.3,.28,d*.86+.3,ry,c);}
// Mayan stepped cornice in the set's materials: `steps` overhanging bands, each further out, then a cap band set back.
function vnCornice(item,x,y,z,w,d,ry,c,steps,cap){steps=steps||2;let yy=y;for(let k=0;k<steps;k++){const o=.18+.22*k;vB(item,x,yy,z,w+2*o,.32,d+2*o,ry,c);yy+=.32;}
 if(cap!==false)vB(item,x,yy,z,w+.1,.26,d+.1,ry,c&&c.clone().multiplyScalar(1.08));return yy+.26;}
// deco vertical strip: a tall narrow recess with horizontal fins, the old Iziz motif carried into stone or timber
function vnStrip(x,y,z,ry,w,h,frameItem,c){const f=loc(x,z,0,.06,ry);vB('vDarkB',f[0],y,f[1],w,h,.12,ry);
 for(const s of[-1,1]){const p=loc(x,z,s*(w/2+.08),.1,ry);vB(frameItem,p[0],y-.1,p[1],.16,h+.2,.22,ry,c);}
 const n=Math.max(2,Math.round(h/.9));for(let k=1;k<n;k++){const p=loc(x,z,0,.12,ry);vB(frameItem,p[0],y+h*k/n-.05,p[1],w+.1,.1,.26,ry,c);}}
// Salvage patchwork over a face: n mismatched sheets, proud of the wall and a few degrees off square.
function vnPatch(x,y,z,ry,w,h,n){const ITEMS=['vSheet','vSheet','vPlate','vPlateW','vBoard'];
 for(let i=0;i<n;i++){const lx=rr(-w/2+.8,w/2-.8),ly=y+rr(.6,h-.6),pw=rr(1.2,2.8),ph=rr(.9,2.2);const p=loc(x,z,lx,.09+i*.012,ry);
  kput(vPick(ITEMS),[p[0],ly,p[1]],vQ(ry,0,rr(-.09,.09)),[pw,ph,1],null);}}

// ---------------------------------------------------------------- roofs (ridge along local x unless noted)
// Gable: a wall-material wedge closes the gable ends flush with the walls; two roof slabs sit on it and overhang.
function vnGableRoof(x,y,z,w,d,rise,ry,slabItem,slabC,over,endItem,endC,thick){over=over===undefined?.9:over;thick=thick||.24;
 if(endItem)kput(endItem,[x,y,z],ry?qEuler(0,ry,0):null,[w,rise,d],endC||null);
 const a=Math.atan2(rise,d/2),ext=d/2+over,S=Math.hypot(ext,rise*ext/(d/2))+.15;
 for(const s of[-1,1]){const zc=s*ext/2,yc=y+(rise-over*rise/(d/2))/2;const p=loc(x,z,0,zc,ry);
  const q=vQ(ry,s*a,0);const n=new THREE.Vector3(0,1,0).applyQuaternion(q).multiplyScalar(thick*.5);
  kput(slabItem,[p[0]+n.x,yc+n.y,p[1]+n.z],q,[w+2*over,thick,S],slabC||null);}
 vB('vWood',x,y+rise+thick*.35,z,w+2*over+.1,.22,.5,ry,slabC?slabC.clone().multiplyScalar(.8):vC(0x6a4a30));     // ridge cap
 for(const s of[-1,1]){const p=loc(x,z,0,s*(ext+.02),ry);vB('vWood',p[0],y-over*rise/(d/2)-.32+thick*.2,p[1],w+2*over,.28,.12,ry,vC(0x6a4a30));}}   // fascia
// Shed: one slab, high at the back (-z), low at the front (+z).
function vnShedRoof(x,y,z,w,d,rise,ry,item,c,over,thick){over=over===undefined?.7:over;thick=thick||.2;const a=Math.atan2(rise,d);const ext=d+2*over,S=ext/Math.cos(a);
 const p=loc(x,z,0,0,ry);const q=vQ(ry,a,0);const n=new THREE.Vector3(0,1,0).applyQuaternion(q).multiplyScalar(thick*.5);
 kput(item,[p[0]+n.x,y+rise/2+n.y,p[1]+n.z],q,[w+2*over,thick,S],c||null);}
// Solid hipped / pyramidal roofs (the wedge items). `over` widens the base; the base drops a little so the wall top is buried.
function vnHipRoof(item,x,y,z,w,d,rise,ry,c,over){over=over===undefined?.8:over;kput(item,[x,y-.35,z],ry?qEuler(0,ry,0):null,[w+2*over,rise+.35,d+2*over],c||null);
 vB('vWood',x,y-.62,z,w+2*over+.06,.28,d+2*over+.06,ry,c?c.clone().multiplyScalar(.75):vC(0x5a3e2a));}   // eaves board
function vnPyrRoof(item,x,y,z,w,d,rise,ry,c,over){vnHipRoof(item,x,y,z,w,d,rise,ry,c,over);}
// A thatch cone on a round building; ragged eave by a second slightly larger, shorter cone.
function vnThatchCone(x,y,z,r,rise,c){kput('vConeT',[x,y-.3,z],null,[r*1.18,rise+.3,r*1.18],c||null);kput('vConeT',[x,y-.55,z],null,[r*1.28,.9,r*1.28],c?c.clone().multiplyScalar(.85):null);}

// ---------------------------------------------------------------- openings
// Window on a wall face. (x,z) is the point ON the face, ry the outward direction of the face.
// kind: 'lit' (electric, rich/civic only), 'glass' (dark glazing), 'open' (unglazed dark), 'shut' (boarded)
function vnWin(x,y,z,ry,w,h,kind,frameItem,c,shutters){const f=loc(x,z,0,.05,ry);
 if(kind==='lit')vB('vWinLit',f[0],y,f[1],w,h,.1,ry);else if(kind==='glass')vB('vWinGlass',f[0],y,f[1],w,h,.1,ry);else vB('vDarkB',f[0],y,f[1],w,h,.1,ry);
 if(kind==='shut'){const p=loc(x,z,0,.12,ry);for(let k=0;k<Math.round(h/.3);k++)vB('vWood',p[0],y+k*.3,p[1],w+.1,.26,.08,ry,c);}
 frameItem=frameItem||'vWood';const p=loc(x,z,0,.14,ry);
 for(const s of[-1,1]){const q=loc(x,z,s*(w/2+.07),.14,ry);vB(frameItem,q[0],y-.08,q[1],.14,h+.16,.16,ry,c);}
 vB(frameItem,p[0],y+h,p[1],w+.3,.14,.18,ry,c);vB(frameItem,p[0],y-.12,p[1],w+.34,.12,.28,ry,c);   // head, sill
 if(kind==='glass'||kind==='lit'){vB(frameItem,p[0],y,p[1],.06,h,.1,ry,c);vB(frameItem,p[0],y+h*.5,p[1],w,.06,.1,ry,c);}   // glazing bars
 if(shutters){for(const s of[-1,1]){const q=loc(x,z,s*(w/2+.15+w*.22),.2,ry);kput('vWood',[q[0],y+h/2,q[1]],vQ(ry,0,0).multiply(qEuler(0,-s*.55,0)),[w*.48,h,.05],c||null);}}}
// Door: dark recess, board leaf, jambs + lintel, a threshold step. Optional electric lamp above (lit rule applies).
function vnDoor(x,y,z,ry,w,h,frameItem,c,leafC,step){frameItem=frameItem||'vWood';const f=loc(x,z,0,.03,ry);vB('vDarkB',f[0],y,f[1],w,h,.1,ry);
 const l=loc(x,z,-w*.06,.1,ry);kput('vWood',[l[0],y+h/2,l[1]],vQ(ry,0,0).multiply(qEuler(0,.22,0)),[w*.92,h-.05,.06],leafC||c||null);   // leaf, slightly ajar
 for(const s of[-1,1]){const q=loc(x,z,s*(w/2+.09),.12,ry);vB(frameItem,q[0],y,q[1],.18,h+.18,.2,ry,c);}
 const p=loc(x,z,0,.12,ry);vB(frameItem,p[0],y+h+.06,p[1],w+.5,.2,.26,ry,c);
 if(step!==false){const s=loc(x,z,0,.5,ry);vB(frameItem==='vStone'?'vStone':'vWood',s[0],y-.18,s[1],w+.6,.18,.8,ry,c);}
 if(vLit()){vnLamp(x,y+h+.5,z,ry);}
 // pathing layer: every door is an agent target. World frame, recorded for the city's Paths overlay / life layer.
 if(window.DOORS&&VERN.cur){const c=VERN.cur,sc=c.o.scale||1;const wp=loc(c.x,c.z,x*sc,z*sc,c.ry);DOORS.push({x:wp[0],z:wp[1],ry:ry+c.ry,y:(c.o.y||0)+y*sc,key:c.D.key});}}
// Electric lamp: an iron bracket out of the wall and a bulb under a small hood. Only ever placed through vLit().
function vnLamp(x,y,z,ry){const a=loc(x,z,0,.05,ry),b=loc(x,z,0,.55,ry);vBeam([a[0],y,a[1]],[b[0],y+.02,b[1]],.05,vC(0x2e2a26),'vIron');
 vB('vIron',b[0],y-.02,b[1],.32,.06,.32,ry,vC(0x2e2a26));vBall('vBulb',b[0],y-.16,b[1],.11);}
// A lamp on a post (yards, drill grounds, gates) — electric.
function vnLampPost(x,y,z,h){vPst('vPipe',x,y,z,.07,h,vC(0x2e2a26));vB('vIron',x,y+h,z,.5,.08,.5,0,vC(0x2e2a26));vBall('vBulb',x,y+h-.16,z,.13);}

// ---------------------------------------------------------------- porches, stairs, yards
// Veranda deck on posts along the front; rail with balusters; posts carry up to `postH` for the roof above.
function vnVeranda(x,y,z,w,d,ry,deckH,postH,c,railC){const zc=d/2;vB('vWood',x,y+deckH-.22,z,w,.22,d,ry,c);
 const n=Math.max(2,Math.round(w/2.6));for(let i=0;i<=n;i++){const p=loc(x,z,-w/2+w*i/n,zc-.15,ry);vPst('vPost',p[0],y,p[1],.12,postH,c);
  if(i<n&&deckH>.3){const q=loc(x,z,-w/2+w*(i+.5)/n,zc-.15,ry);vB('vWood',q[0],y+deckH+.85,q[1],w/n-.28,.1,.1,ry,railC||c);   // rail
   for(let k=1;k<4;k++){const b=loc(x,z,-w/2+w*(i+k/4)/n,zc-.15,ry);vB('vWood',b[0],y+deckH,b[1],.06,.85,.06,ry,railC||c);}}}
 if(deckH>.3)for(let k=0;k<Math.round(w/2.6);k++){const p=loc(x,z,-w/2+.2,-d/2+d*(k+.5)/Math.round(w/2.6),ry);vPst('vPostB',p[0],y-.2,p[1],.13,deckH,c);}}
// Straight stair up to a deck: treads and two stringers. Rises `rise` over `steps` treads toward -z (into the building).
function vnStairs(x,y,z,ry,w,rise,steps,item,c){const run=steps*.32;for(let k=0;k<steps;k++){const t=(k+.5)/steps;const p=loc(x,z,0,run/2-run*t,ry);vB(item||'vWood',p[0],y+rise*k/steps,p[1],w,.08,.34,ry,c);}
 for(const s of[-1,1]){const a=loc(x,z,s*w/2,run/2,ry),b=loc(x,z,s*w/2,-run/2,ry);vBeam([a[0],y-.05,a[1]],[b[0],y+rise-.1,b[1]],.12,c);}}
function vnLadder(x,y,z,ry,h,c){const lean=.25;for(const s of[-1,1]){const p=loc(x,z,s*.3,0,ry);kput('vWood',[p[0],y+h/2,p[1]],vQ(ry,lean,0),[.08,h,.08],c||null);}
 for(let k=1;k<h/.36;k++){const t=k*.36;const p=loc(x,z,0,-Math.sin(lean)*(t-h/2),ry);vB('vWood',p[0],y+t*Math.cos(lean)-.03,p[1],.7,.06,.06,ry,c);}}
function vnBarrel(x,y,z,r,h,c){vPst('vBarrel',x,y,z,r,h,c);vBq('vHoop',x,y+h*.25,z,r*1.02,r*1.02,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));vBq('vHoop',x,y+h*.78,z,r*1.02,r*1.02,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));}
function vnWaterButt(x,y,z,r,h){vPst('vTank',x,y,z,r,h,null);vB('vIron',x,y+h,z,r*1.9,.08,r*1.9,0,vC(0x2e2a26));}
function vnCrate(x,y,z,s,ry,c){vB('vWood',x,y,z,s,s*.8,s*.9,ry,c||vC(vPick(VPAL.woodMid)));}
function vnSacks(x,y,z,n){for(let i=0;i<n;i++)kput('vSack',[x+rr(-.6,.6),y+.32+((i>2)?.45:0),z+rr(-.5,.5)],qEuler(0,rng()*TAU,0),[.42,.32,.36],vC(vPick([0xb8a080,0xa89070,0xc8b898])));}
function vnPlanter(x,y,z,w,d,ry,c){vB('vWood',x,y,z,w,.55,d,ry,c);for(let k=0;k<Math.max(1,Math.round(w*d/1.2));k++)kput('vLeaf',[x+rr(-w*.35,w*.35),y+.62,z+rr(-d*.3,d*.3)],null,[rr(.28,.5),rr(.22,.42),rr(.28,.5)],vC(vPick([0x3f7a34,0x4f9a3a,0x2f6a2a,0x6aa04a])));}
function vnDryingRack(x,y,z,ry,L){for(const s of[-1,1]){const p=loc(x,z,s*L/2,0,ry);vPst('vPost',p[0],y,p[1],.06,2.2,vC(0x8a7a66));}
 const a=loc(x,z,-L/2,0,ry),b=loc(x,z,L/2,0,ry);vBeam([a[0],y+2.1,a[1]],[b[0],y+2.1,b[1]],.03,vC(0xb8a888),'vRope');
 for(let k=0;k<Math.round(L/.9);k++){const p=loc(x,z,-L/2+.5+k*.9,0,ry);kput('vCloth',[p[0],y+1.55,p[1]],vQ(ry,0,0),[.6,1.05,1],vC(vPick(VPAL.awning)));}}
// Striped awning on two poles, sloping down and out from the wall at (x,z,ry-face).
function vnAwning(x,y,z,ry,w,out,c){const q=vQ(ry,.42,0);const p=loc(x,z,0,out/2,ry);const n=new THREE.Vector3(0,1,0).applyQuaternion(q);
 kput('vClothB',[p[0]+n.x*.03,y-Math.tan(.42)*out/2+.35,p[1]+n.z*.03],q,[w,.06,out/Math.cos(.42)],c||vC(vPick(VPAL.awning)));
 for(const s of[-1,1]){const pp=loc(x,z,s*(w/2-.1),out-.1,ry);vPst('vPost',pp[0],y-3,pp[1],.05,y-Math.tan(.42)*out+.3-(y-3),vC(0x6a5a48));}}
function vnBannerPole(x,y,z,ry,h,c){vPst('vPost',x,y,z,.08,h,vC(0x5a4632));const p=loc(x,z,.55,0,ry);vB('vWood',p[0],y+h-.2,p[1],1.1,.08,.08,ry,vC(0x5a4632));
 kput('vCloth',[p[0],y+h-1.6,p[1]],vQ(ry+Math.PI/2,0,0),[.7,2.7,1],c||vC(vPick(VPAL.orange)));}
function vnChimney(x,y,z,h,r,rusty){vPst(rusty?'vPipeR':'vPipe',x,y,z,r,h,null);vB('vIron',x,y+h+.1,z,r*3,.08,r*3,0,vC(0x2e2a26));for(const s of[-1,1])vB('vIron',x+s*r*1.1,y+h-.05,z,.06,.2,.06,0,vC(0x2e2a26));}
// Fence of posts and two rails around a rectangle (gap at the front centre of width `gate`).
function vnFence(x,y,z,w,d,ry,c,gate,h){h=h||1.3;const segs=[[[-w/2,-d/2],[w/2,-d/2]],[[w/2,-d/2],[w/2,d/2]],[[-w/2,d/2],[-w/2,-d/2]]];
 if(gate){segs.push([[-w/2,d/2],[-gate/2,d/2]],[[gate/2,d/2],[w/2,d/2]]);}else segs.push([[w/2,d/2],[-w/2,d/2]]);
 for(const s of segs){const L=Math.hypot(s[1][0]-s[0][0],s[1][1]-s[0][1]);const n=Math.max(1,Math.round(L/2.2));
  for(let i=0;i<=n;i++){const p=loc(x,z,s[0][0]+(s[1][0]-s[0][0])*i/n,s[0][1]+(s[1][1]-s[0][1])*i/n,ry);vPst('vPost',p[0],y,p[1],.07,h,c);}
  const a=loc(x,z,s[0][0],s[0][1],ry),b=loc(x,z,s[1][0],s[1][1],ry);for(const yy of[.5,1.1])vBeam([a[0],y+yy*h/1.3,a[1]],[b[0],y+yy*h/1.3,b[1]],.07,c);}}
// Palisade: close-set sharpened logs on a low earth bank, with a walkway rail behind.
function vnPalisade(x,y,z,w,d,ry,h,gate){const c=vC(0x7a5a3e);const segs=[[[-w/2,-d/2],[w/2,-d/2]],[[w/2,-d/2],[w/2,d/2]],[[-w/2,d/2],[-w/2,-d/2]],[[-w/2,d/2],[-gate/2,d/2]],[[gate/2,d/2],[w/2,d/2]]];
 for(const s of segs){const L=Math.hypot(s[1][0]-s[0][0],s[1][1]-s[0][1]);const n=Math.round(L/.42);
  for(let i=0;i<=n;i++){const p=loc(x,z,s[0][0]+(s[1][0]-s[0][0])*i/n,s[0][1]+(s[1][1]-s[0][1])*i/n,ry);vPst('vPostB',p[0],y-.2,p[1],.2,h+rr(-.25,.25),c.clone().multiplyScalar(rr(.85,1.1)));kput('vConeI',[p[0],y+h-.15,p[1]],null,[.2,.5,.2],c);}
  const a=loc(x,z,s[0][0],s[0][1],ry),b=loc(x,z,s[1][0],s[1][1],ry);vBeam([a[0],y+h*.55,a[1]],[b[0],y+h*.55,b[1]],.14,c);}}
// A few townsfolk for scale (the kit's own figure items), tinted like Iziz robes.
function vnFolk(x,z,n,spread){for(let i=0;i<n;i++){const px=x+rr(-spread,spread),pz=z+rr(-spread,spread);kput('figB',[px,0,pz],qEuler(0,rng()*TAU,0),1,vC(vPick([0xe8d9b8,0xc9442a,0x2f8f8a,0x7a3d8a,0xe0a030,0x3b4a8a,0x8a6a3a])));kput('figH',[px,0,pz],null,1,vC(0xc9a17e));}}
// paved yard / threshold slabs
function vnPaving(x,y,z,w,d,ry,c,n){n=n||Math.round(w*d/4);for(let i=0;i<n;i++){const p=loc(x,z,rr(-w/2,w/2),rr(-d/2,d/2),ry);vB('vFlag',p[0],y-.06,p[1],rr(1.1,2.2),.1,rr(.9,1.8),ry+rr(-.1,.1),c||vC(vPick(VPAL.stoneDark)));}}
// ================================================================= IZIZ VERNACULAR — dwellings
// Three wealth tiers, front toward +z. Poor: stilts, boards, salvage, thatch,
// no light. Middle: timber frame, plaster, wooden stepped cornice, shutter
// strips, salvaged-sheet roofs, no light. Rich: battered stone, stone cornice
// and deco strips, hardwood upper storey, copper roof, courtyard wall,
// electric lamps and lit glazing.
const VTAG_SF={type:['single-family dwelling']},VTAG_MF={type:['multi-family dwelling']};

// ---------------------------------------------------------------- POOR
// A — stilt hut: a board box on stilts under a steep thatch gable, ladder up to a front platform
function buildVernPoorA(G,o){reseed(7101+(o.v|0));const W=5.6,D=6.2,FL=1.7,H=2.5;const wood=vC(vPick(VPAL.woodPoor)),th=vC(vPick(VPAL.thatch));
 vnReg('Stilt hut (poor)',0,0,5.6,FL+H+3.6);
 vnStilts(0,0,0,W-.7,D-.7,FL,0,wood);
 vB('vWood',0,FL-.2,0,W,.2,D,0,wood);                                   // floor
 vB('vWood',0,FL,0,W-.3,H,D-.3,0,wood.clone().multiplyScalar(.94));     // board walls
 vnPatch(0,FL,D/2-.15,0,W-.3,H,3);vnPatch(-W/2+.15,FL,0,-Math.PI/2,D-.3,H,2);vnPatch(0,FL,-D/2+.15,Math.PI,W-.3,H,2);
 vnGableRoof(0,FL+H,0,W-.3,D-.3,2.7,0,'vGableT',th,1.15,'vGableW',wood,.5);
 vB('vWood',0,FL-.2,D/2+.75,2.6,.2,1.5,0,wood);                         // front platform
 for(const s of[-1,1])vPst('vPostB',s*1.2,-.2,D/2+1.35,.14,FL,wood);
 vnLadder(0,0,D/2+1.9,0,FL+.3,wood);
 vnDoor(0,FL,D/2-.15,0,.95,1.85,'vWood',wood,vC(0x7a6a58),false);
 vnWin(-1.7,FL+1.2,D/2-.15,0,.85,.7,'open','vWood',wood);vPl('vTarp',-1.7,FL+1.25,D/2+.03,.95,.62,0,vC(0xb8a070),-.35);   // woven blind, rolled half down
 vnWin(W/2-.15,FL+1.2,-.6,Math.PI/2,.85,.7,'open','vWood',wood);
 for(let k=0;k<4;k++)vBall('vGourd',-W/2+.6+k*1.2,FL+H-.35,D/2+.9,.17,vC(vPick([0xb08a4a,0x8a9a3a,0xc09a5a])),.24);   // gourds under the eave
 vnWaterButt(W/2+1.0,0,D/2-.9,.42,1.1);vnDryingRack(-W/2-1.6,0,.8,Math.PI/2,3.2);vnCrate(W/2+1.1,0,-1.4,.9,.3);
 vnFolk(2.2,D/2+3.4,2,1.2);}
// B — corrugate shack: a salvage box on a rubble pad under a shed roof weighted with stones, lean-to on one side
function buildVernPoorB(G,o){reseed(7111+(o.v|0));const W=6,D=5,H=2.6;const wood=vC(vPick(VPAL.woodPoor));
 vnReg('Corrugate shack (poor)',0,0,5.6,H+2.2);
 vnPaving(0,.05,0,W+2,D+2,0,vC(0x8a7a6a),14);vB('vStone',0,0,0,W+.6,.35,D+.6,0,vC(0x9a8a78));
 vnFrame(0,.35,0,W,H,D,0,wood,.12);
 vB('vCorr',0,.35,0,W-.2,H,D-.2,0);                                     // corrugate skin inside the frame
 vnPatch(0,.35,D/2-.1,0,W,H,4);vnPatch(W/2-.1,.35,0,Math.PI/2,D,H,3);vnPatch(0,.35,-D/2+.1,Math.PI,W,H,3);
 vnShedRoof(0,.35+H,0,W,D,1.1,0,'vCorr',null,.8,.12);
 for(let k=0;k<7;k++){const zz=rr(-D/2+.6,D/2-.6);kput('vRock',[rr(-W/2,W/2),.35+H+1.1*(zz+D/2)/D+.14,zz],qEuler(rng(),rng(),0),[.3,.22,.28],vC(vPick([0x8a8078,0x6a625a,0x9a9088])));}   // stones holding the sheet down
 vnDoor(-1.4,.35,D/2-.1,0,.95,1.9,'vWood',wood,vC(0x8a7a66));
 vnWin(1.5,.35+1.2,D/2-.1,0,.9,.6,'shut','vWood',wood);
 vnChimney(W/2-.8,.35+H+.6,-D/2+.9,1.6,.14,true);
 // lean-to: tarp on poles against the +x wall
 for(const z of[-D/2+.2,D/2-.2])vPst('vPost',W/2+2.4,0,z,.07,2.1,wood);
 kput('vTarpB',[W/2+1.25,.35+H-.5,0],vQ(0,0,.28),[2.7,.06,D-.2],vC(0xb0a080));
 vnBarrel(W/2+1.6,0,-1.2,.42,1.0,wood);vnCrate(W/2+1.9,0,.6,.8,.2,wood);vnSacks(W/2+1.1,0,1.4,4);
 vnFolk(-2.5,D/2+3,2,1);}
// C — panel house: timber frame filled with cut Ancient panels, ghost-white and rust, under a thatch hip roof; low veranda
function buildVernPoorC(G,o){reseed(7121+(o.v|0));const W=6.6,D=6.4,FL=.6,H=2.7;const wood=vC(vPick(VPAL.woodPoor)),th=vC(vPick(VPAL.thatch));
 vnReg('Panel house (poor)',0,0,6.2,FL+H+3.4);
 vnStilts(0,0,0,W-.5,D-.5,FL,0,wood,.15);vB('vWood',0,FL-.18,0,W,.18,D,0,wood);
 vnFrame(0,FL,0,W-.2,H,D-.2,0,wood,.13);
 // infill: one panel per bay, alternating ghost-white and rusted plate, each a little off
 const bays=[[0,D/2-.1,W-.2,0],[0,-D/2+.1,W-.2,Math.PI],[W/2-.1,0,D-.2,Math.PI/2],[-W/2+.1,0,D-.2,-Math.PI/2]];
 for(const b of bays){const n=Math.round(b[2]/2.2);for(let i=0;i<n;i++){const lx=-b[2]/2+b[2]*(i+.5)/n;const p=loc(b[0],b[1],lx,-.05,b[3]);
  kput(rng()<.6?'vPanelB':'vRustB',[p[0],FL+H/2,p[1]],vQ(b[3],0,rr(-.03,.03)),[b[2]/n-.3,H-.25,.08],null);}}
 vnHipRoof('vHipT',0,FL+H,0,W,D,2.4,0,th,1.25);
 vnVeranda(0,0,D/2+1.0,W-.8,2.0,0,FL,2.5,wood);vnStairs(1.6,0,D/2+2.3,0,1.1,FL,3,'vWood',wood);
 vnShedRoof(0,FL+2.5,D/2+1.0,W-.8,2.0,.5,0,'vThatchB',th,.5,.3);
 vnDoor(-.6,FL,D/2-.1,0,.95,1.9,'vWood',wood,vC(0x6a5a4a),false);
 vnWin(1.9,FL+1.3,D/2-.1,0,.9,.8,'open','vWood',wood,true);vnWin(-W/2+.1,FL+1.4,.4,-Math.PI/2,.9,.7,'shut','vWood',wood);
 vnWaterButt(-W/2-.9,0,D/2-1.2,.4,1.0);vnPlanter(W/2+.9,0,D/2-.5,1.6,.7,0,wood);vnCrate(-W/2-1.1,0,-1.6,.8,.5,wood);
 vnFolk(-2.4,D/2+3.6,2,1.1);}

// ---------------------------------------------------------------- MIDDLE
// A — plaster townhouse: two storeys, exposed corner posts and string course, shutter strips above, salvaged-sheet gable roof
function buildVernMidA(G,o){reseed(7201+(o.v|0));const W=8.4,D=8.8,H1=3.3,H2=3.0,Y0=.4;const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand));
 vnReg('Plaster townhouse (middle)',0,0,7.6,Y0+H1+H2+3.6);
 vB('vStone',0,-.1,0,W+.5,.5,D+.5,0,vC(vPick(VPAL.stoneDark)));
 vB('vPlaster',0,Y0,0,W,H1,D,0,pl);vB('vWood',0,Y0+H1,0,W+.34,.3,D+.34,0,wood);vB('vPlaster',0,Y0+H1+.3,0,W,H2,D,0,pl.clone().multiplyScalar(1.04));
 for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',sx*(W/2-.02),Y0,sz*(D/2-.02),.17,H1+H2+.32,wood);
 const top=vnCornice('vWood',0,Y0+H1+.3+H2,0,W,D,0,wood,2);
 vnGableRoof(0,top,0,W,D,2.5,0,'vGableC',null,1.0,'vGablePl',pl,.16);
 // ground floor: door left, shuttered window right, side windows
 vnDoor(-1.6,Y0,D/2,0,1.15,2.3,'vWood',wood,vC(0x6a4a30));
 vnWin(2.1,Y0+1.1,D/2,0,1.3,1.3,'open','vWood',wood,true);
 vnWin(W/2,Y0+1.2,-1.8,Math.PI/2,1.1,1.2,'shut','vWood',wood);vnWin(W/2,Y0+1.2,1.8,Math.PI/2,1.1,1.2,'open','vWood',wood,true);
 vnWin(-W/2,Y0+1.2,0,-Math.PI/2,1.1,1.2,'open','vWood',wood,true);vnWin(0,Y0+1.3,-D/2,Math.PI,1.1,1.1,'shut','vWood',wood);
 // upper floor: three deco shutter strips on the front, two each side
 for(const x of[-2.5,0,2.5])vnStrip(x,Y0+H1+.7,D/2,0,.75,2.2,'vWood',wood);
 for(const s of[-1,1])for(const z of[-2.2,2.2])vnStrip(s*W/2,Y0+H1+.7,z,s*Math.PI/2,.7,2.0,'vWood',wood);
 // porch over the door and an awning over the window
 vnVeranda(-1.6,Y0,D/2+1.1,3.6,2.2,0,.04,2.7,wood);vnShedRoof(-1.6,Y0+2.7,D/2+1.1,3.6,2.2,.7,0,'vPanelB',null,.4,.1);
 vnAwning(2.1,Y0+2.6,D/2,0,2.0,1.2,vC(vPick(VPAL.awning)));
 vnPlanter(3.6,Y0-.1,D/2+.9,1.4,.6,0,wood);vnPlanter(-4.0,Y0-.1,D/2+.9,1.2,.6,0,wood);vnBarrel(W/2+.8,0,-D/2+1.2,.4,1.0,wood);
 vnPaving(0,.02,D/2+2.6,W,2.2,0,vC(vPick(VPAL.stoneDark)),10);vnFolk(1.5,D/2+4,3,1.4);}
// B — setback house: a big plaster ground storey, a smaller upper storey set back behind a roof terrace; two households, outside stair
function buildVernMidB(G,o){reseed(7211+(o.v|0));const W=9.4,D=9,H1=3.4,W2=6.2,D2=5.6,H2=2.9,Y0=.35;const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand)),pl2=vC(vPick(VPAL.adobe));const Z2=-(D-D2)/2+.25;
 vnReg('Setback house (middle, two households)',0,0,8.2,Y0+H1+H2+3.2);
 vB('vStone',0,-.1,0,W+.5,.45,D+.5,0,vC(vPick(VPAL.stoneDark)));
 vB('vPlaster',0,Y0,0,W,H1,D,0,pl);const t1=vnCornice('vWood',0,Y0+H1,0,W,D,0,wood,2,false);
 vB('vWood',0,t1,0,W+.3,.2,D+.3,0,wood);                                // terrace deck edge
 vB('vPlaster',0,t1+.2,Z2,W2,H2,D2,0,pl2);vnCornice('vWood',0,t1+.2+H2,Z2,W2,D2,0,wood,2);
 vnHipRoof('vHipC',0,t1+.2+H2+.84,Z2,W2,D2,2.0,0,null,1.1);
 for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',sx*(W/2-.02),Y0,sz*(D/2-.02),.17,H1+.7,wood);
 // terrace rail (front and sides), a cloth awning on poles over the terrace
 {const y=t1+.2,zf=D/2-.12;for(let i=0;i<=6;i++){vPst('vPost',-W/2+.3+(W-.6)*i/6,y,zf,.07,1.0,wood);}
  vB('vWood',0,y+.95,zf,W-.4,.1,.1,0,wood);for(const s of[-1,1]){const x=s*(W/2-.12);for(let j=0;j<=2;j++)vPst('vPost',x,y,Z2+D2/2+.3+(zf-Z2-D2/2-.3)*j/2,.07,1.0,wood);vB('vWood',x,y+.95,(Z2+D2/2+.3+zf)/2,.1,.1,zf-(Z2+D2/2+.3),0,wood);}
  for(const s of[-1,1])vPst('vPost',s*2.6,y,D/2-.6,.07,2.5,wood);kput('vClothB',[0,y+2.55,Z2+D2/2+1.5],vQ(0,.12,0),[6.2,.06,3.4],vC(vPick(VPAL.awning)));}
 // doors: two on the ground front; the upper household's door opens onto the terrace
 vnDoor(-2.6,Y0,D/2,0,1.1,2.2,'vWood',wood,vC(0x6a4a30));vnDoor(2.6,Y0,D/2,0,1.1,2.2,'vWood',wood,vC(0x8a5a36));
 vnDoor(0,t1+.2,Z2+D2/2,0,1.0,2.0,'vWood',wood,vC(0x6a4a30),false);
 vnWin(0,Y0+1.2,D/2,0,1.3,1.2,'open','vWood',wood,true);
 for(const s of[-1,1]){vnWin(s*W/2,Y0+1.2,-2,s*Math.PI/2,1.1,1.2,'open','vWood',wood,true);vnWin(s*W/2,Y0+1.2,2,s*Math.PI/2,1.1,1.2,'shut','vWood',wood);
  vnWin(s*W2/2,t1+.2+1.0,Z2,s*Math.PI/2,1.0,1.1,'open','vWood',wood,true);}
 vnStrip(-1.9,t1+.6,Z2+D2/2,0,.7,1.9,'vWood',wood);vnStrip(1.9,t1+.6,Z2+D2/2,0,.7,1.9,'vWood',wood);vnWin(0,t1+.2+1.1,Z2-D2/2,Math.PI,1.1,1.0,'shut','vWood',wood);
 // outside stair up the +x side to the terrace
 {const steps=11,run=steps*.32;vnStairs(W/2+.7,Y0,D/2-run/2-.4,0,1.1,t1-Y0,steps,'vWood',wood);
  vB('vWood',W/2+.7,t1-.05,-D/2+1.1,1.2,.15,2.2,0,wood);for(let k=0;k<=3;k++)vPst('vPostB',W/2+.7+(k%2?.5:-.5),0,D/2-run*(k/3)-.4,.12,Y0+(t1-Y0)*(k/3)+.4,wood);}
 vnPlanter(-3.8,t1+.2,D/2-.5,1.4,.6,0,wood);vnPlanter(3.8,t1+.2,D/2-.5,1.4,.6,0,wood);vnBarrel(-W/2-.8,0,D/2-1,.4,1.0,wood);vnCrate(-W/2-1,0,-1.5,.9,.4,wood);
 vnDryingRack(0,t1+.2,Z2-D2/2-1.2,0,3.6);vnFolk(0,D/2+3.6,3,1.6);}
// C — long house: timber frame and plaster under a broad shingle hip roof, full-width veranda, fenced front yard
function buildVernMidC(G,o){reseed(7221+(o.v|0));const W=11,D=7.2,H=3.7,FL=.5;const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.adobe)),sh=vC(vPick([0x8a6a4a,0x7a5a3e,0x9a7a56]));
 vnReg('Long house (middle)',0,0,9.5,FL+H+3.6);
 vnStilts(0,0,0,W-.6,D-.6,FL,0,wood,.16);vB('vWood',0,FL-.2,0,W+.2,.2,D+.2,0,wood);
 vnFrame(0,FL,0,W,H,D,0,wood,.15);vB('vPlaster',0,FL,0,W-.12,H,D-.12,0,pl);
 vnCornice('vWood',0,FL+H,0,W,D,0,wood,1,false);
 vnHipRoof('vHipS',0,FL+H+.32,0,W,D,2.8,0,sh,1.3);
 vnVeranda(0,0,D/2+1.15,W-.4,2.3,0,FL,2.7,wood);vnStairs(-3.2,0,D/2+2.6,0,1.3,FL,3,'vWood',wood);
 vnShedRoof(0,FL+2.7,D/2+1.15,W-.4,2.3,.6,0,'vShingleB',sh,.5,.14);
 vnDoor(-1.8,FL,D/2-.06,0,1.1,2.2,'vWood',wood,vC(0x6a4a30),false);vnDoor(2.8,FL,D/2-.06,0,1.0,2.1,'vWood',wood,vC(0x7a5a36),false);
 vnWin(0.5,FL+1.2,D/2-.06,0,1.2,1.2,'open','vWood',wood,true);vnWin(-4.2,FL+1.2,D/2-.06,0,1.1,1.2,'shut','vWood',wood);
 for(const s of[-1,1])vnWin(s*W/2,FL+1.3,0,s*Math.PI/2,1.1,1.1,'open','vWood',wood,true);
 for(const x of[-3.5,0,3.5])vnWin(x,FL+1.3,-D/2+.06,Math.PI,1.1,1.1,'shut','vWood',wood);
 vnFence(0,0,D/2+3.6,W+3,3.4,0,wood,1.6,1.1);vnPaving(0,.02,D/2+3.5,1.6,3.2,0,vC(vPick(VPAL.stoneDark)),6);
 vnPlanter(-W/2+1.2,0,D/2+2.5,1.6,.7,0,wood);vnPlanter(W/2-1.2,0,D/2+2.5,1.6,.7,0,wood);vnWaterButt(W/2+.9,0,-1.5,.42,1.1);vnDryingRack(-W/2-1.6,0,0,Math.PI/2,3.4);
 for(let k=0;k<3;k++)vBall('vGourd',-W/2+1.4+k*1.1,FL+H-.2,D/2+2.2,.16,vC(vPick([0xb08a4a,0x8a9a3a])),.22);
 vnFolk(2,D/2+5.6,3,1.4);}

// ---------------------------------------------------------------- RICH
// battered face helper: half-width of a batter wedge (taper .86) at height y above its base
const vBatHalf=(W,H,y)=>W/2*(1-.14*clamp(y/H,0,1));
// A — stone manor: battered ashlar ground storey with stepped stone cornice and fluted strips, hardwood gallery storey, copper hip roof, corner tower, walled court
function buildVernRichA(G,o){reseed(7301+(o.v|0));const W=14,D=12,H1=4.6,W2=11,D2=9.4,H2=3.4,Y0=.6;const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),cu=vC(0xffffff);
 vnReg('Stone manor (rich)',0,0,15,Y0+H1+H2+4.5);vnReg('Manor courtyard wall',0,0,14.5,2.6,{type:['single-family dwelling'],part:'wall'});
 // court: paving, wall, gate, lamps
 vB('vStone',0,0,0,W+2,Y0,D+2,0,stD);                                                  // raised stone terrace
 {const CW=26,CD=22,h=2.4;for(const s of[-1,1]){vB('vStone',s*CW/2,0,0,.6,h,CD,0,stD);vB('vStone',s*CW/2,h,0,.9,.3,CD+.3,0,st);}
  vB('vStone',0,0,-CD/2,CW,h,.6,0,stD);vB('vStone',0,h,-CD/2,CW+.3,.3,.9,0,st);
  for(const s of[-1,1]){const L=CW/2-2;vB('vStone',s*(2+L/2),0,CD/2,L,h,.6,0,stD);vB('vStone',s*(2+L/2),h,CD/2,L+.3,.3,.9,0,st);
   vB('vStone',s*2.3,0,CD/2,1.0,h+.9,1.0,0,st);kput('vPyrCu',[s*2.3,h+.9,CD/2],null,[1.2,.7,1.2],cu);vnLampPost(s*3.4,0,CD/2+1.2,3.2);}
  for(let k=-3;k<=3;k++)vB('vIron',k*.5,0,CD/2,.06,h-.3,.06,0,vC(0x2e2a26));vB('vIron',0,h-.5,CD/2,3.6,.08,.08,0,vC(0x2e2a26));vB('vIron',0,.6,CD/2,3.6,.08,.08,0,vC(0x2e2a26));   // iron gate
  vnPaving(0,.02,(D/2+1+CD/2)/2,2.6,CD/2-D/2-1,0,st,6);vnPlanter(-5,0,D/2+2.8,2.4,.9,0,wood);vnPlanter(5,0,D/2+2.8,2.4,.9,0,wood);}
 // ground storey
 vnPlinth('vBatterS',0,Y0,0,W,H1,D,0,st);
 const c1=vnCornice('vStone',0,Y0+H1+.2,0,W*.86,D*.86,0,st,3);
 // fluted deco strips and lit windows on the battered face (face recedes with height: offset by vBatHalf)
 {const y=Y0+1.6,hf=vBatHalf(W,H1,1.6),df=vBatHalf(D,H1,1.6);
  for(const x of[-4.6,-2.3,2.3,4.6])vnWin(x,y,df,0,1.2,1.7,'lit','vStone',st);for(const x of[-3.45,0,3.45])vnStrip(x,Y0+.9,df+.02,0,.7,3.2,'vStone',stD);
  for(const s of[-1,1])for(const z of[-3.2,0,3.2])vnWin(s*hf,y,z,s*Math.PI/2,1.2,1.7,'lit','vStone',st);for(const x of[-3.5,0,3.5])vnWin(x,y,-df,Math.PI,1.2,1.7,'glass','vStone',st);}
 vnStairs(0,0,D/2+1.9,0,3.2,Y0,3,'vStone',st);vnDoor(0,Y0,vBatHalf(D,H1,1.3),0,1.7,2.9,'vStone',st,vC(0x4a2e1c));
 // gallery storey in hardwood, balcony to the front
 vB('vWood',0,c1,0,W2,H2,D2,0,wood);for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',sx*(W2/2-.02),c1,sz*(D2/2-.02),.2,H2,wood.clone().multiplyScalar(.8));
 for(const x of[-3.6,-1.2,1.2,3.6])vnWin(x,c1+1.0,D2/2,0,1.2,1.6,'lit','vWood',wood);for(const s of[-1,1])for(const z of[-2.8,0,2.8])vnWin(s*W2/2,c1+1.0,z,s*Math.PI/2,1.1,1.6,'lit','vWood',wood);
 for(const x of[-3.6,0,3.6])vnWin(x,c1+1.0,-D2/2,Math.PI,1.1,1.5,'glass','vWood',wood);
 {const bz=D2/2+.9,bw=W2-1;vB('vWood',0,c1-.25,bz,bw,.25,1.8,0,wood);for(let i=0;i<=5;i++)vPst('vPost',-bw/2+bw*i/5,c1,bz+.8,.09,1.05,wood);vB('vWood',0,c1+1.0,bz+.8,bw,.1,.1,0,wood);
  for(let i=0;i<=5;i++)vBeam([-bw/2+bw*i/5,c1-.3,bz+.7],[-bw/2+bw*i/5,c1-1.3,D*.86/2+.2],.14,wood);}
 const top=vnCornice('vWood',0,c1+H2,0,W2,D2,0,wood,2);vnHipRoof('vHipCu',0,top,0,W2,D2,2.7,0,cu,1.3);
 // corner tower with a copper pyramid cap and finial
 {const tx=-W/2+1.4,tz=-D/2+1.4,TH=Y0+H1+H2+3.2;vB('vStone',tx,Y0,tz,3.8,TH-Y0,3.8,0,st);vnCornice('vStone',tx,TH,tz,3.8,3.8,0,st,2);
  for(let k=0;k<4;k++){const a=k*Math.PI/2;const p=loc(tx,tz,0,1.9,a);vnWin(p[0],TH-2.6,p[1],a,.8,1.4,'lit','vStone',st);}
  kput('vPyrCu',[tx,TH+.9,tz],null,[4.4,2.6,4.4],cu);vBall('vFinial',tx,TH+3.7,tz,.3);}
 for(const x of[-2.4,2.4])vnLamp(x,Y0+3.4,vBatHalf(D,H1,2.8),0);
 vnFolk(0,D/2+6,3,1.6);}
// B — domed house: two storeys of ashlar under a copper dome, stone loggia across the front, corner pyramids, garden wall
function buildVernRichB(G,o){reseed(7311+(o.v|0));const W=12.4,D=11.6,H1=4.0,H2=3.5,Y0=.5;const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),cu=vC(0xffffff);
 vnReg('Domed house (rich)',0,0,13,Y0+H1+H2+6);vnReg('Garden wall',0,0,13.5,2.4,{part:'wall'});
 vB('vStone',0,0,0,W+1.6,Y0,D+1.6,0,stD);
 {const CW=24,CD=21,h=2.1;for(const s of[-1,1]){vB('vStone',s*CW/2,0,0,.55,h,CD,0,stD);vB('vStone',s*CW/2,h,0,.85,.28,CD+.3,0,st);}
  vB('vStone',0,0,-CD/2,CW,h,.55,0,stD);vB('vStone',0,h,-CD/2,CW+.3,.28,.85,0,st);
  for(const s of[-1,1]){const L=CW/2-1.8;vB('vStone',s*(1.8+L/2),0,CD/2,L,h,.55,0,stD);vB('vStone',s*(1.8+L/2),h,CD/2,L+.3,.28,.85,0,st);vB('vStone',s*2.05,0,CD/2,.9,h+.8,.9,0,st);vBall('vFinial',s*2.05,h+1.05,CD/2,.28);}
  vnLampPost(-3.2,0,CD/2+1,3.0);vnLampPost(3.2,0,CD/2+1,3.0);
  for(let k=-2;k<=2;k++)vB('vIron',k*.6,0,CD/2,.06,h-.2,.06,0,vC(0x2e2a26));vB('vIron',0,h-.4,CD/2,3.2,.08,.08,0,vC(0x2e2a26));
  vnPaving(0,.02,(D/2+.8+CD/2)/2,2.4,CD/2-D/2-.8,0,st,5);for(const s of[-1,1]){vnPlanter(s*6,0,D/2+3,2.8,1.0,0,wood);vnPlanter(s*8.5,0,-2,1.0,3.0,0,wood);}}
 vB('vStone',0,Y0,0,W,H1,D,0,st);const c1=vnCornice('vStone',0,Y0+H1,0,W,D,0,st,2);
 vB('vStone',0,c1,0,W-.6,H2,D-.6,0,st.clone().multiplyScalar(1.03));const c2=vnCornice('vStone',0,c1+H2,0,W-.6,D-.6,0,st,3);
 vB('vStone',0,c2,0,W-.4,.6,D-.4,0,stD);                                                 // parapet
 for(const sx of[-1,1])for(const sz of[-1,1]){vB('vStone',sx*(W/2-1.2),c2,sz*(D/2-1.2),1.6,1.2,1.6,0,st);kput('vPyrCu',[sx*(W/2-1.2),c2+1.2,sz*(D/2-1.2)],null,[1.9,1.2,1.9],cu);}
 // drum + dome
 vPst('vPostS',0,c2+.4,0,3.9,1.7,st);vB('vStone',0,c2+2.1,0,8.4,.3,8.4,0,stD);for(let k=0;k<12;k++){const a=k/12*TAU;vB('vDarkB',Math.cos(a)*3.9,c2+.9,Math.sin(a)*3.9,.5,.8,.2,-a+Math.PI/2);}
 kput('vDomeC',[0,c2+2.4,0],null,[4.1,3.3,4.1],cu);vBall('vFinial',0,c2+5.8,0,.32);
 // loggia across the front: stone posts carrying a slab at c1
 {const lz=D/2+1.4;vB('vStone',0,Y0-.02,lz-.2,W-1,.3,2.8,0,stD);for(let i=0;i<=5;i++){const x=-(W-1.6)/2+(W-1.6)*i/5;vPst('vPostS',x,Y0,lz+.9,.24,H1-.2,st);vB('vStone',x,Y0+H1-.2,lz+.9,.7,.22,.7,0,stD);}
  vB('vStone',0,Y0+H1,lz-.1,W-.6,.32,2.6,0,st);vB('vStone',0,Y0+H1+.32,lz+1.15,W-.6,.14,.5,0,stD);}
 vnStairs(0,0,D/2+3.4,0,3.4,Y0,3,'vStone',st);vnDoor(0,Y0,D/2,0,1.6,2.8,'vStone',st,vC(0x4a2e1c),false);
 for(const x of[-4.2,-2.1,2.1,4.2])vnWin(x,Y0+1.3,D/2,0,1.1,1.8,'lit','vStone',st);for(const x of[-3.6,-1.2,1.2,3.6])vnWin(x,c1+1.0,D/2-.3,0,1.1,1.6,'lit','vStone',st);
 for(const s of[-1,1]){for(const z of[-3.5,-1.2,1.2,3.5])vnWin(s*W/2,Y0+1.3,z,s*Math.PI/2,1.1,1.7,'lit','vStone',st);for(const z of[-2.8,0,2.8])vnWin(s*(W/2-.3),c1+1.0,z,s*Math.PI/2,1.0,1.5,'lit','vStone',st);
  vnStrip(s*(W/2-.3),c1+.5,-4.4,s*Math.PI/2,.6,2.6,'vStone',stD);vnStrip(s*(W/2-.3),c1+.5,4.4,s*Math.PI/2,.6,2.6,'vStone',stD);}
 for(const x of[-4.8,-2.4,0,2.4,4.8])vnStrip(x,c1+.4,D/2-.28,0,.6,2.8,'vStone',stD);for(const x of[-3,0,3])vnWin(x,Y0+1.3,-D/2,Math.PI,1.1,1.7,'glass','vStone',st);
 vnFolk(0,D/2+7,3,1.8);}

VERN.def({key:'vern_house_poor_a',name:'Stilt hut',family:'dwelling',tags:Object.assign({wealth:'poor',lit:false},VTAG_SF),w:8,d:10,h:8,build:buildVernPoorA});
VERN.def({key:'vern_house_poor_b',name:'Corrugate shack',family:'dwelling',tags:Object.assign({wealth:'poor',lit:false},VTAG_SF),w:10,d:8,h:5,build:buildVernPoorB});
VERN.def({key:'vern_house_poor_c',name:'Panel house',family:'dwelling',tags:Object.assign({wealth:'poor',lit:false},VTAG_SF),w:9,d:10,h:7,build:buildVernPoorC});
VERN.def({key:'vern_house_mid_a',name:'Plaster townhouse',family:'dwelling',tags:Object.assign({wealth:'middle',lit:false},VTAG_SF),w:10,d:13,h:11,build:buildVernMidA});
VERN.def({key:'vern_house_mid_b',name:'Setback house',family:'dwelling',tags:Object.assign({wealth:'middle',lit:false},VTAG_MF),w:12,d:11,h:11,build:buildVernMidB});
VERN.def({key:'vern_house_mid_c',name:'Long house',family:'dwelling',tags:Object.assign({wealth:'middle',lit:false},VTAG_SF),w:15,d:14,h:8,build:buildVernMidC});
VERN.def({key:'vern_house_rich_a',name:'Stone manor',family:'dwelling',tags:Object.assign({wealth:'rich',lit:true},VTAG_SF),w:28,d:24,h:16,build:buildVernRichA});
VERN.def({key:'vern_house_rich_b',name:'Domed house',family:'dwelling',tags:Object.assign({wealth:'rich',lit:true},VTAG_SF),w:26,d:23,h:16,build:buildVernRichB});
// ================================================================= IZIZ VERNACULAR — trade and industry
// Shops, the tavern, workshops, the scrap smithy, the market canopy, the
// warehouse. None of these are civic, so none carry electric light; the
// smithy and the kiln glow with fire, which is allowed.

// A market stall: four posts, a striped canopy, a counter with goods, crates behind.
function vnStall(x,z,ry,c){const W2=1.3,D2=.9;const wood=vC(vPick(VPAL.woodMid));
 [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(p=>{const q=loc(x,z,p[0]*W2,p[1]*D2,ry);vPst('vPost',q[0],0,q[1],.06,2.4,wood);});
 kput('vClothB',[x,2.45,z],vQ(ry,.1,0),[W2*2+.7,.06,D2*2+.7],c||vC(vPick(VPAL.awning)));
 const cq=loc(x,z,0,D2*.55,ry);vB('vWood',cq[0],0,cq[1],W2*1.9,.95,.7,ry,wood);
 for(let k=0;k<4;k++){const g=loc(x,z,-W2*.7+k*W2*.47,D2*.55,ry);const r=rng();
  if(r<.4)vnCrate(g[0],.95,g[1],.42,ry+rr(-.3,.3));else if(r<.7)vPst('vClayPot',g[0],.95,g[1],.17,.4,vC(vPick([0x9a5a38,0xb87a4a,0x7a4a30])));else kput('vSack',[g[0],1.12,g[1]],null,[.22,.18,.22],vC(vPick(VPAL.awning)));}
 const bq=loc(x,z,0,-D2*.5,ry);vnCrate(bq[0],0,bq[1],.8,ry,wood);vnSacks(bq[0]-.9,0,bq[1],2);}
// hanging sign board on an iron bracket
function vnSign(x,y,z,ry,c){const a=loc(x,z,0,.05,ry),b=loc(x,z,0,1.1,ry);vBeam([a[0],y,a[1]],[b[0],y,b[1]],.05,vC(0x2e2a26),'vIron');
 const s=loc(x,z,0,.7,ry);kput('vWood',[s[0],y-.5,s[1]],vQ(ry+Math.PI/2,0,0),[.9,.7,.05],c||vC(vPick(VPAL.awning)));vB('vIron',s[0],y-.15,s[1],.04,.15,.04,0,vC(0x2e2a26));}

// ---------------------------------------------------------------- shop row: three units under one salvaged-sheet roof
function buildVernShops(G,o){reseed(7401+(o.v|0));const U=4.6,N=3,W=U*N,D=7.4,H=3.3,Y0=.3;const wood=vC(vPick(VPAL.woodMid));
 vnReg('Shop row (three units)',0,0,9,Y0+H+3.6);
 vB('vStone',0,-.1,0,W+.5,.4,D+.5,0,vC(vPick(VPAL.stoneDark)));vnPaving(0,.02,D/2+1.6,W+2,2.6,0,vC(vPick(VPAL.stoneDark)),14);
 const pls=[vC(vPick(VPAL.sand)),vC(vPick(VPAL.adobe)),vC(vPick(VPAL.sand))];
 for(let i=0;i<N;i++){const x=-W/2+U*(i+.5);vB('vPlaster',x,Y0,0,U,H,D,0,pls[i]);}
 for(let i=0;i<=N;i++){const x=-W/2+U*i;for(const s of[-1,1])vPst('vPost',x,Y0,s*(D/2-.02),.16,H+.4,wood);}
 const top=vnCornice('vWood',0,Y0+H,0,W,D,0,wood,1);
 vnGableRoof(0,top,0,W,D,2.2,0,'vGableC',null,1.0,'vGablePl',pls[1],.16);
 // attic shutter strips over each unit
 for(let i=0;i<N;i++){const x=-W/2+U*(i+.5);vnStrip(x,top+.35,D/2-.05,0,.6,1.3,'vWood',wood);}
 for(let i=0;i<N;i++){const x=-W/2+U*(i+.5),c=vC(VPAL.awning[i*2%VPAL.awning.length]);
  // the shop front: a wide opening, its board shutter propped up as a hood, a counter, an awning, a sign
  vB('vDarkB',x,Y0+.9,D/2-.05,U-1.2,1.7,.2,0);vB('vWood',x,Y0,D/2+.2,U-1.0,.95,.6,0,wood);
  kput('vWood',[x,Y0+2.75,D/2+.75],vQ(0,-.75,0),[U-1.0,.06,1.7],wood.clone().multiplyScalar(.9));
  vnAwning(x,Y0+2.55,D/2,0,U-.9,1.5,c);vnSign(x-U/2+.35,Y0+2.35,D/2,0,c);
  for(let k=0;k<3;k++){const gx=x-(U-1.6)/2+(U-1.6)*(k+.5)/3;const r=rng();
   if(r<.35)vnCrate(gx,Y0+.95,D/2+.2,.5,rr(-.3,.3));else if(r<.7)vPst('vClayPot',gx,Y0+.95,D/2+.2,.2,.5,vC(vPick([0x9a5a38,0xb87a4a])));else kput('vClothB',[gx,Y0+1.1,D/2+.2],qEuler(0,rr(-.3,.3),0),[.6,.3,.45],vC(vPick(VPAL.awning)));}
  vnDoor(x+U/2-.75,Y0,D/2-.05,0,.9,2.1,'vWood',wood,vC(0x6a4a30),false);
  vnWin(x,Y0+1.4,-D/2+.05,Math.PI,1.1,1.1,'shut','vWood',wood);}
 for(const s of[-1,1])vnWin(s*W/2,Y0+1.4,0,s*Math.PI/2,1.1,1.1,'open','vWood',wood,true);
 vnBarrel(W/2+.9,0,D/2-1.2,.4,1.0,wood);vnSacks(-W/2-1.0,0,D/2-1.5,4);vnBannerPole(-W/2-.6,0,D/2+1.8,0,5.5);vnBannerPole(W/2+.6,0,D/2+1.8,0,5.5);
 vnFolk(0,D/2+3.2,5,3.5);}

// ---------------------------------------------------------------- tavern: the deco long hall in timber, cross-gabled porch, inn rooms above
function buildVernTavern(G,o){reseed(7411+(o.v|0));const W=16,D=10,H=4.0,H2=2.6,Y0=.35;const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand)),sh=vC(vPick([0x8a6a4a,0x6a4e38,0x9a7a56]));
 vnReg('Tavern (long hall)',0,0,12,Y0+H+H2+4.6);
 vB('vStone',0,-.1,0,W+.6,.45,D+.6,0,vC(vPick(VPAL.stoneDark)));
 vnFrame(0,Y0,0,W,H,D,0,wood,.18);vB('vPlaster',0,Y0,0,W-.16,H,D-.16,0,pl);
 vB('vWood',0,Y0+H,0,W+.4,.3,D+.4,0,wood);                                           // string course
 vB('vWood',0,Y0+H+.3,0,W,H2,D,0,wood.clone().multiplyScalar(.9));                    // upper storey: boards
 const top=vnCornice('vWood',0,Y0+H+.3+H2,0,W,D,0,wood,2);
 vnGableRoof(0,top,0,W,D,4.2,0,'vGableS',sh,1.1,'vGableW',wood,.2);
 for(const s of[-1,1]){vB('vWood',s*(W/2+1.1),top+4.2-.4,0,.5,2.2,.5,0,wood);kput('vBall',[s*(W/2+1.1),top+6.2,0],null,[.25,.25,.25],vC(0x8a6a2a));}   // ridge finials
 // porch: cross gable on four posts, benches, barrels
 {const PZ=D/2+2.2,PW=6.4,PD=3.6;vB('vWood',0,Y0-.05,PZ,PW,.28,PD,0,wood);
  for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',sx*(PW/2-.2),Y0,PZ+sz*(PD/2-.2),.17,3.4,wood);
  vB('vWood',0,Y0+3.4,PZ,PW+.4,.3,PD+.4,0,wood);vnGableRoof(0,Y0+3.7,PZ,PW,PD+.6,2.3,Math.PI/2,'vGableS',sh,.8,'vGableW',wood,.2);
  for(const s of[-1,1]){vB('vWood',s*(PW/2-.5),Y0+.28,PZ,.45,.45,2.6,0,wood);}
  vnDoor(0,Y0,D/2-.06,0,1.5,2.5,'vWood',wood,vC(0x5a3a24),false);}
 for(const x of[-5.5,-3,3,5.5])vnWin(x,Y0+1.3,D/2-.06,0,1.3,1.4,'open','vWood',wood,true);
 for(const s of[-1,1])for(const z of[-3,0,3])vnWin(s*W/2,Y0+1.3,z,s*Math.PI/2,1.2,1.3,'open','vWood',wood,true);
 for(const x of[-5.5,-2.75,0,2.75,5.5])vnWin(x,Y0+1.3,-D/2+.06,Math.PI,1.1,1.3,'shut','vWood',wood);
 for(const x of[-6,-3.6,-1.2,1.2,3.6,6])vnStrip(x,Y0+H+.6,D/2+.02,0,.6,1.8,'vWood',wood);
 for(const s of[-1,1])for(const z of[-3,0,3])vnStrip(s*W/2,Y0+H+.6,z,s*Math.PI/2,.6,1.8,'vWood',wood);
 // stone chimney at the back, sign, banners, barrel stack, drying rack for the kitchen
 vB('vStone',-W/2+2,Y0,-D/2-.6,1.6,H+H2+5.6,1.3,0,vC(vPick(VPAL.stoneDark)));vB('vStone',-W/2+2,Y0+H+H2+5.6,-D/2-.6,2.0,.3,1.7,0,vC(vPick(VPAL.stone)));
 vnSign(3.8,Y0+3.4,D/2,0,vC(0xc9442a));vnBannerPole(-W/2-.8,0,D/2+1.0,0,6.5,vC(0xe07a2a));vnBannerPole(W/2+.8,0,D/2+1.0,0,6.5,vC(0x9c2d2d));
 for(let k=0;k<4;k++)vnBarrel(W/2+.9+(k%2)*.95,k<2?0:.95,-D/2+1.5+(k%2)*.9*(k<2?1:0)+ (k>=2?.45:0),.42,.95,wood);
 vnSacks(W/2+1.2,0,1.5,3);vnDryingRack(-W/2-1.8,0,-1,Math.PI/2,3.6);
 vnPaving(0,.02,D/2+5.2,10,2.6,0,vC(vPick(VPAL.stoneDark)),12);vnFolk(0,D/2+5.6,5,3);}

// ---------------------------------------------------------------- workshops
// A — carpenter: open-fronted shed, benches, timber stacks, sawpit
function buildVernWorkshopA(G,o){reseed(7421+(o.v|0));const W=9,D=7,H=3.4;const wood=vC(vPick(VPAL.woodMid));
 vnReg('Carpenter\'s workshop',0,0,7.5,H+2.6);
 vB('vStone',0,-.1,0,W+.4,.3,D+.4,0,vC(0x9a8a78));vnFrame(0,.2,0,W,H,D,0,wood,.16);
 vB('vWood',0,.2,-D*.225,W-.2,H,D*.55,0,wood.clone().multiplyScalar(.95));   // back half enclosed, front open
 vnPatch(-W/2+.1,.2,-D*.22,-Math.PI/2,D*.55,H,2);
 vnShedRoof(0,.2+H,0,W,D,1.3,0,'vCorr',null,.9,.12);
 // the open front: benches, tool rack, stacked planks, sawhorses
 vB('vWood',-2.2,.2,D/2-1.4,3.2,.9,.9,0,wood);vB('vWood',2.4,.2,D/2-1.3,2.4,.9,.8,0,wood);
 for(let k=0;k<6;k++)vB('vWood',-3.2+k*.5,1.1,D/2-1.4,.08,.6,.08,0,vC(0x2e2a26));                 // tools standing on the bench
 for(let k=0;k<7;k++)kput('vWood',[W/2-1.2,.35+k*.16,-D*.1],qEuler(0,rr(-.06,.06),0),[.28,.14,4.2],wood.clone().multiplyScalar(rr(.85,1.1)));   // plank stack
 for(const x of[-1,1])for(const s of[-1,1])kput('vWood',[x*.9+s*.35,.55,D/2-3.2],vQ(0,0,s*.35),[.08,1.1,.08],wood);kput('vWood',[0,1.05,D/2-3.2],null,[2.6,.14,.14],wood);   // sawhorses + beam
 for(let k=0;k<5;k++)vPst('vPostB',-W/2-1.2+rr(-.3,.3),0,-2+k*.9,rr(.18,.3),rr(1.5,3.2),vC(vPick(VPAL.woodPoor)),qEuler(Math.PI/2*.98,rng()*.3,0));   // logs lying outside
 vB('vDarkB',0,-.02,D/2+2.4,3.0,.06,1.2,0);for(const s of[-1,1])vB('vWood',s*1.6,0,D/2+2.4,.12,.3,1.3,0,wood);                                   // sawpit
 vnCrate(W/2+.8,0,1.2,.9,.4,wood);vnBarrel(W/2+1,0,-.6,.4,1,wood);vnFolk(-1,D/2+4.2,2,1.2);}
// B — potter: plaster workshop with a domed clay kiln, drying racks of pots, chimney
function buildVernWorkshopB(G,o){reseed(7431+(o.v|0));const W=8,D=7,H=3.2,Y0=.3;const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.adobe));
 vnReg('Potter\'s workshop and kiln',0,0,8.5,Y0+H+3);
 vB('vStone',0,-.1,0,W+.4,.4,D+.4,0,vC(0x9a8a78));vnFrame(0,Y0,0,W,H,D,0,wood,.15);vB('vPlaster',0,Y0,0,W-.14,H,D-.14,0,pl);
 vnCornice('vWood',0,Y0+H,0,W,D,0,wood,1,false);vnHipRoof('vHipC',0,Y0+H+.32,0,W,D,2.1,0,null,1.1);
 vB('vDarkB',-1.2,Y0+.6,D/2-.05,3.4,2.0,.2,0);vB('vWood',-1.2,Y0,D/2+.15,3.2,.9,.5,0,wood);      // open sales front with counter
 for(let k=0;k<5;k++)vPst('vClayPot',-2.4+k*.6,Y0+.9,D/2+.15,rr(.14,.22),rr(.3,.55),vC(vPick([0x9a5a38,0xb87a4a,0x7a4a30,0xc89a6a])));
 vnDoor(2.4,Y0,D/2-.05,0,1.0,2.1,'vWood',wood,vC(0x6a4a30),false);vnAwning(-1.2,Y0+2.6,D/2,0,3.6,1.6,vC(0xe0a030));
 for(const s of[-1,1])vnWin(s*W/2,Y0+1.3,0,s*Math.PI/2,1.0,1.0,'open','vWood',wood,true);
 // kiln: a clay dome on a stone base with a stoke hole and a tall clay chimney; pots drying on shelves beside
 {const kx=W/2+3.2,kz=-.8;vB('vStone',kx,0,kz,3.6,.7,3.6,0,vC(0x8a7a6a));kput('vDomeP',[kx,.7,kz],null,[1.7,1.7,1.7],vC(0xa06a44));
  vB('vDarkB',kx,.7,kz+1.55,.8,.7,.3,0);vBall('vEmber',kx,1.05,kz+1.5,.18);vPst('vClayPot',kx-.3,2.2,kz-.5,.28,2.2,vC(0xa06a44));vnChimney(kx-.3,4.4,kz-.5,.6,.2,true);
  for(let k=0;k<2;k++){vB('vWood',kx-.2,1.6+k*.8,kz+2.6,3.0,.08,.5,0,wood);for(let j=0;j<6;j++)vPst('vClayPot',kx-1.5+j*.55,1.68+k*.8,kz+2.6,.15,.35,vC(vPick([0xb08a6a,0x9a5a38])));}
  for(const s of[-1,1])vPst('vPost',kx-.2+s*1.5,0,kz+2.6,.06,2.6,wood);}
 vnBarrel(-W/2-.8,0,D/2-1.4,.42,1.0,wood);vB('vClayB',-W/2-1.0,0,-1.6,1.4,.6,1.4,.3,vC(0x8a5a3a));   // clay heap
 vnFolk(0,D/2+3.4,2,1.2);}

// ---------------------------------------------------------------- scrap smithy: forge under a salvaged roof on pipe posts, scrap heaps, a hoist frame
function buildVernSmithy(G,o){reseed(7441+(o.v|0));const W=11,D=8,H=3.8;const wood=vC(vPick(VPAL.woodPoor)),iron=vC(0x2e2a26);
 vnReg('Scrap smithy',0,0,9.5,H+7.5);
 vnPaving(0,.02,0,W+4,D+4,0,vC(0x6a625a),24);vB('vStone',0,-.05,0,W,.25,D,0,vC(0x7a7068));
 // pipe posts, salvaged-panel roof in two pitches with a gap for smoke
 for(const sx of[-1,1])for(const z of[-D/2+.3,0,D/2-.3])vPst('vPipeR',sx*(W/2-.3),.2,z,.14,H,null);
 for(const s of[-1,1]){const zc=s*D/4;const q=vQ(0,s*.3,0);kput(s<0?'vPanelB':'vRustB',[0,H+.9+ .1,zc],q,[W+1.2,.12,D/2+.8],null);}
 vB('vIron',0,H+.1,-D/2+.2,W+1.2,.2,.2,0,iron);vB('vIron',0,H+.1,D/2-.2,W+1.2,.2,.2,0,iron);vB('vIron',0,H+1.65,0,W+1.4,.2,.2,0,iron);
 // back wall of plate and sheet, patched
 vB('vRustB',0,.2,-D/2+.15,W-.2,H-.2,.15,0);vnPatch(0,.2,-D/2+.15,0,W,H-.4,5);
 // forge hearth: stone block, ember bed, hood and a tall reclaimed-pipe stack through the roof
 {const fx=-2.6,fz=-D/2+1.6;vB('vStone',fx,.2,fz,2.8,1.1,2.0,0,vC(0x6a625a));vB('vDarkB',fx,1.3,fz,2.2,.15,1.4,0);for(let k=0;k<5;k++)vBall('vEmber',fx+rr(-.8,.8),1.42,fz+rr(-.5,.5),rr(.1,.2));
  kput('vRustB',[fx,2.9,fz],null,[2.6,1.2,1.8],null);kput('vRustB',[fx,2.3,fz],null,[3.0,.2,2.2],null);vnChimney(fx,3.5,fz,H+4.2,.42,true);}
 // anvil on a stump, quench barrel, bellows box, workbench with tongs
 vPst('vPostB',.6,.2,-.4,.34,.75,wood);vB('vIron',.6,.95,-.4,1.1,.35,.4,0,iron);vB('vIron',.6,1.3,-.4,.5,.12,.3,0,iron);
 vnWaterButt(2.0,.2,-1.4,.45,.9);vB('vWood',-2.6,.2,-D/2+3.4,1.6,.7,1.0,0,wood);vB('vTarpB',-2.6,.9,-D/2+3.4,1.4,.35,.8,0,vC(0x8a7a5a));
 vB('vWood',3.6,.2,-D/2+1.2,3.0,.9,.9,0,wood);for(let k=0;k<4;k++)vB('vIron',2.6+k*.6,1.1,-D/2+1.2,.05,.7,.05,0,iron);
 // scrap heaps: rusted plates, pipe offcuts, ghost panel scraps
 for(let i=0;i<40;i++){const x=W/2+1.6+rr(-1.3,1.7),z=rr(-D/2,D/2);const r=rng();const hgt=Math.pow(rng(),2)*.45;
  if(r<.5)kput('vRustB',[x,hgt+.05,z],qEuler(rr(-.5,.5),rng()*TAU,rr(-.5,.5)),[rr(.5,1.2),rr(.03,.07),rr(.4,1.0)],null);
  else if(r<.8)kput('vPipeR',[x,hgt+.08,z],qEuler(Math.PI/2,rng()*TAU,rr(-.3,.3)),[rr(.05,.12),rr(.7,2.0),rr(.05,.12)],null);
  else kput('vPanelB',[x,hgt+.05,z],qEuler(rr(-.4,.4),rng()*TAU,rr(-.4,.4)),[rr(.5,1.1),.06,rr(.5,1.1)],null);}
 for(let i=0;i<10;i++)kput('vIron',[-W/2-1.4+rr(-.8,.8),rr(.1,.6),rr(-2,2)],qEuler(rng(),rng()*TAU,rng()),[rr(.3,.9),rr(.2,.5),rr(.3,.9)],iron);
 // hoist: an A-frame of pipe with a rope and hook over the yard
 {const hx=3.4,hz=D/2+2.4;for(const s of[-1,1])vPst('vPipeR',hx+s*1.4,0,hz,.12,5.2,null,qEuler(0,0,-s*.27));vB('vIron',hx,5.05,hz,1.0,.2,.2,0,iron);
  vPst('vRope',hx,2.4,hz,.03,2.7,vC(0xa89878));vB('vIron',hx,2.1,hz,.25,.3,.08,0,iron);}
 vnFolk(0,D/2+3.4,2,1.4);}

// ---------------------------------------------------------------- market canopy: a great two-tier rain roof over rows of stalls
function buildVernMarket(G,o){reseed(7451+(o.v|0));const W=24,D=17,H=5.2;const wood=vC(vPick(VPAL.woodMid)),th=vC(vPick(VPAL.thatch));
 vnReg('Market canopy',0,0,15,H+6);
 vnPaving(0,.02,0,W+4,D+4,0,vC(vPick(VPAL.stoneDark)),60);
 // outer posts and ring beams, inner posts higher for the clerestory
 const nx=6,nz=4;for(let i=0;i<=nx;i++)for(const s of[-1,1]){vPst('vPostB',-W/2+W*i/nx,0,s*D/2,.2,H,wood);}
 for(let j=1;j<nz;j++)for(const s of[-1,1])vPst('vPostB',s*W/2,0,-D/2+D*j/nz,.2,H,wood);
 for(const s of[-1,1]){vB('vWood',0,H-.15,s*D/2,W+.4,.3,.3,0,wood);vB('vWood',s*W/2,H-.15,0,.3,.3,D+.4,0,wood);}
 for(let i=0;i<=nx;i++)vB('vWood',-W/2+W*i/nx,H-.15,0,.22,.22,D,0,wood);                       // tie beams
 // lower thatch skirt all round (two long slabs, two short) and an upper hip over the middle third
 vnHipRoof('vHipT',0,H,0,W,D,2.6,0,th,1.3);
 for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',sx*W/6,H+1.4,sz*D/8,.16,2.2,wood);
 vnHipRoof('vHipT',0,H+3.4,0,W*.42,D*.5,2.0,0,th,.9);
 vB('vWood',0,H+3.4,0,W*.42+.4,.25,.25,0,wood);vB('vWood',0,H+3.4,0,.25,.25,D*.5+.4,0,wood);
 // banners on alternate outer posts, gourds and lanterns from the tie beams
 for(let i=0;i<=nx;i+=2)vnBannerPole(-W/2+W*i/nx,0,D/2+.5,0,H+1.2,vC(vPick(VPAL.orange.concat([0x9c2d2d,0x2f8f8a]))));
 // rows of stalls with an aisle down the middle
 for(let i=0;i<5;i++){const x=-W/2+2.6+i*(W-5.2)/4;vnStall(x,-D/2+3.4,0);vnStall(x,D/2-3.4,Math.PI);}
 for(let i=0;i<3;i++){const x=-W/2+4+i*(W-8)/2;vnStall(x,-1.6,Math.PI);vnStall(x,1.6,0);}
 vnWaterButt(-W/2-1.2,0,-D/2-1,.5,1.1);vnCrate(W/2+1.2,0,D/2-2,.9,.3,wood);vnSacks(W/2+1.4,0,-D/2+2,5);
 vnFolk(0,0,10,7);vnFolk(0,D/2+3,4,3);}

// ---------------------------------------------------------------- warehouse: long timber shed clad in board and sheet, gable-end doors, loading dock and hoist
function buildVernWarehouse(G,o){reseed(7461+(o.v|0));const W=22,D=12,H=5.2,Y0=.9;const wood=vC(vPick(VPAL.woodMid));
 vnReg('Warehouse',0,0,14,Y0+H+5);
 vB('vStone',0,-.1,0,W+.6,Y0+.1,D+.6,0,vC(vPick(VPAL.stoneDark)));                       // loading-height plinth
 vnFrame(0,Y0,0,W,H,D,0,wood,.2);vB('vWood',0,Y0,0,W-.2,H,D-.2,0,wood.clone().multiplyScalar(.92));
 // sheet cladding on the lower half, boards above; patches
 for(const s of[-1,1]){vB('vCorr',0,Y0,s*(D/2-.05),W-.4,H*.45,.1,0);vnPatch(0,Y0+H*.45,s*(D/2-.05),s>0?0:Math.PI,W-.4,H*.5,4);}
 for(const s of[-1,1])vB('vCorr',s*(W/2-.05),Y0,0,.1,H*.45,D-.4,0);
 vnGableRoof(0,Y0+H,0,D,W,3.4,Math.PI/2,'vGableP',null,1.0,'vGableW',wood,.16);   // ridge along z (long axis)
 for(let k=0;k<4;k++)kput('vIron',[-W/2+3+k*(W-6)/3,Y0+H+3.9,0],null,[.9,.6,1.4],vC(0x4a4640));   // roof vents
 // gable-end doors on the front (+z... the ridge runs along z, so the gable ends face ±x): put the doors on +x and the dock along +z
 {const dx=W/2-.05;vB('vDarkB',dx,Y0,-1.0,.2,3.8,3.6,0);for(const s of[-1,1])kput('vWood',[dx+.12,Y0+1.9,-1.0+s*1.05],vQ(Math.PI/2,0,0).multiply(qEuler(0,s*.55,0)),[1.9,3.7,.08],wood.clone().multiplyScalar(.85));
  vB('vWood',dx+.1,Y0+3.8,-1.0,.3,.3,4.4,0,wood);vB('vDarkB',dx,Y0+H+1.6,-1.0,.2,1.4,1.4,0);vB('vWood',dx+.9,Y0+H+2.9,-1.0,2.2,.25,.25,0,wood);vPst('vRope',dx+1.8,Y0+1.2,-1.0,.03,Y0+H+1.7-Y0-1.2,vC(0xa89878));vnCrate(dx+1.8,Y0+.5,-1.0,.9,.2,wood);}
 // loading dock along the front with stairs, ramp, crates and barrels; a lean-to office
 vB('vWood',0,Y0-.28,D/2+1.4,W-2,.28,2.8,0,wood);for(let i=0;i<=8;i++)vPst('vPostB',-W/2+1+(W-2)*i/8,-.1,D/2+2.7,.13,Y0-.2,wood);
 vnStairs(W/2-2.2,0,D/2+3.4,0,1.4,Y0,3,'vWood',wood);kput('vWood',[-W/2+2.6,Y0/2-.1,D/2+4.2],vQ(0,Math.atan2(Y0,3.2),0),[2.2,.12,3.4],wood);
 for(let k=0;k<5;k++)vnCrate(-W/2+4+k*2.4,Y0,D/2+1.2,rr(.7,1.1),rr(-.2,.2),wood);vnBarrel(W/2-4,Y0,D/2+1.0,.42,1.0,wood);vnBarrel(W/2-4.9,Y0,D/2+1.0,.42,1.0,wood);vnSacks(-1,Y0,D/2+1.6,5);
 for(const x of[-6,0,6])vnDoor(x,Y0,D/2-.05,0,2.2,3.0,'vWood',wood,vC(0x6a4a30),false);
 for(const x of[-8,-4,4,8])vnWin(x,Y0+3.6,D/2-.05,0,1.1,.9,'shut','vWood',wood);for(const x of[-8,-4,0,4,8])vnWin(x,Y0+3.6,-D/2+.05,Math.PI,1.1,.9,'shut','vWood',wood);
 {const ox=-W/2-2.6;vB('vWood',ox,0,D/2-2.5,4.6,3.0,4.8,0,wood.clone().multiplyScalar(.9));vnShedRoof(ox,3.0,D/2-2.5,4.6,4.8,1.0,Math.PI/2,'vCorr',null,.6,.12);
  vnDoor(ox,0,D/2-.1,0,1.0,2.1,'vWood',wood,vC(0x6a4a30));vnWin(ox-2.3,1.3,D/2-2.5,-Math.PI/2,1.0,1.0,'open','vWood',wood,true);vnChimney(ox-1.6,3.6,D/2-4.2,1.4,.12,true);}
 vnFolk(2,D/2+5.6,4,2.5);}

VERN.def({key:'vern_shops',name:'Shop row',family:'trade',tags:{type:['market/shop'],wealth:'middle',lit:false},w:18,d:12,h:10,build:buildVernShops});
VERN.def({key:'vern_tavern',name:'Tavern',family:'trade',tags:{type:['tavern/inn'],wealth:'middle',lit:false},w:22,d:20,h:15,build:buildVernTavern});
VERN.def({key:'vern_workshop_a',name:'Carpenter\'s workshop',family:'industry',tags:{type:['industry'],wealth:'middle',lit:false},w:14,d:12,h:6,build:buildVernWorkshopA});
VERN.def({key:'vern_workshop_b',name:'Potter\'s workshop',family:'industry',tags:{type:['industry','market/shop'],wealth:'middle',lit:false},w:16,d:12,h:7,build:buildVernWorkshopB});
VERN.def({key:'vern_smithy',name:'Scrap smithy',family:'industry',tags:{type:['industry'],wealth:'poor',lit:false},w:18,d:14,h:12,build:buildVernSmithy});
VERN.def({key:'vern_market',name:'Market canopy',family:'trade',tags:{type:['market/shop'],wealth:'middle',lit:false},w:30,d:22,h:12,build:buildVernMarket});
VERN.def({key:'vern_warehouse',name:'Warehouse',family:'industry',tags:{type:['industry'],wealth:'middle',lit:false},w:30,d:20,h:11,build:buildVernWarehouse});
// ================================================================= IZIZ VERNACULAR — civic
// School, hospital, barracks + drill yard, the alchemist's compound. Civic
// buildings are built in stone with copper roofs where the Empire still can,
// and they are the buildings (with the rich) that carry electric light.
const VTAG_CIV={type:['civic'],wealth:'civic',lit:true};

// stone civic block helper: stone box, stepped cornice, deco strips between lit windows on the front face
function vnCivicBlock(x,y,z,w,h,d,ry,st,stD,winY,winH,nWin,strips){vB('vStone',x,y,z,w,h,d,ry,st);const top=vnCornice('vStone',x,y+h,z,w,d,ry,st,2);
 for(let i=0;i<nWin;i++){const lx=-w/2+w*(i+.5)/nWin;const p=loc(x,z,lx,d/2,ry);vnWin(p[0],y+winY,p[1],ry,1.2,winH,'lit','vStone',st);
  if(strips&&i<nWin-1){const q=loc(x,z,lx+w/(2*nWin),d/2+.02,ry);vnStrip(q[0],y+winY-.5,q[1],ry,.55,winH+1.1,'vStone',stD);}}
 return top;}

// ---------------------------------------------------------------- school: hall with a bell tower, two classroom wings round a shaded yard
function buildVernSchool(G,o){reseed(7501+(o.v|0));const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),th=vC(vPick(VPAL.thatch)),cu=vC(0xffffff);
 vnReg('School',0,0,17,15);
 const HW=16,HD=8,HZ=-7,Y0=.5;vB('vStone',0,0,0,30,Y0,26,0,stD);
 // main hall: two storeys of stone
 vB('vStone',0,Y0,HZ,HW,4.0,HD,0,st);const c1=vnCornice('vStone',0,Y0+4.0,HZ,HW,HD,0,st,1,false);
 const top=vnCivicBlock(0,c1,HZ,HW-.4,3.6,HD-.4,0,st.clone().multiplyScalar(1.03),stD,1.0,1.6,5,true);
 for(const x of[-5,-2.5,2.5,5])vnWin(x,Y0+1.3,HZ+HD/2,0,1.2,1.8,'lit','vStone',st);vnDoor(0,Y0,HZ+HD/2,0,1.7,2.9,'vStone',st,vC(0x4a2e1c));
 for(const s of[-1,1])for(const z of[-2,2]){vnWin(s*HW/2,Y0+1.3,HZ+z,s*Math.PI/2,1.1,1.7,'lit','vStone',st);vnWin(s*(HW/2-.2),c1+1.0,HZ+z,s*Math.PI/2,1.1,1.5,'lit','vStone',st);}
 for(const x of[-5,-2.5,0,2.5,5])vnWin(x,c1+1.0,HZ-HD/2+.2,Math.PI,1.1,1.5,'glass','vStone',st);
 vnHipRoof('vHipCu',0,top,HZ,HW-.4,HD-.4,2.6,0,cu,1.2);
 // bell tower at the hall's corner: stone shaft, open timber belfry, copper pyramid, bell
 {const tx=HW/2-1.2,tz=HZ-HD/2+1.2,TH=top+3.2;vB('vStone',tx,Y0,tz,3.2,TH-Y0,3.2,0,st);vnCornice('vStone',tx,TH,tz,3.2,3.2,0,st,1);
  for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',tx+sx*1.3,TH+.6,tz+sz*1.3,.14,2.6,wood);vB('vWood',tx,TH+3.2,tz,3.2,.25,3.2,0,wood);
  kput('vPyrCu',[tx,TH+3.45,tz],null,[3.8,2.2,3.8],cu);vBall('vFinial',tx,TH+5.9,tz,.22);
  vB('vWood',tx,TH+2.9,tz,.1,.4,.1,0,wood);kput('vBall',[tx,TH+2.0,tz],null,[.5,.6,.5],vC(0x7a6a2a));}
 // classroom wings: single storey stone with timber verandas facing the yard, copper shed roofs
 for(const s of[-1,1]){const wx=s*10.5,WW=7,WD=13,wz=1.5;vB('vStone',wx,Y0,wz,WW,3.6,WD,0,st);const t=vnCornice('vStone',wx,Y0+3.6,wz,WW,WD,0,st,1);
  vnShedRoof(wx,t,wz,WD,WW,1.4,s*Math.PI/2,'vCopperB',cu,.9,.16);
  const fx=wx-s*WW/2;for(const z of[-4.2,-1.4,1.4,4.2])vnWin(fx,Y0+1.2,wz+z,-s*Math.PI/2,1.3,1.7,'lit','vStone',st);vnDoor(fx,Y0,wz-5.6,-s*Math.PI/2,1.2,2.4,'vStone',st,vC(0x4a2e1c),false);
  vnVeranda(fx-s*1.3,Y0,wz,WD,2.6,-s*Math.PI/2,.04,3.0,wood);vnShedRoof(fx-s*1.3,Y0+3.0,wz,WD,2.6,.6,-s*Math.PI/2,'vCopperB',cu,.4,.12);
  for(const z of[-3,0,3])vnWin(wx+s*WW/2,Y0+1.4,wz+z,s*Math.PI/2,1.1,1.3,'glass','vStone',st);}
 // the yard: paving, a thatch shade on posts with benches under it, planters, lamps, a low wall with a gate to the front
 vnPaving(0,Y0+.02,2,12,12,0,st,26);
 {for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',sx*2.6,Y0,3+sz*2.2,.16,3.2,wood);vnHipRoof('vHipT',0,Y0+3.2,3,5.2,4.4,1.6,0,th,1.0);
  for(const x of[-1.4,1.4])vB('vWood',x,Y0,3,.5,.45,3.6,0,wood);}
 for(const s of[-1,1]){vnPlanter(s*5.5,Y0,-2,3.0,.9,0,wood);vnLampPost(s*4.6,Y0,9.4,3.4);}
 {const CW=30,h=1.4;for(const s of[-1,1]){const L=CW/2-2.2;vB('vStone',s*(2.2+L/2),Y0,11.5,L,h,.5,0,stD);vB('vStone',s*(2.2+L/2),Y0+h,11.5,L+.2,.22,.7,0,st);vB('vStone',s*2.4,Y0,11.5,.8,h+.7,.8,0,st);}
  for(const s of[-1,1])vB('vStone',s*CW/2,Y0,-.5,.5,h,24,0,stD);}
 vnLamp(-1.3,Y0+3.4,HZ+HD/2,0);vnLamp(1.3,Y0+3.4,HZ+HD/2,0);vnBannerPole(0,Y0,9,0,7,vC(0xe07a2a));
 vnFolk(0,4,8,4);}

// ---------------------------------------------------------------- hospital: a long ward block with deep verandas both sides, a domed entrance pavilion, herb court
function buildVernHospital(G,o){reseed(7511+(o.v|0));const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),cu=vC(0xffffff);
 vnReg('Hospital',0,0,20,18);
 const W=26,D=9,H=4.8,Y0=.7;vB('vStone',0,0,0,34,Y0,24,0,stD);
 vB('vStone',0,Y0,-2,W,H,D,0,st);const top=vnCornice('vStone',0,Y0+H,-2,W,D,0,st,2);
 vnGableRoof(0,top,-2,W,D,2.6,0,'vGableCu',cu,1.2,'vGableSt',st,.16);
 // ward verandas both long sides: timber posts, copper shed roofs, rails; tall lit windows and doors between them
 for(const s of[-1,1]){const fz=-2+s*D/2;vnVeranda(0,Y0,fz+s*1.5,W-2,3.0,s>0?0:Math.PI,.04,3.4,wood);vnShedRoof(0,Y0+3.4,fz+s*1.5,W-2,3.0,.7,s>0?0:Math.PI,'vCopperB',cu,.5,.12);
  for(let i=0;i<7;i++){const x=-W/2+W*(i+.5)/7;if(i%3===1)vnDoor(x,Y0,fz,s>0?0:Math.PI,1.3,2.6,'vStone',st,vC(0x4a2e1c),false);else vnWin(x,Y0+1.1,fz,s>0?0:Math.PI,1.4,2.4,'lit','vStone',st);}}
 for(const s of[-1,1])for(const z of[-4.5,-2,.5])vnWin(s*W/2,Y0+1.3,z,s*Math.PI/2,1.2,2.0,'lit','vStone',st);
 // entrance pavilion on the front: two storeys, cornices, a drum and copper dome, the door between stone piers
 {const PW=8,PD=6,PZ=-2+D/2+PD/2-.3;vB('vStone',0,Y0,PZ,PW,H,PD,0,st);const c1=vnCornice('vStone',0,Y0+H,PZ,PW,PD,0,st,1,false);
  vB('vStone',0,c1,PZ,PW-.4,3.0,PD-.4,0,st.clone().multiplyScalar(1.03));const c2=vnCornice('vStone',0,c1+3.0,PZ,PW-.4,PD-.4,0,st,3);
  vPst('vPostS',0,c2,PZ,2.6,1.2,st);vB('vStone',0,c2+1.2,PZ,5.6,.25,5.6,0,stD);kput('vDomeC',[0,c2+1.45,PZ],null,[2.8,2.4,2.8],cu);vBall('vFinial',0,c2+3.95,PZ,.25);
  for(let k=0;k<8;k++){const a=k/8*TAU;vB('vDarkB',Math.cos(a)*2.6,c2+.3,PZ+Math.sin(a)*2.6,.5,.7,.2,-a+Math.PI/2);}
  vnStairs(0,0,PZ+PD/2+1.2,0,4.4,Y0,3,'vStone',st);vnDoor(0,Y0,PZ+PD/2,0,1.9,3.0,'vStone',st,vC(0x4a2e1c),false);
  for(const s of[-1,1]){vB('vStone',s*1.7,Y0,PZ+PD/2+.3,.6,H-.3,.6,0,stD);vnStrip(s*3.2,Y0+.8,PZ+PD/2,0,.6,3.2,'vStone',stD);vnWin(s*2.4,c1+.9,PZ+PD/2-.2,0,1.2,1.6,'lit','vStone',st);}
  for(const s of[-1,1]){vnWin(s*PW/2,Y0+1.3,PZ,s*Math.PI/2,1.2,2.0,'lit','vStone',st);vnWin(s*(PW/2-.2),c1+.9,PZ,s*Math.PI/2,1.1,1.6,'lit','vStone',st);}
  vnLamp(-1.9,Y0+3.6,PZ+PD/2,0);vnLamp(1.9,Y0+3.6,PZ+PD/2,0);}
 // herb court to the front: raised beds, a cistern with a spout, benches, lamps; store room at one end
 vnPaving(0,Y0+.02,7.5,20,6,0,st,30);
 for(const x of[-8,-4,4,8])vnPlanter(x,Y0,7.5,2.6,1.1,0,wood);for(const s of[-1,1])vnLampPost(s*11,Y0,7.5,3.4);
 {const cx=-W/2-2.4;vB('vStone',cx,Y0,-2,3,1.2,3,0,stD);vPst('vTankW',cx,Y0+1.2,-2,1.3,2.4,null);vBq('vHoop',cx,Y0+2.0,-2,1.34,1.34,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));vBq('vHoop',cx,Y0+3.2,-2,1.34,1.34,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));
  vB('vIron',cx,Y0+3.6,-2,2.8,.12,2.8,0,vC(0x2e2a26));vPst('vPipe',cx+1.3,Y0+.5,0,.06,.9,vC(0x2e2a26));kput('vPipe',[cx+1.3,Y0+1.4,-.9],qEuler(Math.PI/2,0,0),[.06,1.9,.06],vC(0x2e2a26));vB('vStone',cx+1.3,Y0,.9,1.2,.6,.9,0,stD);}
 {const sx=W/2+2.6;vB('vStone',sx,Y0,-2,3.2,3.2,5,0,st);vnCornice('vStone',sx,Y0+3.2,-2,3.2,5,0,st,1);vnHipRoof('vHipCu',sx,Y0+3.2+.58,-2,3.2,5,1.2,0,cu,.6);vnDoor(sx,Y0,.5,0,1.0,2.1,'vStone',st,vC(0x4a2e1c),false);}
 vnFolk(0,11,6,4);}

// ---------------------------------------------------------------- barracks and drill yard: palisade, two barrack blocks, armoury, watch tower, pells, standard
function buildVernBarracks(G,o){reseed(7521+(o.v|0));const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand)),st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark));
 const CW=42,CD=32;vnReg('Barracks and drill yard',0,0,26,14,{type:['civic','military']});
 vB('vStone',0,-.12,0,CW+4,.14,CD+4,0,vC(0x8a7a66));vnPalisade(0,0,0,CW,CD,0,4.2,5);
 // gate towers either side of the gate, a bridge between them, a standard and lamps
 for(const s of[-1,1]){const gx=s*3.6;for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',gx+sx*1.0,0,CD/2+sz*1.0,.16,7,wood);
  vB('vWood',gx,4.6,CD/2,2.6,.2,2.6,0,wood);for(let k=0;k<8;k++){const a=k/8*TAU;vPst('vPost',gx+Math.cos(a)*1.25,4.8,CD/2+Math.sin(a)*1.25,.06,1.0,wood);}
  vnHipRoof('vHipC',gx,7,CD/2,2.6,2.6,1.3,0,null,.6);vnLampPost(s*2.0,0,CD/2+1.4,3.6);}
 vB('vWood',0,4.6,CD/2,5.0,.2,1.4,0,wood);vB('vWood',0,4.8,CD/2+.6,5.0,.9,.08,0,wood);
 for(const s of[-1,1])kput('vWood',[s*1.35,2.2,CD/2+.1],vQ(0,0,0).multiply(qEuler(0,s*.5,0)),[2.4,4.2,.1],wood.clone().multiplyScalar(.85));   // gate leaves, half open
 // two barrack blocks along the sides: timber frame + plaster, verandas to the yard, corrugate gable roofs
 for(const s of[-1,1]){const bx=s*13.5,BW=8,BD=20,Y0=.4;vB('vStone',bx,-.1,-2,BW+.5,.5,BD+.5,0,stD);vnFrame(bx,Y0,-2,BW,3.6,BD,0,wood,.16);vB('vPlaster',bx,Y0,-2,BW-.14,3.6,BD-.14,0,pl);
  const t=vnCornice('vWood',bx,Y0+3.6,-2,BW,BD,0,wood,1);vnGableRoof(bx,t,-2,BD,BW,2.4,Math.PI/2,'vGableC',null,1.0,'vGablePl',pl,.12);
  const fx=bx-s*BW/2;vnVeranda(fx-s*1.2,Y0,-2,BD-1,2.4,-s*Math.PI/2,.04,2.9,wood);vnShedRoof(fx-s*1.2,Y0+2.9,-2,BD-1,2.4,.6,-s*Math.PI/2,'vCorr',null,.4,.12);
  for(let i=0;i<6;i++){const z=-2-BD/2+BD*(i+.5)/6;if(i%3===1)vnDoor(fx,Y0,z,-s*Math.PI/2,1.2,2.3,'vWood',wood,vC(0x5a3a24),false);else vnWin(fx,Y0+1.3,z,-s*Math.PI/2,1.2,1.2,'open','vWood',wood,true);}
  for(let i=0;i<5;i++)vnWin(bx+s*BW/2,Y0+1.4,-2-BD/2+BD*(i+.5)/5,s*Math.PI/2,1.0,1.0,'shut','vWood',wood);
  vnChimney(bx,t+2.6,-2-BD/2+3,1.8,.16,true);vnDryingRack(bx,0,-2+BD/2+2.2,0,4);}
 // armoury at the back: squat stone, iron door, lamp
 {const AW=9,AD=6,az=-CD/2+AD/2+1.5;vB('vStone',0,0,az,AW,3.4,AD,0,st);vnCornice('vStone',0,3.4,az,AW,AD,0,st,2);vnHipRoof('vHipC',0,3.4+.84,az,AW,AD,1.4,0,null,.7);
  vB('vDarkB',0,0,az+AD/2,1.6,2.4,.1,0);vB('vIron',0,0,az+AD/2+.06,1.5,2.35,.08,0,vC(0x3a3632));for(const s of[-1,1])vB('vStone',s*1.05,0,az+AD/2+.1,.3,2.6,.3,0,stD);vB('vStone',0,2.6,az+AD/2+.1,2.6,.3,.4,0,stD);
  for(const x of[-3,3])vnWin(x,1.6,az+AD/2,0,.7,.6,'open','vStone',st);vnLamp(0,3.0,az+AD/2,0);
  for(let k=0;k<6;k++)kput('vWood',[-3.4+k*.5,1.6,az+AD/2+.9],vQ(0,.15,0),[.06,3.2,.06],vC(0x5a4632));vB('vWood',-2.2,1.05,az+AD/2+.6,3.0,.12,.4,0,wood);}   // spear rack
 // watch tower on the back corner
 {const tx=-CW/2+3,tz=-CD/2+3;for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',tx+sx*1.6,-.2,tz+sz*1.6,.18,10.5,wood,qEuler(sz*.05,0,-sx*.05));
  for(const y of[3,6])for(const s of[-1,1]){vB('vWood',tx,y,tz+s*1.5,3.2,.14,.14,0,wood);vB('vWood',tx+s*1.5,y,tz,.14,.14,3.2,0,wood);}
  vB('vWood',tx,8.8,tz,3.8,.22,3.8,0,wood);for(let k=0;k<12;k++){const a=k/12*TAU;vPst('vPost',tx+Math.cos(a)*1.85,9,tz+Math.sin(a)*1.85,.06,1.0,wood);}
  vnHipRoof('vHipC',tx,11.4,tz,3.4,3.4,1.5,0,null,.7);for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',tx+sx*1.5,9,tz+sz*1.5,.1,2.4,wood);
  vnLadder(tx+1.2,0,tz+2.2,0,8.8,wood);}
 // the drill yard: paving, pells, a straw archery butt, weapon racks, the standard, benches, water
 vnPaving(0,.02,2,18,20,0,vC(0x8a7a66),40);
 for(let k=0;k<5;k++){vPst('vPostB',-6+k*3,0,7,.16,2.0,vC(0x6a5a48));vB('vWood',-6+k*3,1.5,7,.9,.12,.12,0,vC(0x6a5a48));}
 for(let k=0;k<3;k++){vPst('vStave',-3+k*3,0,-9,.7,1.4,vC(0xc8a870));vBq('vHoop',-3+k*3,.9,-9+.72,.4,.4,1,qEuler(0,0,0),vC(0xc9442a));}
 vnBannerPole(0,0,1,0,9,vC(0xe07a2a));vB('vStone',0,0,1,1.4,.6,1.4,0,stD);
 for(const x of[-5,5]){vB('vWood',x,0,-4,.5,.45,3.0,0,wood);}vnWaterButt(8,0,-6,.5,1.1);vnWaterButt(-8,0,-6,.5,1.1);vnCrate(8.5,0,8,.9,.2,wood);
 vnLampPost(-7,0,1,3.6);vnLampPost(7,0,1,3.6);
 vnFolk(0,2,9,5);}

// ---------------------------------------------------------------- the alchemist's compound: walled; house with a dome-topped lab tower, still-house of copper, furnace, herb beds
function buildVernAlchemist(G,o){reseed(7531+(o.v|0));const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),cu=vC(0xffffff),pl=vC(vPick(VPAL.sand));
 vnReg('Alchemist\'s compound',0,0,17,19,{type:['civic','industry']});
 const CW=28,CD=24,h=2.6;vB('vStone',0,0,0,CW+2,.4,CD+2,0,stD);
 for(const s of[-1,1]){vB('vStone',s*CW/2,0,0,.6,h,CD,0,stD);vB('vStone',s*CW/2,h,0,.9,.3,CD+.3,0,st);}vB('vStone',0,0,-CD/2,CW,h,.6,0,stD);vB('vStone',0,h,-CD/2,CW+.3,.3,.9,0,st);
 for(const s of[-1,1]){const L=CW/2-1.7;vB('vStone',s*(1.7+L/2),0,CD/2,L,h,.6,0,stD);vB('vStone',s*(1.7+L/2),h,CD/2,L+.3,.3,.9,0,st);vB('vStone',s*1.95,0,CD/2,1.0,h+1.0,1.0,0,st);kput('vPyrCu',[s*1.95,h+1.0,CD/2],null,[1.2,.8,1.2],cu);}
 for(let k=-2;k<=2;k++)vB('vIron',k*.6,0,CD/2,.06,h-.2,.06,0,vC(0x2e2a26));for(const y of[.5,h-.5])vB('vIron',0,y,CD/2,3.0,.08,.08,0,vC(0x2e2a26));vnLampPost(-3.4,0,CD/2+1.2,3.2);vnLampPost(3.4,0,CD/2+1.2,3.2);
 // the house: two storeys of stone with a round lab tower carrying a copper dome and a glass lantern
 {const HW=11,HD=8,hx=-5,hz=-5,Y0=.4;vB('vStone',hx,Y0,hz,HW,3.8,HD,0,st);const c1=vnCornice('vStone',hx,Y0+3.8,hz,HW,HD,0,st,1,false);
  vB('vWood',hx,c1,hz,HW-.3,3.2,HD-.3,0,wood);const c2=vnCornice('vWood',hx,c1+3.2,hz,HW-.3,HD-.3,0,wood,2);vnHipRoof('vHipCu',hx,c2,hz,HW-.3,HD-.3,2.4,0,cu,1.2);
  vnDoor(hx+1.5,Y0,hz+HD/2,0,1.4,2.6,'vStone',st,vC(0x4a2e1c));for(const x of[-3.5,-1.2])vnWin(hx+x,Y0+1.2,hz+HD/2,0,1.2,1.7,'lit','vStone',st);vnStrip(hx+3.9,Y0+.7,hz+HD/2+.02,0,.6,2.8,'vStone',stD);
  for(const x of[-3.6,-1.2,1.2,3.6])vnWin(hx+x,c1+.9,hz+HD/2-.15,0,1.1,1.5,'lit','vWood',wood);
  for(const s of[-1,1])for(const z of[-2,2]){vnWin(hx+s*HW/2,Y0+1.2,hz+z,s*Math.PI/2,1.1,1.7,'lit','vStone',st);vnWin(hx+s*(HW/2-.15),c1+.9,hz+z,s*Math.PI/2,1.0,1.5,'lit','vWood',wood);}
  const tx=hx+HW/2+1.2,tz=hz-HD/2+1.6,TH=c2+3.2;vPst('vPostS',tx,Y0,tz,2.6,TH-Y0,st);vB('vStone',tx,TH,tz,6.0,.35,6.0,0,stD);
  for(let k=0;k<3;k++){const y=Y0+2.2+k*3.0;for(let j=0;j<6;j++){const a=j/6*TAU+k*.3;vnWin(tx+Math.cos(a)*2.6,y,tz+Math.sin(a)*2.6,Math.PI/2-a,.8,1.4,'lit','vStone',st);}}
  for(let k=0;k<10;k++){const a=k/10*TAU;vPst('vPipeC',tx+Math.cos(a)*2.4,TH+.35,tz+Math.sin(a)*2.4,.08,1.6,cu);}
  mesh(lathe({rFn:()=>2.45,H:1.6,nu:24,nv:2}),MAT.glass,G,tx,TH+.35,tz);kput('vDomeC',[tx,TH+1.95,tz],null,[2.7,2.2,2.7],cu);vBall('vFinial',tx,TH+4.3,tz,.28);
  vBall('vBulb',tx,TH+1.1,tz,.22);}
 // still-house: open timber shed with copper stills, coils and glass retorts on a bench; furnace with a chimney behind
 {const sx=7.5,sz=-4,SW=9,SD=8;vB('vStone',sx,0,sz,SW+.4,.4,SD+.4,0,stD);vnFrame(sx,.4,sz,SW,3.6,SD,0,wood,.16);vB('vPlaster',sx,.4,sz-SD/4-.1,SW-.2,3.6,SD/2-.2,0,pl);
  const t=vnCornice('vWood',sx,4.0,sz,SW,SD,0,wood,1,false);vnGableRoof(sx,t,sz,SW,SD,2.3,0,'vGableCu',cu,1.0,'vGablePl',pl,.14);
  for(let k=0;k<3;k++){const px=sx-3+k*3,pz=sz+1.4;vB('vStone',px,.4,pz,1.8,.7,1.8,0,stD);vPst('vPipeC',px,1.1,pz,.75,1.6,cu);kput('vDomeC',[px,2.7,pz],null,[.78,.7,.78],cu);
   vPst('vPipeC',px,3.35,pz,.14,.7,cu);kput('vPipeC',[px+.8,3.9,pz],qEuler(0,0,Math.PI/2*.9),[.1,1.6,.1],cu);for(let j=0;j<4;j++)vBq('vHoop',px+1.6,3.3-j*.35,pz,.32,.32,1,qEuler(0,Math.PI/2,0),cu.clone().multiplyScalar(.8));
   vPst('vBarrel',px+1.6,.4,pz,.4,1.6,wood);vBall('vEmber',px,.75,pz+.85,.16);}
  vB('vWood',sx,.4,sz+3.4,SW-1.4,.9,.8,0,wood);for(let k=0;k<6;k++){const x=sx-3.2+k*1.28;mesh(lathe({rFn:y=>.28*Math.sqrt(clamp(1-Math.pow(y/.5-1,2),0,1))+.04,H:1.0,nu:12,nv:8}),MAT.glass,G,x,1.3,sz+3.4);vPst('vClayPot',x+.5,1.3,sz+3.4,.1,.3,vC(vPick([0x9a5a38,0x5a7a8a])));}
  vB('vStone',sx-3.2,.4,sz-3.2,2.2,1.6,1.6,0,stD);vB('vDarkB',sx-3.2,.9,sz-2.4,.9,.6,.2,0);vBall('vEmber',sx-3.2,1.1,sz-2.35,.14);vnChimney(sx-3.2,2.0,sz-3.2,5.4,.3,true);}
 // herb beds, a well, drying racks with bundles, jars along the wall
 for(let k=0;k<4;k++)vnPlanter(-9+k*3.4,0,6.5,2.8,1.2,0,wood);for(let k=0;k<3;k++)vnPlanter(-9+k*3.4,0,9.2,2.8,1.2,0,wood);
 {const wx=7,wz=6;vPst('vPostS',wx,0,wz,1.3,1.1,stD);vB('vDarkB',wx,1.1,wz,1.6,.1,1.6,0);for(const s of[-1,1])vPst('vPost',wx+s*1.2,0,wz,.09,2.6,wood);vB('vWood',wx,2.5,wz,2.8,.14,.14,0,wood);vnHipRoof('vHipCu',wx,2.8,wz,2.0,2.0,.9,0,cu,.5);vPst('vRope',wx,1.2,wz,.02,1.3,vC(0xa89878));vnBarrel(wx+.4,1.1,wz+.3,.22,.35,wood);}
 vnDryingRack(-5,0,-CD/2+1.6,0,5);for(let k=0;k<7;k++)vPst('vClayPot',-CW/2+1.2,0,-8+k*1.3,rr(.22,.32),rr(.5,.8),vC(vPick([0x9a5a38,0xb87a4a,0x7a4a30,0x5a7a8a])));
 vnPaving(0,.02,(CD/2-3)/2+2,2.6,CD/2-3,0,st,6);vnLamp(-3.5,3.4,-1,0);
 vnFolk(0,2,4,3);}

VERN.def({key:'vern_school',name:'School',family:'civic',tags:VTAG_CIV,w:34,d:30,h:15,build:buildVernSchool});
VERN.def({key:'vern_hospital',name:'Hospital',family:'civic',tags:VTAG_CIV,w:38,d:28,h:16,build:buildVernHospital});
VERN.def({key:'vern_barracks',name:'Barracks and drill yard',family:'civic',tags:{type:['civic','military'],wealth:'civic',lit:true},w:48,d:38,h:14,build:buildVernBarracks});
VERN.def({key:'vern_alchemist',name:'Alchemist\'s compound',family:'civic',tags:{type:['civic','industry'],wealth:'civic',lit:true},w:32,d:28,h:19,build:buildVernAlchemist});
// ================================================================= POLICE STATION — "the Watch"
function buildPolice(scene,gx,gz,d){reseed(9230+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);
 REGISTER({name:'Police station — the Watch ('+STATE(d)+')',x:0,z:0,r:90,h:60});
 kput(SLABC(d),[0,.4,0],null,[80,.8,80],null);
 // main block: battered hex, two storeys, slit windows, a sally-port
 const R0=34,R1=30,HM=12;mesh(lathe({rFn:y=>R0-(R0-R1)*y/HM,H:HM,nu:6,nv:4,hole:holeFn(d*.7,1800,null,1.5)}),CONC(d),G,0,.8,0);mesh(lathe({rFn:y=>(R0-(R0-R1)*y/HM)*.9,H:HM,nu:6,nv:1}),MAT.dark,G,0,.8,0);
 kput(SLABC(d),[0,.8+HM,0],null,[R1*.98,.8,R1*.98],null);
 for(let f=0;f<6;f++){const fa=f/6*TAU+Math.PI/6;const n=[Math.cos(fa),0,Math.sin(fa)];const tg=[-n[2],0,n[0]];for(let k=-2;k<=2;k++)for(const yy of [4.5,9.5]){const r=hexR(R0-(R0-R1)*(yy-.8)/HM,fa)+.2;kput(d>0?'winSmD':'winSmI',[n[0]*r+tg[0]*k*7,yy,n[2]*r+tg[2]*k*7],qFacing(n),[1.2,2.6,1],null);}
  for(let k=-2;k<=2;k++){const r=hexR(R0,fa)+1;beam(BOXC(d),[n[0]*r+tg[0]*k*8,.8,n[2]*r+tg[2]*k*8],[n[0]*(r-4.5)+tg[0]*k*8,.8+HM+2,n[2]*(r-4.5)+tg[2]*k*8],1.6,1.4);}}
 kput('archOpen',[0,4,hexR(R0,Math.PI/2)-.5],qFacing([0,0,1]),[1,1,3],null);kput(BOXC(d),[0,7,hexR(R0,Math.PI/2)+6],null,[16,1,12],null);
 // watch tower: lattice hyperboloid with cupola and light
 const TH=44,tcut=d>0?TH*.6:null;const tx=-22,tz=-18;const rFn=y=>4*Math.sqrt(1+2.5*Math.pow((y-TH*.6)/(TH*.6),2));
 for(let k=0;k<6;k++)for(const dir of [-1,1]){let prev=null;for(let y=0;y<=(tcut||TH);y+=3){const th=k/6*TAU+dir*y*.06;const r=rFn(y);const p=[tx+r*Math.cos(th),.8+HM+y,tz+r*Math.sin(th)];if(prev)beam(d>0?'strutR':'strutW',prev,p,.7,.7);prev=p;}}
 kput('tube',[tx,.8+HM+(tcut||TH)/2,tz],null,[1.6,(tcut||TH),1.6],null);
 if(!tcut){mesh(lathe({rFn:y=>8*Math.pow(clamp(1-Math.pow((y-4)/4,2),0,1),.5)+.01,H:8,nu:32,nv:8}),CONC(d),G,tx,.8+HM+TH-2,tz);kput('slab',[tx,.8+HM+TH+1.5,tz],null,[7,.6,7],new THREE.Color(0x1a1d22));stripRing(tx,.8+HM+TH+2,tz,6.5,d,16);kput('finial',[tx,.8+HM+TH+8,tz],null,[1.2,2,1.2],null);}
 // vehicle bays wing + perimeter wall with gate
 kput(BOXC(d),[42,5,-10],null,[30,10,50],null);kput('boxD',[42,5,-10],null,[28,9,48],null);for(let k=0;k<3;k++)kput('archOpen',[57.2,3.4,-26+k*16],qFacing([1,0,0]),[.9,.75,1.5],null);
 for(let k=0;k<3;k++){const lit=d>0?rng()<.2:true;kput('strip',[57.4,9.2,-26+k*16],qEuler(0,0,0),[10,1,1],lit?CYAN:DEAD);}
 for(let k=0;k<4;k++){const a=k*Math.PI/2;for(let j=-1;j<=1;j+=2){if(k===0&&j===1)continue;kput(BOXC(d),[Math.cos(a)*44+ (-Math.sin(a))*j*22,2.5,Math.sin(a)*44+Math.cos(a)*j*22],qEuler(0,-a,0),[1.2,5,44],null);}}
 kput(BOXC(d),[46,6,44],null,[3,12,3],null);kput(BOXC(d),[-46,6,44],null,[3,12,3],null);kput('boxD',[0,3,44],null,[1,6,1],null);
 for(let k=0;k<6;k++){const x=-30+k*12;kput(BOXC(d),[x,.8,60],null,[5,.5,10],null);}
 if(d>0){mossOnRing(0,.8+HM+.5,0,26,20,2);rubbleRing(0,.8,0,36,60,40,2);vinesOnRing(0,.8+HM,0,R1,12,10);}
 figures(0,50,4,6);KOFF=[0,0,0];return G;}

// ================================================================= IZIZ VERNACULAR — infrastructure
// Grain silos (farm), the reclaimed storage tank, the electric generator.
// The generator is civic infrastructure and lit; the silos and tank are not.

// ---------------------------------------------------------------- grain silos: four stave silos on stilts under thatch cones, a covered loading deck, ladders
function buildVernSilos(G,o){reseed(7601+(o.v|0));const wood=vC(vPick(VPAL.woodMid)),th=vC(vPick(VPAL.thatch)),stv=vC(vPick([0xa88a5e,0x9a7a4e,0xb89a6a]));
 vnReg('Grain silos',0,0,11,13,{type:['farm','infrastructure']});
 vnPaving(0,.02,0,20,14,0,vC(0x8a7a66),16);
 const S=[[-6,-2.5,2.2],[-2,-3.5,2.0],[2.2,-3.2,2.3],[6.2,-2.4,1.9]];
 S.forEach((s,i)=>{const[x,z,r]=s;const FL=1.8,H=5.0+rr(-.4,.6);
  for(let k=0;k<6;k++){const a=k/6*TAU;vPst('vPostB',x+Math.cos(a)*r*.8,-.2,z+Math.sin(a)*r*.8,.16,FL+.2,wood);vB('vStone',x+Math.cos(a)*r*.8,-.35,z+Math.sin(a)*r*.8,.5,.35,.5,0,vC(0x9a8a78));}
  vB('vWood',x,FL-.2,z,r*2.3,.2,r*2.3,0,wood);
  vPst('vStave',x,FL,z,r,H,stv.clone().multiplyScalar(rr(.9,1.08)));for(const yy of[.6,H*.45,H-.5])vBq('vHoop',x,FL+yy,z,r*1.02,r*1.02,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));
  vnThatchCone(x,FL+H,z,r,r*1.3,th);vB('vWood',x,FL+H+r*1.3-.3,z,.16,.9,.16,0,wood);
  vB('vDarkB',x,FL+.6,z+r-.05,.8,.9,.2,0);vB('vWood',x,FL+.6,z+r+.05,.75,.85,.06,0,wood);      // hatch and its board
  vnLadder(x+r*.55,0,z+r+.5,0,FL+.4,wood);});
 // covered loading deck in front of the row: a long thatch shed on posts, sacks and a cart-less pile
 vB('vWood',0,.9-.2,3.2,15,.2,3.2,0,wood);for(let i=0;i<=6;i++)vPst('vPostB',-7.5+15*i/6,-.1,4.7,.13,.9,wood);
 for(let i=0;i<=5;i++)for(const s of[-1,1])vPst('vPost',-7+14*i/5,.9,3.2+s*1.4,.12,2.8,wood);
 vnGableRoof(0,3.7,3.2,15,3.2,1.4,0,'vGableT',th,.9,null,null,.4);
 vnSacks(-4,.9,3.2,6);vnSacks(3,.9,3.4,5);vnCrate(6.2,.9,3,.8,.3,wood);vnStairs(-7.6,0,4.5,Math.PI/2,1.2,.9,3,'vWood',wood);
 vnDryingRack(7.5,0,-6,Math.PI/2,3);vnFolk(0,7,3,2.5);}

// ---------------------------------------------------------------- storage tank: a reclaimed Ancient tank on a stone base, riveted bands, stair and gantry, pipe run to a trough, pump hut
function buildVernTank(G,o){reseed(7611+(o.v|0));const st=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodMid)),iron=vC(0x2e2a26);
 vnReg('Storage tank (reclaimed)',0,0,9,12,{type:['infrastructure']});
 const R=4.6,H=7.5,B=1.2;vB('vStone',0,0,0,R*2.6,B,R*2.6,0,st);vPst('vPostS',0,B,0,R*1.08,.4,st);
 vPst(rng()<.5?'vTankW':'vTankR',0,B+.4,0,R,H,null);vPst('vTankR',0,B+.4,0,R+.02,H*.28,null);                    // rust rising from the foot
 for(const yy of[.5,H*.33,H*.66,H-.35])vBq('vHoop',0,B+.4+yy,0,R*1.03,R*1.03,1,qEuler(Math.PI/2,0,0),iron);
 for(let k=0;k<3;k++)vPl('vPlate',Math.cos(k*2.3)*(R+.05),B+.4+rr(1.5,5.5),Math.sin(k*2.3)*(R+.05),Math.PI/2-k*2.3,null,0);   // welded patches
 kput('vDomeC',[0,B+.4+H,0],null,[R*1.02,R*.28,R*1.02],vC(0x8a8a8a));vB('vIron',0,B+.4+H+R*.28,0,.9,.6,.9,0,iron);vB('vIron',0,B+.4+H+R*.28+.6,0,.3,.9,.3,0,iron);
 // spiral-ish stair: three straight flights on the outside, a gantry rail at the top
 for(let f=0;f<3;f++){const a0=f*1.5,steps=9;for(let k=0;k<steps;k++){const a=a0+k*1.5/steps,y=B+.4+f*H/3+H/3*k/steps;vBq('vIron',Math.cos(a)*(R+.55),y,Math.sin(a)*(R+.55),.9,.06,.3,qEuler(0,-a,0),iron);
   if(k%3===0)vBq('vIron',Math.cos(a)*(R+.95),y+.5,Math.sin(a)*(R+.95),.05,1.0,.05,null,iron);}
  vBq('vIron',Math.cos(a0+.75)*(R+.98),B+.4+f*H/3+H/6+1.0,Math.sin(a0+.75)*(R+.98),.06,.06,1.5,qEuler(0,-(a0+.75),0),iron);}
 for(let k=0;k<20;k++){const a=k/20*TAU;vPst('vIron',Math.cos(a)*(R+.3),B+.4+H,Math.sin(a)*(R+.3),.04,1.0,iron);}
 vBq('vHoop',0,B+.4+H+1.0,0,R+.3,R+.3,1,qEuler(Math.PI/2,0,0),iron);
 // outlet pipe down the side, along the ground to a stone trough and a standpipe; a hand pump hut
 kput('vPipe',[R+.4,B+.4+1.2,0],qEuler(0,0,Math.PI/2),[.16,.9,.16],iron);vPst('vPipe',R+.85,.3,0,.16,B+1.3,iron);kput('vPipe',[R+.85+3,.5,0],qEuler(0,0,Math.PI/2),[.14,6,.14],iron);
 vB('vStone',R+7.4,0,0,3.0,.8,1.2,0,st);vB('vDarkB',R+7.4,.6,0,2.6,.25,.9,0);vPst('vPipe',R+6.4,.8,0,.08,1.2,iron);kput('vPipe',[R+6.7,1.9,0],qEuler(0,0,Math.PI/2),[.07,.6,.07],iron);
 for(let k=0;k<3;k++)vB('vIron',R+2+k*1.8,0,.35,.18,.5,.18,0,iron);
 {const hx=-R-3.6;vB('vWood',hx,0,1.5,3.2,2.6,3.0,0,wood);vnShedRoof(hx,2.6,1.5,3.2,3.0,.8,0,'vCorr',null,.5,.1);vnDoor(hx,0,3.0,0,.9,2.0,'vWood',wood,vC(0x6a4a30),false);
  kput('vPipe',[(hx+1.6-R)/2,.5,1.5],qEuler(0,0,Math.PI/2),[.12,-R-(hx+1.6),.12],iron);vnBarrel(hx-2.0,0,-.5,.4,1,wood);}
 vnPaving(0,.02,0,R*3.4,R*3.4,0,vC(0x7a7068),20);vnWaterButt(2,0,R+2.6,.45,1.0);vnWaterButt(3.1,0,R+2.6,.45,1.0);
 vnFolk(0,R+4,2,1.5);}

// ---------------------------------------------------------------- electric generator: stone engine house, a reclaimed machine with flywheel, exhaust stack, cable poles, fuel drums, fenced yard
function buildVernGenerator(G,o){reseed(7621+(o.v|0));const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodMid)),iron=vC(0x2e2a26);
 vnReg('Electric generator',0,0,12,12,{type:['infrastructure','civic']});
 vnPaving(0,.02,0,22,16,0,vC(0x7a7068),30);vnFence(0,0,0,22,16,0,wood,3,1.4);
 // engine house: open on the front so the machine reads
 const W=9,D=7,H=4.6,Y0=.4;vB('vStone',0,-.1,-1,W+.6,.5,D+.6,0,stD);
 vB('vStone',0,Y0,-1-D/2+.4,W,H,.8,0,st);for(const s of[-1,1])vB('vStone',s*(W/2-.4),Y0,-1,.8,H,D,0,st);      // three stone walls
 for(const s of[-1,1])vB('vStone',s*(W/2-.4),Y0,-1+D/2-.4,.9,H+.6,.9,0,stD);vB('vStone',0,Y0+H,-1,W+.2,.5,D+.2,0,stD);
 const t=vnCornice('vStone',0,Y0+H+.5,-1,W,D,0,st,1);vnGableRoof(0,t,-1,W,D,2.0,0,'vGableCu',vC(0xffffff),1.0,'vGableSt',st,.16);
 for(const s of[-1,1])vnWin(s*W/2,Y0+2.4,-1,s*Math.PI/2,1.2,1.4,'lit','vStone',st);vnWin(0,Y0+2.6,-1-D/2,Math.PI,1.6,1.2,'lit','vStone',st);
 // the machine: a rusted housing, a big flywheel on a shaft, a dynamo drum, cooling fins, pipes, gauges
 {const mx=-.6,mz=-1.2;vB('vStone',mx,Y0,mz,5.2,.6,3.4,0,stD);kput('vRustB',[mx-1.2,Y0+1.7,mz],null,[2.2,2.2,2.6],null);kput('vPanelB',[mx-1.2,Y0+2.95,mz],null,[2.4,.3,2.8],null);
  for(let k=0;k<7;k++)kput('vRustB',[mx-1.2,Y0+1.7,mz-1.35-.02+k*0],null,[.1,.1,.1],null);for(let k=0;k<6;k++)vBq('vIron',mx-2.35,Y0+.9+k*.3,mz,.08,.12,2.2,null,iron);   // fins
  kput('vPipe',[mx+1.2,Y0+1.7,mz],qEuler(0,0,Math.PI/2),[.16,3.2,.16],iron);
  vBq('vHoop',mx+1.6,Y0+1.7,mz,1.5,1.5,1,qEuler(0,Math.PI/2,0),vC(0x4a4640));for(let k=0;k<6;k++)vBq('vIron',mx+1.6,Y0+1.7,mz,.1,2.9,.12,qEuler(k*Math.PI/6,0,0).multiply(qEuler(0,Math.PI/2,0)),vC(0x4a4640));
  vBq('vIron',mx+1.6,Y0+1.7,mz,.3,.5,.5,null,iron);vPst('vPostS',mx+1.6,Y0+.6,mz+.9,.25,1.1,stD);vPst('vPostS',mx+1.6,Y0+.6,mz-.9,.25,1.1,stD);
  kput('vPipeC',[mx+2.6,Y0+1.5,mz],qEuler(0,0,Math.PI/2),[.7,1.4,.7],vC(0xffffff));vBq('vIron',mx+2.6,Y0+1.5,mz,1.5,.5,.5,null,iron);           // the dynamo drum, copper
  for(let k=0;k<3;k++)vBall('vBallW',mx-1.9+k*.6,Y0+3.15,mz+1.1,.12,vC(0xd8d0c0));
  vPst('vPipeR',mx-1.6,Y0+2.9,mz-.8,.22,H-2.9+.6,null);vnChimney(mx-1.6,Y0+H+.4,mz-.8,3.6,.22,true);
  vBall('vBulb',mx,Y0+H-.4,mz,.16);vBall('vEmber',mx-1.2,Y0+1.1,mz+1.31,.08);}
 // cable poles leading away from the house, a switchboard on the wall, lamps in the yard, fuel drums under a lean-to
 {const pts=[[3.8,3.6],[9.2,6.2],[-9.5,5.5]];for(const p of pts){vPst('vPost',p[0],0,p[1],.1,5.6,wood);vB('vWood',p[0],5.2,p[1],1.2,.1,.1,0,wood);for(const s of[-1,1])vBall('vBallW',p[0]+s*.5,5.32,p[1],.06,vC(0xd8d0c0));}
  vBeam([-W/2+.4,Y0+H+.3,-1+D/2-.5],[pts[0][0]-.5,5.3,pts[0][1]],.03,vC(0x2e2a26),'vRope');vBeam([pts[0][0]+.5,5.3,pts[0][1]],[pts[1][0]-.5,5.3,pts[1][1]],.03,vC(0x2e2a26),'vRope');
  vBeam([-W/2+.4,Y0+H+.3,-1+D/2-.5],[pts[2][0]+.5,5.3,pts[2][1]],.03,vC(0x2e2a26),'vRope');
  vB('vIron',W/2-.45,Y0+1.2,-1+D/2-.1,.3,1.4,1.0,0,vC(0x3a3632));for(let k=0;k<4;k++)vBall('vBallW',W/2-.28,Y0+1.5+k*.25,-1+D/2-.4+k*.2,.05,vC(0xd8d0c0));}
 vnLampPost(-7,0,-3,3.6);vnLampPost(7,0,-3,3.6);vnLampPost(0,0,6.4,3.8);
 {const lx=W/2+2.6;for(const z of[-3.5,.5])vPst('vPost',lx+1.4,0,z,.08,2.4,wood);for(const z of[-3.5,.5])vPst('vPost',lx-1.4,0,z,.08,2.0,wood);kput('vCorr',[lx,2.3,-1.5],vQ(0,0,.14),[3.2,.08,4.6],null);
  for(let k=0;k<4;k++)vPst('vTank',lx-.7+(k%2)*1.4,0,-3+Math.floor(k/2)*1.5,.42,1.1,null);for(let k=0;k<2;k++)kput('vTank',[lx-.7+k*1.4,.45,.7],qEuler(0,0,Math.PI/2),[.42,1.1,.42],null);}
 vnCrate(-W/2-2.2,0,-3,.9,.3,wood);vnFolk(0,4,2,2);}

VERN.def({key:'vern_silos',name:'Grain silos',family:'infrastructure',tags:{type:['farm','infrastructure'],wealth:'middle',lit:false},w:22,d:16,h:13,build:buildVernSilos});
VERN.def({key:'vern_tank',name:'Storage tank',family:'infrastructure',tags:{type:['infrastructure'],wealth:'middle',lit:false},w:24,d:16,h:12,build:buildVernTank});
VERN.def({key:'vern_generator',name:'Electric generator',family:'infrastructure',tags:{type:['infrastructure','civic'],wealth:'civic',lit:true},w:24,d:18,h:12,build:buildVernGenerator});
// ================================================================= IZIZ VERNACULAR — guilds
// The Farmers' Guild, the Beast Hunters' Guild, the caravanserai and the
// Forgemaster's Hall where the Empire's surviving Ancient mechs are kept
// walking. Three are civic and carry electric light; the caravanserai is
// trade, middle class, and has only the fire in its braziers. Seeds 7701–7739.
// Local helpers are prefixed vg (the shared vn* set is off limits here).

// ---------------------------------------------------------------- local helpers (LOCAL frame, y = base of the piece)
// cloth banner hanging from a bar at (x,y,z), face normal ry; `sheaf` adds the Farmers' straw-sheaf motif
function vgBanner(x,y,z,ry,w,h,c,sheaf){vB('vWood',x,y-.08,z,w+.3,.08,.08,ry,vC(0x5a4632));vPl('vCloth',x,y-.1-h/2,z,w,h,ry,c||vC(vPick(VPAL.awning)));
 if(sheaf){const p=loc(x,z,0,.05,ry);vB('vThatchB',p[0],y-.1-h*.68,p[1],w*.3,h*.36,.05,ry,vC(0xd8b860));vB('vWood',p[0],y-.1-h*.52,p[1],w*.36,.06,.06,ry,vC(0x5a4632));}}
// feeding trough: board box with a dark bed, on two sleepers
function vgTrough(x,y,z,L,ry,c){vB('vWood',x,y+.2,z,L,.55,.8,ry,c);vB('vDarkB',x,y+.62,z,L-.16,.12,.64,ry);for(const s of[-1,1]){const p=loc(x,z,s*(L/2-.4),0,ry);vB('vWood',p[0],y,p[1],.14,.22,1.0,ry,c);}}
// tethering post with an iron ring
function vgTether(x,z,c){vPst('vPostB',x,-.15,z,.13,1.75,c);vBq('vHoop',x,1.3,z,.2,.2,1,qEuler(Math.PI/2,0,0),vC(0x2e2a26));}
// drying rack with hides (tarp planes tinted hide-brown) over a rail
function vgHideRack(x,z,ry,L,c){for(const s of[-1,1]){const p=loc(x,z,s*L/2,0,ry);vPst('vPost',p[0],0,p[1],.08,2.5,c);}
 const a=loc(x,z,-L/2,0,ry),b=loc(x,z,L/2,0,ry);vBeam([a[0],2.4,a[1]],[b[0],2.4,b[1]],.1,c);
 for(let k=0;k<Math.round(L/1.2);k++){const p=loc(x,z,-L/2+.7+k*1.2,rr(-.03,.03),ry);kput('vTarp',[p[0],1.6,p[1]],vQ(ry,rr(-.08,.08),0),[rr(.8,1.1),rr(1.3,1.7),1],vC(vPick([0x7a5236,0x6a4630,0x8a6244,0x5a3e2c])));}}
// rack of spears / harpoons leaning in a rail
function vgSpearRack(x,z,ry,n,c){const L=n*.42+.4;vB('vWood',x,1.05,z,L,.12,.32,ry,c);for(const s of[-1,1]){const p=loc(x,z,s*(L/2-.1),0,ry);vPst('vPost',p[0],0,p[1],.07,1.15,c);}
 for(let k=0;k<n;k++){const p=loc(x,z,-L/2+.4+k*.42,0,ry);kput('vWood',[p[0],1.6,p[1]],vQ(ry,.1,0),[.06,3.2,.06],vC(0x5a4632));kput('vConeI',[p[0],3.15,p[1]],vQ(ry,.1,0),[.06,.45,.06],vC(0x8a8a8a));}}
// beam balance on a post: pivot, beam, two pans on ropes, sacks on one and iron weights on the other
function vgScale(x,z,c){const iron=vC(0x2e2a26);vB('vStone',x,0,z,1.2,.3,1.2,0,vC(0x8a7a66));vPst('vPostB',x,.3,z,.14,2.6,c);vB('vIron',x,2.85,z,.3,.14,.3,0,iron);
 vB('vWood',x,2.8,z,3.4,.12,.14,0,c);for(const s of[-1,1]){const px=x+s*1.55;for(const q of[-1,1])vPst('vRope',px+q*.3,1.35,z,.02,1.45,vC(0xa89878));
  vPst('vPost',px,1.3,z,.48,.06,c);if(s<0){kput('vSack',[px,1.6,z],null,[.42,.32,.36],vC(0xb8a080));kput('vSack',[px+.1,1.95,z+.1],qEuler(0,.7,0),[.38,.28,.32],vC(0xa89070));}
  else{for(let k=0;k<3;k++)vB('vIron',px-.2+k*.2,1.36,z,.16,.22-k*.05,.16,0,iron);}}}
// two-wheeled farm cart parked with its shafts down
function vgCart(x,z,ry,c){const q=loc(x,z,0,0,ry);vB('vWood',q[0],.75,q[1],1.5,.22,3.0,ry,c);for(const s of[-1,1]){const p=loc(x,z,s*.72,0,ry);vB('vWood',p[0],.97,p[1],.08,.55,3.0,ry,c);}
 for(const e of[-1,1]){const p=loc(x,z,0,e*1.5,ry);vB('vWood',p[0],.97,p[1],1.5,.55,.08,ry,c);}
 for(const s of[-1,1]){const p=loc(x,z,s*.92,.4,ry);kput('vPost',[p[0],.72,p[1]],vQ(ry,0,Math.PI/2),[.7,.1,.7],c.clone().multiplyScalar(.9));vBq('vHoop',p[0],.72,p[1],.74,.74,1,vQ(ry,0,0).multiply(qEuler(0,Math.PI/2,0)),vC(0x2e2a26));}
 {const a=loc(x,z,-1.0,.4,ry),b=loc(x,z,1.0,.4,ry);vBeam([a[0],.72,a[1]],[b[0],.72,b[1]],.06,vC(0x2e2a26),'vPipe');}
 for(const s of[-1,1]){const a=loc(x,z,s*.6,1.5,ry),b=loc(x,z,s*.6,3.6,ry);vBeam([a[0],.9,a[1]],[b[0],.2,b[1]],.08,c);}
 vnSacks(q[0],.97,q[1]-.6,3);}
// courtyard well: stone ring, two posts, a windlass beam, a little corrugate roof, rope and bucket
function vgWell(x,z,wood,st){vPst('vPostS',x,0,z,1.35,1.05,st.clone().multiplyScalar(.7));vB('vDarkB',x,1.05,z,1.7,.08,1.7,0);vB('vStone',x,1.0,z,3.1,.14,3.1,0,st.clone().multiplyScalar(.9));
 for(const s of[-1,1])vPst('vPost',x+s*1.3,0,z,.1,2.8,wood);kput('vPost',[x-1.3,2.55,z],qEuler(0,0,-Math.PI/2),[.12,2.6,.12],wood);vB('vWood',x+1.5,2.5,z,.5,.08,.08,0,wood);
 vnHipRoof('vHipC',x,3.1,z,2.2,2.2,.9,0,null,.5);vPst('vRope',x,1.1,z,.02,1.4,vC(0xa89878));vPst('vBarrel',x+.4,1.05,z+.4,.22,.36,wood);}
// brazier: iron bowl on three legs, embers
function vgBrazier(x,z){const iron=vC(0x2e2a26);for(let k=0;k<3;k++){const a=k/3*TAU;vPst('vPipe',x+Math.cos(a)*.3,0,z+Math.sin(a)*.3,.03,.85,iron,qEuler(Math.sin(a)*.25,0,-Math.cos(a)*.25));}
 vPst('vPipe',x,.8,z,.42,.28,iron);vB('vDarkB',x,1.05,z,.6,.06,.6,0);for(let k=0;k<3;k++)vBall('vEmber',x+rr(-.15,.15),1.1,z+rr(-.15,.15),rr(.08,.14));}
// scrap pile in the smithy idiom: rusted plates, pipe offcuts and ghost-panel scraps within rx × rz
function vgScrap(x,z,rx,rz,n){for(let i=0;i<n;i++){const px=x+rr(-rx,rx),pz=z+rr(-rz,rz);const r=rng();const hgt=Math.pow(rng(),2)*.5;
  if(r<.5)kput('vRustB',[px,hgt+.05,pz],qEuler(rr(-.5,.5),rng()*TAU,rr(-.5,.5)),[rr(.5,1.3),rr(.03,.08),rr(.4,1.1)],null);
  else if(r<.8)kput('vPipeR',[px,hgt+.08,pz],qEuler(Math.PI/2,rng()*TAU,rr(-.3,.3)),[rr(.05,.14),rr(.7,2.2),rr(.05,.14)],null);
  else kput('vPanelB',[px,hgt+.05,pz],qEuler(rr(-.4,.4),rng()*TAU,rr(-.4,.4)),[rr(.5,1.2),.06,rr(.5,1.2)],null);}}
// oil drums: rows standing, a couple lying on top
function vgDrums(x,z,n){for(let k=0;k<n;k++)vPst(k%3===1?'vTankR':'vTank',x+(k%2)*.95,0,z+Math.floor(k/2)*.95,.44,1.15,null);
 if(n>=4)kput('vTank',[x+.47,1.6,z+.47],qEuler(0,0,Math.PI/2),[.44,1.15,.44],null);}
// stylised beast skull, jaw at y, facing +z; scale s (1 = a 2.5 m trophy). Cranium = dome, face plate, void sockets, lathe beak and horns.
function vgSkull(G,x,y,z,s,bone){const B=bone||vC(0xe8dfcc);
 vB('vPlaster',x,y,z,2.3*s,.5*s,2.5*s,0,B);kput('vDomeP',[x,y+.5*s,z-.15*s],null,[1.28*s,1.05*s,1.45*s],B);
 vB('vPlaster',x,y+.5*s,z+.85*s,2.2*s,1.05*s,.7*s,0,B);vB('vPlaster',x,y+1.35*s,z+.75*s,2.5*s,.3*s,1.0*s,0,B.clone().multiplyScalar(.95));   // face plate, brow
 for(const q of[-1,1])vB('vDarkB',x+q*.65*s,y+.75*s,z+1.15*s,.55*s,.5*s,.2*s,0);
 for(let k=0;k<5;k++)vB('vPlaster',x-.7*s+k*.35*s,y-.3*s,z+1.15*s,.12*s,.34*s,.12*s,0,B);                                              // teeth
 const beak=mesh(lathe({rFn:yy=>(.5*(1-yy/(1.9*s))+.04)*s,H:1.9*s,nu:12,nv:4}),MAT.plaster,G,x,y+.62*s,z+1.15*s);beak.rotation.x=Math.PI/2+.28;
 for(const q of[-1,1]){const horn=mesh(lathe({rFn:yy=>(.2*(1-yy/(2.3*s))+.03)*s,H:2.3*s,nu:10,nv:4}),MAT.plaster,G,x+q*.95*s,y+1.25*s,z-.5*s);horn.rotation.set(-.55,0,-q*1.0);}}
// the Ancient walker: ~9 m bipedal mech in ghost-white panel with rust, reverse-jointed legs, one arm (the other lies on a bench). Faces +z.
function vgMech(x,y,z){const white=null,iron=vC(0x2e2a26),dark=vC(0x3a3632);
 for(const s of[-1,1]){const fx=x+s*1.35;
  vB('vPanelB',fx,y,z+.3,1.5,.55,2.7,0,white);for(let k=0;k<3;k++)vB('vRustB',fx-.45+k*.45,y,z+1.7,.3,.4,.5,0,null);                    // foot, toes
  vBall('vBall',fx,y+.95,z+.1,.4,iron);vBeam([fx,y+.95,z+.1],[fx+s*.05,y+3.5,z-1.35],.62,white,'vPanelB');                            // ankle, shin (back to the knee)
  vBall('vBall',fx+s*.05,y+3.5,z-1.35,.5,iron);vB('vRustB',fx+s*.05,y+3.15,z-1.95,.7,.7,.35,0,null);                                 // knee, knee cap
  vBeam([fx+s*.05,y+3.5,z-1.35],[fx+s*.1,y+5.5,z+.35],.78,white,'vPanelB');vB('vRustB',fx+s*.5,y+4.0,z-.6,.3,.9,.5,0,null);        // thigh (forward to the hip), rust
  vBq('vDarkB',fx+s*.42,y+2.3,z-.7,.12,.7,.35,null);}                                                                             // shin vents
 vBq('vPanelB',x,y+5.55,z+.1,3.9,1.15,1.9,null,white);vB('vRustB',x,y+5.2,z+.1,4.1,.25,2.0,0,null);                               // hip block
 vBq('vPanelB',x,y+7.15,z-.1,3.9,2.3,2.3,null,white);vBq('vRustB',x,y+6.55,z+1.05,2.6,1.0,.2,null);vBq('vRustB',x-1.6,y+7.6,z-.4,.5,1.2,1.4,null);   // torso, chest plate, rust
 for(let k=0;k<3;k++)vBq('vDarkB',x+.9,y+7.15+k*.28,z+1.06,.5,.1,.14,null);   // vents
 vBq('vPanelB',x,y+8.75,z+.2,1.35,.95,1.35,null,white);vBq('vWinGlass',x,y+8.75,z+.88,.72,.42,.12,null);vBq('vHoop',x,y+8.75,z+.9,.42,.42,1,null,iron);   // head, the cyclops eye
 vPst('vPipe',x+.35,y+9.2,z-.2,.03,.9,iron);vBq('vIron',x,y+9.3,z-.2,.9,.12,.9,null,dark);
 for(const s of[-1,1]){vBq('vPanelB',x+s*2.4,y+7.9,z-.1,1.1,.9,1.9,null,white);vB('vRustB',x+s*2.4,y+8.3,z-.1,1.15,.14,1.95,0,null);}     // shoulder blocks
 // right arm: shoulder ball, upper arm, elbow, forearm, a two-finger claw
 {const sx=x+2.95;vBall('vBall',sx,y+7.85,z,.42,iron);vBeam([sx,y+7.85,z],[sx+.35,y+5.7,z+.4],.52,white,'vPanelB');vBall('vBall',sx+.35,y+5.7,z+.4,.36,iron);
  vBeam([sx+.35,y+5.7,z+.4],[sx+.5,y+3.6,z+1.5],.46,white,'vPanelB');vB('vRustB',sx+.6,y+4.6,z+1.0,.3,.7,.3,0,null);
  for(const q of[-1,1])kput('vIron',[sx+.5+q*.25,y+3.0,z+1.7],qEuler(.3,0,q*.35),[.16,1.1,.3],dark);}
 // left arm: gone — the empty socket, cable stubs
 vBq('vDarkB',x-2.95,y+7.85,z,.4,.7,.7,null);for(let k=0;k<3;k++)kput('vRope',[x-3.1,y+7.5+k*.2,z-.3+k*.3],qEuler(.4,0,1.3),[.03,.7,.03],vC(0x2a2622));}
// a dismantled mech leg lying on a low trolley
function vgMechLeg(x,z,ry,wood){const iron=vC(0x2e2a26);const q=loc(x,z,0,0,ry);vB('vWood',q[0],.5,q[1],5.0,.3,1.9,ry,wood);
 for(const s of[-1,1])for(const e of[-1,1]){const p=loc(x,z,s*1.8,e*1.05,ry);kput('vPost',[p[0],.45,p[1]],vQ(ry,Math.PI/2,0),[.45,.12,.45],iron);}
 const a=loc(x,z,-2.2,0,ry),b=loc(x,z,.4,.3,ry),c2=loc(x,z,2.3,-.2,ry);vBeam([a[0],1.15,a[1]],[b[0],1.25,b[1]],.62,null,'vPanelB');vBall('vBall',b[0],1.25,b[1],.5,iron);
 vBeam([b[0],1.25,b[1]],[c2[0],1.2,c2[1]],.55,null,'vPanelB');vBq('vDarkB',(a[0]+b[0])/2,1.45,(a[1]+b[1])/2,.9,.25,.4,vQ(ry,0,0));
 kput('vPanelB',[c2[0],1.15,c2[1]],vQ(ry,0,0),[.55,1.4,.6],null);vB('vRustB',(b[0]+c2[0])/2,1.5,(b[1]+c2[1])/2,.5,.12,.6,ry,null);
 const d=loc(x,z,-1.0,1.4,ry);kput('vPanelB',[d[0],.05,d[1]],vQ(ry+.3,0,0),[1.3,.08,.9],null);kput('vRustB',[d[0]+.6,.05,d[1]-.3],vQ(ry-.4,0,0),[.8,.06,.6],null);}

// ---------------------------------------------------------------- Farmers' Guild: half-timber hall on a stone plinth, cross-gabled entrance, raised grain loft, cart shed, weighing yard
function buildVernFarmersGuild(G,o){reseed(7701+(o.v|0));const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand)),sh=vC(vPick([0x8a6a4a,0x6a4e38,0x9a7a56])),st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),trim=vC(vPick(VPAL.trim)),th=vC(vPick(VPAL.thatch)),iron=vC(0x2e2a26);
 vnReg("Farmers' Guild hall",0,0,16,14,{type:['civic','farm']});
 const W=16,D=11,HZ=-3.5,H1=3.9,H2=3.0,Y0=.6,FZ=HZ+D/2,Y1=Y0+H1+.32;
 vB('vStone',0,-.1,HZ,W+.7,Y0+.1,D+.7,0,stD);
 // two half-timber storeys: frame, plaster infill, a jettied string course between
 vnFrame(0,Y0,HZ,W,H1,D,0,wood,.18);vB('vPlaster',0,Y0,HZ,W-.16,H1,D-.16,0,pl);
 vB('vWood',0,Y0+H1,HZ,W+.44,.32,D+.44,0,wood);
 vnFrame(0,Y1,HZ,W,H2,D,0,wood,.16);vB('vPlaster',0,Y1,HZ,W-.14,H2,D-.14,0,pl.clone().multiplyScalar(1.04));
 for(const s of[-1,1])for(const z of[HZ-3.6,HZ+.2]){const a=[s*(W/2+.06),Y1+.2,z],b=[s*(W/2+.06),Y1+H2-.2,z+1.6];vBeam(a,b,.14,wood);}    // diagonal braces, upper side panels
 const top=vnCornice('vWood',0,Y1+H2,HZ,W,D,0,wood,2);
 vnGableRoof(0,top,HZ,W,D,5.2,0,'vGableS',sh,1.1,'vGablePl',pl,.2);
 for(const s of[-1,1]){for(let k=-2;k<=2;k++){const z=HZ+k*2.2;const hh=5.2*(1-Math.abs(k*2.2)/(D/2))-.15;if(hh>.3)vB('vWood',s*(W/2+.02),top,z,.16,hh,.16,0,wood);}   // studs on the plaster gables
  vB('vWood',s*(W/2+.02),top+2.3,HZ,.16,.16,D*.55,0,wood);vB('vWood',s*(W/2+1.1),top+5.2-.5,HZ,.4,1.6,.4,0,wood);kput('vThatchB',[s*(W/2+1.1),top+6.5,HZ],null,[.5,.7,.5],vC(0xd8b860));}   // collar, sheaf finials
 // ground floor: lit windows with shutters; upper floor: deco shutter strips
 for(const x of[-6.86,-4.57,4.57,6.86]){vnWin(x,Y0+1.3,FZ,0,x>5||x<-5?1.2:1.3,1.5,'lit','vWood',wood,true);vnStrip(x,Y1+.5,FZ+.02,0,.6,2.0,'vWood',wood);}
 for(const s of[-1,1])for(const z of[HZ-3,HZ,HZ+3]){vnWin(s*W/2,Y0+1.3,z,s*Math.PI/2,1.2,1.5,'lit','vWood',wood,true);if(z!==HZ-3)vnStrip(s*W/2,Y1+.5,z,s*Math.PI/2,.6,2.0,'vWood',wood);}
 for(const x of[-5.7,-1.9,1.9,5.7])vnWin(x,Y0+1.4,HZ-D/2,Math.PI,1.1,1.2,'shut','vWood',wood);vnDoor(-3.8,Y0,HZ-D/2,Math.PI,1.2,2.3,'vWood',wood,trim,false);
 for(const x of[-5.7,-1.9,1.9,5.7])vnStrip(x,Y1+.5,HZ-D/2-.02,Math.PI,.6,2.0,'vWood',wood);
 // entrance bay: full height, its own cross gable, door with steps, upper window, hanging sheaf banners
 {const PW=6.6,PD=2.8,pz=FZ+PD/2-.1;vB('vStone',0,-.1,pz,PW+.7,Y0+.1,PD+.9,0,stD);
  vnFrame(0,Y0,pz,PW,H1,PD,0,wood,.18);vB('vPlaster',0,Y0,pz,PW-.16,H1,PD-.16,0,pl);vB('vWood',0,Y0+H1,pz,PW+.44,.32,PD+.44,0,wood);
  vnFrame(0,Y1,pz,PW,H2,PD,0,wood,.16);vB('vPlaster',0,Y1,pz,PW-.14,H2,PD-.14,0,pl.clone().multiplyScalar(1.04));
  vnCornice('vWood',0,Y1+H2,pz,PW,PD,0,wood,2);
  vnGableRoof(0,top,pz-2.0,PD+4.0,PW,3.4,Math.PI/2,'vGableS',sh,.9,'vGablePl',pl,.2);
  for(let k=-1;k<=1;k++){const hh=3.4*(1-Math.abs(k*2.2)/(PW/2))-.15;vB('vWood',k*2.2,top,pz+PD/2+.02,.16,hh,.16,0,wood);}
  vnDoor(0,Y0,pz+PD/2,0,2.0,3.0,'vWood',wood,trim);vnStairs(0,0,pz+PD/2+1.0,0,3.6,Y0,3,'vStone',stD);
  vnWin(0,Y1+.6,pz+PD/2,0,1.6,1.7,'lit','vWood',wood,true);
  for(const s of[-1,1]){vgBanner(s*2.5,Y0+H1-.02,pz+PD/2+.14,0,1.1,2.5,vC(vPick(VPAL.awning)),true);vBeam([s*1.3,Y1+.2,pz+PD/2+.05],[s*3.0,Y1+H2-.2,pz+PD/2+.05],.14,wood);}
  vnLamp(-3.0,Y0+3.0,pz+PD/2,0);vnLamp(3.0,Y0+3.0,pz+PD/2,0);}
 // granary: a board loft on stilts against the west wall, thatch roof, hatch and ladder, sacks stored underneath; a stave silo beside
 {const lx=-11.8,lz=HZ+.5,LW=5.6,LD=7.2,FL=2.5,LH=3.2;vnStilts(lx,0,lz,LW,LD,FL,0,wood,.2);vB('vWood',lx,FL-.24,lz,LW+.4,.24,LD+.4,0,wood);
  vnFrame(lx,FL,lz,LW,LH,LD,0,wood,.14);vB('vWood',lx,FL,lz,LW-.12,LH,LD-.12,0,wood.clone().multiplyScalar(.9));
  vnGableRoof(lx,FL+LH,lz,LD,LW,2.6,Math.PI/2,'vGableT',th,1.0,'vGableW',wood,.42);
  vB('vDarkB',lx,FL+.4,lz+LD/2-.05,1.1,1.7,.2,0);kput('vWood',[lx+.75,FL+1.25,lz+LD/2+.12],qEuler(0,.85,0),[1.0,1.6,.06],trim);
  for(const s of[-1,1])vnWin(lx+s*LW/2,FL+1.0,lz-1.5,s*Math.PI/2,.9,.7,'shut','vWood',wood);
  vnLadder(lx,0,lz+LD/2+.75,0,FL+.6,wood);vnSacks(lx-.6,0,lz-.4,7);vnSacks(lx+1.2,0,lz+1.4,4);vnCrate(lx+1.5,0,lz-2.2,.9,.2,wood);
  const sx=-12.4,sz=FZ+2.4;vB('vStone',sx,0,sz,3.2,.5,3.2,0,stD);vPst('vStave',sx,.5,sz,1.35,4.2,vC(0xa88a5e));for(const yy of[.6,2.2,3.8])vBq('vHoop',sx,.5+yy,sz,1.38,1.38,1,qEuler(Math.PI/2,0,0),iron);
  vnThatchCone(sx,4.7,sz,1.35,1.8,th);vB('vDarkB',sx,1.2,sz+1.3,.8,.9,.2,0);vB('vWood',sx,1.2,sz+1.4,.75,.85,.06,0,wood);vnLadder(sx+.9,0,sz+1.9,0,1.9,wood);}
 // cart shed: lean-to against the east wall, corrugate roof on three posts, the cart and a plough-less pile of tools
 {const cz=HZ-1,CD2=8;for(const z of[cz-3.6,cz,cz+3.6])vPst('vPostB',W/2+4.4,0,z,.15,3.0,wood);vB('vWood',W/2+4.4,3.0,cz,.18,.18,CD2+.4,0,wood);
  vB('vWood',W/2+.2,4.15,cz,.18,.18,CD2+.4,0,wood);vnShedRoof(W/2+2.3,3.1,cz,CD2,4.4,1.1,Math.PI/2,'vCorr',null,.6,.12);
  vgCart(W/2+2.2,cz+.5,0,wood);vnCrate(W/2+3.6,0,cz-3.0,.8,.3,wood);vnBarrel(W/2+1.0,0,cz-3.2,.4,1.0,wood);}
 // walled yard: low stone wall with a gate, weighing scale, sacks and crates, planters, lamps, banner poles
 {const YL=-9.6,YR=13.2,YF=10.6,hw=1.35;
  for(const x of[YL,YR]){vB('vStone',x,0,(FZ+YF)/2,.5,hw,YF-FZ,0,stD);vB('vStone',x,hw,(FZ+YF)/2,.72,.2,YF-FZ+.2,0,st);}
  vB('vStone',(YL-8)/2,0,FZ+.25,-YL-8,hw,.5,0,stD);vB('vStone',(YR+8)/2,0,FZ+.25,YR-8,hw,.5,0,stD);
  for(const seg of[[YL,-1.9],[1.9,YR]]){const cx=(seg[0]+seg[1])/2,L=seg[1]-seg[0];vB('vStone',cx,0,YF,L,hw,.5,0,stD);vB('vStone',cx,hw,YF,L+.2,.2,.72,0,st);}
  for(const s of[-1,1]){vB('vStone',s*2.2,0,YF,.8,hw+.75,.8,0,st);vB('vWood',s*2.2,hw+.75,YF,1.0,.14,1.0,0,trim);vnBannerPole(s*3.6,0,YF+.9,0,6.5,vC(vPick(VPAL.awning)));vnLampPost(s*5.0,0,YF-1.6,3.4);}
  vnPaving(0,.02,(FZ+2.7+YF)/2,4.2,YF-FZ-2.7,0,stD,10);vnPaving(0,.02,YF+1.6,6,2.6,0,stD,8);
  vgScale(6.8,5.6,wood);vnSacks(9.2,0,7.6,6);vnSacks(4.6,0,8.4,3);vnCrate(11.2,0,4.6,.95,.2,wood);vnCrate(11.2,.76,4.6,.7,.5,wood);vnCrate(9.6,0,3.4,.8,-.3,wood);
  vnPlanter(-6.2,0,YF-1.0,2.8,.9,0,wood);vnPlanter(-3.6,0,FZ+1.2,1.6,.7,0,wood);vnPlanter(5.4,0,FZ+1.2,1.6,.7,0,wood);vnBarrel(-8.6,0,4.2,.42,1.0,wood);vnWaterButt(-8.4,0,6.4,.5,1.1);}
 vnFolk(0,7,4,2.5);vnFolk(0,14,3,2);}

// ---------------------------------------------------------------- Beast Hunters' Guild: trophy hall with a towering porch, the great skull, a palisaded beast pen, hide racks, a watch platform, a roost on the ridge
function buildVernBeastHunters(G,o){reseed(7711+(o.v|0));const wood=vC(vPick(VPAL.woodRich)),wd2=vC(vPick(VPAL.woodMid)),sh=vC(vPick([0x6a4e38,0x5a4030,0x7a5a44])),st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),trim=vC(vPick(VPAL.trim)),iron=vC(0x2e2a26),bone=vC(0xe8dfcc);
 vnReg("Beast Hunters' Guild",0,0,17,16,{type:['civic','military']});
 const W=14,D=10,HX=-4.5,HZ=-4,H=4.2,Y0=.7,FZ=HZ+D/2;
 vB('vStone',HX,-.1,HZ,W+.9,Y0-.2,D+.9,0,stD);vB('vStone',HX,Y0-.3,HZ,W+.6,.3,D+.6,0,st);
 vnFrame(HX,Y0,HZ,W,H,D,0,wood,.2);vB('vWood',HX,Y0,HZ,W-.2,H,D-.2,0,wd2);
 const top=vnCornice('vWood',HX,Y0+H,HZ,W,D,0,wood,2);
 vnGableRoof(HX,top,HZ,W,D,3.8,0,'vGableS',sh,1.1,'vGableW',wd2,.2);
 // the roost: crossed timbers off the ridge at either end, lashed where they cross, perch bars between
 {const RY=top+3.8;for(const x of[HX-4.6,HX+4.6]){for(const s of[-1,1])vBeam([x,RY-1.3,HZ+s*2.7],[x,RY+4.6,HZ-s*1.5],.2,wood);vPst('vRope',x,RY+2.15,HZ,.2,.5,vC(0xa89878));}
  for(const s of[-1,1]){vB('vWood',HX,RY+3.7,HZ+s*.93,9.8,.2,.2,0,wood);vB('vWood',HX,RY+.85,HZ+s*1.05,9.8,.18,.18,0,wood);}
  vB('vWood',HX,RY+3.9,HZ,3.0,.12,2.2,0,wd2);vPst('vRope',HX+1.2,RY+.95,HZ+1.05,.03,2.75,vC(0xa89878));}                  // landing board, a hanging tether
 // porch: four tall posts, beams and knee braces, a board screen up to the porch roof where the trophies hang, its own steep gable
 {const PW=9,PD=5,pz=FZ+PD/2,PH=8.4;vB('vStone',HX,-.1,pz,PW+1.6,.35,PD+.7,0,stD);
  for(const sx of[-1,1]){const px=HX+sx*(PW/2-.3);for(const z of[pz+PD/2-.4,FZ+.55]){vPst('vPostB',px,.2,z,.3,PH,wood);vPst('vRope',px,4.6,z,.34,.35,vC(0xa89878));}
   vB('vWood',px,PH-.1,pz,.3,.3,PD+.6,0,wood);vBeam([px,PH-2.4,pz+PD/2-.4],[HX+sx*(PW/2-2.2),PH+.05,pz+PD/2-.4],.16,wood);vBeam([px,PH-2.4,pz+PD/2-.4],[px,PH+.05,pz+PD/2-2.3],.16,wood);}
  vB('vWood',HX,PH-.1,pz+PD/2-.4,PW+.6,.36,.36,0,wood);vB('vWood',HX,PH-.1,FZ+.55,PW+.6,.36,.36,0,wood);
  vB('vWood',HX,top-.3,FZ+.35,PW-.6,PH+.3-(top-.3),.16,0,wd2);for(const sx of[-1,1])vB('vWood',HX+sx*(PW/2-.3),top-.3,FZ+.35,.2,PH+.3-(top-.3),.24,0,wood);   // the screen
  vnGableRoof(HX,PH+.3,FZ+.35+5.55/2,5.55,PW,2.8,Math.PI/2,'vGableS',sh,.9,'vGableW',wd2,.2);
  vgSkull(G,HX,5.0,pz+.3,1.0,bone);for(const s of[-1,1])vPst('vRope',HX+s*.7,6.6,pz+.1,.04,PH-.3-6.6,vC(0xa89878));
  for(const s of[-1,1]){for(const q of[-1,1]){const horn=mesh(lathe({rFn:yy=>.14*(1-yy/1.8)+.02,H:1.8,nu:10,nv:4}),MAT.plaster,G,HX+s*2.6+q*.35,6.9,FZ+.45);horn.rotation.set(.35,0,-q*.75);}
   vB('vStone',HX+s*2.6,6.5,FZ+.45,.9,.5,.2,0,bone);vgSkull(G,HX+s*2.6,7.6,FZ+.6,.3,bone);}                                          // mounted horns and small skulls on the screen
  vnDoor(HX,Y0,FZ,0,2.0,3.0,'vWood',wood,trim);vnStairs(HX,.25,FZ+.9,0,3.6,Y0-.25,2,'vStone',stD);
  for(const s of[-1,1]){vnWin(HX+s*3.0,Y0+1.2,FZ,0,1.2,1.4,'lit','vWood',wood,true);vB('vWood',HX+s*3.2,.25,FZ+2.6,.5,.45,2.6,0,wood);vnLamp(HX+s*(PW/2-.3),4.4,pz+PD/2-.24,0);}
  vgSpearRack(HX+PW/2+.9,FZ+2.2,Math.PI/2,6,wd2);vgSpearRack(HX-PW/2-.9,FZ+2.2,Math.PI/2,5,wd2);}
 // hall windows, side trophies, a back door
 for(const s of[-1,1])for(const z of[HZ-3,HZ,HZ+3])vnWin(HX+s*W/2,Y0+1.3,z,s*Math.PI/2,1.2,1.4,'lit','vWood',wood,true);
 for(const x of[HX-4.5,HX-1.5,HX+1.5,HX+4.5])vnWin(x,Y0+1.4,HZ-D/2,Math.PI,1.1,1.2,'shut','vWood',wood);vnDoor(HX-6.0,Y0,HZ-D/2,Math.PI,1.1,2.2,'vWood',wood,trim,false);
 for(const z of[HZ-1.5,HZ+1.5])for(const q of[-1,1]){const horn=mesh(lathe({rFn:yy=>.12*(1-yy/1.5)+.02,H:1.5,nu:10,nv:4}),MAT.plaster,G,HX+W/2+.15,Y0+H-.6,z+q*.3);horn.rotation.set(0,0,-.95);horn.rotation.y=q*.6;}
 vnChimney(HX-5.5,top+2.2,HZ-3,3.0,.2,true);
 // the beast pen: palisade with a gated front, troughs, tethering posts, hay, a mud wallow, a saddle rack
 {const px=8.4,pz=-1.5,PWd=10.6,PDd=13;vnPalisade(px,0,pz,PWd,PDd,0,2.8,2.8);
  for(const s of[-1,1])vPst('vPostB',px+s*1.7,-.2,pz+PDd/2,.22,4.0,wood);vB('vWood',px,3.6,pz+PDd/2,4.2,.3,.3,0,wood);vgSkull(G,px,3.95,pz+PDd/2,.35,bone);
  kput('vWood',[px-1.4+.7*Math.cos(1.1),1.35,pz+PDd/2-.7*Math.sin(1.1)],qEuler(0,1.1,0),[1.4,2.6,.08],wd2);   // one gate leaf open
  vgTrough(px-3.2,0,pz-4.6,3.2,0,wd2);vgTrough(px+3.0,0,pz-4.6,3.0,0,wd2);
  for(const x of[-3,0,3])vgTether(px+x,pz+.8,wd2);
  kput('vThatchB',[px+3.6,.5,pz-1.2],qEuler(0,.3,0),[1.8,1.0,1.5],vC(vPick(VPAL.thatch)));kput('vThatchB',[px+3.4,1.3,pz-1.0],qEuler(0,-.2,0),[1.2,.7,1.1],vC(vPick(VPAL.thatch)));
  vB('vClayB',px-1.5,-.03,pz+3.0,4.6,.06,3.4,.2,vC(0x6a4a30));vnWaterButt(px-4.2,0,pz+4.4,.5,1.1);
  for(const s of[-1,1])vPst('vPost',px+s*.6,0,pz-2.2,.06,1.2,wd2);vB('vWood',px,1.15,pz-2.2,1.6,.1,.1,0,wd2);kput('vTarpB',[px,1.25,pz-2.2],null,[.9,.25,.7],vC(0x6a4630));}
 // hide racks behind, watch platform at the front corner, lamps, paving, banners
 vgHideRack(-13.6,HZ-3,Math.PI/2,5,wd2);vgHideRack(-13.6,HZ+3.2,Math.PI/2,5,wd2);
 {const tx=-12.4,tz=7.4;for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',tx+sx*1.15,-.2,tz+sz*1.15,.16,6.4,wood,qEuler(sz*.03,0,-sx*.03));
  for(const s of[-1,1]){vB('vWood',tx,2.6,tz+s*1.1,2.5,.12,.12,0,wood);vB('vWood',tx+s*1.1,2.6,tz,.12,.12,2.5,0,wood);}
  vB('vWood',tx,4.9,tz,3.0,.2,3.0,0,wood);for(let k=0;k<10;k++){const a=k/10*TAU;vPst('vPost',tx+Math.cos(a)*1.45,5.1,tz+Math.sin(a)*1.45,.05,.95,wood);}
  vnHipRoof('vHipS',tx,7.0,tz,2.6,2.6,1.2,0,sh,.6);for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',tx+sx*1.15,5.1,tz+sz*1.15,.08,1.9,wood);
  vnLadder(tx+.9,0,tz+1.8,0,5.0,wood);}
 vnPaving(HX+3,.02,FZ+5.2,20,7,0,stD,32);vnLampPost(HX-6.5,0,FZ+6.5,3.6);vnLampPost(8.4,0,6.6,3.6);
 vnBannerPole(HX-5.8,0,FZ+3.2,0,7,vC(vPick(VPAL.awning)));vnBannerPole(HX+5.8,0,FZ+3.2,0,7,vC(0x9c2d2d));vnCrate(-10.5,0,FZ+3.5,.9,.3,wd2);vnBarrel(-9.6,0,FZ+3.8,.4,1,wd2);
 vnFolk(HX,FZ+6.5,4,2.5);vnFolk(8,8.5,2,1.2);}

// ---------------------------------------------------------------- caravanserai: walled court, gatehouse with a two-storey block, arcades of posts under corrugate shed roofs, well, stables, stalls
function buildVernCaravanserai(G,o){reseed(7721+(o.v|0));const wood=vC(vPick(VPAL.woodMid)),pl=vC(vPick(VPAL.sand)),pl2=vC(vPick(VPAL.adobe)),st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),trim=vC(vPick(VPAL.trim)),iron=vC(0x2e2a26),th=vC(vPick(VPAL.thatch));
 vnReg('Caravanserai',0,0,22,12);
 const CW=34,CD=28,WH=4.4,Y0=.5,T=.6,RD=4.3,PH=3.3,GW=8,GD=6.4,gz=CD/2-GD/2+1.4;
 vB('vStone',0,-.12,0,CW+1.2,.14,CD+1.2,0,vC(0x8a7a66));
 // walls: stone plinth, plaster, stone cap; corner piers with corrugate pyramid caps
 const wall=(x,z,L,ry)=>{vB('vStone',x,-.1,z,L,Y0+.1,T+.4,ry,stD);vB('vPlaster',x,Y0,z,L,WH,T,ry,pl);vB('vStone',x,Y0+WH,z,L+.2,.28,T+.5,ry,st);};
 wall(0,-CD/2+T/2,CW,0);wall(-CW/2+T/2,0,CD,Math.PI/2);wall(CW/2-T/2,0,CD,Math.PI/2);
 for(const s of[-1,1])wall(s*(CW/2+GW/2)/2+s*.2,CD/2-T/2,CW/2-GW/2-.4,0);
 for(const sx of[-1,1])for(const sz of[-1,1]){vB('vStone',sx*(CW/2-.45),0,sz*(CD/2-.45),1.0,Y0+WH+.9,1.0,0,stD);kput('vPyrC',[sx*(CW/2-.45),Y0+WH+.9,sz*(CD/2-.45)],null,[1.3,.9,1.3],null);}
 // gatehouse: battered stone plinth, two plaster storeys with orange timber trim, shutter strips, corrugate hip; a proud stone portal with timber leaves half open
 for(const s of[-1,1]){vnPlinth('vBatterS',s*(1.9+1.45),0,gz,2.9,1.2,GD+1.6,0,stD);vB('vPlaster',s*(1.9+1.05),1.2,gz,2.1,4.4,GD,0,pl2);}vB('vPlaster',0,4.4,gz,3.8,1.2,GD,0,pl2);vB('vWood',0,5.6,gz,GW+.44,.3,GD+.44,0,trim);vB('vPlaster',0,5.9,gz,GW-.2,3.0,GD-.2,0,pl2.clone().multiplyScalar(1.05));
 for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',sx*(GW/2-.1),1.2,gz+sz*(GD/2-.1),.16,7.7,trim);
 const gt=vnCornice('vWood',0,8.9,gz,GW-.2,GD-.2,0,trim,2);vnHipRoof('vHipC',0,gt,gz,GW-.2,GD-.2,2.2,0,null,1.0);
 for(const e of[-1,1]){const zp=gz+e*(GD/2+ (e>0?.6:.3));for(const s of[-1,1])vB('vStone',s*2.4,0,zp,1.0,5.0,1.0,0,stD);vB('vStone',0,4.4,zp,5.8,.9,1.2,0,stD);vB('vWood',0,4.3,zp,4.2,.22,1.3,0,trim);}
 kput('vWood',[-.95,2.1,gz+GD/2+1.14],qEuler(0,.08,0),[1.85,4.1,.1],trim);kput('vWood',[1.9-.93*Math.cos(1.25),2.1,gz+GD/2+1.14-.93*Math.sin(1.25)],qEuler(0,-1.25,0),[1.85,4.1,.1],trim);
 for(const yy of[1.0,2.1,3.3]){vB('vIron',-.95,yy,gz+GD/2+1.21,1.7,.1,.04,0,iron);}for(let k=0;k<6;k++)vB('vIron',-1.7+k*.3,2.05,gz+GD/2+1.22,.06,.06,.04,0,iron);
 for(const x of[-2.4,0,2.4])vnStrip(x,6.4,gz+GD/2+.02,0,.6,2.0,'vWood',trim);for(const x of[-2.4,2.4])vnStrip(x,6.4,gz-GD/2-.02,Math.PI,.6,2.0,'vWood',trim);
 for(const s of[-1,1]){vnStrip(s*GW/2,6.4,gz,s*Math.PI/2,.6,2.0,'vWood',trim);vnWin(s*3.0,2.7,gz+GD/2,0,1.0,1.0,'open','vWood',trim,true);vnBannerPole(s*5.4,0,CD/2+1.6,0,7.2,vC(vPick(VPAL.awning)));}
 vnWin(0,6.5,gz-GD/2,Math.PI,1.3,1.4,'open','vWood',trim,true);
 // arcades: a room range on the back and front walls, open bays on the sides; posts on the court edge, corrugate shed roofs down to them
 const arcade=(xc,zc,L,ry,rooms,plc)=>{const zi=RD/2;   // local: -z is the outer wall, +z the court; L along local x
  if(rooms){const p=loc(xc,zc,0,-.1,ry);vB('vStone',p[0],-.05,p[1],L,.45,RD-.2,ry,stD);vB('vPlaster',p[0],.4,p[1],L-.2,PH-.4,RD-.4,ry,plc);}
  const n=Math.max(2,Math.round(L/3.0));for(let i=0;i<=n;i++){const p=loc(xc,zc,-L/2+L*i/n,zi,ry);vPst('vPost',p[0],0,p[1],.16,PH,wood);}
  const b=loc(xc,zc,0,zi,ry);vB('vWood',b[0],PH-.15,b[1],L+.3,.3,.3,ry,wood);vnShedRoof(xc,PH+.15,zc,L,RD,1.3,ry,'vCorr',null,.5,.12);};
 arcade(0,-CD/2+T+RD/2,CW-2*T-.2,0,true,pl);                                                   // back: lodging rooms
 for(const s of[-1,1])arcade(s*(CW/2-T+GW/2+.5)/2,CD/2-T-RD/2,CW/2-T-GW/2-.9,Math.PI,true,pl2);   // front, either side of the gate: stores
 arcade(CW/2-T-RD/2,0,CD-2*T-2*RD-.4,-Math.PI/2,false);                                         // east: stables
 arcade(-CW/2+T+RD/2,0,CD-2*T-2*RD-.4,Math.PI/2,false);                                        // west: stalls
 {const fz=-CD/2+T+RD-.3;for(const x of[-12,-6,0,6,12])vnDoor(x,.4,fz,0,1.1,2.2,'vWood',wood,trim,false);for(const x of[-9,-3,3,9])vnWin(x,1.5,fz,0,1.0,.9,'open','vWood',wood,true);
  vnAwning(-6,PH-.35,fz,0,3.0,1.5,vC(vPick(VPAL.awning)));vnAwning(6,PH-.35,fz,0,3.0,1.5,vC(vPick(VPAL.awning)));}
 {const fz=CD/2-T-RD+.3;for(const s of[-1,1]){for(const x of[7.6,12.4])vnDoor(s*x,.4,fz,Math.PI,1.7,2.4,'vWood',wood,trim,false);vnCrate(s*10,.4,fz-1.0,.9,.2,wood);vnSacks(s*13.5,.4,fz-1.2,3);}}
 {const xw=CW/2-T,xp=xw-RD;for(let k=0;k<5;k++){const z=-8.6+k*3.6;vB('vWood',xw-RD/2,0,z,RD-.3,1.5,.08,0,wood);}                         // stable partitions
  for(let k=0;k<4;k++){const z=-6.8+k*3.6;vgTrough(xw-.6,0,z,2.6,Math.PI/2,wood);kput('vThatchB',[xw-RD/2-.2,.06,z+.6],qEuler(0,rr(-.3,.3),0),[2.8,.12,2.6],th);
   if(k%2===0)kput('vThatchB',[xw-1.2,.6,z-.9],qEuler(0,.4,0),[1.2,.8,1.0],th);vgTether(xp+.5,z,wood);}
  vnWaterButt(xp-.9,0,8.0,.5,1.0);}
 {const xw=-CW/2+T,xp=xw+RD;for(const z of[-6,-1,4])vnStall(xw+1.6,z,Math.PI/2);for(const z of[-6,-1,4])vnAwning(xp,PH-.35,z,Math.PI/2,3.4,1.6,vC(vPick(VPAL.awning)));
  vnBarrel(xw+1.0,0,8.2,.42,1.0,wood);vnBarrel(xw+1.9,0,8.4,.42,1.0,wood);vnBarrel(xw+1.45,1.0,8.3,.42,1.0,wood);}
 // the court: paving, the well and trough, braziers, caravan goods stacked inside the gate
 vnPaving(0,.02,0,22,16,0,stD,64);vgWell(0,-.5,wood,st);vB('vStone',3.4,0,-.5,3.0,.7,1.1,0,stD);vB('vWinGlass',3.4,.6,-.5,2.6,.12,.8,0);
 vgBrazier(-4.5,4.5);vgBrazier(5.5,4.0);
 for(let k=0;k<5;k++)kput('vTarpB',[-7.5+rr(-.4,.4)+ (k%3)*1.1,.45+(k>2?.8:0),6.0+Math.floor(k/3)*.9],qEuler(0,rr(-.3,.3),0),[.9,.8,.7],vC(vPick([0x8a7a5a,0x7a6a4e,0xa08a68])));
 for(let k=0;k<3;k++)vPst('vRope',-7.5+k*1.1,.85,6.0,.02,.9,vC(0x6a5a48));vnCrate(7.5,0,6.2,1.0,.2,wood);vnCrate(7.5,.8,6.2,.8,-.4,wood);vnSacks(6.0,0,7.0,4);vnBarrel(8.8,0,7.0,.42,1.0,wood);
 // outside: a hitching rail and a trough by the gate, high shut windows on the blank walls
 for(const s of[-1,1]){vPst('vPost',s*7.5,0,CD/2+3.0,.08,1.1,wood);}vB('vWood',0,1.0,CD/2+3.0,15.2,.1,.1,0,wood);vgTrough(-10.5,0,CD/2+2.2,2.6,0,wood);
 for(const s of[-1,1])for(const z of[-8,0,8])vnWin(s*CW/2,Y0+2.6,z,s*Math.PI/2,.8,.7,'shut','vWood',wood);
 vnFolk(0,3,6,4);vnFolk(0,CD/2+4.5,3,2.5);}

// ---------------------------------------------------------------- Forgemaster's Hall: tall stone hall with a 9 m opening, copper gable, the gantry and the mech in its cradle, forge, yard
function buildVernForgemasters(G,o){reseed(7731+(o.v|0));const st=vC(vPick(VPAL.stone)),stD=vC(vPick(VPAL.stoneDark)),wood=vC(vPick(VPAL.woodRich)),cu=vC(0xffffff),iron=vC(0x2e2a26),dark=vC(0x3a3632),chain=vC(0x2a2622);
 vnReg("Forgemaster's Hall",0,0,20,18,{type:['civic','industry']});
 const W=30,D=20,HZ=-5,WH=10,Y0=.5,T=1.0,OW=9,OH=9,FZ=HZ+D/2;
 vB('vStone',0,-.1,HZ,W+1.4,Y0+.1,D+1.4,0,stD);vnPaving(0,Y0+.02,HZ,W-2.4,D-2.4,0,st.clone().multiplyScalar(.92),50);
 // walls as slabs so the hall is hollow: back, sides, front pieces, piers and the lintel over the opening
 vB('vStone',0,Y0,HZ-D/2+T/2,W,WH,T,0,st);for(const s of[-1,1])vB('vStone',s*(W/2-T/2),Y0,HZ,T,WH,D,0,st);
 for(const s of[-1,1]){const cx=s*(OW/2+1.6+(W/2-OW/2-1.6)/2);vB('vStone',cx,Y0,FZ-T/2,W/2-OW/2-1.6,WH,T,0,st);vB('vStone',s*(OW/2+.8),Y0,FZ-T/2+.25,1.6,WH,1.7,0,stD);vB('vStone',s*(OW/2+.8),Y0+OH-.35,FZ-T/2+.3,1.9,.35,2.0,0,st);}
 vB('vStone',0,Y0+OH,FZ-T/2,OW+3.2,WH-OH,T+.6,0,stD);vB('vIron',0,Y0+OH-.45,FZ-T/2,OW+1.0,.45,.5,0,dark);      // stone beam + the Ancient girder under it
 const top=vnCornice('vStone',0,Y0+WH,HZ,W,D,0,st,3);
 vnGableRoof(0,top,HZ,D,W,6.0,Math.PI/2,'vGableCu',cu,1.3,'vGableSt',st,.2);for(const s of[-1,1])vBall('vFinial',0,top+6.0+.2,HZ+s*(D/2+1.2),.3);
 // deco strips on the front pieces and the flanks; clerestory lit windows on the flanks; a round window in the front gable
 for(const s of[-1,1])for(const x of[8.2,12.6])vnStrip(s*x,Y0+1.6,FZ+.02,0,.7,6.2,'vStone',stD);
 for(const s of[-1,1])for(let k=0;k<4;k++){const z=HZ-D/2+2.5+k*5;vnWin(s*W/2,Y0+6.4,z,s*Math.PI/2,1.3,1.8,'lit','vStone',st);if(k<3)vnStrip(s*W/2,Y0+1.6,z+2.5,s*Math.PI/2,.7,7.0,'vStone',stD);}
 for(const x of[-9,-3,3,9])vnWin(x,Y0+6.4,HZ-D/2,Math.PI,1.3,1.8,'lit','vStone',st);
 vBq('vHoop',0,top+2.6,FZ+.06,1.15,1.15,1,null,vC(0x8a7a66));vB('vWinLit',0,top+1.55,FZ-.04,2.0,2.1,.1,0);for(const s of[-1,1])vnStrip(s*4.0,top+.6,FZ+.02,0,.6,2.6,'vStone',stD);
 for(const s of[-1,1])vnWin(s*10.4,Y0+8.2,FZ,0,1.3,1.2,'lit','vStone',st);
 for(const s of[-1,1]){vnLamp(s*(OW/2+.8),Y0+6.2,FZ+.4,0);vnLamp(s*(OW/2+.8),Y0+3.6,FZ+.4,0);vPl('vCloth',s*10.4,Y0+5.2,FZ+.16,2.2,5.0,0,vC(vPick(VPAL.awning)));vB('vWood',s*10.4,Y0+7.8,FZ+.14,2.6,.1,.1,0,vC(0x5a4632));}
 for(let k=0;k<3;k++)for(const s of[-1,1])vnLamp(s*(W/2-T),Y0+5.0,HZ-D/2+4+k*6,-s*Math.PI/2);                                       // interior wall lamps
 // the gantry: reclaimed pipe columns, rusted beams, a hoist trolley with chains down to the mech's shoulders; the mech in its cradle
 {const mz=HZ+1.5;for(const sx of[-1,1])for(const sz of[-1,1]){vPst('vPipeR',sx*4.6,Y0,mz+sz*3.4,.26,9.0,null);vB('vRustB',sx*4.6,Y0,mz+sz*3.4,1.2,.4,1.2,0,null);}
  for(const sz of[-1,1])vB('vRustB',0,Y0+8.8,mz+sz*3.4,10.2,.5,.5,0,null);for(const sx of[-1,1])vB('vRustB',sx*4.6,Y0+8.8,mz,.5,.5,7.4,0,null);
  vB('vRustB',0,Y0+9.05,mz-1.0,10.2,.7,.6,0,null);vB('vIron',0,Y0+8.55,mz-1.0,1.4,.5,.9,0,dark);for(const s of[-1,1])vBeam([s*4.6,Y0+6.2,mz-3.4],[s*4.6,Y0+8.8,mz-.6],.2,null,'vPanelB');   // hoist beam + trolley
  for(const s of[-1,1]){vPst('vRope',s*2.4,Y0+8.45,mz-.9,.06,.6,chain);vB('vIron',s*2.4,Y0+8.4,mz-.9,.34,.1,.34,0,iron);vBeam([s*2.4,Y0+9.05,mz-.9],[s*.7,Y0+8.55,mz-1.0],.05,chain,'vRope');}
  for(const s of[-1,1])vB('vRustB',s*3.3,Y0+5.35,mz,2.6,.45,.45,0,null);                                                             // cradle clamps at the hip
  vgMech(0,Y0,mz);
  // the removed arm on a workbench, tools, a step ladder up to the hip
  vB('vWood',-9.5,Y0,mz+2,4.6,.9,1.3,0,wood);kput('vPanelB',[-10.3,Y0+1.2,mz+2],qEuler(0,.05,0),[2.4,.5,.5],null);vBall('vBall',-8.9,Y0+1.2,mz+2,.36,iron);kput('vPanelB',[-7.9,Y0+1.15,mz+2.1],qEuler(0,-.15,0),[1.6,.44,.44],null);
  vB('vRustB',-10.6,Y0+1.45,mz+2,.6,.1,.3,0,null);for(let k=0;k<4;k++)vB('vIron',-11.4+k*.4,Y0+.9,mz+1.6,.05,.5,.05,0,iron);
  vnLadder(-2.6,Y0,mz+2.6,0,5.4,wood);}
 // forge in the back-left corner: hearth, embers, hood, a chimney out through the copper roof; tool wall, drums
 {const fx=-10.5,fz=HZ-D/2+2.6;vB('vStone',fx,Y0,fz,3.2,1.1,2.4,0,stD);vB('vDarkB',fx,Y0+1.2,fz,2.6,.15,1.7,0);for(let k=0;k<6;k++)vBall('vEmber',fx+rr(-.9,.9),Y0+1.32,fz+rr(-.6,.6),rr(.1,.22));
  kput('vRustB',[fx,Y0+3.0,fz],null,[3.0,1.3,2.2],null);kput('vRustB',[fx,Y0+2.3,fz],null,[3.4,.2,2.6],null);vnChimney(fx,Y0+3.6,fz,top+4.6-Y0-3.6,.42,true);
  vPst('vPostB',fx+3.2,Y0,fz+1.2,.36,.8,wood);vB('vIron',fx+3.2,Y0+.8,fz+1.2,1.2,.36,.42,0,iron);vnWaterButt(fx+4.6,Y0,fz+.4,.45,.9);
  vB('vWood',W/2-T-.6,Y0,HZ-D/2+4,1.0,1.0,6.0,0,wood);for(let k=0;k<8;k++)vB('vIron',W/2-T-.6,Y0+1.0,HZ-D/2+1.4+k*.7,.06,.6,.06,0,iron);
  for(let k=0;k<5;k++)vB('vIron',W/2-T-.08,Y0+2.6,HZ-D/2+1.6+k*.9,.12,1.2,.3,0,dark);vgDrums(W/2-T-3.2,HZ+2.2,6);
  for(let k=0;k<3;k++)kput('vPipeR',[W/2-T-.9,Y0+.12+k*.25,HZ+7.2+rr(-.2,.2)],qEuler(Math.PI/2,0,rr(-.05,.05)),[.12,5.0,.12],null);}
 // the yard: paving, the second leg on its trolley, scrap piles, drums, flag pole, lamp posts, bollards
 vnPaving(0,.02,FZ+5.6,W+8,11.4,0,stD,90);
 vgMechLeg(9.5,FZ+6.5,.35,wood);vgScrap(-11.5,FZ+3.5,2.2,2.0,34);vgScrap(15.5,FZ+1.5,1.5,2.4,24);vgDrums(-16.5,FZ+7.5,4);
 for(let i=0;i<8;i++)kput('vIron',[-15.5+rr(-.8,.8),rr(.1,.5),FZ+2.5+rr(-1.5,1.5)],qEuler(rng(),rng()*TAU,rng()),[rr(.3,.9),rr(.2,.5),rr(.3,.9)],iron);
 vnBannerPole(-13.5,0,FZ+10,0,9.5,vC(0xe07a2a));vB('vStone',-13.5,0,FZ+10,1.4,.6,1.4,0,stD);
 for(const s of[-1,1]){vnLampPost(s*7.5,0,FZ+3.2,4.0);vnLampPost(s*14,0,FZ+9.5,4.0);}
 for(let k=0;k<6;k++)vB('vStone',-12.5+k*5,0,FZ+11.0,.6,.9,.6,0,stD);vnCrate(5.2,0,FZ+2.4,1.0,.2,wood);vnCrate(6.4,0,FZ+2.0,.8,.5,wood);
 vnFolk(-6,FZ+6,4,2.5);vnFolk(-7,HZ+6,2,1.2);}

VERN.def({key:'vern_farmers_guild',name:"Farmers' Guild",family:'civic',tags:{type:['civic','farm'],wealth:'civic',lit:true},w:30,d:22,h:14,build:buildVernFarmersGuild});
VERN.def({key:'vern_beast_hunters_guild',name:"Beast Hunters' Guild",family:'civic',tags:{type:['civic','military'],wealth:'civic',lit:true},w:28,d:22,h:15,build:buildVernBeastHunters});
VERN.def({key:'vern_caravanserai',name:'Caravanserai',family:'trade',tags:{type:['tavern/inn','market/shop'],wealth:'middle',lit:false},w:36,d:30,h:12,build:buildVernCaravanserai});
VERN.def({key:'vern_forgemasters_hall',name:"Forgemaster's Hall",family:'civic',tags:{type:['civic','industry'],wealth:'civic',lit:true},w:40,d:32,h:18,build:buildVernForgemasters});
// ================================================================= PORTED — the Voth Embassy (a Voth clan compound in Iziz)
// Re-description of Voth's `voth_bldg_clan_compound` + the townhouse kinds (hlaalu / velothi / domed) against the
// Iziz kit. Voth is a Venice/Vivec-like Dunmer city: grey-brown ashlar (cooler than Iziz's orange sandstone), pale
// plaster upper walls, dark pantile roofs, gilded domes and finials, deep-red and dark-blue clan banners. The
// compound: a curtain wall with pilaster buttresses, four tapered corner bastions, a gatehouse; inside a Velothi
// tower (tapering octagonal drums, banded, domed), a hlaalu house (stacked, shrinking, corniced flat blocks), a
// domed hall, a paved court with a shrine obelisk, a well and an emperor-mushroom sapling in a stone planter.
// Shared `vp*` textures / materials / kit items for both ported buildings (75 + 76) live at the top of this file.

// ---------------------------------------------------------------- textures (near-grey, tinted per instance; 128 px = 2 m unless noted)
TEX.vpTile=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // pantile: courses 0.3 m, tiles 0.25 m, each tile rounded across
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const row=Math.floor(y/19),fy=y%19,off=(row%2)*8,fx=(x+off)%16,tx=Math.floor((x+off)/16);
  const curve=Math.sin(fx/16*Math.PI);let v=150+curve*46+(h3(tx*1.7,row*2.3,3.1)-.5)*30+(fbm(x/9,y/9,4.4,2)-.5)*14;
  if(fy>16)v-=55;else if(fy<1)v+=8;if(fx<1)v-=30;d[i]=v;d[i+1]=v*.92;d[i+2]=v*.86;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.vpBanco=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // hand-smoothed mud plaster: sweeping horizontal trowel strokes, fine grit
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;let v=200+(fbm(x/40,y/9,5.1,3)-.5)*30+(fbm(x/6,y/6,2.7,2)-.5)*16+(fbm(x/2,y/2,8.8,1)-.5)*8;
  const band=Math.sin(y/128*Math.PI*7+fbm(x/30,0,1.3,2)*3);v+=band*5;const crack=fbm(x/14,y/14,6.2,2);if(Math.abs(crack-.5)<.005)v-=50;
  d[i]=v;d[i+1]=v*.95;d[i+2]=v*.88;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.vpMosaic=canvasTex(128,128,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // COLOUR texture: blue-and-white tesserae, 1 m per tile; a diamond lattice in the Order's blue
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const tx=Math.floor(x/8),ty=Math.floor(y/8),grout=(x%8<1)||(y%8<1);
  const u=(x/128)%.5,vv=(y/128);const diamond=Math.abs(u-.25)+Math.abs(vv-.5)<.24;const blue=diamond?(Math.abs(u-.25)+Math.abs(vv-.5)>.12):false;
  let r,gg,b;if(blue){r=42+h3(tx,ty,1)*30;gg=106+h3(tx,ty,2)*40;b=176+h3(tx,ty,3)*40;}else{r=236+h3(tx,ty,4)*14;gg=232+h3(tx,ty,5)*12;b=218+h3(tx,ty,6)*14;}
  if(diamond&&!blue){r=216;gg=150+h3(tx,ty,7)*30;b=48;}   // a warm gold heart in each diamond
  if(grout){r*=.55;gg*=.55;b*=.55;}d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;}
 g.putImageData(id,0,0);});
TEX.vpBanner=canvasTex(64,160,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;   // a hung banner: dark field (takes the tint), a pale device, a fringed foot
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const u=x/w-.5,v=y/h;let val=118+(fbm(x/6,y/6,2.2,2)-.5)*18+((x%3<1)?-6:0);
  const r=Math.hypot(u*1.9,(v-.42)*1.9);if(r<.36&&r>.28)val=240;if(Math.abs(u)<.03&&v>.2&&v<.64)val=240;if(Math.abs(v-.42)<.02&&Math.abs(u)<.22)val=240;   // ring + cross device
  if(v>.93&&((x%6)<3))val=0;if(v<.03)val=200;if(Math.abs(u)>.47)val*=.7;
  d[i]=val;d[i+1]=val;d[i+2]=val;d[i+3]=255;}
 g.putImageData(id,0,0);});

// ---------------------------------------------------------------- materials
MAT.vpTile=new THREE.MeshStandardMaterial({map:TEX.vpTile,color:0xffffff,roughness:.9,metalness:0,side:DS});vWorldUV(MAT.vpTile,.5);
MAT.vpBanco=new THREE.MeshStandardMaterial({map:TEX.vpBanco,color:0xffffff,roughness:.98,metalness:0,side:DS});vWorldUV(MAT.vpBanco,.5);
MAT.vpMosaic=new THREE.MeshStandardMaterial({map:TEX.vpMosaic,color:0xffffff,roughness:.45,metalness:.05,side:DS});vWorldUV(MAT.vpMosaic,1);
MAT.vpGilt=new THREE.MeshStandardMaterial({color:0xd0a53c,roughness:.32,metalness:.75});
MAT.vpBanner=new THREE.MeshStandardMaterial({map:TEX.vpBanner,color:0xffffff,roughness:.9,metalness:0,side:DS});   // plain 0..1 UVs: the device must not tile
MAT.vpBrass=new THREE.MeshStandardMaterial({color:0xb08a3a,roughness:.4,metalness:.7});

// ---------------------------------------------------------------- geometry
const VPOCT=new THREE.CylinderGeometry(.86,1,1,8).translate(0,.5,0).rotateY(Math.PI/8);      // tapering octagonal drum, a FACE to the front
const VPOCTS=new THREE.CylinderGeometry(1,1,1,8).translate(0,.5,0).rotateY(Math.PI/8);       // straight octagonal band
const VPDRUM=new THREE.CylinderGeometry(1,1,1,28).translate(0,.5,0);
const VPDISC=new THREE.CylinderGeometry(1,1,1,24).rotateX(Math.PI/2);                        // a disc facing ±z, thickness = scale z
const VPBANCO7=vnWedgeGeo(.93,.93), VPBANCO5=vnWedgeGeo(.55,.55), VPOBELISK=vnWedgeGeo(.42,.42);
// a wall slab W x H x T with a PARABOLIC opening ow x oh (Yuni's arch), base at y=0, centred in x and z
function vpArchGeo(W,H,T,ow,oh){const s=new THREE.Shape();s.moveTo(-W/2,0);s.lineTo(W/2,0);s.lineTo(W/2,H);s.lineTo(-W/2,H);s.lineTo(-W/2,0);
 const p=new THREE.Path();const n=18;p.moveTo(-ow/2,0);for(let i=1;i<n;i++){const x=-ow/2+ow*i/n;p.lineTo(x,oh*(1-Math.pow(2*x/ow,2)));}p.lineTo(ow/2,0);p.lineTo(-ow/2,0);s.holes.push(p);
 const g=new THREE.ExtrudeGeometry(s,{depth:T,bevelEnabled:false,curveSegments:8});g.translate(0,0,-T/2);g.computeVertexNormals();return g;}
// an ARCHIVOLT: the parabolic ring `t` thick round an opening ow x oh (a horseshoe polygon, so no hole touches the outline), extruded T
function vpArchRingGeo(ow,oh,t,T){const s=new THREE.Shape();const n=22,OW=ow+2*t,OH=oh+t;s.moveTo(-OW/2,0);for(let i=1;i<n;i++){const x=-OW/2+OW*i/n;s.lineTo(x,OH*(1-Math.pow(2*x/OW,2)));}s.lineTo(OW/2,0);s.lineTo(ow/2,0);
 for(let i=n-1;i>0;i--){const x=-ow/2+ow*i/n;s.lineTo(x,oh*(1-Math.pow(2*x/ow,2)));}s.lineTo(-ow/2,0);s.lineTo(-OW/2,0);
 const g=new THREE.ExtrudeGeometry(s,{depth:T,bevelEnabled:false,curveSegments:8});g.translate(0,0,-T/2);g.computeVertexNormals();return g;}

// ---------------------------------------------------------------- kit items
kdef('vpTileB',VBOX,MAT.vpTile);kdef('vpTilePyr',VPYR,MAT.vpTile);kdef('vpTileHip',VHIP,MAT.vpTile);kdef('vpTileCone',VCONE,MAT.vpTile);
kdef('vpBancoB',VBOX,MAT.vpBanco);kdef('vpBanco7',VPBANCO7,MAT.vpBanco);kdef('vpBanco5',VPBANCO5,MAT.vpBanco);kdef('vpBancoCone',VCONE,MAT.vpBanco);
kdef('vpBancoPost',VPOST,MAT.vpBanco);kdef('vpDrumB',VPDRUM,MAT.vpBanco);kdef('vpDrumS',VPDRUM,MAT.stone);kdef('vpRingB',new THREE.TorusGeometry(1,.13,7,26),MAT.vpBanco);
kdef('vpDiscDark',VPDISC,MAT.void);kdef('vpDiscP',VPDISC,MAT.plaster);kdef('vpArchRingM',vpArchRingGeo(3.4,5.0,.55,.36),MAT.vpMosaic);kdef('vpArchRingB',vpArchRingGeo(3.4,5.0,.5,.3),MAT.vpBanco);kdef('vpDiscLit',VPDISC,MAT.warmPane);kdef('vpMosaicB',VBOX,MAT.vpMosaic);
kdef('vpGateArchB',vpArchGeo(7,6.5,1.6,3.4,5.0),MAT.vpBanco);kdef('vpBayArchB',vpArchGeo(3.2,4.0,.7,2.3,3.4),MAT.vpBanco);kdef('vpBayArchM',vpArchGeo(3.2,4.0,.7,2.3,3.4),MAT.vpMosaic);
kdef('vpOctS',VPOCT,MAT.stone);kdef('vpOctBand',VPOCTS,MAT.stone);kdef('vpObelisk',VPOBELISK,MAT.stone);
kdef('vpGilt',VBALL,MAT.vpGilt);kdef('vpGiltCone',VCONE,MAT.vpGilt);kdef('vpGiltDome',VDOME,MAT.vpGilt);kdef('vpBrassBell',new THREE.SphereGeometry(1,10,7,0,TAU,0,Math.PI*.62),MAT.vpBrass);
kdef('vpBanner',VPLANE,MAT.vpBanner);

// ---------------------------------------------------------------- local helpers (vp prefix)
// a hung banner: pole-less cloth `w` x `h` whose top edge is at y, facing `ry`, tinted
function vpHang(x,y,z,ry,w,h,c){kput('vpBanner',[x,y-h/2,z],vQ(ry,0,0),[w,h,1],c||null);}
// a banner on a pole: post, cross-arm, hung cloth turned across the arm
function vpBannerPole(x,y,z,ry,h,c){vPst('vPipe',x,y,z,.07,h,vC(0x3a2f22));const p=loc(x,z,.5,0,ry);vB('vIron',p[0],y+h-.25,p[1],1.0,.07,.07,ry,vC(0x3a2f22));vpHang(p[0],y+h-.3,p[1],ry+Math.PI/2,.85,2.6,c);}
// Voth window: a dark recess with a stone sill and a lintel; `lit` swaps the recess for a warm pane (electric)
function vpVWin(x,y,z,ry,w,h,c,lit){const f=loc(x,z,0,.04,ry);vB(lit?'vWinLit':'vDarkB',f[0],y,f[1],w,h,.12,ry);
 const s=loc(x,z,0,.16,ry);vB('vStone',s[0],y-.24,s[1],w+.55,.24,.42,ry,c);vB('vStone',s[0],y+h,s[1],w+.4,.2,.3,ry,c);
 if(lit){vB('vStone',f[0],y,f[1],.07,h,.14,ry,c);}}
// Voth door: recessed dark surround, leaf, stone lintel, one or two threshold steps, lamp if lit
function vpVDoor(x,y,z,ry,w,h,c,steps){const a=loc(x,z,0,.22,ry);vB('vStone',a[0],y,a[1],w+1.1,h+.8,.5,ry,c.clone().multiplyScalar(.82));
 const f=loc(x,z,0,.4,ry);vB('vDarkB',f[0],y,f[1],w,h,.2,ry);const l=loc(x,z,-w*.06,.5,ry);kput('vWood',[l[0],y+h/2,l[1]],vQ(ry,0,0).multiply(qEuler(0,.2,0)),[w*.9,h-.05,.07],vC(0x1c1a16));
 const t=loc(x,z,0,.3,ry);vB('vStone',t[0],y+h+.8,t[1],w+1.5,.35,.7,ry,c.clone().multiplyScalar(.8));
 for(let k=0;k<(steps||2);k++){const s=loc(x,z,0,.7+k*.4,ry);vB('vStone',s[0],y-(k+1)*.2,s[1],w+1.0-k*.2,.2,.8,ry,c.clone().multiplyScalar(.75));}
 if(vLit()){const q=loc(x,z,-(w/2+.9),0,ry);vnLamp(q[0],y+h+.3,q[1],ry);}}

// ---------------------------------------------------------------- the embassy
function buildVpEmbassy(G,o){reseed(7801+(o.v|0));
 const st=vC(vPick([0x8c8579,0x958e80,0x8b8069])),stD=st.clone().multiplyScalar(.78),cop=st.clone().multiplyScalar(.86),pl=vC(0xb8b0a2),tile=vC(vPick([0x5a4a48,0x4e4a52,0x6b5a58])),dome=vC(0xb08d3c),red=vC(0xa8241c),blue=vC(0x2f5a86),timber=vC(0x4a3a28),iron=vC(0x3a2f22);
 const CW=34,CD=30,WT=1.0,WH=4.8,Y0=.35;
 vnReg('Voth Embassy',0,0,25.5,24,{role:'embassy'});
 // raised stone pad the whole compound stands on
 vB('vStone',0,0,0,CW+1.2,Y0,CD+1.2,0,stD);
 // ---- curtain wall: back, sides, front halves; coping; pilaster buttresses outside; a walkway ledge inside
 const hx=CW/2-WT/2,hz=CD/2-WT/2,GAP=5.2;
 vB('vStone',0,Y0,-hz,CW-2*WT,WH,WT,0,st);vB('vStone',0,Y0+WH-.1,-hz,CW-2*WT+.3,.3,WT+.3,0,cop);
 for(const s of[-1,1]){vB('vStone',s*hx,Y0,0,WT,WH,CD-2*WT,0,st);vB('vStone',s*hx,Y0+WH-.1,0,WT+.3,.3,CD-2*WT+.3,0,cop);
  const L=(CW-2*WT-GAP)/2,cx=s*(GAP/2+L/2);vB('vStone',cx,Y0,hz,L,WH,WT,0,st);vB('vStone',cx,Y0+WH-.1,hz,L+.3,.3,WT+.3,0,cop);}
 for(const s of[-1,1]){vB('vStone',0,Y0+2.5,s*(hz+.06),CW-2*WT,.22,WT+.12,0,cop);vB('vStone',s*(hx+.06),Y0+2.5,0,WT+.12,.22,CD-2*WT,0,cop);}   // string course
 for(const px of[-11,-5.5,0,5.5,11])for(const s of[-1,1]){if(s>0&&Math.abs(px)<8)continue;vB('vStone',px,Y0,s*(hz+.5),1.3,WH-.5,1.0,0,st.clone().multiplyScalar(.93));vB('vStone',px,Y0+WH-.5,s*(hz+.5),1.5,.25,1.2,0,cop);}
 for(const pz of[-9,-3,3,9])for(const s of[-1,1]){vB('vStone',s*(hx+.5),Y0,pz,1.0,WH-.5,1.3,0,st.clone().multiplyScalar(.93));vB('vStone',s*(hx+.5),Y0+WH-.5,pz,1.2,.25,1.5,0,cop);}
 // wall-walk inside: a corbelled ledge along the inner faces and a stone stair up to it beside the gate
 for(const s of[-1,1]){vB('vStone',s*(hx-WT/2-.45),Y0+3.5,0,.9,.3,CD-2*WT-1,0,cop);for(let k=0;k<5;k++)vB('vStone',s*(hx-WT/2-.45),Y0+3.1,-CD/2+4+k*5.5,.6,.4,.5,0,stD);}
 vB('vStone',0,Y0+3.5,-(hz-WT/2-.45),CW-2*WT-1,.3,.9,0,cop);for(let k=0;k<6;k++)vB('vStone',-CW/2+4+k*5.2,Y0+3.1,-(hz-WT/2-.45),.5,.4,.6,0,stD);
 for(let i=0;i<8;i++)vB('vStone',-(hx-WT/2-.7),Y0+i*.44,hz-WT/2-2.2-i*.75,1.4,.44,.8,0,st.clone().multiplyScalar(.9));
 // ---- corner bastions: tapered square towers oversailing the wall, cornice, cap, slits, a red clan banner on each
 for(const p of[[-1,-1],[1,-1],[-1,1],[1,1]]){const tx=p[0]*hx,tz=p[1]*hz,BH=9.4;kput('vBatterS',[tx,Y0,tz],null,[4.6,BH,4.6],st.clone().multiplyScalar(.96));
  vB('vStone',tx,Y0+BH-.05,tz,4.5,.4,4.5,0,cop);vB('vStone',tx,Y0+BH+.35,tz,3.9,.8,3.9,0,st);
  for(const s of[-1,1]){vB('vDarkB',tx+s*1.98,Y0+5.6,tz,.24,1.3,.5,0);vB('vDarkB',tx,Y0+5.6,tz+s*1.98,.5,1.3,.24,0);vB('vDarkB',tx+s*1.7,Y0+BH+.5,tz+p[1]*1.98,.5,.55,.2,0);}
  vpBannerPole(tx,Y0+BH+1.15,tz,p[0]>0?-Math.PI/2:Math.PI/2,3.6,red);}
 // ---- gatehouse: a block across the wall line, dark arched-lintel passage, iron-studded leaves half open, lamps, banners red + blue
 {const gz=hz,GW=9.2,GD=4.2,GH=8.2;for(const s of[-1,1])vB('vStone',s*(GW/4+.9),Y0,gz,GW/2-1.8,4.6,GD,0,st);vB('vStone',0,Y0+4.6,gz,GW,GH-4.6,GD,0,st);   // piers + the storey over the passage: a REAL opening
  vB('vFlag',0,Y0-.02,gz,3.6,.06,GD+.4,0,cop);vB('vStone',0,Y0+GH-.1,gz,GW+.4,.4,GD+.4,0,cop);vB('vStone',0,Y0+GH+.3,gz,GW-1.4,.9,GD-1.2,0,st.clone().multiplyScalar(.95));
  for(let k=-2;k<=2;k++)vB('vStone',k*2.0,Y0+GH+1.2,gz+GD/2-.4,1.0,.7,.6,0,st);   // merlons on the front parapet
  vB('vStone',0,Y0+4.6,gz+GD/2+.1,5.2,.55,.9,0,cop);vB('vStone',0,Y0+4.6,gz-GD/2-.1,5.2,.55,.9,0,cop);vB('vStone',0,Y0+5.15,gz+GD/2+.05,4.4,.25,.5,0,st);
  for(const s of[-1,1]){vB('vStone',s*2.25,Y0,gz+GD/2+.1,.9,4.8,.7,0,st.clone().multiplyScalar(.9));vB('vStone',s*2.25,Y0,gz-GD/2-.1,.9,4.8,.7,0,st.clone().multiplyScalar(.9));
   kput('vWood',[s*1.2,Y0+2.2,gz+GD/2-1.1],vQ(0,0,0).multiply(qEuler(0,s*.95,0)),[1.85,4.3,.12],vC(0x2a221a));   // gate leaves, swung inward, seen from the street
   for(const yy of[1.0,2.3,3.6])kput('vIron',[s*1.2,Y0+yy,gz+GD/2-1.1],vQ(0,0,0).multiply(qEuler(0,s*.95,0)),[1.7,.1,.16],iron);
   vpVWin(s*3.0,Y0+5.6,gz+GD/2,0,.8,1.4,st,false);vpVWin(s*3.0,Y0+5.6,gz-GD/2,Math.PI,.8,1.4,st,vLit());
   vpBannerPole(s*3.6,Y0+GH+1.2,gz-.6,0,4.2,s<0?red:blue);
   if(vLit()){vnLamp(s*2.9,Y0+4.3,gz+GD/2,0);vnLamp(s*2.9,Y0+4.3,gz-GD/2,Math.PI);}}
  vpHang(0,Y0+GH-.4,gz+GD/2+.12,0,2.2,3.0,blue);vpHang(0,Y0+GH-.4,gz-GD/2-.12,Math.PI,2.2,3.0,red);          // the embassy's colours on the gate itself
  vB('vStone',0,0,gz+GD/2+.5,4.6,.175,1.1,0,stD);                                                               // a step down to the street
  for(const s of[-1,1])vnLampPost(s*3.6,0,gz+GD/2+.8,3.6);}
 // ---- Velothi tower, back-left: base, three tapering octagonal drums with bands, a gilt dome; porch, slits, bracketed balcony
 {const tx=-10,tz=-8.5;let y=Y0;const apo=Math.cos(Math.PI/8);const drums=[[3.6,8.0],[3.0,6.4],[2.35,3.6]];
  kput('vpOctBand',[tx,y,tz],null,[3.9,1.0,3.9],stD);y+=1.0;
  const faceAt=(r,h,t)=>(r*(1-.14*t/h))*apo;const face0=[];
  drums.forEach((d,i)=>{kput('vpOctS',[tx,y,tz],null,[d[0],d[1],d[0]],st.clone().multiplyScalar(1+i*.03));face0.push(y);
   const rt=d[0]*.86;y+=d[1];kput('vpOctBand',[tx,y,tz],null,[rt+.12,.45,rt+.12],cop);y+=.45;});
  kput('vpOctBand',[tx,y,tz],null,[2.15,.5,2.15],st);y+=.5;kput('vDomeP',[tx,y,tz],null,[2.0,1.7,2.0],dome);vBall('vpGilt',tx,y+1.85,tz,.4);vPst('vPipe',tx,y+1.6,tz,.05,1.4,iron);vpHang(tx+.35,y+2.9,tz,Math.PI/2,.6,1.4,red);
  // slit windows round the drums on the flats (k*45°, face 0 = +z front)
  drums.forEach((d,i)=>{const yb=face0[i];const rows=i===0?[2.6,5.6]:[d[1]*.5];for(const yy of rows)for(let k=0;k<8;k++){if(i===0&&k===0)continue;if(i===2&&k%2===0)continue;const a=k*Math.PI/4;const r=faceAt(d[0],d[1],yy)+.02;
    const p=[tx+Math.sin(a)*r,tz+Math.cos(a)*r];vpVWin(p[0],yb+yy-.7,p[1],a,k%2?.6:.95,1.4,st,vLit()&&i<2&&k%2===0);}});
  // porch on the front flat of the first drum
  {const g0=faceAt(drums[0][0],drums[0][1],1.6);const pz=tz+g0;vpVDoor(tx,Y0+1.0,pz,0,1.7,2.7,st,2);
   for(const s of[-1,1]){vPst('vpDrumS',tx+s*1.75,Y0+1.0,pz+.9,.28,3.9,st.clone().multiplyScalar(.9));vB('vStone',tx+s*1.75,Y0+4.9,pz+.9,.8,.3,.8,0,cop);}
   vB('vStone',tx,Y0+5.2,pz+.45,4.4,.4,1.6,0,cop);}
  // bracketed balcony over the porch on the second drum's front flat
  {const yb=face0[1]+1.3;const b0=tz+faceAt(drums[1][0],drums[1][1],1.3);vB('vStone',tx,yb,b0+.8,4.6,.3,1.7,0,cop);
   for(const ox of[-1.7,1.7])vBeam([tx+ox,yb,b0],[tx+ox,yb-1.1,b0+1.4],.3,timber);
   vB('vWood',tx,yb+.3,b0+1.55,4.6,.8,.14,0,timber);for(const ox of[-2.25,2.25])vB('vWood',tx+ox,yb+.3,b0+.8,.14,.8,1.6,0,timber);}
  // external stair up the left flank to a first-floor door, and a stone buttress at the back
  {const sx=tx-faceAt(drums[0][0],drums[0][1],2)-.5;for(let i=0;i<7;i++)vB('vStone',sx+.08*i,Y0+i*.6,tz-3.2+i*.9,1.5,.6,1.0,0,st.clone().multiplyScalar(.9));
   const fx=tx-faceAt(drums[0][0],drums[0][1],4.5);vB('vStone',(sx+fx)/2,Y0+4.2,tz-5.3,fx-sx+.6,.3,2.0,0,cop);vB('vDarkB',fx-.1,Y0+4.5,tz-5.3,.3,2.2,1.3,0);vB('vStone',fx-.15,Y0+6.7,tz-5.3,.4,.3,1.9,0,cop);vBeam([sx-.2,Y0+.9,tz-3.2],[sx+.5,Y0+5.4,tz+3.8],.08,timber,'vIron');
   kput('vBatterS',[tx,Y0,tz-4.4],null,[1.5,6.4,1.5],st.clone().multiplyScalar(.95));vB('vStone',tx,Y0+6.4,tz-4.4,1.7,.4,1.7,0,cop);}}
 // ---- hlaalu house, back-right: stacked shrinking flat blocks (stone below, pale plaster above), cornices, balcony, chimney
 {const lev=[];let jx=7.2,jz=-8.6,y=Y0,fw=12.5,fd=9.2;const hs=[6.0,4.8,3.6];
  vB('vStone',jx,Y0,jz,fw+.8,.4,fd+.8,0,stD);y+=.4;
  hs.forEach((fh,i)=>{if(i>0){jx+=rr(-.5,.5);jz+=rr(-.4,.2);}const item=i===0?'vStone':'vPlaster',c=i===0?st:pl;vB(item,jx,y,jz,fw,fh,fd,0,c);
   if(i>0)for(const sx of[-1,1])for(const sz of[-1,1])vB('vStone',jx+sx*(fw/2-.35),y,jz+sz*(fd/2-.35),.7,fh,.7,0,st.clone().multiplyScalar(.9));   // stone quoins on the plaster storeys
   vB('vStone',jx,y+fh-.28,jz,fw+.4,.36,fd+.4,0,cop);lev.push({x:jx,z:jz,y,w:fw,d:fd,h:fh});y+=fh;fw*=.8;fd*=.8;});
  const L0=lev[0],L1=lev[1],L2=lev[2];vB('vStone',L2.x,y,L2.z,L2.w*.9,.7,L2.d*.9,0,cop);
  // openings on every elevation
  const row=(L,side,ys,n,spread,ww,wh,lit)=>{for(let i=0;i<n;i++){const u=n===1?0:-spread+2*spread*i/(n-1);
   if(side===0)vpVWin(L.x+u,L.y+ys,L.z+L.d/2,0,ww,wh,st,lit);else if(side===1)vpVWin(L.x+u,L.y+ys,L.z-L.d/2,Math.PI,ww,wh,st,lit);
   else if(side===2)vpVWin(L.x+L.w/2,L.y+ys,L.z+u,Math.PI/2,ww,wh,st,lit);else vpVWin(L.x-L.w/2,L.y+ys,L.z+u,-Math.PI/2,ww,wh,st,lit);}};
  const lit=vLit();row(L0,0,1.5,2,3.9,1.3,1.8,lit);row(L0,0,4.2,3,4.2,1.1,1.3,false);row(L0,2,1.6,2,2.6,1.2,1.7,lit);row(L0,3,1.6,2,2.6,1.2,1.7,lit);row(L0,1,1.6,3,3.6,1.1,1.6,false);
  row(L1,0,1.4,3,3.4,1.2,1.7,lit);row(L1,2,1.4,2,2.2,1.1,1.5,lit);row(L1,3,1.4,2,2.2,1.1,1.5,false);row(L1,1,1.4,2,2.6,1.0,1.4,false);
  row(L2,0,1.1,2,2.0,1.0,1.4,lit);row(L2,1,1.1,1,0,1.0,1.3,false);row(L2,2,1.1,1,0,.9,1.3,false);
  vpVDoor(L0.x-2.4,L0.y,L0.z+L0.d/2,0,1.7,2.8,st,2);
  // first-floor balcony on timber brackets across the front
  {const by=L0.y+L0.h-.1,bz=L0.z+L0.d/2;vB('vStone',L0.x,by,bz+.7,6.6,.3,1.5,0,cop);for(const ox of[-2.6,2.6])vBeam([L0.x+ox,by,bz],[L0.x+ox,by-1.2,bz+1.3],.32,timber);
   vB('vWood',L0.x,by+.3,bz+1.38,6.6,.8,.14,0,timber);for(const ox of[-3.25,3.25])vB('vWood',L0.x+ox,by+.3,bz+.7,.14,.8,1.5,0,timber);for(let k=-5;k<=5;k++)vB('vWood',L0.x+k*.6,by+.3,bz+1.38,.07,.8,.07,0,timber);}
  // roof furniture: chimney, a drain pipe, a small dome-capped stair turret on the top block
  {const cx=L1.x+L1.w/2-1.1,cz=L1.z-L1.d/2+1.1;vB('vStone',cx,L1.y+L1.h,cz,.85,2.8,.85,0,stD);vB('vStone',cx,L1.y+L1.h+2.8,cz,1.15,.5,1.15,0,cop);vPst('vPipe',cx,L1.y+L1.h+3.3,cz,.22,.5,iron);}
  vPst('vPipe',L0.x+L0.w/2+.2,Y0+.4,L0.z+L0.d/2-.6,.11,L0.h+L1.h-.3,st.clone().multiplyScalar(.7));
  vPst('vpDrumS',L2.x-L2.w/2+1.3,y+.7,L2.z,1.0,1.2,st);kput('vDomeP',[L2.x-L2.w/2+1.3,y+1.9,L2.z],null,[1.05,.8,1.05],dome);vBall('vpGilt',L2.x-L2.w/2+1.3,y+2.8,L2.z,.18);
  }
 // ---- service range (kitchen / stable) against the right wall: stone, dark pantile hip roof, chimney, stable door
 {const rx=13,rz=4,RW=5.6,RD=6.4,RH=3.4;vB('vStone',rx,Y0,rz,RW,RH,RD,0,st.clone().multiplyScalar(.95));vB('vStone',rx,Y0+RH-.1,rz,RW+.3,.28,RD+.3,0,cop);
  vnHipRoof('vpTileHip',rx,Y0+RH+.55,rz,RW,RD,2.0,0,tile,.8);vB('vStone',rx-1.8,Y0+RH,rz-2.2,.7,2.4,.7,0,stD);vB('vStone',rx-1.8,Y0+RH+2.4,rz-2.2,.95,.4,.95,0,cop);
  vB('vDarkB',rx-RW/2-.02,Y0,rz+1.2,.2,2.4,1.8,0);kput('vWood',[rx-RW/2-.1,Y0+1.2,rz+1.2],qEuler(0,Math.PI/2,0),[1.7,2.3,.08],vC(0x2a221a));vpVWin(rx-RW/2,Y0+1.6,rz-1.6,-Math.PI/2,.9,1.0,st,false);vpVWin(rx,Y0+1.6,rz+RD/2,0,.9,1.0,st,false);
  vnBarrel(rx-RW/2-1.0,Y0,rz-2.4,.38,.9,timber);vnCrate(rx-RW/2-1.2,Y0,rz+2.8,.8,.3,timber);} // ---- domed hall (the embassy's audience room), left of the court: corniced stone block, ribbed drum, gilt-ochre dome, lucarnes, corner urns
 {const hx2=-11,hz2=4.5,HW=8.4,HD=7.0,HH=5.6;vB('vStone',hx2,Y0,hz2,HW+.6,.4,HD+.6,0,stD);vB('vStone',hx2,Y0+.4,hz2,HW,HH,HD,0,st);
  vB('vStone',hx2,Y0+.4+HH*.5,hz2,HW+.3,.26,HD+.3,0,cop);vB('vStone',hx2,Y0+.4+HH-.2,hz2,HW+.4,.4,HD+.4,0,cop);vB('vStone',hx2,Y0+.4+HH+.2,hz2,HW-.8,.5,HD-.8,0,st.clone().multiplyScalar(.95));
  const dy=Y0+.4+HH+.7;vPst('vpDrumS',hx2,dy,hz2,2.7,2.4,st.clone().multiplyScalar(1.04));
  for(let i=0;i<8;i++){const a=i/8*TAU;vB('vStone',hx2+Math.sin(a)*2.7,dy,hz2+Math.cos(a)*2.7,.3,2.4,.3,-a,cop);if(i%2===0)vB(vLit()?'vWinLit':'vDarkB',hx2+Math.sin(a)*2.68,dy+.7,hz2+Math.cos(a)*2.68,.9,1.2,.3,-a);}
  vB('vStone',hx2,dy+2.4,hz2,5.9,.3,5.9,0,cop);kput('vDomeP',[hx2,dy+2.7,hz2],null,[2.85,2.5,2.85],dome);vBall('vpGilt',hx2,dy+5.3,hz2,.36);
  for(const p of[[-1,-1],[1,-1],[-1,1],[1,1]]){const ux=hx2+p[0]*(HW/2-.6),uz=hz2+p[1]*(HD/2-.6);vB('vStone',ux,Y0+.4+HH+.2,uz,.9,.9,.9,0,cop);vBall('vpGilt',ux,Y0+.4+HH+1.4,uz,.32);}
  vpVDoor(hx2+HW/2,Y0+.4,hz2,Math.PI/2,1.6,2.6,st,1);   // door faces the court
  vpVWin(hx2+HW/2,Y0+1.9,hz2-2.4,Math.PI/2,1.2,1.7,st,vLit());vpVWin(hx2+HW/2,Y0+1.9,hz2+2.4,Math.PI/2,1.2,1.7,st,vLit());
  for(const z of[-2.2,0,2.2])vpVWin(hx2-HW/2,Y0+1.9,hz2+z,-Math.PI/2,1.1,1.6,st,false);for(const x of[-2.4,0,2.4]){vpVWin(hx2+x,Y0+1.9,hz2+HD/2,0,1.1,1.6,st,vLit());vpVWin(hx2+x,Y0+1.9,hz2-HD/2,Math.PI,1.1,1.6,st,false);}
  // a corbelled projecting bay on the front, as the domed townhouse has
  vB('vStone',hx2+2.4,Y0+3.2,hz2+HD/2+.7,2.8,2.4,1.4,0,st.clone().multiplyScalar(1.03));vB('vStone',hx2+2.4,Y0+5.6,hz2+HD/2+.7,3.1,.3,1.7,0,cop);vBeam([hx2+2.4,Y0+3.2,hz2+HD/2],[hx2+2.4,Y0+2.0,hz2+HD/2+1.2],.45,timber);
  vB('vDarkB',hx2+2.4,Y0+3.8,hz2+HD/2+1.42,1.7,1.4,.1,0);}
 // ---- the court: paving, a paved way from the gate to the house, a shrine obelisk on a stepped base, a well, the emperor-mushroom sapling in a stone planter, lamps
 vnPaving(0,Y0+.02,2,26,22,0,st.clone().multiplyScalar(.9),40);
 vB('vFlag',0,Y0+.03,8.4,3.4,.1,9.6,0,cop);vB('vFlag',2.6,Y0+.03,-1.6,7.6,.1,2.6,0,cop);
 {const ox=0,oz=1.5;for(let k=0;k<3;k++)vB('vStone',ox,Y0+k*.3,oz,3.6-k*.8,.3,3.6-k*.8,0,k%2?st:stD);kput('vpObelisk',[ox,Y0+.9,oz],null,[1.15,6.2,1.15],st.clone().multiplyScalar(1.05));
  kput('vPyrS',[ox,Y0+7.1,oz],null,[.5,.5,.5],cop);vBall('vpGilt',ox,Y0+7.7,oz,.16);for(let k=0;k<4;k++){const a=k*Math.PI/2;vB('vDarkB',ox+Math.sin(a)*.55,Y0+2.2,oz+Math.cos(a)*.55,.3,1.4,.06,-a);}
  if(vLit())for(const s of[-1,1]){vPst('vPipe',ox+s*1.35,Y0+.6,oz,.04,.5,iron);vBall('vBulb',ox+s*1.35,Y0+1.2,oz,.1);}}
 {const wx=8.5,wz=6.5;vPst('vpDrumS',wx,Y0,wz,1.5,.9,stD);vPst('vpDrumS',wx,Y0+.9,wz,1.3,.2,cop);vB('vDarkB',wx,Y0+1.1,wz,1.8,.06,1.8,0);
  for(const s of[-1,1])vPst('vPipe',wx+s*1.35,Y0+.9,wz,.09,2.4,iron);vB('vIron',wx,Y0+3.2,wz,2.9,.1,.1,0,iron);vPst('vRope',wx,Y0+1.3,wz,.02,1.9,vC(0x8a7a5a));vnBarrel(wx+.5,Y0+1.1,wz+.4,.2,.32,timber);}
 {const px=-4,pz=8.5;vB('vStone',px,Y0,pz,3.2,.9,3.2,0,st);vB('vStone',px,Y0+.9,pz,3.5,.2,3.5,0,cop);vB('vClayB',px,Y0+1.0,pz,2.7,.12,2.7,0,vC(0x4a3a2c));
  const fungus=vC(0x9a8aa2),gill=vC(0xe8dce4,1.4);vPst('vPostB',px,Y0+1.0,pz,.42,4.6,vC(0xc8c0c8));kput('vDomeP',[px,Y0+5.4,pz],null,[3.4,1.5,3.4],fungus);kput('vpDiscP',[px,Y0+5.36,pz],qEuler(Math.PI/2,0,0),[3.25,3.25,.14],gill);
  kput('vDomeP',[px,Y0+6.9,pz],null,[1.3,.7,1.3],fungus.clone().multiplyScalar(1.1));vPst('vPostB',px+.9,Y0+1.0,pz-.6,.14,1.6,vC(0xc8c0c8));kput('vDomeP',[px+.9,Y0+2.55,pz-.6],null,[.9,.45,.9],fungus);
  vPst('vPostB',px-1.0,Y0+1.0,pz+.7,.1,1.1,vC(0xc8c0c8));kput('vDomeP',[px-1.0,Y0+2.05,pz+.7],null,[.6,.3,.6],fungus);}
 for(const s of[-1,1])vnLampPost(s*6,Y0,11.5,3.4);vnLampPost(-3,Y0,-2,3.4);
 for(const x of[-13,13])vB('vWood',x,Y0,11.5,.5,.45,3.0,0,timber);   // benches along the front wall
 vnFolk(1,6,4,3);vnFolk(0,CD/2+4,3,2);}

VERN.def({key:'port_voth_embassy',name:'Voth Embassy',family:'ported',tags:{culture:'voth',type:['civic'],wealth:'rich',lit:true,role:'embassy'},w:36,d:34,h:24,build:buildVpEmbassy});
// ================================================================= UNIVERSITY v2 — "the Hill School" (one interconnected terrace structure)
function buildCampus(scene,gx,gz,d){reseed(9800+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);
 REGISTER({name:'University — the Hill School ('+STATE(d)+')',x:-40,z:60,r:330,h:90});
 const hill=(x,z)=>{const t=clamp((330-z)/600,0,1);const ex=clamp((380-Math.abs(x))/120,0,1),ez=clamp((360-Math.abs(z))/60,0,1);const e=ex*ex*(3-2*ex)*ez*ez*(3-2*ez);return (58*t*t*(3-2*t)+4*fbm(x/60+3,z/60,1.5,2))*e;};
 const hm=gridSurface((u,v)=>{const x=(u-.5)*780,z=(v-.5)*740;return[x,hill(x,z),z];},90,86,{uS:30,vS:28});mesh(hm,d>0?MAT.turfR:MAT.turf,G);
 const SH=4.2,DEP=18,SB=3.2;const wings=[];const GREEN=new THREE.Color().setHSL(.29,.5,d>0?.14:.24);
 // wing: bar from p0→p1 (horizontal), floors nf, base y0, terraces stepping toward `up` (unit vector, uphill)
 function wing(p0,p1,nf,y0,up,name){const dx=p1[0]-p0[0],dz=p1[1]-p0[1];const L=Math.hypot(dx,dz);const ax=dx/L,az=dz/L;const ang=Math.atan2(az,ax);const q=qEuler(0,-ang,0);
  const mid=[(p0[0]+p1[0])/2,(p0[1]+p1[1])/2];wings.push({p0,p1,y0,nf,up});REGISTER({name,x:mid[0],z:mid[1],y:y0-8,r:L/2+10,h:nf*SH+14});
  // platform cut into the hill: retaining walls
  kput(BOXC(d),[mid[0]-up[0]*4,y0-6,mid[1]-up[1]*4,],q,[L+6,12,DEP+12],null);
  for(let f=0;f<=nf;f++){const y=y0+f*SH;const off=f*SB;const cx=mid[0]+up[0]*(off+DEP/2),cz=mid[1]+up[1]*(off+DEP/2);const gone=d>0&&f===nf&&rng()<.5;
   if(!gone){kput(BOXC(d),[cx,y,cz],q,[L+2,.6,DEP+1.5],null);
    // planted front edge on every terrace, parapet on the top
    for(let k=0;k<Math.round(L/6);k++){const t=(k+.5)/Math.round(L/6);const x=p0[0]+dx*t+up[0]*(off+.8),z=p0[1]+dz*t+up[1]*(off+.8);if(d>0&&rng()<.3)continue;if(rng()<.55)kput('hedge',[x,y+.7,z],q,[5.4,.9,1.6],GREEN);
     if(d>0)kput('vine',[x,y+.3,z-up[1]*.6],qEuler(rr(-.1,.1),0,rr(-.1,.1)),[1.2,rr(3,SH*2),1.2],null);}
    if(f===nf){kput('brick',[cx+up[0]*(DEP/2-.5),y+.6,cz+up[1]*(DEP/2-.5)],q,[L+2,1.2,.5],null);for(let k=0;k<3;k++)kput('hedge',[mid[0]+up[0]*(off+DEP*.6)+ax*(k-1)*L*.3,y+1.1,mid[1]+up[1]*(off+DEP*.6)+az*(k-1)*L*.3],q,[8,1,3],GREEN);}}
   if(f<nf){const ff=f*SB;const fcx=mid[0]+up[0]*(ff+DEP/2),fcz=mid[1]+up[1]*(ff+DEP/2);
    kput('boxD',[fcx,y+SH/2,fcz],q,[L-1,SH-.8,DEP-2],null);
    // front: columns + spandrel brick + glass; back wall brick; ends brick
    const nx=Math.round(L/5);for(let k=0;k<=nx;k++){const t=k/nx;const x=p0[0]+dx*t+up[0]*(ff+1.2),z=p0[1]+dz*t+up[1]*(ff+1.2);if(d>0&&rng()<.06)continue;kput(BOXC(d),[x,y+SH/2,z],q,[.7,SH,.7],null);}
    kput('brick',[mid[0]+up[0]*(ff+1.4),y+.9,mid[1]+up[1]*(ff+1.4)],q,[L,1.2,.4],null);
    if(d===0)kput('pane',[mid[0]+up[0]*(ff+1.4),y+2.8,mid[1]+up[1]*(ff+1.4)],q,[L,2.8,1],null);else if(rng()<.5)kput('paneD',[mid[0]+up[0]*(ff+1.4),y+2.7,mid[1]+up[1]*(ff+1.4)],q,[L*.6,2.4,1],null);
    kput('brick',[mid[0]+up[0]*(ff+DEP-.6),y+SH/2,mid[1]+up[1]*(ff+DEP-.6)],q,[L+1,SH,.6],null);
    for(const s of [-1,1])kput('brick',[mid[0]+ax*s*(L/2)+up[0]*(ff+DEP/2),y+SH/2,mid[1]+az*s*(L/2)+up[1]*(ff+DEP/2)],q,[.6,SH,DEP-1],null);
    for(let k=0;k<Math.round(L/10);k++){const t=(k+.5)/Math.round(L/10);const lit=d>0?rng()<.1:true;kput('strip',[p0[0]+dx*t+up[0]*(ff+4),y+SH-.5,p0[1]+dz*t+up[1]*(ff+4)],q,[7,1,1],lit?CYAN:DEAD);}
    if(f===0){const t=.5;kput('archOpen',[p0[0]+dx*t+up[0]*(ff+1.3),y+2.4,p0[1]+dz*t+up[1]*(ff+1.3)],qFacing([-up[0],0,-up[1]]),[.45,.45,1],null);}}}
  // external stair down the front at one end
  for(let k=0;k<8;k++)kput(BOXC(d),[p1[0]-ax*3-up[0]*(2+k*1.5),y0-.4-k*.9,p1[1]-az*3-up[1]*(2+k*1.5)],q,[3,.4,1.5],null);
  if(d>0){for(let k=0;k<4;k++){const t=rng();kput('vine',[p0[0]+dx*t+up[0]*.8,y0+nf*SH,p0[1]+dz*t+up[1]*.8],null,[1.4,rr(6,nf*SH),1.4],null);}}}
 // the chain: zigzag up the hill (uphill = −z); each wing's base is the hill height at its downhill face
 const chain=[[[-190,230],[30,230],3,'Wing 1 — academic'],[[30,150],[30,230],3,'Wing 2 — link'],[[30,150],[-170,150],4,'Wing 3 — library floors'],[[-170,60],[-170,150],3,'Wing 4 — link'],[[-170,60],[70,60],4,'Wing 5 — laboratories'],[[70,-30],[70,60],3,'Wing 6 — link'],[[70,-30],[-130,-30],3,'Wing 7 — halls']];
 chain.forEach((c,i)=>{const isX=c[0][1]===c[1][1];const up=isX?[0,-1]:[(c[0][0]<0?1:-1),0];const zf=Math.max(c[0][1],c[1][1]);const y0=Math.round(hill((c[0][0]+c[1][0])/2,zf+2)+1);wing(c[0],c[1],c[2],y0,up,'Campus '+c[3]);});
 // courtyards between wings: big trees, paths, an atrium bridge across each
 [[-70,190,-190,150,30,230],[-70,105,-170,60,30,150],[-50,15,-130,-30,70,60]].forEach((c,i)=>{const [cx,cz,x0,z0,x1,z1]=c;const y=hill(cx,cz);REGISTER({name:'Campus courtyard '+(i+1),x:cx,z:cz,y:y-2,r:60,h:30});
  for(let k=0;k<5;k++){const x=rr(x0+20,x1-20),z=rr(z0+20,z1-20);const h=rr(18,30);kput('trunk',[x,y-2,z],null,[4,h,4],null);for(let j=0;j<4;j++){const s=rr(8,14);kput('moss',[x+rr(-4,4),y+h*.6+j*3,z+rr(-4,4)],qEuler(rng(),rng(),rng()),[s,s*.55,s],new THREE.Color().setHSL(rr(.25,.34),rr(.4,.55),rr(.15,.26)));}}
  for(let k=0;k<12;k++)kput('hedge',[rr(x0+8,x1-8),y+.4,rr(z0+8,z1-8)],qEuler(0,rng()*3,0),[rr(3,8),.8,rr(2,4)],GREEN);
  kput(BOXC(d),[cx,y+.1,cz],qEuler(0,rr(0,.6),0),[3,.3,Math.abs(z1-z0)-10],null);kput(BOXC(d),[cx,y+.1,cz],qEuler(0,rr(0,.6),0),[Math.abs(x1-x0)-10,.3,3],null);});
  // The atrium bridge that used to run diagonally over each courtyard is gone.
  // It cut across the one open void in the plan at a 0.5 rad angle that matched
  // nothing else on the hill, and closed the courtyards off from above.
  // Both rr() calls above are kept so the paths land where they always did.
 // curving concrete steps at the foot; a summit drum
 // (the rectangular lawn terrace that used to sit here is gone: a hard-edged
 //  260x140 slab of flat green laid across a rolling hill read as a decal, not
 //  as ground. The steps and the hill mesh carry the approach on their own.)
 for(let s=0;s<5;s++){const zb=280+s*14;mesh(gridSurface((u,v)=>{const x=-180+u*170;const z=zb+18*Math.sin(u*4+s*.6)+v*1.2-s*3*Math.sin(u*2);return[x,hill(x,z)+.4+s*.05,z];},60,1,{}),CONC(d),G);}
 for(let k=0;k<6;k++)kput(BOXC(d),[-40,hill(-40,330)+.3,330-k*2],null,[20,.4,1.6],null);
 {const cx=-40,cz=-110;const y=hill(cx,cz)+1;REGISTER({name:'Campus — summit hall',x:cx,z:cz,y:y-4,r:30,h:16});kput(SLABC(d),[cx,y-4,cz],null,[30,8,30],null);
  mesh(lathe({rFn:()=>24,H:11,nu:48,nv:4,hole:holeFn(d*.6,2100,null,2)}),MAT.brick,G,cx,y,cz);mesh(lathe({rFn:()=>22,H:11,nu:24,nv:1}),MAT.dark,G,cx,y,cz);
  kput(SLABC(d),[cx,y+11,cz],null,[25,.8,25],null);for(let k=0;k<20;k++){const th=(k+.5)/20*TAU;if(d===0)kput('pane',[cx+24.2*Math.cos(th),y+6,cz+24.2*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[5,4,1],null);kput(BOXC(d),[cx+24.4*Math.cos(th+.16),y+5.5,cz+24.4*Math.sin(th+.16)],qEuler(0,-th-.16,0),[1,11,1.4],null);}
  for(let k=0;k<8;k++)kput('hedge',[cx+18*Math.cos(k/8*TAU),y+12,cz+18*Math.sin(k/8*TAU)],qEuler(0,-k/8*TAU,0),[8,1,2.5],GREEN);kput('archOpen',[cx,y+2.6,cz+23.8],qFacing([0,0,1]),[.6,.6,1],null);stripRing(cx,y+9.5,cz,20,d,24);
  for(let k=0;k<6;k++)kput(BOXC(d),[cx+k*5,hill(cx+k*5,cz+40)+.4,cz+40],null,[4,.4,6],null);}
 // forest — big canopies, none on platforms/lawn
 for(let i=0;i<300;i++){const x=rr(-380,380),z=rr(-350,350);let on=z>240&&x>-200&&x<70;for(const w of wings){const minx=Math.min(w.p0[0],w.p1[0])-12,maxx=Math.max(w.p0[0],w.p1[0])+12,minz=Math.min(w.p0[1],w.p1[1])-12-(w.up[1]<0?DEP+w.nf*SB:0),maxz=Math.max(w.p0[1],w.p1[1])+12;const wx=w.up[0];const mx0=minx-(wx>0?0:DEP+w.nf*SB),mx1=maxx+(wx>0?DEP+w.nf*SB:0);if(x>mx0&&x<mx1&&z>minz&&z<maxz)on=true;}
  if(on||(Math.abs(x+40)<36&&Math.abs(z+110)<36))continue;const y=hill(x,z);const h=rr(16,34);kput('trunk',[x,y,z],null,[3.5,h,3.5],null);for(let k=0;k<4;k++){const s=(4-k)*2.6*(h/24);kput('moss',[x+rr(-2,2),y+h*.5+k*h*.14,z+rr(-2,2)],qEuler(0,rng()*TAU,0),[s,s*.65,s],new THREE.Color().setHSL(rr(.25,.35),rr(.35,.5),rr(.1,.2)));}}
 figures(-80,300,10,30);figures(-70,190,6,20);KOFF=[0,0,0];return G;}

// ================================================================= PORTED — the Order of Historians' chapterhouse (from the Yuni set)
// Re-description of Yuni's `civic_chapter_house` ("Chapter house of the Historians": laterite drum halls under tile
// cones with lanterns, round relief-ringed windows, curved arcaded gallery wings, a carved forecourt wall with a
// parabolic gate) crossed with the Order's Djenne-type civic vocabulary (`civic_hall_records`, `civic_sankore_spire`:
// battered banco walls, pilaster-buttresses with pinnacles, toron rows, blue-and-white mosaic string courses) and the
// Locus Geomancers' chapterhouse's nested-archivolt porch. Ochre / laterite / dark-umber earth palette; the only
// saturated colour is the Order's blue in the mosaic bands and the electric light. Uses the shared vp* kit from 75.
//
// Programme, local frame (+z front): a walled forecourt with a parabolic gate between two pylons; two arcaded
// wings (the archive stacks, the scriptorium) with a drum pavilion at each front corner; the READING HALL across
// the back — a battered block whose great drum carries a tile cone and a lantern; the Order's bell tower (a
// Sankore-style pyramid bristling with toron) at the back corner. Electric lamps: the Order runs the Vault's cable.

// battered face: half-depth of a `vpBanco7` block (7 % taper) at height y above its base
const vpBat7=(D,H,y)=>D/2*(1-.07*clamp(y/H,0,1));
// Yuni window on a battered banco face: dark reveal + pane (lit if electric), a small banco sill; (x,z) ON the face
function vpYWin(x,y,z,ry,w,h,c,lit){const f=loc(x,z,0,.03,ry);vB('vDarkB',f[0],y-.06,f[1],w+.24,h+.12,.14,ry);const p=loc(x,z,0,.06,ry);vB(lit?'vWinLit':'vDarkB',p[0],y,p[1],w,h,.12,ry);
 const s=loc(x,z,0,.16,ry);vB('vpBancoB',s[0],y-.2,s[1],w+.5,.2,.36,ry,c);}
// round Order window: banco relief ring, dark socket, a pane that glows if electric. r = pane radius. Faces `ry`.
function vpRoundWin(x,y,z,ry,r,c,lit){const q=vQ(ry,0,0);const a=loc(x,z,0,.14,ry),b=loc(x,z,0,.02,ry),d=loc(x,z,0,-.04,ry);
 kput('vpRingB',[a[0],y,a[1]],q,[r*1.25,r*1.25,r*1.25],c);kput('vpDiscDark',[b[0],y,b[1]],q,[r*1.15,r*1.15,.16],null);kput(lit?'vpDiscLit':'vpDiscDark',[d[0],y,d[1]],q,[r,r,.3],null);}
// a row of toron (projecting timber posts) along a face: from (x0,z0) to (x1,z1) at height y, n posts, outward (nx,nz)
function vpTorons(x0,z0,x1,z1,y,n,nx,nz,len){const c=vC(0x4a3624);for(let i=0;i<n;i++){const t=(i+.5)/n;const x=x0+(x1-x0)*t,z=z0+(z1-z0)*t;vBeam([x-nx*.3,y,z-nz*.3],[x+nx*(len||.95),y-.06,z+nz*(len||.95)],.17,c);}}
// pilaster-buttress with a pinnacle cone and a gilt ball: a battered post proud of a wall, base at (x,z)
function vpPinnacle(x,y,z,w,h,c,ry){kput('vpBanco7',[x,y,z],ry?qEuler(0,ry,0):null,[w,h,w],c);kput('vpBancoCone',[x,y+h-.05,z],null,[w*.42,w*1.1,w*.42],c);vBall('vpGilt',x,y+h+w*1.1+.12,z,.17);}
// drum pavilion: laterite drum, dark relief band, tile cone, 8-post lantern with a dark core, small cone, gilt ball. Returns the top.
function vpDrumHall(x,y,z,R,H,lat,dk,tile){vPst('vpDrumB',x,y,z,R,H,lat);vPst('vpDrumB',x,y+H-1.3,z,R+.08,.7,dk);vPst('vpDrumB',x,y+H-.3,z,R*1.04,.3,lat);
 const rb=R+.85,rt=R*.42,rh=R*.36;kput('vpTileCone',[x,y+H,z],null,[rb,rh+rt*.0+R*.02,rb],tile);   // the cone is a frustum in the source; a cone whose tip is buried under the lantern floor reads the same
 vPst('vpDrumB',x,y+H+rh*.7,z,rt+.3,.35,dk);const lr=rt*.82,lh=R*.3+.9;for(let i=0;i<8;i++){const a=i/8*TAU;vPst('vpBancoPost',x+Math.cos(a)*lr,y+H+rh*.7+.35,z+Math.sin(a)*lr,.16,lh,lat);}
 kput('vpDiscDark',[x,y+H+rh*.7+.35+lh/2,z],qEuler(Math.PI/2,0,0),[lr*.5,lr*.5,lh],null);kput('vpTileCone',[x,y+H+rh*.7+.35+lh,z],null,[rt+.9,R*.28+.6,rt+.9],tile.clone().multiplyScalar(.9));
 const top=y+H+rh*.7+.35+lh+R*.28+.6;vBall('vpGilt',x,top+.2,z,.24);return top;}

function buildVpChapterhouse(G,o){reseed(7811+(o.v|0));
 const och=vC(vPick([0xc89a62,0xbc8e58,0xd4a66e])),och2=och.clone().multiplyScalar(.9),dk=vC(0x8a6a48),lat=vC(vPick([0xb4683e,0xa85c36,0xc07448])),lat2=lat.clone().multiplyScalar(.8),tile=vC(vPick([0xb8633a,0xa85832,0xc47044])),pave=vC(0xd8cdb4),plank=vC(0x8a6c48),white=vC(0xf2eee2);
 const lit=vLit();const Y0=.45;
 vnReg('Chapterhouse of the Order of Historians',0,0,24.5,21,{role:'chapterhouse'});
 // plinth: a low battered banco platform the whole compound stands on, with a mosaic dado along its front
 kput('vpBanco7',[0,0,0],null,[36,Y0,30],dk);
 for(let k=0;k<12;k++){const x=-13.2+k*2.4;if(Math.abs(x)<3.6)continue;vB('vpMosaicB',x,.06,14.85,2.3,.32,.16,0,null);}
 // ================================================================ the reading hall (back), battered block with parapet, pilasters, toron, mosaic string course
 const HW=22,HD=11,HH=8.6,hz=-8.5;
 kput('vpBanco7',[0,Y0,hz],null,[HW,HH,HD],och);
 {const tw=vpBat7(HW,HH,HH)*2,td=vpBat7(HD,HH,HH)*2;vB('vpBancoB',0,Y0+HH-.05,hz,tw+.3,.5,td+.3,0,dk);                     // dark eaves band
  vB('vpBancoB',0,Y0+HH+.45,hz,tw+.1,.9,.6,0,och);vB('vpBancoB',0,Y0+HH+.45,hz-td/2+.3,tw+.1,.9,.6,0,och);              // parapet: front + back
  for(const s of[-1,1])vB('vpBancoB',s*(tw/2-.25),Y0+HH+.45,hz,.6,.9,td-.4,0,och);vB('vpBancoB',0,Y0+HH+.45,hz+td/2-.3,tw+.1,.9,.6,0,och);
  vB('vpBancoB',0,Y0+HH+.45,hz,tw-1.4,.12,td-1.4,0,vC(0xb89a6e));                                                             // roof deck
  for(let vx=0;vx<5;vx++)for(let vz=0;vz<2;vz++)vBall('vLeaf',-8+vx*4,Y0+HH+.95,hz-3+vz*6,.42,vC((vx+vz)%2?0xb8633a:0x98764e),.5);   // pots along the roof terrace
  // mosaic string course below the eaves and a whitewash band at the floor line: the Order's blue-and-white
  const my=Y0+HH-1.6,mw=vpBat7(HW,HH,HH-1.6)*2,md=vpBat7(HD,HH,HH-1.6)*2;vB('vpMosaicB',0,my,hz+md/2-.1,mw+.2,.5,.3,0,null);vB('vpMosaicB',0,my,hz-md/2+.1,mw+.2,.5,.3,0,null);
  for(const s of[-1,1])vB('vpMosaicB',s*(mw/2-.1),my,hz,.3,.5,md+.2,0,null);
  vB('vpBancoB',0,Y0+.02,hz,HW+.3,.9,HD+.3,0,white);}
 // pilaster-buttresses with pinnacles: 7 across the front (the middle three frame the porch), 7 behind, 3 each side, corners heavier
 {const zf=hz+HD/2,zb=hz-HD/2;for(let i=0;i<=6;i++){const x=-HW/2+HW*i/6,k=(i===0||i===6)?1.5:1.15;if(Math.abs(x)<4)continue;vpPinnacle(x,Y0,zf+.35,k,HH+1.4,och2);vpPinnacle(x,Y0,zb-.35,k,HH+1.4,och2);}
  for(let j=1;j<3;j++){const z=zb+HD*j/3;vpPinnacle(-HW/2-.35,Y0,z,1.15,HH+1.4,och2);vpPinnacle(HW/2+.35,Y0,z,1.15,HH+1.4,och2);}
  // toron rows between the pilasters, two heights, all four faces (the face recedes with height)
  for(const yy of[4.9,7.9]){const zf2=hz+vpBat7(HD,HH,yy),zb2=hz-vpBat7(HD,HH,yy),xw=vpBat7(HW,HH,yy);
   for(let i=0;i<6;i++){const x0=-HW/2+HW*i/6+.9,x1=-HW/2+HW*(i+1)/6-.9;if(Math.abs((x0+x1)/2)<4&&yy<6)continue;vpTorons(x0,zf2,x1,zf2,Y0+yy,3,0,1);vpTorons(x0,zb2,x1,zb2,Y0+yy,3,0,-1);}
   for(let j=0;j<3;j++){const z0=zb2+HD*j/3+.7,z1=zb2+HD*(j+1)/3-.7;vpTorons(xw,z0,xw,z1,Y0+yy,3,1,0);vpTorons(-xw,z0,-xw,z1,Y0+yy,3,-1,0);}}
  // the porch: three nested parabolic archivolts (banco · mosaic · banco) stepping in to the doors, between the two middle pilasters
  const pz=zf+vpBat7(HD,HH,0)-HD/2;   // = face at the base
  kput('vpBayArchB',[0,Y0,pz+1.9],null,[1.7,1.6,2.0],och2);kput('vpBayArchM',[0,Y0,pz+1.15],null,[1.45,1.42,1.2],null);kput('vpBayArchB',[0,Y0,pz+.45],null,[1.25,1.27,.9],och);
  vB('vpBancoB',0,Y0+6.4,pz+1.1,6.0,.5,2.8,0,dk);vB('vpBancoB',0,Y0+6.9,pz+1.1,5.4,.6,2.2,0,och2);vpRoundWin(0,Y0+7.5,pz+2.52,0,.5,och2,lit);
  for(const s of[-1,1])vpPinnacle(s*3.1,Y0,pz+2.6,1.1,7.3,och2);
  vB('vDarkB',0,Y0,pz-.3,2.9,3.9,.8,0);for(const s of[-1,1])kput('vWood',[s*.72,Y0+1.95,pz-.1],vQ(0,0,0).multiply(qEuler(0,s*.25,0)),[1.4,3.8,.08],plank);
  for(let i=0;i<3;i++)for(let j=0;j<5;j++)for(const s of[-1,1])vB('vIron',s*(.3+i*.42),Y0+.5+j*.75,pz+.02,.09,.09,.08,0,vC(0xb08a3a));   // brass studs
  vB('vpBancoB',0,Y0,pz+2.9,5.6,.14,1.4,0,dk);   // threshold slab
  if(lit){vnLamp(-2.5,Y0+4.4,pz+2.9,0);vnLamp(2.5,Y0+4.4,pz+2.9,0);}
  // windows: tall paired reading-hall windows either side of the porch, round windows above; sides and back likewise
  for(const s of[-1,1])for(const x of[5.4,9.2]){vpYWin(s*x,Y0+1.6,hz+vpBat7(HD,HH,1.6),0,1.0,2.6,och2,lit);vpRoundWin(s*x,Y0+6.2,hz+vpBat7(HD,HH,6.2),0,.5,och2,lit);}
  for(const s of[-1,1])for(const z of[-2.6,0,2.6]){vpYWin(s*vpBat7(HW,HH,1.6),Y0+1.6,hz+z,s*Math.PI/2,1.0,2.4,och2,lit);vpRoundWin(s*vpBat7(HW,HH,5.6),Y0+5.6,hz+z,s*Math.PI/2,.45,och2,lit);}
  for(const x of[-8,-4,0,4,8])vpYWin(x,Y0+1.8,hz-vpBat7(HD,HH,1.8),Math.PI,1.0,2.2,och2,false);for(const x of[-6,0,6])vpRoundWin(x,Y0+5.8,hz-vpBat7(HD,HH,5.8),Math.PI,.5,och2,lit);}
 // the great drum over the hall: laterite, round windows, tile cone, lantern
 {const top=vpDrumHall(0,Y0+HH+.5,hz,4.8,3.6,lat,dk,tile);
  for(let k=0;k<6;k++){const a=k/6*TAU+Math.PI/6;vpRoundWin(Math.sin(a)*4.8,Y0+HH+2.3,hz+Math.cos(a)*4.8,a,.5,lat2,lit);}
  for(let k=0;k<12;k++){const a=k/12*TAU;vBeam([Math.sin(a)*4.6,Y0+HH+3.0,hz+Math.cos(a)*4.6],[Math.sin(a)*5.5,Y0+HH+2.95,hz+Math.cos(a)*5.5],.16,vC(0x4a3624));}   // toron ring under the eaves
  void top;}
 // stair up to the roof terrace on the right flank, as a Yuni roof is living space
 {const sx=HW/2+1.2;for(let i=0;i<12;i++)vB('vpBancoB',sx,Y0+i*.7,hz+4.2-i*.72,1.3,.7,.75,0,och2);vB('vpBancoB',sx+.75,Y0,hz+.2,.25,HH+.9,9.0,0,och2);}
 // ================================================================ the wings: archive stacks (left), scriptorium (right) — battered ranges with parabolic arcades to the court
 for(const s of[-1,1]){const wx=s*15.3,WW=5.2,WD=11,wz=1.5,WH=4.6;kput('vpBanco7',[wx,Y0,wz],null,[WW,WH,WD],och);
  const tw=vpBat7(WW,WH,WH)*2,td=vpBat7(WD,WH,WH)*2;vB('vpBancoB',wx,Y0+WH-.05,wz,tw+.25,.4,td+.25,0,dk);vB('vpBancoB',wx,Y0+WH+.35,wz,tw,.6,td,0,och);vB('vpBancoB',wx,Y0+WH+.35,wz,tw-1.0,.7,td-1.0,0,vC(0xb89a6e));
  for(let j=0;j<=3;j++)vpPinnacle(wx+s*(WW/2+.3),Y0,wz-WD/2+WD*j/3,.95,WH+1.1,och2);
  for(const yy of[3.5]){const xo=wx+s*vpBat7(WW,WH,yy);for(let j=0;j<3;j++)vpTorons(xo,wz-WD/2+WD*j/3+.6,xo,wz-WD/2+WD*(j+1)/3-.6,Y0+yy,3,s,0);}
  for(const z of[-3.5,0,3.5])vpYWin(wx+s*vpBat7(WW,WH,2.0),Y0+1.3,wz+z,s*Math.PI/2,.8,1.5,och2,lit);   // outer face: small windows
  vB('vpMosaicB',wx+s*(vpBat7(WW,WH,WH-.3)),Y0+WH-.5,wz,.26,.4,td-.6,0,null);
  // arcade: 3 parabolic bays on the court side carrying a flat roof back to the wing; lit doors behind
  const ax=wx-s*(WW/2+1.6);for(let j=0;j<3;j++){const z=wz-WD/2+WD*(j+.5)/3;kput('vpBayArchB',[ax,Y0,z],qEuler(0,s*Math.PI/2,0),[WD/3/3.2*1.02,1.0,1.0],och2);
   const bx=wx-s*vpBat7(WW,WH,1.2);if(j===1){vB('vDarkB',bx,Y0,z,.3,2.5,1.6,0);kput('vWood',[bx+s*.02,Y0+1.25,z],qEuler(0,Math.PI/2,0),[1.5,2.4,.08],plank);if(lit)vnLamp(bx,Y0+3.0,z,-s*Math.PI/2);}
   else vpYWin(bx,Y0+1.5,z,-s*Math.PI/2,1.0,1.6,och2,lit);}
  vB('vpBancoB',(ax+wx)/2,Y0+4.0,wz,Math.abs(wx-ax)+.6,.45,WD+.2,0,och2);vB('vpBancoB',(ax+wx)/2,Y0+4.45,wz,Math.abs(wx-ax)+.2,.35,WD-.2,0,dk);
  for(let j=0;j<=3;j++)vpTorons(ax-s*.2,wz-WD/2+WD*j/3,ax-s*.2,wz-WD/2+WD*j/3,Y0+3.5,1,-s,0,.7);
  // drum pavilion at the wing's front end (the chapter house's paired drums flank the gate)
  const dz=wz+WD/2+3.0,dx=s*14.6;vpDrumHall(dx,Y0,dz,3.1,6.4,lat,dk,tile);
  for(const a of[0.55,1.2].map(v=>s<0?Math.PI-v:v))vpRoundWin(dx+Math.cos(a)*3.1,Y0+4.4,dz+Math.sin(a)*3.1,Math.PI/2-a,.55,lat2,lit);
  {const a=s<0?-.4:Math.PI+.4;vB('vDarkB',dx+Math.cos(a)*3.05,Y0,dz+Math.sin(a)*3.05,1.3,2.3,.3,Math.PI/2-a);kput('vWood',[dx+Math.cos(a)*2.98,Y0+1.15,dz+Math.sin(a)*2.98],qEuler(0,Math.PI/2-a,0),[1.2,2.2,.08],plank);}
  for(let k=0;k<10;k++){const a=k/10*TAU+.15;vBeam([dx+Math.cos(a)*2.95,Y0+2.6,dz+Math.sin(a)*2.95],[dx+Math.cos(a)*3.85,Y0+2.55,dz+Math.sin(a)*3.85],.15,vC(0x4a3624));}}
 // ================================================================ the forecourt wall and the gate
 {const gz=13.4,GW=7.0;for(const s of[-1,1]){const x0=s*(GW/2+.2),x1=s*11.4,L=Math.abs(x1-x0),cx=(x0+x1)/2;vB('vpBancoB',cx,Y0,gz,L,3.4,.7,0,och);vB('vpBancoB',cx,Y0+3.3,gz,L+.2,.35,.95,0,dk);
   // carved glyph panels with mosaic diamonds along the wall, as the source's forecourt wall carries
   for(let g=0;g<3;g++){const x=x0+(x1-x0)*(g+.5)/3;vB('vpBancoB',x,Y0+.5,gz+.4,1.9,2.3,.16,0,och2);kput('vpMosaicB',[x,Y0+1.65,gz+.52],vQ(0,0,Math.PI/4),[.9,.9,.1],null);vB('vpBancoB',x,Y0+.5,gz-.4,1.9,2.3,.16,0,och2);}}
  // gate: a parabolic arch slab between two pylons with pinnacles, a relief band and a round window above the arch; lamps
  kput('vpGateArchB',[0,Y0,gz],null,[1,1,1],och2);vB('vpBancoB',0,Y0+6.5,gz,7.4,.4,2.0,0,dk);vB('vpBancoB',0,Y0+6.9,gz,6.6,.7,1.6,0,och);
  kput('vpArchRingM',[0,Y0,gz+.95],null,[1,1,1],null);kput('vpArchRingB',[0,Y0,gz-.9],null,[1,1,1],dk);   // archivolts: mosaic to the street, dark banco to the court
  for(const s of[-1,1]){vpPinnacle(s*4.1,Y0,gz,1.7,7.6,och2);if(lit){vnLamp(s*2.6,Y0+4.2,gz+.8,0);}}
  for(let k=0;k<3;k++)vB('vpBancoB',0,Y0-(k+1)*.15,gz+1.2+k*.5,6.4-k*.4,.15,.6,0,dk);   // steps down to the street
  for(const s of[-1,1])vnLampPost(s*5.6,0,gz+2.4,3.6);
  vpHang(-4.1,Y0+6.2,gz+.92,0,1.1,2.6,vC(0x2a6ab0));vpHang(4.1,Y0+6.2,gz+.92,0,1.1,2.6,vC(0xffffff,1.6));}   // the Order's blue and white on the pylons
 // ================================================================ the court: paving, reflecting pool, a gnomon, planters, lamps, a bench, folk
 vnPaving(0,Y0+.02,4,20,16,0,pave,40);vB('vFlag',0,Y0+.03,6.5,3.6,.1,13,0,pave.clone().multiplyScalar(.92));
 {const px=-6,pz=5;vB('vpBancoB',px,Y0,pz,5.2,.55,5.2,0,lat);vB('vpBancoB',px,Y0+.55,pz,5.6,.15,5.6,0,dk);vB('vpMosaicB',px,Y0+.2,pz,4.4,.4,4.4,0,null);
  mesh(new THREE.BoxGeometry(4.3,.06,4.3),MAT.glass,G,px,Y0+.62,pz);}
 {const gx=6.5,gz2=5.5;vB('vpBancoB',gx,Y0,gz2,2.6,.5,2.6,0,och2);vB('vpBancoB',gx,Y0+.5,gz2,2.0,.4,2.0,0,dk);vBeam([gx,Y0+.9,gz2],[gx+1.1,Y0+3.6,gz2-.3],.1,vC(0xb08a3a),'vIron');
  for(let k=0;k<7;k++)vB('vpMosaicB',gx-1.2+k*.4,Y0+.5,gz2+1.3,.3,.06,.3,0,null);}
 for(const x of[-9,9]){vB('vpBancoB',x,Y0,10.5,2.6,.6,1.2,0,lat);for(let k=0;k<3;k++)kput('vLeaf',[x+rr(-.8,.8),Y0+.75,10.5+rr(-.3,.3)],null,[rr(.3,.5),rr(.3,.45),rr(.3,.5)],vC(vPick([0x5e7444,0x6a7e4c,0x7a8a58])));}
 for(const x of[-4,4])vB('vpBancoB',x,Y0,-1.6,3.0,.5,.8,0,och2);   // benches before the porch
 for(const s of[-1,1])vnLampPost(s*8.5,Y0,1,3.4);
 // ================================================================ the bell tower: Sankore-type pyramid bristling with toron, a second stage, cone and gilt ball, the bell in an opening
 {const tx=-15.2,tz=-11.2,TW=5.6,TH=13.5;kput('vpBanco5',[tx,Y0,tz],null,[TW,TH,TW],och);const hw=y=>TW/2*(1-.45*y/TH);
  kput('vpBanco5',[tx,Y0+TH,tz],null,[TW*.55,4.4,TW*.55],och2);const hw2=y=>TW*.55/2*(1-.45*y/4.4);
  kput('vpBancoCone',[tx,Y0+TH+4.3,tz],null,[.95,2.2,.95],och2);vBall('vpGilt',tx,Y0+TH+6.7,tz,.3);
  for(const q of[[-1,-1],[1,-1],[-1,1],[1,1]])kput('vpBancoCone',[tx+q[0]*(TW*.55/2+.35),Y0+TH-.1,tz+q[1]*(TW*.55/2+.35)],null,[.3,.9,.3],och2);
  for(let r=0;r<7;r++){const y=2.6+r*1.6,h=hw(y),n=Math.max(1,Math.floor(2*h/1.25));for(let i=0;i<n;i++){const o=(i-(n-1)/2)*1.15+((r%2)?.25:0)*(n>1?1:0);
   const c=vC(0x4a3624);vBeam([tx+o,Y0+y,tz+h-.3],[tx+o,Y0+y-.05,tz+h+.85],.16,c);vBeam([tx+o,Y0+y,tz-h+.3],[tx+o,Y0+y-.05,tz-h-.85],.16,c);vBeam([tx+h-.3,Y0+y,tz+o],[tx+h+.85,Y0+y-.05,tz+o],.16,c);vBeam([tx-h+.3,Y0+y,tz+o],[tx-h-.85,Y0+y-.05,tz+o],.16,c);}}
  for(let r=0;r<2;r++){const y=TH+1.2+r*1.5,h=hw2(y-TH);for(const nn of[[0,1],[0,-1],[1,0],[-1,0]])vBeam([tx+nn[0]*(h-.3),Y0+y,tz+nn[1]*(h-.3)],[tx+nn[0]*(h+.75),Y0+y-.05,tz+nn[1]*(h+.75)],.14,vC(0x4a3624));}
  // bell opening on the front face of the upper stage, with the bell
  {const y=TH+1.6,h=hw2(y-TH);vB('vDarkB',tx,Y0+y,tz+h-.2,1.1,1.5,.5,0);kput('vpBrassBell',[tx,Y0+y+.95,tz+h-.1],null,[.4,.5,.4],null);vB('vIron',tx,Y0+y+1.36,tz+h-.1,1.2,.08,.08,0,vC(0x3a2f22));}
  vB('vDarkB',tx,Y0+7.6,tz+hw(7.6)-.15,.5,1.1,.4,0);vB('vDarkB',tx+hw(4.5)-.15,Y0+4.5,tz,.4,1.1,.5,0);
  vB('vDarkB',tx,Y0,tz+hw(0)-.3,1.2,2.2,.8,0);kput('vWood',[tx,Y0+1.1,tz+hw(0)+.1],null,[1.1,2.1,.08],plank);vB('vpBancoB',tx,Y0+2.2,tz+hw(0)+.1,1.9,.3,.5,0,dk);
  if(lit)vnLamp(tx+1.1,Y0+2.7,tz+hw(0)+.02,0);}
 // a low archive annex behind the hall on the right (the stacks overflow), flat-roofed with pinnacles and a hatch
 {const ax=15.6,az=-9,AW=5.2,AD=7.4,AH=3.4;kput('vpBanco7',[ax,Y0,az],null,[AW,AH,AD],och2);vB('vpBancoB',ax,Y0+AH-.05,az,AW*.94,.4,AD*.94,0,dk);vB('vpBancoB',ax,Y0+AH+.3,az,AW*.9,.5,AD*.9,0,och2);
  for(const s of[-1,1])vpPinnacle(ax+AW/2+.2,Y0,az+s*(AD/2-.2),.9,AH+1.0,och2);vpTorons(ax+vpBat7(AW,AH,2.4),az-3.0,ax+vpBat7(AW,AH,2.4),az+3.0,Y0+2.4,5,1,0,.8);
  for(const z of[-2.2,2.2])vpYWin(ax+vpBat7(AW,AH,1.6),Y0+1.6,az+z,Math.PI/2,.8,1.0,och2,false);vB('vDarkB',ax-vpBat7(AW,AH,1.1)+.1,Y0,az+2.6,.3,2.2,1.1,0);}
 vnFolk(0,7,4,3);vnFolk(0,17.5,3,2);}

VERN.def({key:'port_order_chapterhouse',name:'Order Chapterhouse',family:'ported',tags:{culture:'yuni-order',type:['civic','religious'],wealth:'civic',lit:true,role:'chapterhouse'},w:38,d:34,h:21,build:buildVpChapterhouse});
// ================================================================= IZIZ — ANCIENTS RECLAIMED: the two guilds
// Two Ancient buildings the later people have moved into and made their own. Each VERN builder wraps a vendored
// Ancients-kit builder at decay 3 (repaired) + repairPass(), then adds the guild's own vernacular accretion in the
// LOCAL frame (origin = the Ancient building's centre, +z = front, metres). Culture tag 'ancients-reclaimed'.
//   anc_salvagers_guild  — the Salvagers' Guild in the Laboratory ("the Reliquary", buildLab)   seed 7901
//   anc_mercenary_guild  — the Mercenary Guild in the Police station ("the Watch", buildPolice)  seed 7911
// Local helpers carry the vq prefix. Nothing here touches world coordinates: VERN.place owns the transform.
const VQ_IRON=0x2e2a26,VQ_PALISADE=0x7a5a3e;

// Run a kit builder inside a VERN builder: repaired state (HOLES .55), KOFF at the origin so the kit's kput and
// REGISTER land in the group frame (KXF carries the group transform), then the salvage dressing on the finished
// group, then the kit's REG volumes moved into world space + tagged. `stripFlora` drops the trees a d>0 kit
// builder scatters round itself (flora is never part of a building — the biome pass plants at placement time).
function vqWrapKit(G,builder,nameFn,stripFlora,mossR,holes){const c=VERN.cur,r0=c.r0;const nT=KIT.items.trunk.length,nL=KIT.items.leafCard.length,nM=KIT.items.moss.length;
 HOLES=holes==null?.55:holes;let H=null;try{H=withFlatGround(()=>builder(G,0,0,3));}finally{HOLES=1;KOFF=[0,0,0];}
 if(stripFlora){KIT.items.trunk.length=nT;KIT.items.leafCard.length=nL;}
 // the kit's ground-moss scatter runs far past the building (scatterMoss to r 120 on the lab): keep it within mossR of the plot
 if(mossR){const s=c.o.scale||1,R2=mossR*mossR*s*s,M=KIT.items.moss;let w=nM;for(let i=nM;i<M.length;i++){const dx=M[i].p[0]-c.x,dz=M[i].p[2]-c.z;if(dx*dx+dz*dz<=R2)M[w++]=M[i];}M.length=w;}
 if(H)repairPass(H,3);
 vnAdoptREG(r0,nameFn);return H;}

// Palisade along explicit local segments [[x0,z0],[x1,z1]] — the yards here lean on the Ancient fabric for one side.
function vqPalisade(segs,y,h){const c=vC(VQ_PALISADE);for(const s of segs){const L=Math.hypot(s[1][0]-s[0][0],s[1][1]-s[0][1]);const n=Math.max(1,Math.round(L/.42));
 for(let i=0;i<=n;i++){const x=s[0][0]+(s[1][0]-s[0][0])*i/n,z=s[0][1]+(s[1][1]-s[0][1])*i/n;vPst('vPostB',x,y-.2,z,.2,h+rr(-.25,.25),c.clone().multiplyScalar(rr(.85,1.1)));kput('vConeI',[x,y+h-.15,z],null,[.2,.5,.2],c);}
 vBeam([s[0][0],y+h*.55,s[0][1]],[s[1][0],y+h*.55,s[1][1]],.14,c);}}
// Yard gate in a palisade line: two heavy posts, a lintel with a sign, leaves swung wide open INTO the yard (-z), lamps if lit.
function vqGate(x,y,z,ry,w,h,c){for(const s of[-1,1]){const p=loc(x,z,s*(w/2+.35),0,ry);vPst('vPostB',p[0],y-.2,p[1],.3,h+1.1,c);kput('vConeI',[p[0],y+h+.85,p[1]],null,[.3,.6,.3],c);}
 vB('vWood',x,y+h+.45,z,w+1.6,.36,.42,ry,c);const sp=loc(x,z,0,.3,ry);kput('vWood',[sp[0],y+h-.1,sp[1]],vQ(ry,0,0),[w*.55,.8,.06],vC(vPick(VPAL.awning)));
 const a=1.15;for(const s of[-1,1]){const p=loc(x,z,s*(w/2-(w/4)*Math.cos(a)),-(w/4)*Math.sin(a),ry);kput('vWood',[p[0],y+(h-.3)/2+.05,p[1]],vQ(ry,0,0).multiply(qEuler(0,-s*a,0)),[w/2-.12,h-.3,.1],c.clone().multiplyScalar(.85));
  for(const yy of[.4,h-.7]){const b=loc(x,z,s*(w/2-(w/4)*Math.cos(a)),-(w/4)*Math.sin(a)-.07,ry);kput('vIron',[b[0],y+yy,b[1]],vQ(ry,0,0).multiply(qEuler(0,-s*a,0)),[w/2-.2,.1,.04],vC(VQ_IRON));}}
 if(vLit())for(const s of[-1,1]){const p=loc(x,z,s*(w/2+.35),.32,ry);vnLamp(p[0],y+h+.1,p[1],ry);}}
// A sorted scrap heap with a low board rim: kind 0 rusted plates, 1 pipe offcuts, 2 ghost-white panel offcuts (the smithy idiom).
function vqHeap(x,y,z,r,n,kind){const c=vC(vPick(VPAL.woodPoor));for(let k=0;k<4;k++){const a=k*Math.PI/2;vB('vWood',x+Math.cos(a)*r,y,z+Math.sin(a)*r,.08,.55,r*2+.1,a,c);}
 for(let i=0;i<n;i++){const a=rng()*TAU,rad=Math.sqrt(rng())*(r-.4);const px=x+Math.cos(a)*rad,pz=z+Math.sin(a)*rad;const hgt=y+Math.pow(1-rad/r,1.4)*r*.55*rng()+.05;
  if(kind===0)kput('vRustB',[px,hgt,pz],qEuler(rr(-.5,.5),rng()*TAU,rr(-.5,.5)),[rr(.5,1.4),rr(.03,.08),rr(.4,1.1)],null);
  else if(kind===1)kput('vPipeR',[px,hgt,pz],qEuler(Math.PI/2,rr(-.25,.25),rr(-.3,.3)),[rr(.05,.14),rr(.8,2.4),rr(.05,.14)],null);
  else kput('vPanelB',[px,hgt,pz],qEuler(rr(-.4,.4),rng()*TAU,rr(-.4,.4)),[rr(.6,1.4),.06,rr(.6,1.3)],null);}}
// A-frame of reclaimed pipe: legs spread along the frame's own z, meeting at (x,y+h,z).
function vqAFrame(x,y,z,ry,h,spread){const t=Math.atan2(spread,h),L=Math.hypot(spread,h)+.2;for(const s of[-1,1]){const p=loc(x,z,0,s*spread,ry);vPst('vPipeR',p[0],y,p[1],.13,L,null,vQ(ry,-s*t,0));}
 vB('vIron',x,y+h-.1,z,.5,.3,.3,ry,vC(VQ_IRON));}
// Beam balance for weighing scrap: post, cross beam, two pans on ropes, weights on one and a plate on the other.
function vqScales(x,y,z,ry){const iron=vC(VQ_IRON);vPst('vPipe',x,y,z,.09,2.6,iron);vB('vIron',x,y-.05,z,.9,.12,.9,ry,iron);vB('vIron',x,y+2.5,z,3.0,.1,.1,ry,iron);
 for(const s of[-1,1]){const p=loc(x,z,s*1.35,0,ry);vPst('vRope',p[0],y+1.2,p[1],.025,1.3,vC(0xa89878));vB('vIron',p[0],y+1.1,p[1],.95,.06,.95,ry,iron);
  if(s<0){for(let k=0;k<3;k++)vB('vIron',p[0]+rr(-.2,.2),y+1.16,p[1]+rr(-.2,.2),.22,.22,.22,rng(),iron);}else kput('vRustB',[p[0],y+1.24,p[1]],qEuler(0,rr(0,TAU),.05),[.8,.06,.6],null);}}
// Hand cart: plank bed on two hoop wheels, an axle, two shafts resting on the ground. `load` 0 empty, 1 plates, 2 crates.
function vqCart(x,y,z,ry,c,load){const iron=vC(VQ_IRON);vB('vWood',x,y+.72,z,2.3,.14,1.4,ry,c);
 for(const s of[-1,1]){const p=loc(x,z,0,s*.68,ry);vB('vWood',p[0],y+.86,p[1],2.3,.42,.06,ry,c);const q=loc(x,z,s*1.12,0,ry);vB('vWood',q[0],y+.86,q[1],.06,.42,1.4,ry,c);}
 for(const s of[-1,1]){const p=loc(x,z,.2,s*.8,ry);vBq('vHoop',p[0],y+.6,p[1],.58,.58,1,vQ(ry,0,0),iron);vB('vIron',p[0],y+.52,p[1],.16,.16,.1,ry,iron);}
 {const ax=loc(x,z,.2,-.85,ry);kput('vPipe',[ax[0],y+.6,ax[1]],vQ(ry,Math.PI/2,0),[.05,1.7,.05],iron);}   // axle: VPOST is base-at-0, so pivot at one wheel
 for(const s of[-1,1]){const a=loc(x,z,-1.15,s*.5,ry),b=loc(x,z,-2.6,s*.5,ry);vBeam([a[0],y+.75,a[1]],[b[0],y+.05,b[1]],.07,c);}
 if(load===1)for(let k=0;k<5;k++)kput('vRustB',[x+rr(-.3,.3),y+.85+k*.07,z+rr(-.2,.2)],qEuler(0,ry+rr(-.2,.2),0),[1.6,.05,1.0],null);
 else if(load===2){vnCrate(x,y+.8,z,.8,ry,c);const p=loc(x,z,.6,.3,ry);kput('vSack',[p[0],y+1.0,p[1]],qEuler(0,ry,0),[.4,.3,.34],vC(0xb8a080));}}
// Ridge tent: two poles and a ridge, two canted canvas slabs, guy ropes, a bedroll crate at the open end (+z of the tent).
function vqTent(x,y,z,ry,w,d,h,item,c){const wood=vC(vPick(VPAL.woodPoor));for(const s of[-1,1]){const p=loc(x,z,s*w/2,0,ry);vPst('vPost',p[0],y,p[1],.06,h,wood);}
 vB('vWood',x,y+h-.04,z,w+.3,.08,.08,ry,wood);const a=Math.atan2(h,d/2),L=Math.hypot(h,d/2)+.25;
 for(const s of[-1,1]){const p=loc(x,z,0,s*d/4,ry);kput(item,[p[0],y+h/2+.03,p[1]],vQ(ry,s*a,0),[w+.35,.06,L],c);
  for(const t of[-1,1]){const g0=loc(x,z,t*w/2,0,ry),g1=loc(x,z,t*(w/2+.9),s*(d/2+.9),ry);vBeam([g0[0],y+h-.1,g0[1]],[g1[0],y+.02,g1[1]],.025,vC(0xa89878),'vRope');}}
 const b=loc(x,z,w/2+.9,0,ry);vnCrate(b[0],y,b[1],.6,ry,wood);}
// Drill kit: a pell (post with a crossbar), an archery butt, a weapon rack of spears and blades against a rail.
function vqPell(x,y,z){const c=vC(0x6a5a48);vPst('vPostB',x,y,z,.16,2.0,c);vB('vWood',x,y+1.5,z,.9,.12,.12,0,c);vB('vWood',x,y+.6,z,.5,.5,.5,0,c);}
function vqButt(x,y,z,ry){vPst('vStave',x,y,z,.7,1.4,vC(0xc8a870));const p=loc(x,z,0,.72,ry);vBq('vHoop',p[0],y+.9,p[1],.4,.4,1,vQ(ry,0,0),vC(0xc9442a));vBq('vHoop',p[0],y+.9,p[1],.2,.2,1,vQ(ry,0,0),vC(0xe0a030));}
function vqRack(x,y,z,ry,n){const wood=vC(vPick(VPAL.woodMid)),iron=vC(VQ_IRON);const L=n*.5+.6;for(const s of[-1,1]){const p=loc(x,z,s*L/2,0,ry);vPst('vPost',p[0],y,p[1],.08,1.5,wood);}
 vB('vWood',x,y+1.35,z,L,.12,.14,ry,wood);vB('vWood',x,y+.2,z,L,.1,.5,ry,wood);
 for(let k=0;k<n;k++){const p=loc(x,z,-L/2+.5+k*.5,.28,ry);if(k%3===2)kput('vIron',[p[0],y+.75,p[1]],vQ(ry,.14,0),[.08,1.3,.03],iron);
  else{kput('vWood',[p[0],y+1.5,p[1]],vQ(ry,.15,0),[.05,3.0,.05],vC(0x5a4632));const t=loc(x,z,-L/2+.5+k*.5,.28-.22,ry);kput('vIron',[t[0],y+2.95,t[1]],vQ(ry,.15,0),[.06,.45,.02],iron);}}}
// Hitching rail and a water trough.
function vqHitch(x,y,z,ry,L){const c=vC(vPick(VPAL.woodMid));const n=Math.max(1,Math.round(L/2.5));for(let i=0;i<=n;i++){const p=loc(x,z,-L/2+L*i/n,0,ry);vPst('vPostB',p[0],y,p[1],.1,1.15,c);}vB('vWood',x,y+1.05,z,L+.2,.12,.12,ry,c);}
function vqTrough(x,y,z,ry){const c=vC(vPick(VPAL.woodPoor));vB('vWood',x,y,z,2.4,.62,.8,ry,c);vB('vDarkB',x,y+.5,z,2.2,.1,.6,ry);for(const s of[-1,1]){const p=loc(x,z,s*1.1,0,ry);vB('vIron',p[0],y+.1,p[1],.08,.5,.86,ry,vC(VQ_IRON));}}
// Trophy banners hung from a rope between two tall poles: orange and red cloth, a few torn short.
function vqBannerLine(x0,z0,x1,z1,y,h,n){const wood=vC(0x5a4632);for(const p of[[x0,z0],[x1,z1]]){vPst('vPost',p[0],y,p[1],.1,h,wood);vBall('vBall',p[0],y+h+.1,p[1],.14,vC(VQ_IRON));}
 vBeam([x0,y+h-.15,z0],[x1,y+h-.15,z1],.03,vC(0xa89878),'vRope');const ry=Math.atan2(x1-x0,z1-z0)+Math.PI/2;
 for(let k=0;k<n;k++){const t=(k+.5)/n;const px=x0+(x1-x0)*t,pz=z0+(z1-z0)*t;const bh=rr(1.6,2.6);kput('vCloth',[px,y+h-.2-bh/2,pz],vQ(ry,0,rr(-.05,.05)),[rr(.8,1.2),bh,1],vC(vPick([0xe07a2a,0xc9442a,0xe07a2a,0xb8552a,0xd8893c])));}}

// ---------------------------------------------------------------- THE SALVAGERS' GUILD — the Reliquary
// The lab tower at repaired decay, its colonnade and reactor hut; the guild's salvage yard in front of the arcade,
// beyond the apron's toe (z 46..74, 60 m wide): sorted scrap heaps, gantry, scales, sorting shed on pipe posts,
// carts, guild banners, palisade with a gate to the street, electric lamp posts (civic).
function buildAncSalvagers(G,o){reseed(7901+(o.v|0));
 const LG=vqWrapKit(G,buildLab,n=>"Salvagers' Guild — "+n,true,62,0);   // rust-skinned but whole (Travis): the guild keeps its Reliquary in one piece
 // the DOME, repaired (Travis): the kit's repaired lab still breaks its lattice dome open (its collapse field ignores HOLES).
 // Find the shell (r 17, 22 high) and its dark liner, drop both, and put back the whole ribbed dome in rust with its
 // panels glazed again — a guild that salvages Ancient glass has re-glazed its own roof.
 if(LG){let dome=null;const dead=[];LG.traverse(m=>{if(!m.isMesh)return;m.geometry.computeBoundingBox();const b=m.geometry.boundingBox;const w=b.max.x-b.min.x,h=b.max.y-b.min.y;
   if(Math.abs(h-22)<1.5&&w>28&&w<36&&Math.abs(b.min.y)<.5){dead.push(m);if(!dome||w>dome.w)dome={w,m,y:m.position.y,x:m.position.x,z:m.position.z,parent:m.parent};}});
  if(dome){for(const m of dead)m.parent.remove(m);const R=17,Hd=22,dR=y=>R*Math.pow(clamp(1-Math.pow(y/Hd,2),0,1),.62);
   mesh(lathe({rFn:dR,H:Hd,flutes:24,amp:.07,sharp:2,nu:120,nv:36,hole:(u,y)=>Math.cos(u*TAU*24)<.35&&y<Hd*.82&&y>1.5}),MAT.rust,dome.parent,dome.x,dome.y,dome.z);
   mesh(lathe({rFn:y=>dR(y)*.94,H:Hd,nu:64,nv:24}),MAT.tGlassO||MAT.darkGlass,dome.parent,dome.x,dome.y,dome.z);}}
 reseed(7901+(o.v|0));   // the accretion runs on its own stream, so a kit change cannot move the yard about
 const wood=vC(vPick(VPAL.woodPoor)),iron=vC(VQ_IRON),org=vC(0xe07a2a);
 const YZ=60,YW=60,YD=28,YB=.2;   // yard centre z, width, depth, base height (a slab buries the apron's toe)
 vnReg("Salvagers' Guild — salvage yard",0,YZ,33,10);vnReg("Salvagers' Guild — colonnade to the reactor hut",62,0,30,9);vnReg("Salvagers' Guild — fallen spire",46,-40,14,7);
 vB('vStone',0,-.12,YZ,YW+2,YB+.12,YD+2,0,vC(0x7a7068));vnPaving(0,YB+.02,YZ,YW-4,YD-4,0,vC(0x6a625a),70);
 // palisade: sides, front with the gate, short returns toward the lab leaving the arcade approach open
 const z0=YZ-YD/2,z1=YZ+YD/2,hx=YW/2;
 vqPalisade([[[-hx,z0],[-hx,z1]],[[hx,z1],[hx,z0]],[[-hx,z1],[-4,z1]],[[4,z1],[hx,z1]],[[-hx,z0],[-16,z0]],[[16,z0],[hx,z0]]],YB,3.6);
 vqGate(0,YB,z1,0,7,4.2,vC(VQ_PALISADE));vnSign(-3.9,YB+3.2,z1+.4,0,org);
 for(const s of[-1,1])vnBannerPole(s*6.5,YB,z1-1.2,0,7.5,org);
 // sorting shed on pipe posts in the west corner: corrugate shed roof, sorting benches and bins beneath
 {const sx=-18,sz=z0+5,SW=14,SD=7,SH=3.4;for(const px of[-SW/2+.3,0,SW/2-.3])for(const pz of[-SD/2+.3,SD/2-.3])vPst('vPipeR',sx+px,YB,sz+pz,.13,SH+(pz<0?1.0:0),null);
  vB('vIron',sx,YB+SH+.95,sz-SD/2+.3,SW+.6,.18,.18,0,iron);vB('vIron',sx,YB+SH-.05,sz+SD/2-.3,SW+.6,.18,.18,0,iron);
  vnShedRoof(sx,YB+SH,sz,SW,SD,1.0,0,'vCorr',null,.9,.12);
  vB('vRustB',sx,YB,sz-SD/2+.2,SW-.4,SH-.2,.14,0);vnPatch(sx,YB,sz-SD/2+.1,Math.PI,SW,SH-.2,4);   // back wall of plate, patched
  for(let k=0;k<3;k++){const bx=sx-SW/2+2.4+k*4.6;vB('vWood',bx,YB,sz+1.2,3.4,.85,1.0,0,wood);for(let j=0;j<4;j++)kput(['vRustB','vPanelB','vIron','vRustB'][j],[bx+rr(-1.3,1.3),YB+.9,sz+1.2+rr(-.3,.3)],qEuler(0,rng()*TAU,0),[rr(.4,.9),.05,rr(.3,.7)],null);}
  for(let k=0;k<4;k++){const bx=sx-SW/2+1.6+k*3.2,bz=sz-1.4;for(const s of[-1,1]){vB('vWood',bx+s*1.2,YB,bz,.06,1.1,2.0,0,wood);vB('vWood',bx,YB,bz+s*.97,2.4,1.1,.06,0,wood);}
   const kind=k%3;for(let j=0;j<9;j++){const px=bx+rr(-.9,.9),pz=bz+rr(-.7,.7),py=YB+.2+rr(0,.7);if(kind===0)kput('vRustB',[px,py,pz],qEuler(rr(-.6,.6),rng()*TAU,rr(-.6,.6)),[rr(.3,.7),.05,rr(.3,.7)],null);else if(kind===1)kput('vPipeR',[px,py,pz],qEuler(rr(-.4,.4),rng()*TAU,rr(1.2,1.9)),[rr(.04,.09),rr(.5,1.2),rr(.04,.09)],null);else kput('vPanelB',[px,py,pz],qEuler(rr(-.6,.6),rng()*TAU,rr(-.6,.6)),[rr(.3,.7),.05,rr(.3,.7)],null);}}
  vnBannerPole(sx+SW/2+1.2,YB,sz-SD/2,0,6.5,org);}
 // the sorted heaps: plates, pipe, ghost-white panels; a stack of whole panels leaning on the east palisade
 vqHeap(9,YB,z0+6,3.4,46,0);vqHeap(18,YB,z0+7,3.0,34,1);vqHeap(24,YB,YZ+3,3.0,38,2);
 for(let k=0;k<6;k++)kput('vPanelB',[hx-1.0-k*.16,YB+1.7,YZ+8+rr(-.15,.15)],qEuler(0,rr(-.04,.04),.22+k*.03),[.1,3.4,rr(1.6,2.6)],null);
 for(let k=0;k<5;k++)kput('vPipeR',[-hx+1.2+k*.28,YB+.1,YZ+3+rr(-.3,.3)],qEuler(Math.PI/2,rr(-.05,.05),0),[rr(.08,.16),rr(3,5.5),rr(.08,.16)],null);   // long pipe stock lying along the west palisade
 // gantry: two pipe A-frames, a beam between, rope and pulley with a plate on the hook
 vqAFrame(8,YB,YZ+5,0,7,2.2);vqAFrame(17,YB,YZ+5,0,7,2.2);kput('vPipeR',[17.4,YB+6.95,YZ+5],qEuler(0,0,Math.PI/2),[.14,9.8,.14],null);
 vB('vIron',12.5,YB+6.5,YZ+5,.34,.5,.24,0,iron);vPst('vRope',12.5,YB+2.9,YZ+5,.03,3.6,vC(0xa89878));vB('vIron',12.5,YB+2.6,YZ+5,.3,.35,.1,0,iron);
 kput('vRustB',[12.5,YB+1.9,YZ+5],qEuler(0,.3,.08),[2.4,1.5,.08],null);
 // scales by the gate where loads are weighed in; carts; a water butt; a lamp post at each corner and two by the gate
 vqScales(-9,YB,YZ+7,.2);vqCart(-22,YB,YZ+7,.35,wood,1);vqCart(20,YB,YZ+10,-.5,wood,0);vqCart(-6,YB,z0+4,1.4,wood,2);
 vnWaterButt(hx-1.6,YB,z0+2,.55,1.2);vnCrate(-hx+2,YB,YZ+11,1.0,.3,wood);vnSacks(-hx+3.5,YB,YZ+11,3);
 for(const p of[[-hx+1.6,z1-1.6],[hx-1.6,z1-1.6],[-hx+1.6,z0+1.6],[hx-1.6,z0+1.6],[-9,z1-1.2],[9,z1-1.2]])vnLampPost(p[0],YB,p[1],4.2);
 vnFolk(-2,YZ+2,8,9);vnFolk(0,z1+4,3,3);}

// ---------------------------------------------------------------- THE MERCENARY GUILD — the Watch
// The hex police block at repaired decay with its tower, vehicle wing and perimeter wall; the guild's muster yard in
// front of the wall (z 46..84, 92 m wide) closed by a palisade with a gate: rostrum with trophy banners, pells,
// archery butts, weapon racks, a tent row for the hired blades, hitching rail and troughs, lamp posts (civic).
// The kit's own wall gap is on the east (vehicle-bay) side, so the yard uses the kit's front wall + pylons as its
// back and the palisade meets the pylons at x = ±46. NB the kit's pad is a 160 m concrete DISC (slabCR r 80): the
// measured footprint is x ±80, z -80..90, and the def's w/d say so.
function buildAncMercenaries(G,o){reseed(7911+(o.v|0));
 vqWrapKit(G,buildPolice,n=>"Mercenary Guild — "+n,true,0);
 reseed(7911+(o.v|0));
 const wood=vC(vPick(VPAL.woodMid)),iron=vC(VQ_IRON),org=vC(0xe07a2a);
 // the kit's pad is a CYLINDER (slabCR, r 80, top at y .8), so the yard is a rectangular platform at the pad's height that
 // runs out past its round edge at the corners and the gate; steps take the gate down to the ground
 const YZ=65,YW=92,YD=38,YB=.85;const z0=YZ-YD/2,z1=YZ+YD/2,hx=YW/2;
 vnReg("Mercenary Guild — muster yard",0,YZ,48,10);
 vB('vStone',0,-.12,YZ,YW+2,YB+.12,YD+2,0,vC(0x8a8480));vnPaving(0,YB+.02,YZ+3,YW-8,YD-10,0,vC(0x6a625a),110);
 vnStairs(0,0,z1+2.0,0,7.5,YB,4,'vStone',vC(0x8a8480));
 vqPalisade([[[-hx,45.6],[-hx,z1]],[[hx,z1],[hx,45.6]],[[-hx,z1],[-4.5,z1]],[[4.5,z1],[hx,z1]]],YB,4.2);
 vqGate(0,YB,z1,0,8,4.6,vC(VQ_PALISADE));
 // gate towers: a timber platform on four posts either side with a corrugate cap, a watchman's rail, banners
 for(const s of[-1,1]){const gx=s*7.5;for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPostB',gx+sx*1.1,YB,z1-1.4+sz*1.1,.16,7.2,wood);
  vB('vWood',gx,YB+5.0,z1-1.4,2.8,.2,2.8,0,wood);for(let k=0;k<8;k++){const a=k/8*TAU;vPst('vPost',gx+Math.cos(a)*1.3,YB+5.2,z1-1.4+Math.sin(a)*1.3,.06,1.0,wood);}
  vnHipRoof('vHipC',gx,YB+7.2,z1-1.4,2.8,2.8,1.3,0,null,.6);vnLadder(gx+s*1.7,YB,z1-1.4,s*Math.PI/2,5.0,wood);vnBannerPole(s*12.5,YB,z1-1.2,0,8,org);}
 // rostrum against the Watch's wall: timber stage on posts, steps to the front, rail behind, orange canopy, trophy banners strung above
 {const rx=0,rz=z0+5.5,RW=8,RD=4.5,RH=1.3;for(let i=0;i<4;i++)for(const s of[-1,1])vPst('vPostB',rx-RW/2+.4+i*(RW-.8)/3,YB-.2,rz+s*(RD/2-.4),.14,RH+.2,wood);
  vB('vWood',rx,YB+RH-.2,rz,RW,.2,RD,0,wood);for(const s of[-1,1])vB('vWood',rx+s*(RW/2-.05),YB+RH-.9,rz,.1,.7,RD,0,wood);
  vnStairs(rx,YB,rz+RD/2+.7,0,2.4,RH,4,'vWood',wood);
  for(let k=0;k<7;k++)vB('vWood',rx-RW/2+.2+k*(RW-.4)/6,YB+RH,rz-RD/2+.15,.07,1.0,.07,0,wood);vB('vWood',rx,YB+RH+.95,rz-RD/2+.15,RW,.1,.1,0,wood);
  for(const sx of[-1,1])for(const sz of[-1,1])vPst('vPost',rx+sx*(RW/2-.3),YB+RH,rz+sz*(RD/2-.3),.09,3.4,wood);
  kput('vClothB',[rx,YB+RH+3.45,rz],vQ(0,.1,0),[RW+1.0,.06,RD+1.0],org);vB('vWood',rx+RW/2-1.2,YB+RH,rz+RD/2-1.0,1.0,1.1,.5,0,wood);   // canopy, lectern
  vqBannerLine(-15,z0+1.8,15,z0+1.8,YB,9.5,9);vnBannerPole(rx-RW/2-1.6,YB,rz,0,8.5,org);vnBannerPole(rx+RW/2+1.6,YB,rz,0,8.5,vC(0xc9442a));}
 // weapon racks flanking the rostrum, a spear-stack, crates of gear
 vqRack(-13,YB,z0+3.2,0,9);vqRack(13,YB,z0+3.2,0,9);vnCrate(-16,YB,z0+6,1.0,.2,wood);vnCrate(16.2,YB,z0+6.2,.9,-.3,wood);vnSacks(17.5,YB,z0+8,3);
 // tent row for the hired blades along the west palisade; a fire circle of stones between them
 for(let k=0;k<6;k++){const tz=z0+4.5+k*5.4;const canvas=k%3===1?['vClothB',vC(vPick(VPAL.awning))]:['vTarpB',vC(vPick([0xb8a080,0xa89070,0x9a8a70]))];vqTent(-hx+5.2,YB,tz,Math.PI/2,4.2,3.4,2.5,canvas[0],canvas[1]);}
 {const fx=-hx+11.5,fz=YZ+2;for(let k=0;k<9;k++){const a=k/9*TAU;kput('vRock',[fx+Math.cos(a)*1.1,YB+.12,fz+Math.sin(a)*1.1],qEuler(0,a,0),[.5,.3,.4],vC(0x7a7068));}for(let k=0;k<3;k++)vBall('vEmber',fx+rr(-.3,.3),YB+.16,fz+rr(-.3,.3),.16);
  for(const s of[-1,1])vB('vWood',fx+s*2.6,YB,fz,.5,.45,2.4,0,wood);}
 // drill ground: pells in a row, three archery butts against a board backstop on the east side
 for(let k=0;k<5;k++)vqPell(-22+k*4,YB,z1-8);
 {const bx=hx-6;for(let k=0;k<3;k++)vqButt(bx,YB,z0+8+k*6,-Math.PI/2);for(let k=0;k<5;k++)vB('vWood',hx-2.6,YB,z0+4+k*4.3,.12,2.4,4.2,0,wood);vB('vWood',hx-2.6,YB+2.3,z0+12.6,.16,.14,21.6,0,wood);
  for(let k=0;k<3;k++){vB('vWood',bx-1.4,YB,z0+8+k*6,.08,1.2,.08,0,wood);}}
 // hitching rail and troughs by the gate on the east, a water butt, lamp posts, folk
 vqHitch(hx-8,YB,z1-6,Math.PI/2,10);vqTrough(hx-11,YB,z1-3.2,Math.PI/2);vqTrough(hx-11,YB,z1-9,Math.PI/2);vnWaterButt(hx-2.2,YB,z1-2.2,.55,1.2);
 for(const p of[[-hx+1.8,z1-1.8],[hx-1.8,z1-1.8],[-hx+1.8,z0+1.8],[hx-1.8,z0+1.8],[-20,YZ],[20,YZ]])vnLampPost(p[0],YB,p[1],4.4);
 vnFolk(-4,YZ+4,10,11);vnFolk(4,z0+9,5,4);vnFolk(0,z1+5,3,3);}

const VTAG_ANC_GUILD={culture:'ancients-reclaimed',wealth:'civic',lit:true,role:'guild'};
VERN.def({key:'anc_salvagers_guild',name:"Salvagers' Guild (the Reliquary)",family:'ancients-reclaimed',tags:Object.assign({type:['civic','industry']},VTAG_ANC_GUILD),w:174,d:140,h:87,build:buildAncSalvagers});
VERN.def({key:'anc_mercenary_guild',name:'Mercenary Guild (the Watch)',family:'ancients-reclaimed',tags:Object.assign({type:['civic','military']},VTAG_ANC_GUILD),w:160,d:170,h:40,build:buildAncMercenaries});
// ================================================================= factory: great silo replaces the ring block
function factorySilo(G,d,skin){const ax=110,az=-60;REGISTER({name:'Factory — great silo',x:ax,z:az,r:45,h:150});
 const stem=y=>y<12?8+.03*Math.pow(12-y,2):(y<20?8+27*Math.pow((y-12)/8,1.6):35);
 mesh(lathe({rFn:stem,H:30,nu:64,nv:30,hole:holeFn(d*.6,80,null,1.5)}),skin,G,ax,6,az);if(d>0)mesh(lathe({rFn:y=>stem(y)*.92,H:30,nu:32,nv:6}),MAT.dark,G,ax,6,az);
 for(let k=0;k<28;k++){const th=k/28*TAU;if(d>0&&rng()<.4)continue;beam(d>0?'strutR':'strutW',[ax+Math.cos(th)*17,20,az+Math.sin(th)*17],[ax+Math.cos(th)*37,38,az+Math.sin(th)*37],2.2,1.8);
  const r=35.6;kput(d>0?'winSmD':'winSmI',[ax+Math.cos(th+.11)*r,31,az+Math.sin(th+.11)*r],qFacing([Math.cos(th+.11),0,Math.sin(th+.11)]),[5,1.6,1],null);}
 kput('slab',[ax,36.4,az],null,[36,1,36],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));stripRing(ax,33,az,33,d,40);
 for(let k=0;k<16;k++){const th=k/16*TAU;if(d>0&&(k===3||k===9))continue;kput(d>0?'colR':'colW',[ax+Math.cos(th)*30,6,az+Math.sin(th)*30],null,[1.2,14,1.2],null);}
 // the silo proper: 8-lobed drum rising 110 m from the ring, domed cap, service ring
 const SH=110,cut=d>0?SH*.7:null;const sr=y=>26*(1-.12*y/SH);
 mesh(lathe({rFn:sr,H:SH,cut,jag:cut?5:0,flutes:8,amp:.22,sharp:1.2,nu:96,nv:50,hole:holeFn(d,85,cut,1.4),seed:85}),skin,G,ax,37,az);
 if(d>0)mesh(lathe({rFn:y=>sr(y)*.88,H:SH,cut,jag:5,nu:32,nv:8,seed:85}),MAT.guts,G,ax,37,az);
 for(let yy=12;yy<(cut||SH)-8;yy+=22)kput(d>0?'ringR':'ringW',[ax,37+yy,az],qEuler(Math.PI/2,0,0),[sr(yy)*1.05,sr(yy)*1.05,4],null);
 if(!cut){mesh(lathe({rFn:y=>sr(SH)*Math.sqrt(clamp(1-Math.pow(y/14,2),0,1)),H:14,nu:48,nv:8}),skin,G,ax,37+SH-.5,az);stripRing(ax,37+SH-3,az,sr(SH)*.95,d,32);}
 else rubbleRing(ax,6,az,38,70,60,3);
 for(let k=0;k<3;k++){const th=k/3*TAU+.5;kput(d>0?'pipeR':'pipe',[ax+Math.cos(th)*24,37,az+Math.sin(th)*24],null,[1.1,(cut||SH)*.9,1.1],null);}
 kput(d>0?'pipeR':'pipe',[ax-30,26,az+20],qEuler(0,.6,Math.PI/2),[1.6,60,1.6],null);}

// ================================================================= IZIZ TRANSPLANT — the Iziz building families (claude/iziz-transplant.html, r5) ported to this repo
// Per family two vocabularies: the ORIGINAL Iziz massing (izBlock etc.) and the Ancients TRANSPLANT (drums, vaults,
// petal crowns), and for each a post-build `wreck()` pass that makes the destroyed or the rehabilitated state.
// Names are prefixed t*/T* where the showcase's would collide with the vendored kit. The pair functions themselves
// are the showcase's, unchanged, so the buildings are the ones Travis approved.
//
// Placement contract (used by the city): TRANS.place(scene, kind, mode, x, z, ry, scale, seed, extraTags, y) — mode is
// 'orig' | 'ruin' | 'rehab' (Iziz original: intact / destroyed / rehabilitated) or 'anc' | 'ancruin' | 'ancrehab'
// (Ancients transplant). Pueblo is defined but EXCLUDED from placement (Travis). Palace is 'orig' only, temple and
// arena 'anc' only, one of each, placed by the city target. TRANS.bake() merges the one-off meshes per material.
const TPAL=[0xe9cb8c,0xdcb474,0xcf9d5b,0xe2ab5e,0xbf8a44,0xf1dba6,0xd8893c,0xc8a26a,0xe6bd7e,0xd4a05a];
const TPAL_BRUT=[0xb9a58a,0xa8957a,0xc7b294,0x9c8b70,0xd2bc9c];
const TTIMBER=0x5e3f28,TTIMBER2=0x74513a,TTRIM=0x6e5428;
const _tmc={};function tsand(hex,tex){const k=hex+'_'+(tex||'p');if(_tmc[k])return _tmc[k];const m=new THREE.MeshStandardMaterial({map:tex==='c'?TEX.concrete:TEX.panel,color:hex,metalness:tex==='c'?0:.3,roughness:tex==='c'?.9:.42,side:DS});_tmc[k]=m;return m;}
kdef('frus93',vnWedgeGeo(.93,.93),MAT.white);kdef('frus90',vnWedgeGeo(.9,.9),MAT.white);kdef('frus88',vnWedgeGeo(.88,.88),MAT.white);kdef('frus85',vnWedgeGeo(.85,.85),MAT.white);kdef('frus60',vnWedgeGeo(.6,.6),MAT.white);kdef('frusT',vnWedgeGeo(.42,.42),MAT.white);kdef('frusWd',vnWedgeGeo(.55,.1),MAT.white);kdef('frusPyr',vnWedgeGeo(.05,.05),MAT.white);kdef('frus82',vnWedgeGeo(.82,.82),MAT.white);
kdef('pent',new THREE.CylinderGeometry(.88,1,1,5).rotateY(Math.PI/5).translate(0,.5,0),MAT.white);kdef('hept',new THREE.CylinderGeometry(.8,1,1,7).translate(0,.5,0),MAT.white);
kdef('dome',new THREE.SphereGeometry(1,16,10,0,TAU,0,Math.PI/2),MAT.white);kdef('gable',vnWedgeGeo(1,.04),MAT.white);
kdef('lampI',new THREE.BoxGeometry(1,1,1),MAT.dot);
MAT.scrap=new THREE.MeshStandardMaterial({map:TEX.rust,color:0xffffff,roughness:.9,metalness:.2,side:DS});MAT.plank=new THREE.MeshStandardMaterial({map:TEX.wood,color:0xffffff,roughness:1,side:DS});vWorldUV(MAT.plank,.5);
kdef('tscrap',new THREE.BoxGeometry(1,1,1),MAT.scrap);kdef('tplank',new THREE.BoxGeometry(1,1,1),MAT.plank);kdef('tpole',new THREE.CylinderGeometry(.12,.12,1,6),MAT.pipeRust);kdef('tbulb',new THREE.SphereGeometry(.22,6,5),MAT.dot);
const TSCRAP=[0x8a3a2a,0x7a7a72,0x9a8a6a,0x5a6a3a,0x6a6a80],TPLANK=[0xb08a5a,0xc8a070,0x9a7a4a],TTARP=[0x2a5a8a,0xe07a2a,0x3a7a5a,0x8a3a3a,0xe0a030];
const _trm={};function rustify(m){if(!m||m===MAT.glass)return m;if(m===MAT.white)return MAT.rust;if(m.map===TEX.panel&&m!==MAT.white){const k='w'+m.color.getHex();if(!_trm[k])_trm[k]=new THREE.MeshStandardMaterial({map:TEX.rust,color:new THREE.Color(m.color).multiplyScalar(.85),roughness:.95,metalness:.15,side:DS});return _trm[k];}if(m===MAT.concrete)return MAT.concreteR;if(m===MAT.winIntact)return MAT.winDead;if(_trm[m.uuid])return _trm[m.uuid];
 const n=new THREE.MeshStandardMaterial({map:TEX.rust,color:new THREE.Color(m.color).multiplyScalar(.85),roughness:.95,metalness:.15,side:DS});_trm[m.uuid]=n;return n;}
const DEADNAME={winI:'winD',winBigI:'winBigD',winSmI:'winSmD',ovalI:'ovalD',mullW:'mullR',colW:'colR',strutW:'strutR',ringW:'ringR',pipe:'pipeR',boxW:'boxR',boxC:'boxCR',slabC:'slabCR',pane:'paneD',plateW:'plateR',arch:'archR',vaultRib:'vaultRibR',finial:null,lampI:null,tbulb:null,pierW:'pierR'};
// ---- generic post-build passes: 'ruin' and 'rehab' ---------------------------------------------------------------
// P is the (possibly transformed) group the pair built into; `root` is an IDENTITY group in the scene that receives
// the cut geometry (which is computed in world space). ranges = KIT.items lengths before the pair ran.
function wreck(P,root,ranges,mode,cx,cz,seed){reseed(seed);const rehab=mode==='rehab';
 const bb=new THREE.Box3();P.updateMatrixWorld(true);const meshes=[];P.traverse(o=>{if(o.isMesh)meshes.push(o);});
 for(const m of meshes){m.geometry.computeBoundingBox();bb.union(m.geometry.boundingBox.clone().applyMatrix4(m.matrixWorld));}
 for(const n in ranges){const it=KIT.items[n];for(let i=ranges[n];i<it.length;i++){const p=it[i].p;bb.expandByPoint(new THREE.Vector3(p[0],p[1],p[2]));}}
 if(!isFinite(bb.min.x))return;
 const H=Math.max(4,bb.max.y-bb.min.y),y0=bb.min.y;const R=Math.max(bb.max.x-bb.min.x,bb.max.z-bb.min.z)/2;
 const BIGSKIP=/^(win|oval|strip|dot|cell|mull|ring|pipe|finial|lamp|vine|moss|rubble|trunk|fig|hedge|tscrap|tplank|tpole|tbulb|v[A-Z])/;
 for(const n in ranges){const it=KIT.items[n];if(BIGSKIP.test(n))continue;const keep=it.slice(0,ranges[n]);for(let i=ranges[n];i<it.length;i++){const o=it[i];const sz=typeof o.s==='number'?[o.s,o.s,o.s]:o.s;
   if(Math.max(sz[0],sz[1],sz[2])<3){keep.push(o);continue;}
   // subdivide the shared unit geometry to ~1.5 m cells so the cut is ragged rather than whole faces vanishing: a
   // five-sided prism cut at its native two triangles a side left standing triangular sails (the pentagon block)
   const def=KIT.defs[n];let geo=def.geo;if(geo.type==='BoxGeometry'){geo=new THREE.BoxGeometry(1,1,1,Math.max(1,Math.round(sz[0]/1.5)),Math.max(1,Math.round(sz[1]/1.5)),Math.max(1,Math.round(sz[2]/1.5)));}
   else if(geo.type==='CylinderGeometry'&&geo.parameters){const P=geo.parameters;geo=new THREE.CylinderGeometry(P.radiusTop,P.radiusBottom,P.height,Math.max(P.radialSegments,Math.round(P.radialSegments*Math.ceil(Math.max(sz[0],sz[2])*2/(P.radialSegments*1.5)))),Math.max(1,Math.round(sz[1]/1.5)),P.openEnded,P.thetaStart,P.thetaLength);
    if(def.geo.boundingBox===null||true){const bb0=new THREE.Box3().setFromBufferAttribute(def.geo.attributes.position),bb1=new THREE.Box3().setFromBufferAttribute(geo.attributes.position);geo.translate(0,bb0.min.y-bb1.min.y,0);}}
   const m=new THREE.Mesh(geo,o.c?(()=>{const mm=def.mat.clone();mm.onBeforeCompile=def.mat.onBeforeCompile;mm.color=o.c.clone();return mm;})():def.mat);m.position.set(o.p[0],o.p[1],o.p[2]);if(o.q)m.quaternion.copy(o.q);m.scale.set(sz[0],sz[1],sz[2]);root.add(m);meshes.push(m);}
  KIT.items[n]=keep;}
 root.updateMatrixWorld(true);P.updateMatrixWorld(true);
 const cutF=rehab?rr(.55,.85):rr(.4,.75);const cut=y0+H*cutF;const jag=(x,z)=>(fbm(x*.08+seed,z*.08,seed*.3,2)-.5)*H*.3;
 const hf=clamp(2.6/R,.07,.5);const holeT=rehab?.17:.25;const hole=(x,y,z)=>fbm(x*hf+seed*.7,y*hf,z*hf,3)<holeT;let topKept=y0;
 const gone=[],cutGeos=[];
 for(const m of meshes){if(m.material===MAT.glass){m.parent.remove(m);continue;}
  const g=(m.geometry.index?m.geometry.toNonIndexed():m.geometry).clone();g.applyMatrix4(m.matrixWorld);const p=g.attributes.position.array,uv=g.attributes.uv?g.attributes.uv.array:null;
  const np=[],nu=[];for(let i=0;i<p.length;i+=9){const x=(p[i]+p[i+3]+p[i+6])/3,y=(p[i+1]+p[i+4]+p[i+7])/3,z=(p[i+2]+p[i+5]+p[i+8])/3;
   const keep=y<cut+jag(x,z)&&!hole(x,y,z);
   if(keep){for(let k=0;k<9;k++)np.push(p[i+k]);for(let k=1;k<9;k+=3)if(p[i+k]>topKept&&Math.hypot(p[i+k-1]-cx,p[i+k+1]-cz)<R*.8)topKept=p[i+k];
    // world-metre UVs from the triangle's dominant axis: the materials' world-UV hook then tiles the cut fabric in metres
    {const ax=p[i+3]-p[i],ay=p[i+4]-p[i+1],az=p[i+5]-p[i+2],bx=p[i+6]-p[i],by=p[i+7]-p[i+1],bz=p[i+8]-p[i+2];const nx=Math.abs(ay*bz-az*by),ny=Math.abs(az*bx-ax*bz),nz=Math.abs(ax*by-ay*bx);
     const A=(ny>=nx&&ny>=nz)?[0,2]:(nx>=nz)?[2,1]:[0,1];for(let k=0;k<9;k+=3)nu.push(p[i+k+A[0]],p[i+k+A[1]]);}}
   else if(y<cut+jag(x,z)-1&&gone.length<600&&rng()<.25){const ax=p[i+3]-p[i],ay=p[i+4]-p[i+1],az=p[i+5]-p[i+2],bx=p[i+6]-p[i],by=p[i+7]-p[i+1],bz=p[i+8]-p[i+2];const n=new THREE.Vector3(ay*bz-az*by,az*bx-ax*bz,ax*by-ay*bx);const L=n.length();if(L>0.05)gone.push([x,y,z,n.x/L,n.y/L,n.z/L,Math.sqrt(L)]);}}
  m.parent.remove(m);if(!np.length)continue;const ng=new THREE.BufferGeometry();ng.setAttribute('position',new THREE.Float32BufferAttribute(np,3));ng.setAttribute('uv',new THREE.Float32BufferAttribute(nu,2));ng.computeVertexNormals();
  const rm=rustify(m.material),uk=(rm&&rm.userData&&rm.userData.uvK)||.125;{const a=ng.attributes.uv.array;for(let k=0;k<a.length;k++)a[k]*=uk;}   // metres -> the material's tile
  const nm=new THREE.Mesh(ng,rm);root.add(nm);cutGeos.push(ng);}
 const moves=[];for(const n in ranges){const it=KIT.items[n];const keep=it.slice(0,ranges[n]);for(let i=ranges[n];i<it.length;i++){const o=it[i];const p=o.p;
   const above=p[1]>cut+jag(p[0],p[2]);const lost=above||hole(p[0],p[1],p[2])||rng()<(rehab?.12:.25);
   if(lost){if(!above&&rng()<.2&&gone.length<600)gone.push([p[0],p[1],p[2],0,1,0,1.5]);continue;}
   if(p[1]+(typeof o.s==='number'?o.s:o.s[1])*.5>topKept&&Math.hypot(p[0]-cx,p[2]-cz)<R*.8)topKept=p[1]+(typeof o.s==='number'?o.s:o.s[1])*.5;
   let tn=n in DEADNAME?DEADNAME[n]:n;if(tn===null)continue;if(n==='strip'||n==='dot'||n==='cell'){o.c=(rehab&&rng()<.35)?WARM.clone().multiplyScalar(rr(.4,.9)):(rng()<.08?CYAN.clone().multiplyScalar(.6):DEAD);}
   else if(o.c){o.c=o.c.clone().multiplyScalar(.8);o.c.r*=1.05;o.c.b*=.85;}
   if(tn===n)keep.push(o);else moves.push([tn,o]);}
  KIT.items[n]=keep;}
 for(const [tn,o] of moves)KIT.items[tn].push(o);
 // decay dressing (world frame)
 const kx0=KXF;KXF=null;KOFF=[0,0,0];
 rubbleRing(cx,y0,cz,R*.6,R*1.6,rehab?18:Math.round(20+R*3),Math.min(2.5,.6+R*.08));scatterMoss(cx,y0,cz,R*.3,R*1.6,rehab?10:Math.round(10+R*2),Math.min(2,.5+R*.06));
 // vines hang off the CUT WALLS themselves (side faces of the new geometry), not off a ring in the air round the plot
 if(!rehab&&cutGeos.length){for(const f of sideFaces(cutGeos,Math.round(R*.6))){if(f.p[1]<y0+H*.3)continue;const L=Math.min(rr(3,H*.5),f.p[1]-y0-.3);
  kput('vine',[f.p[0]+f.n[0]*.2,f.p[1],f.p[2]+f.n[2]*.2],qEuler(rr(-.08,.08),0,rr(-.08,.08)),[1.8,L,1.8],null);}}
 if(!rehab){KXF=kx0;return;}
 // ---- rehab: patchwork — scrap plates and planks over the holes, tarp roofs over the cut, scaffold poles, bulbs
 for(const g of gone){if(rng()>.75)continue;const q=qFacing([g[3],g[4],g[5]]);const s=clamp(g[6]*rr(.8,1.6),.6,3.2);const plank=rng()<.4;
  kput(plank?'tplank':'tscrap',[g[0]+g[3]*.15,g[1]+g[4]*.15,g[2]+g[5]*.15],q.multiply(qEuler(0,0,rr(-.2,.2))),[s*rr(.7,1.3),plank?s*.3:s*rr(.6,1.1),.18],vC(plank?TPLANK[Math.floor(rng()*3)]:TSCRAP[Math.floor(rng()*5)]));
  if(rng()<.08)kput('tbulb',[g[0]+g[3]*.6,g[1]+g[4]*.6+.4,g[2]+g[5]*.6],null,1,WARM);}
 // where a canopy pole can stand: walking in from radius r along bearing a to the first point with fabric within 1.5 m
 // horizontally and within 5 m of the kept top (the roof), so a pole never hangs in the air round a narrow crown
 const RV=[];for(const g of cutGeos){const pa=g.attributes.position.array;for(let i=0;i<pa.length;i+=9)if(pa[i+1]>topKept-5)RV.push(pa[i],pa[i+1],pa[i+2]);}
 const roofFoot=(a,r)=>{for(let rr2=r;rr2>=.5;rr2-=.75){const px=cx+Math.cos(a)*rr2,pz=cz+Math.sin(a)*rr2;let y=-1e9;for(let i=0;i<RV.length;i+=3)if(Math.abs(RV[i]-px)<1.5&&Math.abs(RV[i+2]-pz)<1.5&&RV[i+1]>y)y=RV[i+1];if(y>-1e8)return[px,pz,y-.2];}return[cx+Math.cos(a)*r,cz+Math.sin(a)*r,topKept-.3];};
 // the ROOF over the cut: a draped tarp on poles for a small building, a corrugated-sheet cap on more poles for a big one
 // (a rehabilitated building always gets its roof back — the old pass only scattered planks over anything past R 22)
 const tc=vC(TTARP[Math.floor(rng()*5)]);const tr=R*.7;const ty=topKept+1.6;const bigRoof=R>=22;
 {const K=.5;const roof=gridSurface((u,v)=>{const a=u*TAU,r=v*tr;return[cx+r*Math.cos(a),ty+(bigRoof?3.2-2.6*v:2.4-2.2*v*v)+.4*Math.sin(a*5)*(bigRoof?0:1),cz+r*Math.sin(a)];},bigRoof?40:24,bigRoof?6:5,{uS:tr*TAU*K,vS:tr*K,hole:bigRoof?null:(u,v)=>fbm(u*5+seed,v*4,3,2)<.3});
  const rm=new THREE.Mesh(roof,(bigRoof?MAT.corrugate:MAT.tarp).clone());if(!bigRoof)rm.material.color=tc;if(MAT.corrugate.onBeforeCompile)rm.material.onBeforeCompile=(bigRoof?MAT.corrugate:MAT.tarp).onBeforeCompile;root.add(rm);
  const np=bigRoof?Math.round(7+R*.35):7;for(let k=0;k<np;k++){const a=k/np*TAU+.3;const px=cx+Math.cos(a)*tr,pz=cz+Math.sin(a)*tr;const top=ty+.2;const ft=roofFoot(a,tr),px2=ft[0],pz2=ft[1],pb=ft[2];kput('tpole',[px2,(pb+top)/2,pz2],qEuler(rr(-.06,.06),0,rr(-.06,.06)),[1,top-pb,1],null);/* the canopy stands on the ROOF, not on poles up from the street (Travis) */kput('tplank',[px,top+.2,pz],qEuler(0,-a,0),[tr*2*Math.sin(Math.PI/np)*.9,.2,.35],vC(TPLANK[1]));}
  if(bigRoof)for(let k=0;k<Math.round(R*.5);k++){const a=rng()*TAU,r=rng()*tr*.9;kput('tscrap',[cx+Math.cos(a)*r,ty+3.3-2.6*(r/tr)+.15,cz+Math.sin(a)*r],qEuler(0,rng()*TAU,0),[rr(1,2.2),.08,rr(.8,1.6)],vC(TSCRAP[Math.floor(rng()*5)]));}}   // weights and patches
 if(H>18){for(let k=0;k<3;k++){const y=y0+H*rr(.15,.6);const a=rng()*TAU;kput('tbulb',[cx+Math.cos(a)*R*1.05,y,cz+Math.sin(a)*R*1.05],null,1,WARM);}KXF=kx0;return;}   // no ladders or scaffold up a tall block (Travis)
 const sa=rng()*TAU;const sx=cx+Math.cos(sa)*(R+1.0),sz=cz+Math.sin(sa)*(R+1.0);const lh=Math.min(topKept,y0+H*.8)-y0;
 for(const d of [-.25,.25]){const px=sx+(-Math.sin(sa))*d,pz=sz+Math.cos(sa)*d;kput('tpole',[px,y0+lh/2,pz],qEuler(-.08*Math.cos(sa),0,.08*Math.sin(sa)),[.8,lh,.8],null);}
 for(let y=y0+.3;y<y0+lh;y+=.3)kput('tplank',[sx,y,sz],qEuler(0,-sa,0),[.08,.06,.5],vC(TPLANK[0]));
 if(R>9){const ox=-Math.sin(sa),oz=Math.cos(sa);const bays=[-3.2,-1.2,1.2,3.2];
  for(const d of bays){for(const o of [0,1.1]){const px=sx+ox*d+Math.cos(sa)*o,pz=sz+oz*d+Math.sin(sa)*o;kput('tpole',[px,y0+lh/2,pz],null,[.9,lh,.9],null);}}
  for(let y=y0+2.2;y<y0+lh;y+=2.2){for(const d of bays)kput('tpole',[sx+ox*d+Math.cos(sa)*.55,y,sz+oz*d+Math.sin(sa)*.55],qEuler(Math.PI/2,0,0).premultiply(qEuler(0,-sa,0)),[.7,1.1,.7],null);
   for(let k=0;k<2;k++)kput('tplank',[sx+ox*(-2.2+k*4.4)+Math.cos(sa)*.55,y+.1,sz+oz*(-2.2+k*4.4)+Math.sin(sa)*.55],qEuler(0,-sa,0),[2.2,.08,.9],vC(TPLANK[1]));}}
 for(let k=0;k<3;k++){const y=y0+H*rr(.15,.6);const a=rng()*TAU;kput('tbulb',[cx+Math.cos(a)*R*1.05,y,cz+Math.sin(a)*R*1.05],null,1,WARM);}
 KXF=kx0;}

const tC=(hex,k)=>new THREE.Color(hex).multiplyScalar(k||1);
// --- Iziz primitives (originals) ------------------------------------------------------------------
function izBlock(x,y,z,w,h,d,ry,cc,o){o=o||{};const q=qEuler(0,ry,0);const col=tC(cc);kput('boxW',[x,y+h/2,z],q,[w,h,d],col);
 if(!o.plain){kput('boxW',[x,y+h-.4,z],q,[w+.6,.5,d+.6],tC(cc,1.12));kput('boxW',[x,y+h-1.2,z],q,[w+.3,.3,d+.3],tC(cc,.8));
  const n=Math.max(1,Math.round(w/2.2));for(let i=0;i<n;i++){const lx=((i+.5)/n-.5)*w*.8;for(const s of [-1,1]){const p=loc2(x,z,lx,s*(d/2+.05),ry);kput('finW',[p[0],y+h*.55,p[1]],q,[.7,h*.7,.3],null);}}}
 if(!o.noDoor){const p=loc2(x,z,0,d/2+.2,ry);kput('boxD',[p[0],y+1.5,p[1]],q,[1.6,3,.5],null);kput('boxW',[p[0],y+3.2,p[1]],q,[2.6,.35,.9],tC(0x8a6a3a));}
 if(o.roof){kput('boxW',[x+rr(-w*.2,w*.2),y+h+.6,z+rr(-d*.2,d*.2)],q,[1.2,1.2,1.2],tC(0x8a6a3a));}}
function loc2(x,z,lx,lz,ry){return[x+lx*Math.cos(ry)+lz*Math.sin(ry),z-lx*Math.sin(ry)+lz*Math.cos(ry)];}
function izLamp(x,y,z){kput('lampI',[x,y+.5,z],null,[1.2,.7,1.2],WARM);}
// --- Ancients primitives (transplants) ------------------------------------------------------------
function acDrum(P,x,y,z,r,h,cc,o){o=o||{};const m=tsand(cc);const n=o.n||3.2;const fl=o.flutes||10;const g=gridSurface((u,v)=>{const th=u*TAU;const rr0=r*se(th,n)*(1+.06*Math.pow(.5+.5*Math.cos(th*fl),2))*(1-(o.taper||0)*v);return[x+rr0*Math.cos(th),y+v*h,z+rr0*Math.sin(th)];},64,4,{uS:r*2,vS:h/4});
 mesh(g,m,P);kput('ringW',[x,y+h-.3,z],qEuler(Math.PI/2,0,0),[r*1.06,r*1.06,4],tC(cc,.85));kput('ringW',[x,y+h-1.4,z],qEuler(Math.PI/2,0,0),[r*1.03,r*1.03,2.5],tC(cc,1.1));
 kput('slab',[x,y+h,z],null,[r*.98*(1-(o.taper||0)),.4,r*.98*(1-(o.taper||0))],tC(cc,1.08));
 const nw=o.nw||Math.max(4,Math.round(r*1.4));for(let yy=2.2;yy<h-1.5;yy+=3.4)for(let k=0;k<nw;k++){const th=(k+.5)/nw*TAU;if(o.door&&Math.abs(th-Math.PI/2)<.5&&yy<4)continue;const rr0=r*se(th,n)*(1-(o.taper||0)*yy/h)+.1;kput('winSmI',[x+rr0*Math.cos(th),y+yy,z+rr0*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1,1.2,1],null);}
 if(o.door!==false){const rr0=r*se(Math.PI/2,n)-.1;kput('archOpen',[x,y+1.6,z+rr0],qFacing([0,0,1]),[.28,.36,1],null);}
 if(o.strip!==false)stripRing(x,y+h-2.2,z,r*.9,0,Math.round(r*2));}
function acPetalCrown(P,x,y,z,r,h,cc,n){const Q=new THREE.Group();Q.position.set(x,y,z);P.add(Q);petalRing(Q,n||6,r*.6,h,r*.7,r*.25,.6,0,0,7,tsand(cc),null);
 mesh(lathe({rFn:yy=>r*.55*Math.pow(clamp(1-Math.pow(yy/(h*.6),2),0,1),.6),H:h*.6,nu:24,nv:6}),MAT.glass,Q,0,.3,0);kput('finial',[x,y+h*.75,z],null,[.6,1,.6],null);}
function acLatticeDome(P,x,y,z,r,cc){mesh(lathe({rFn:yy=>r*Math.pow(clamp(1-Math.pow(yy/(r*.9),2),0,1),.55),H:r*.9,flutes:12,amp:.08,nu:48,nv:12,hole:(u,yy)=>Math.cos(u*TAU*12)<.3&&yy>r*.15&&yy<r*.75}),tsand(cc),P,x,y,z);
 mesh(lathe({rFn:yy=>r*.94*Math.pow(clamp(1-Math.pow(yy/(r*.9),2),0,1),.55),H:r*.9,nu:32,nv:8}),MAT.glass,P,x,y,z);kput('finial',[x,y+r*.95,z],null,[.5,.9,.5],null);}
function acVault(P,x,y,z,W,Hh,L,ry,cc,o){o=o||{};const m=tsand(cc);const q=qEuler(0,ry,0);const nr=Math.max(3,Math.round(L/4));
 for(let i=0;i<=nr;i++){const t=(i/nr-.5)*L;const p=loc2(x,z,0,t,ry);const rib=mesh(arcShape(W,Hh,W*.05,.5),m,P,p[0],y,p[1]);rib.rotation.y=ry;}
 const sk=gridSurface((u,v)=>{const lx=(u-.5)*(W-.4);const lz=(v-.5)*L;const p=loc2(x,z,lx,lz,ry);return[p[0],y+(Hh-.25)*(1-Math.pow(2*lx/(W-.4),2)),p[1]];},24,8,{uS:W/2,vS:L/2,hole:o.skylight?(u,v)=>Math.abs(u-.5)<.06:null});mesh(sk,m,P);
 if(o.skylight)mesh(gridSurface((u,v)=>{const lx=(u-.5)*W*.14;const lz=(v-.5)*L;const p=loc2(x,z,lx,lz,ry);return[p[0],y+(Hh-.3)*(1-Math.pow(2*lx/(W-.4),2)),p[1]];},4,8,{}),MAT.glass,P);
 for(const s of [-1,1]){const p=loc2(x,z,0,s*L/2,ry);const e=mesh(paraFill(W,Hh,o.doorW||W*.3,o.doorH||Hh*.55),m,P,p[0],y,p[1]);e.rotation.y=ry;
  if(o.glassEnds){const g=mesh(paraFill(o.doorW||W*.3,o.doorH||Hh*.55,0,0),MAT.glass,P,p[0],y,p[1]);g.rotation.y=ry;}
  for(let k=-2;k<=2;k++){const pp=loc2(x,z,k*W*.18,s*L/2,ry);kput('mullW',[pp[0],y+Hh*.28,pp[1]],q,[.7,Hh*.55*(1-Math.pow(k/2.8,2)),.7],tC(cc,.9));}}
 for(let i=0;i<Math.round(L/5);i++){const p=loc2(x,z,0,(i+.5)/Math.round(L/5)*L-L/2,ry);kput('strip',[p[0],y+Hh-.6,p[1]],q,[W*.5,1,1],CYAN);}}
function acStruts(P,x,y,z,r0,r1,h,n,cc,ry){for(let k=0;k<n;k++){const th=k/n*TAU+(ry||0);beam('strutW',[x+Math.cos(th)*r0,y,z+Math.sin(th)*r0],[x+Math.cos(th)*r1,y+h,z+Math.sin(th)*r1],.9,.7,tC(cc,.9));}}
function acNeedle(P,x,y,z,r,h,cc){mesh(lathe({rFn:yy=>r*(1-.55*yy/h)+.15,H:h,flutes:6,amp:.25,sharp:1.5,twist:.15,nu:24,nv:14}),tsand(cc),P,x,y,z);
 for(let yy=h*.3;yy<h-2;yy+=h*.3)kput('ringW',[x,y+yy,z],qEuler(Math.PI/2,0,0),[r*(1-.55*yy/h)*1.6,r*(1-.55*yy/h)*1.6,2],tC(cc,.85));kput('finial',[x,y+h+.6,z],null,[.5,.9,.5],null);}

// --- the pairs: fn(P, x, z, orig) builds one instance at x,z; original when `orig` true -----------------------------
const TPAIRS=[];const TBY={};
function tpair(key,name,size,tall,fn){const p={key,name,size,tall,fn};TPAIRS.push(p);TBY[key]=p;}
tpair('box','Box house',24,false,(P,x,z,orig)=>{const cc=TPAL[0];if(orig){izBlock(x,0,z,6,8,6,0,cc,{roof:true});izLamp(x+2,8,z+1);}
 else{acDrum(P,x,0,z,3.4,8,cc,{door:true,nw:8});}});
tpair('tier','Tiered house',24,false,(P,x,z,orig)=>{const cc=TPAL[1];if(orig){izBlock(x,0,z,6.5,5,6.5,0,cc,{});izBlock(x,5,z,4.2,3.6,4.2,0,cc,{noDoor:true});}
 else{acDrum(P,x,0,z,3.6,5,cc,{door:true,nw:8});acDrum(P,x,5,z,2.3,3.6,cc,{door:false,nw:6,flutes:6});acPetalCrown(P,x,8.6,z,2.3,2.4,cc,6);}});
tpair('domed','Domed house',24,false,(P,x,z,orig)=>{const cc=TPAL[2];if(orig){izBlock(x,0,z,6,5.6,6,0,cc,{});kput('dome',[x,5.6,z],null,[3,3.6,3],tC(cc));}
 else{acDrum(P,x,0,z,3.4,5.6,cc,{door:true,nw:8});acLatticeDome(P,x,5.6,z,3.2,cc);}});
tpair('barrel','Barrel house',26,false,(P,x,z,orig)=>{const cc=TPAL[3];if(orig){kput('boxW',[x,1.4,z],null,[7,2.8,9.6],tC(cc));kput('dome',[x,2.8,z],null,[3.6,3.2,4.8],tC(cc));kput('boxD',[x,1.4,z+4.9],null,[1.6,2.6,.4],null);}
 else{acVault(P,x,0,z,7.2,6,9.6,0,cc,{skylight:true,glassEnds:true,doorW:2.4,doorH:3.2});}});
tpair('tent','Tent house',26,false,(P,x,z,orig)=>{const cc=TPAL[4];if(orig){kput('frusPyr',[x,0,z],null,[9.6,5.6,9.6],tC(cc));kput('boxD',[x,1.3,z+4.6],null,[1.6,2.6,.4],null);}
 else{const m=tsand(cc);const W=9.6,H=6.4,D=9.2;for(const sd of [-1,1]){mesh(gridSurface((u,v)=>{const q=u*2-1;const lz=q*D/2*(1-.3*v)+.4*Math.sin(Math.PI*v)*q;const lx=sd*(W/2*(1-v)+.18*W*q*q*(1-v));return[x+lx,v*H+.15,z+lz];},20,14,{uS:5,vS:3}),m,P);
   mesh(gridSurface((u,v)=>{const q=u*2-1;const lz=q*D/2*(1-.3*v)+.4*Math.sin(Math.PI*v)*q;const lx=sd*(W/2*(1-v)+.18*W*q*q*(1-v))*.96;return[x+lx,v*H+.15,z+lz];},20,14,{}),MAT.dark,P);}
  for(const sd of [-1,1]){const g=new THREE.Shape();g.moveTo(-W/2,0);g.lineTo(W/2,0);g.lineTo(0,H*.98);g.lineTo(-W/2,0);mesh(new THREE.ShapeGeometry(g),MAT.glass,P,x,.15,z+sd*D/2*.7);for(let k=-1;k<=1;k++)kput('mullW',[x+k*W*.2,H*.35*(1-Math.pow(k/2.6,2)),z+sd*D/2*.7],null,[.4,H*.7*(1-Math.pow(k/2.6,2)),.4],tC(cc,.9));}
  kput('archOpen',[x,1.4,z+D/2*.7+.1],qFacing([0,0,1]),[.28,.34,1],null);kput('boxW',[x,H+.25,z],null,[.5,.5,D*.75],tC(cc,.85));kput('slab',[x,.15,z],null,[6.2,.3,6.2],tC(cc,1.05));stripRing(x,H*.6,z,1.4,0,6);}});
tpair('pyr','Pyramid house',26,false,(P,x,z,orig)=>{const cc=TPAL[5];if(orig){kput('frusPyr',[x,0,z],null,[7.5,8,7.5],tC(cc));kput('boxW',[x,7.2,z],null,[7.2,.8,7.2],tC(cc,1.1));kput('boxD',[x,1.4,z+3.6],null,[1.6,2.8,.4],null);}
 else{const m=tsand(cc);let w=7.5,y=0;for(let i=0;i<2;i++){const h=i?2.6:3.6;const w0=w;mesh(gridSurface((u,v)=>{const th=u*TAU;const r=w0/2*se(th,3.5)*(1-.22*v)*(1+.06*Math.pow(.5+.5*Math.cos(th*12),3));return[x+r*Math.cos(th),y+v*h,z+r*Math.sin(th)];},72,6,{uS:8,vS:3}),m,P);
   kput('ringW',[x,y+h-.2,z],qEuler(Math.PI/2,0,0),[w0/2*.8,w0/2*.8,3],tC(cc,1.1));if(!i){mesh(lathe({rFn:()=>w0/2*.78*.95,H:1.2,nu:40,nv:1}),MAT.glass,P,x,y+h,z);mesh(lathe({rFn:()=>w0/2*.7,H:1.2,nu:24,nv:1}),MAT.dark,P,x,y+h,z);mullions(x,y+h,z,w0/2*.78,1.2,14,0);stripRing(x,y+h+.6,z,w0/2*.6,0,12);}
   y+=h+(i?0:1.2);w*=.72;}
  mesh(lathe({rFn:yy=>1.5*Math.pow(clamp(1-Math.pow(yy/2,2),0,1),.55),H:2,flutes:10,amp:.08,nu:32,nv:6,hole:(u,yy)=>Math.cos(u*TAU*10)<.3&&yy>.4&&yy<1.6}),tsand(0xf1dba6),P,x,y,z);mesh(lathe({rFn:yy=>1.4*Math.pow(clamp(1-Math.pow(yy/2,2),0,1),.55),H:2,nu:24,nv:5}),MAT.glass,P,x,y,z);kput('finial',[x,y+2.4,z],null,[.4,.7,.4],null);
  kput('archOpen',[x,1.5,z+3.6],qFacing([0,0,1]),[.28,.34,1],null);}});
tpair('setback','Setback tower',40,true,(P,x,z,orig)=>{const cc=TPAL[6];const w=7,h=40;if(orig){izBlock(x,0,z,w*.95,h,w*.95,0,cc,{});izBlock(x,h,z,w*.6,h*.28,w*.6,0,cc,{noDoor:true});izBlock(x,h*1.28,z,w*.32,h*.16,w*.32,0,cc,{noDoor:true,plain:true});kput('boxW',[x,h*1.44+4,z],null,[.5,8,.5],tC(0x8a6a3a));izLamp(x,h*1.44+8,z);}
 else{const rFn=yy=>{const t=clamp(yy/h,0,1);return 3.6+1.6*Math.pow(Math.abs(t-.4)/.6,1.6);};mesh(lathe({rFn,H:h,flutes:14,amp:.09,sharp:2.5,nu:72,nv:40}),tsand(cc),P,x,4,z);
  acStruts(P,x,0,z,7,rFn(0)*.95,4.5,10,cc,0);kput('slab',[x,4.2,z],null,[rFn(0),1,rFn(0)],tC(cc,.9));
  for(let yy=6;yy<h-4;yy+=3.4)for(let k=0;k<14;k++){const th=(k+.5)/14*TAU;kput('cell',[x+(rFn(yy)+.05)*Math.cos(th),4+yy,z+(rFn(yy)+.05)*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1,.9,1],rng()<.8?WARM.clone().multiplyScalar(rr(.5,1)):new THREE.Color(0x14283c));}
  glassBand(P,rFn,h*.55,2.4,0,x,4,z,20);for(let k=0;k<14;k++){const th=k/14*TAU;beam('strutW',[x+Math.cos(th)*rFn(h)*1.02,4+h-2,z+Math.sin(th)*rFn(h)*1.02],[x+Math.cos(th)*(rFn(h)+2.4),4+h+4,z+Math.sin(th)*(rFn(h)+2.4)],.6,.5,tC(cc,.9));}
  mesh(lathe({rFn:yy=>rFn(h)*(1+.3*yy/5)*(1-.2*Math.pow(yy/5,3)),H:5,nu:32,nv:6}),MAT.glass,P,x,4+h-1,z);kput('finial',[x,4+h+7,z],null,[.9,1.6,.9],null);kput('archOpen',[x,1.6,z+rFn(0)-.2],qFacing([0,0,1]),[.3,.36,1],null);}});
tpair('setback2','Setback tower (stepped)',40,true,(P,x,z,orig)=>{const cc=TPAL[6];const w=7,h=40;if(orig){izBlock(x,0,z,w*.95,h,w*.95,0,cc,{});izBlock(x,h,z,w*.6,h*.28,w*.6,0,cc,{noDoor:true});izBlock(x,h*1.28,z,w*.32,h*.16,w*.32,0,cc,{noDoor:true,plain:true});kput('boxW',[x,h*1.44+4,z],null,[.5,8,.5],tC(0x8a6a3a));izLamp(x,h*1.44+8,z);}
 else{const tiers=[[3.6,h*.62,14],[2.5,h*.24,10],[1.5,h*.16,8]];let y=0;tiers.forEach((t,i)=>{const [r,hh,fl]=t;mesh(lathe({rFn:yy=>r*(1-.06*yy/hh),H:hh,flutes:fl,amp:.1,sharp:2.5,nu:56,nv:Math.round(hh/2)}),tsand(cc),P,x,y,z);
   for(let yy=2.4;yy<hh-2;yy+=3.4)for(let k=0;k<fl;k++){const th=(k+.5)/fl*TAU;const rr0=r*(1-.06*yy/hh)+.1;if(i===0&&yy<4&&Math.abs(th-Math.PI/2)<.5)continue;kput('cell',[x+rr0*Math.cos(th),y+yy,z+rr0*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1,.9,1],rng()<.8?WARM.clone().multiplyScalar(rr(.5,1)):new THREE.Color(0x14283c));}
   kput('ringW',[x,y+hh-.4,z],qEuler(Math.PI/2,0,0),[r*1.08,r*1.08,3],tC(cc,.85));kput('slab',[x,y+hh,z],null,[r*1.02,.4,r*1.02],tC(cc,1.08));
   if(i<2){const rn=tiers[i+1][0];mesh(lathe({rFn:()=>rn*1.12,H:1.8,nu:40,nv:1}),MAT.glass,P,x,y+hh,z);mesh(lathe({rFn:()=>rn*.95,H:1.8,nu:24,nv:1}),MAT.dark,P,x,y+hh,z);mullions(x,y+hh,z,rn*1.12,1.8,12,0);stripRing(x,y+hh+.9,z,rn*.9,0,12);
    for(let k=0;k<8;k++){const th=k/8*TAU;beam('strutW',[x+Math.cos(th)*r*.98,y+hh-3,z+Math.sin(th)*r*.98],[x+Math.cos(th)*rn*1.15,y+hh+1.8,z+Math.sin(th)*rn*1.15],.5,.4,tC(cc,.9));}}
   y+=hh+(i<2?1.8:0);});
  for(let k=0;k<8;k++){const th=k/8*TAU;beam('strutW',[x+Math.cos(th)*1.55,y-1,z+Math.sin(th)*1.55],[x+Math.cos(th)*2.4,y+4,z+Math.sin(th)*2.4],.5,.4,tC(cc,.9));}mesh(lathe({rFn:yy=>1.5*(1+.3*yy/3)*(1-.2*Math.pow(yy/3,3)),H:3,nu:24,nv:5}),MAT.glass,P,x,y-.5,z);kput('finial',[x,y+4.5,z],null,[.7,1.3,.7],null);
  kput('archOpen',[x,1.6,z+3.4],qFacing([0,0,1]),[.3,.36,1],null);}});
tpair('tyrell','Tyrell block',40,true,(P,x,z,orig)=>{const cc=TPAL_BRUT[0];const bw=13,h=30;if(orig){kput('frusT',[x,0,z],null,[bw,h,bw],tC(cc));for(let k=1;k<=3;k++){const f=k/4,s=1-(1-.42)*f;kput('boxW',[x,h*f,z],null,[bw*s+.6,.7,bw*s+.6],tC(TTRIM));}izLamp(x,h+.2,z);kput('boxD',[x,1.7,z+bw/2-.3],null,[2.2,3.4,.5],null);}
 else{const m=tsand(cc,'c');mesh(gridSurface((u,v)=>{const th=u*TAU;const r=bw/2*se(th,5)*(1-.58*v)*(1-.05*Math.pow(.5+.5*Math.cos(th*8),3));return[x+r*Math.cos(th),v*h,z+r*Math.sin(th)];},64,12,{uS:12,vS:8}),m,P);
  for(let f=0;f<4;f++){const a=f*Math.PI/2;for(let k=-1;k<=1;k++){const off=bw/2*.71+.6;beam('strutW',[x+Math.cos(a)*(off+1)+(-Math.sin(a))*k*bw*.28,0,z+Math.sin(a)*(off+1)+Math.cos(a)*k*bw*.28],[x+Math.cos(a)*(bw/2*.42*.71+.5)+(-Math.sin(a))*k*bw*.12,h,z+Math.sin(a)*(bw/2*.42*.71+.5)+Math.cos(a)*k*bw*.12],1,.8,tC(cc,.85));}}
  for(let yy=3;yy<h-3;yy+=4.5)for(let f=0;f<4;f++){const a=f*Math.PI/2+Math.PI/4;const r=bw/2*se(a,5)*(1-.58*yy/h)+.1;for(let k=-1;k<=1;k+=2){kput('dot',[x+r*Math.cos(a)+(-Math.sin(a))*k*r*.4,yy,z+r*Math.sin(a)+Math.cos(a)*k*r*.4],qFacing([Math.cos(a),0,Math.sin(a)]),[.9,.5,.4],WARM);}}
  for(let k=0;k<12;k++){const th=k/12*TAU;const r=bw/2*.42*se(th,5);beam('strutW',[x+Math.cos(th)*r,h-1,z+Math.sin(th)*r],[x+Math.cos(th)*(r+1.5),h+4,z+Math.sin(th)*(r+1.5)],.5,.4,tC(cc,.9));}
  mesh(lathe({rFn:yy=>bw/2*.42*(1+.3*yy/4)*(1-.2*Math.pow(yy/4,3)),H:4,nu:24,nv:5}),MAT.glass,P,x,h-.5,z);kput('archOpen',[x,1.7,z+bw/2-.2],qFacing([0,0,1]),[.35,.4,1],null);}});
tpair('wedge','Wedge block',34,true,(P,x,z,orig)=>{const cc=TPAL_BRUT[2];const w=10,d=14,h=22;if(orig){kput('frusWd',[x,0,z],null,[w,h,d],tC(cc));kput('boxD',[x,1.5,z+d/2-.3],null,[1.8,3,.5],null);}
 else{const m=tsand(cc,'c');mesh(gridSurface((u,v)=>{const s=u*2-1;const lx=s*w/2*(1-.45*v);const lz=(d/2)*(1-.9*v)+.3*Math.sin(Math.PI*v);return[x+lx,v*h,z+lz];},20,12,{uS:6,vS:8}),m,P);
  mesh(gridSurface((u,v)=>{const s=u*2-1;const lx=s*w/2*(1-.45*v);return[x+lx,v*h,z-d/2*(1-.05*v)];},20,12,{uS:6,vS:8}),m,P);
  for(const s of [-1,1]){mesh(gridSurface((u,v)=>{const lz=lerp(-d/2*(1-.05*v),(d/2)*(1-.9*v)+.3*Math.sin(Math.PI*v),u);return[x+s*w/2*(1-.45*v),v*h,z+lz];},12,12,{uS:6,vS:8,hole:(u,v)=>{const cx=u*6,cy=v*9;return Math.abs((cx%1)-.5)<.3&&Math.abs((cy%1)-.5)<.3&&v>.08&&v<.92;}}),m,P);
   mesh(gridSurface((u,v)=>{const lz=lerp(-d/2*(1-.05*v),(d/2)*(1-.9*v)+.3*Math.sin(Math.PI*v),u);return[x+s*(w/2*(1-.45*v)-.4),v*h,z+lz];},12,12,{}),MAT.glass,P);}
  kput('slab',[x,h,z-d*.2],null,[w*.28,.5,d*.28],tC(cc,1.1));kput('archOpen',[x,1.6,z+d/2-.1],qFacing([0,0,1]),[.3,.36,1],null);stripRing(x,h*.5,z-d*.2,w*.2,0,8);}});
tpair('pent','Pentagon block',30,true,(P,x,z,orig)=>{const cc=TPAL_BRUT[1];const w=10,h=20;if(orig){kput('pent',[x,0,z],null,[w*1.3,h,w*1.3],tC(cc));kput('boxW',[x,h-.8,z],null,[w*1.3*.86+.6,.9,w*1.3*.86+.6],tC(TTRIM));kput('boxD',[x,1.5,z+w*.62],null,[1.8,3,.5],null);return;}
 mesh(lathe({rFn:yy=>w/2*(1-.12*yy/h),H:h,flutes:5,amp:.32,sharp:1,nu:60,nv:12}),tsand(cc,'c'),P,x,0,z);
 for(let s=0;s<5;s++){const y=s*4;mesh(lathe({rFn:()=>w/2*(1-.12*(y+3.4)/h)*1.08,H:.6,flutes:5,amp:.34,sharp:1,nu:60,nv:1}),tsand(cc,'c'),P,x,y+3.4,z);
  for(let k=0;k<5;k++){const th=k/5*TAU+.2;const r=w/2*(1-.12*(y+2)/h)*1.32+.1;kput('winSmI',[x+r*Math.cos(th),y+1.9,z+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1.4,1.3,1],null);}}
 kput('slab',[x,h,z],null,[w*.5,.5,w*.5],tC(cc,1.1));acPetalCrown(P,x,h,z,w*.42,3.5,cc,5);kput('archOpen',[x,1.6,z+w/2*1.3-.3],qFacing([0,0,1]),[.3,.36,1],null);});
tpair('hept','Heptagon block',30,true,(P,x,z,orig)=>{const cc=TPAL_BRUT[3];const w=10,h=18;if(orig){kput('hept',[x,0,z],null,[w*1.3,h,w*1.3],tC(cc));kput('boxW',[x,h-.8,z],null,[w*1.3*.8+.6,.9,w*1.3*.8+.6],tC(TTRIM));kput('boxD',[x,1.5,z+w*.62],null,[1.8,3,.5],null);return;}
 mesh(lathe({rFn:yy=>w/2*(1-.2*yy/h),H:h,flutes:7,amp:.3,sharp:1,nu:70,nv:12}),tsand(cc,'c'),P,x,0,z);
 for(let yy=3;yy<h-2;yy+=4)for(let k=0;k<7;k++){const th=k/7*TAU;const r=w/2*(1-.2*yy/h)*1.3+.1;kput('ovalI',[x+r*Math.cos(th),yy,z+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.7,.9,.8],null);}
 for(let yy=6;yy<h-2;yy+=6)kput('ringW',[x,yy,z],qEuler(Math.PI/2,0,0),[w/2*(1-.2*yy/h)*1.32,w/2*(1-.2*yy/h)*1.32,2],tC(cc,.85));
 mesh(lathe({rFn:yy=>w/2*.8*Math.sqrt(clamp(1-Math.pow(yy/2.5,2),0,1)),H:2.5,nu:28,nv:5}),tsand(cc,'c'),P,x,h-.2,z);kput('archOpen',[x,1.6,z+w/2*1.3-.3],qFacing([0,0,1]),[.3,.36,1],null);});
tpair('hall','Deco long hall',36,false,(P,x,z,orig)=>{const cc=TPAL[7];const L=18,Wd=11,h=10;if(orig){izBlock(x,0,z,L,h,Wd,0,cc,{noDoor:true});kput('gable',[x,h,z],null,[L+1.2,h*.55,Wd+1.2],tC(TTIMBER2));kput('boxW',[x,h+h*.55,z],null,[L+1.4,.4,.5],tC(TTIMBER));
  for(const s of [-1,1]){kput('boxW',[x+s*L*.5,h+h*.55+1,z],null,[.5,2.2,.5],tC(TTIMBER));}kput('boxD',[x,1.5,z+Wd/2+.3],null,[2.2,3,.5],null);kput('boxW',[x,3.6,z+Wd/2+1.5],null,[8,.4,3],tC(TTIMBER2));for(let k=-1;k<=1;k+=2)kput('boxW',[x+k*3.5,1.6,z+Wd/2+2.8],null,[.4,3.2,.4],tC(TTIMBER));
  kput('dot',[x+L*.3,h*.6,z+Wd/2+.3],null,[3,.8,.3],new THREE.Color(0x3ee0ff));}
 else{acVault(P,x,0,z,Wd+1,h+2,L,Math.PI/2,cc,{skylight:true,glassEnds:true,doorW:4,doorH:6});
  for(let k=-1;k<=1;k++){beam('strutW',[x+k*4,0,z+Wd/2+4.5],[x+k*3,h*.7,z+Wd/2+.4],.6,.5,tC(cc,.9));}kput('strutW',[x,h*.7,z+Wd/2+2.4],qEuler(-.2,0,0),[10,.35,5],tC(cc,1.05));
  kput('archOpen',[x,2,z+Wd/2+.3],qFacing([0,0,1]),[.42,.45,1],null);}});
tpair('stave','Stave hall with tower',40,false,(P,x,z,orig)=>{const cc=TPAL[8];const L=15,Wd=15,h=12;if(orig){izBlock(x,0,z,L,h,Wd,0,cc,{noDoor:true});kput('gable',[x,h,z],null,[L+1,h*.55,Wd+1],tC(TTIMBER2));kput('gable',[x,h+h*.72,z],qEuler(0,Math.PI/2,0),[L*.62,h*.55,Wd*.75],tC(TTIMBER2));
  izBlock(x,h,z,Wd*.36,h*1.2,Wd*.36,0,cc,{noDoor:true,plain:true});kput('gable',[x,h*2.2,z],null,[Wd*.46,h*.55,Wd*.46],tC(TTIMBER));kput('boxW',[x,h*2.75+1.5,z],null,[.4,3,.4],tC(TTIMBER));izLamp(x,h*2.75+3,z);kput('boxD',[x,1.5,z+Wd/2+.3],null,[2.2,3,.5],null);}
 else{acVault(P,x,0,z,Wd+1,h+1,L,Math.PI/2,cc,{skylight:false,glassEnds:true,doorW:4,doorH:6});acVault(P,x,0,z,Wd*.75,h*.85,L*.62,0,cc,{skylight:true,glassEnds:false,doorW:.1,doorH:.1});
  acNeedle(P,x,h+.5,z,2.2,h*1.8,cc);kput('archOpen',[x,2,z+Wd/2+.3],qFacing([0,0,1]),[.42,.45,1],null);}});
tpair('compound','Walled compound',30,false,(P,x,z,orig)=>{const ac=0xc98f5c,cc=TPAL[9];const W2=7.5,D2=7.5,h=6;if(orig){[[0,-D2,W2*2,1],[-W2,0,1,D2*2],[W2,0,1,D2*2],[-W2*.55,D2,W2*.9,1],[W2*.55,D2,W2*.9,1]].forEach(wl=>kput('boxW',[x+wl[0],1.1,z+wl[1]],null,[wl[2],2.2,wl[3]],tC(ac)));
  kput('frusPyr',[x,0,z],qEuler(0,.15,0),[W2*1.1*1.6,h*.7,D2*1.1*1.6],tC(cc));kput('boxW',[x-W2*.55,h*.3,z-D2*.5],null,[3,h*.6,3],tC(ac));kput('dome',[x-W2*.55,h*.6,z-D2*.5],null,[1.5,1.5,1.5],tC(ac));kput('boxD',[x,1.3,z+D2*.55],null,[1.6,2.6,.4],null);}
 else{const m=tsand(ac);for(let k=0;k<20;k++){const th=k/20*TAU;const r=W2*1.35*se(th,4);if(Math.abs(th-Math.PI/2)<.2)continue;kput('colW',[x+r*Math.cos(th),0,z+r*Math.sin(th)],null,[.8,3,.8],tC(ac,.9));}
  mesh(gridSurface((u,v)=>{const th=u*TAU;const r=W2*1.35*se(th,4);return[x+r*Math.cos(th),2.8+v*.7,z+r*Math.sin(th)];},64,1,{uS:20}),m,P);
  const Q=new THREE.Group();Q.position.set(x,0,z);P.add(Q);petalRing(Q,6,3.6,h*.9,4.2,1.2,.5,0,0,13,tsand(cc),null);mesh(lathe({rFn:yy=>3*Math.pow(clamp(1-Math.pow(yy/3,2),0,1),.6),H:3,nu:20,nv:5}),MAT.glass,Q,0,h*.6,0);
  mesh(lathe({rFn:yy=>1.6*(1-.05*Math.pow(yy/3.6,6)),H:3.6,nu:20,nv:4}),m,P,x-W2*.55,0,z-D2*.5);mesh(lathe({rFn:yy=>1.7*Math.sqrt(clamp(1-Math.pow(yy/1.4,2),0,1)),H:1.4,nu:20,nv:4}),m,P,x-W2*.55,3.5,z-D2*.5);
  kput('archOpen',[x,1.3,z+W2*1.35],qFacing([0,0,1]),[.25,.3,1],null);}});
tpair('midrise','Midrise',30,true,(P,x,z,orig)=>{const cc=TPAL[3];const w=7,h=22;if(orig){izBlock(x,0,z,w*1.15,h*.55,w*1.15,0,cc,{});izBlock(x,h*.55,z,w*.85,h*.3,w*.85,0,cc,{noDoor:true});izBlock(x,h*.85,z,w*.5,h*.15,w*.5,0,cc,{noDoor:true,plain:true,roof:true});}
 else{const R=4.2;const lobe=(th,yy)=>R*(1-.25*yy/h)*(1+.3*(.5+.5*Math.cos(8*th)));mesh(lathe({rFn:yy=>R*(1-.25*yy/h),H:h,flutes:8,amp:.3,sharp:1,nu:72,nv:20}),tsand(cc),P,x,0,z);
  for(let s=0;s<5;s++){const y=s*4.2;mesh(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(lobe(th,y+3.4)*.97,lobe(th,y+3.4)*1.1,v);return[x+r*Math.cos(th),y+3.6,z+r*Math.sin(th)];},72,2,{}),tsand(cc),P);
   for(let k=0;k<8;k++){const th=k/8*TAU;const r=lobe(th,y+1.8)+.1;kput('winSmI',[x+r*Math.cos(th),y+1.8,z+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1.4,1.4,1],null);}if(s%2===0)stripRing(x,y+2.4,z,R*(1-.25*y/h)*.85,0,16);}
  kput('slab',[x,h+.2,z],null,[R*.8,.5,R*.8],tC(cc,1.1));acPetalCrown(P,x,h,z,R*.8,3,cc,8);kput('archOpen',[x,1.6,z+lobe(Math.PI/2,1)-.2],qFacing([0,0,1]),[.3,.36,1],null);}});
tpair('stall','Market stall',14,false,(P,x,z,orig)=>{if(orig){[[-2.4,-1.7],[2.4,-1.7],[-2.4,1.7],[2.4,1.7]].forEach(p=>kput('boxW',[x+p[0],1.4,z+p[1]],null,[.25,2.8,.25],tC(TTIMBER)));kput('frusPyr',[x,2.8,z],null,[5.6,1.2,4.2],tC(0xe07a2a));kput('boxW',[x,.5,z+1.2],null,[4.4,1,1],tC(TTIMBER2));}
 else{mesh(lathe({rFn:yy=>.5*Math.sqrt(1+3*Math.pow((yy-1.6)/1.6,2)),H:3.2,nu:16,nv:6}),tsand(TPAL[6]),P,x,0,z);const Q=new THREE.Group();Q.position.set(x,3,z);P.add(Q);petalRing(Q,5,.4,1.2,3.2,3,1.4,0,0,17,tsand(0xe07a2a),null);
  kput('slab',[x,.5,z+1.4],null,[2.2,1,2.2],tC(TPAL[6],.9));stripRing(x,2.6,z,2,0,8);}});
tpair('fountain','Fountain',18,false,(P,x,z,orig)=>{if(orig){kput('slab',[x,.3,z],null,[5,.6,5],tC(TPAL[7]));kput('slab',[x,1.4,z],null,[1.6,1.6,1.6],tC(TPAL[7],.9));kput('slab',[x,2.6,z],null,[2.8,.4,2.8],tC(TPAL[7]));kput('slab',[x,3.6,z],null,[.8,1.6,.8],tC(TPAL[7],.9));kput('slab',[x,4.6,z],null,[1.6,.3,1.6],tC(TPAL[7]));izLamp(x,4.8,z);}
 else{mesh(lathe({rFn:yy=>5*Math.sqrt(clamp(1-Math.pow(yy/1.2,2),0,1))+.4,H:1.2,flutes:8,amp:.08,nu:48,nv:4}),tsand(TPAL[7]),P,x,0,z);for(let k=0;k<8;k++){const th=k/8*TAU;beam('strutW',[x+Math.cos(th)*3.6,1,z+Math.sin(th)*3.6],[x+Math.cos(th)*.8,5,z+Math.sin(th)*.8],.35,.3,tC(TPAL[7],.9));}
  kput('finial',[x,5.4,z],null,[.9,1.5,.9],null);stripRing(x,1.3,z,3.8,0,16);}});
tpair('temple','Temple — pyramid on legs',110,true,(P,x,z,orig)=>{const tm=0xd9924a,tmD=0xb8742e;const LEG=18,BASE=52;const m=tsand(tm),mD=tsand(tmD);
 [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(c=>{beam('strutW',[x+c[0]*33,0,z+c[1]*33],[x+c[0]*22,LEG+1,z+c[1]*22],5.5,4.5,tC(tmD));beam('strutW',[x+c[0]*30,0,z+c[1]*36],[x+c[0]*21,LEG+1,z+c[1]*23],2.4,2,tC(tmD));beam('strutW',[x+c[0]*36,0,z+c[1]*30],[x+c[0]*23,LEG+1,z+c[1]*21],2.4,2,tC(tmD));});
 mesh(gridSurface((u,v)=>{const th=u*TAU;const r=(BASE/2+5)*se(th,4)*(1-.04*v);return[x+r*Math.cos(th),LEG-2+v*3.5,z+r*Math.sin(th)];},96,2,{uS:30,vS:2}),mD,P);
 mesh(gridSurface((u,v)=>{const th=u*TAU;const r=(BASE/2+5)*se(th,4)*v;return[x+r*Math.cos(th),LEG+1.5,z+r*Math.sin(th)];},48,4,{}),m,P);
 for(let i=-3;i<=3;i++){kput('strip',[x+i*7,LEG-2.2,z+BASE/2+5.2],null,[3,1,1],CYAN);kput('strip',[x+BASE/2+5.2,LEG-2.2,z+i*7],qEuler(0,Math.PI/2,0),[3,1,1],CYAN);}
 let w=BASE,y=LEG+1.5;for(let i=0;i<3;i++){const h=10;const w0=w;mesh(gridSurface((u,v)=>{const th=u*TAU;const r=w0/2*se(th,3.5)*(1-.16*v)*(1+.05*Math.pow(.5+.5*Math.cos(th*16),3));return[x+r*Math.cos(th),y+v*h,z+r*Math.sin(th)];},112,8,{uS:24,vS:5}),m,P);
  kput('ringW',[x,y+h-.4,z],qEuler(Math.PI/2,0,0),[w0/2*.86,w0/2*.86,5],tC(0xf1dba6));if(i<2){const yy=y+h;mesh(lathe({rFn:()=>w0/2*.8*.98,H:2.2,nu:64,nv:1}),MAT.glass,P,x,yy,z);mesh(lathe({rFn:()=>w0/2*.76,H:2.2,nu:32,nv:1}),MAT.dark,P,x,yy,z);mullions(x,yy,z,w0/2*.8,2.2,24,0);stripRing(x,yy+1.2,z,w0/2*.7,0,24);}
  for(let k=0;k<12;k++){const th=(k+.5)/12*TAU;const r=w0/2*se(th,3.5)*(1-.08)+.1;kput('winI',[x+r*Math.cos(th),y+h*.5,z+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.7,.7,1],null);}
  y+=h+(i<2?2.2:0);w*=.72;}
 mesh(lathe({rFn:yy=>7*Math.pow(clamp(1-Math.pow(yy/9,2),0,1),.55),H:9,flutes:16,amp:.06,nu:48,nv:10,hole:(u,yy)=>Math.cos(u*TAU*16)<.3&&yy>1.5&&yy<7}),tsand(0xf1dba6),P,x,y,z);mesh(lathe({rFn:yy=>6.6*Math.pow(clamp(1-Math.pow(yy/9,2),0,1),.55),H:9,nu:32,nv:8}),MAT.glass,P,x,y,z);kput('finial',[x,y+10.5,z],null,[1.6,2.6,1.6],null);
 kput('archOpen',[x,y+3,z+6.6],qFacing([0,0,1]),[.7,.7,1],null);
 kput('slab',[x,.3,z],null,[24,.5,24],tC(0xf1dba6));mesh(lathe({rFn:yy=>4.5*(1-.15*yy/2.4),H:2.4,flutes:8,amp:.1,nu:32,nv:3}),mD,P,x,.5,z);kput('finial',[x,5,z],null,[1.6,1.6,1.6],null);kput('tube',[x,3.5,z],null,[.3,2,.3],null);
 for(let r=12;r<=20;r+=4)for(let i=0;i<Math.round(r*1.3);i++){const t=i/Math.round(r*1.3)*TAU;kput('boxW',[x+r*Math.cos(t),.85,z+r*Math.sin(t)],qEuler(0,-t,0),[2.4,.7,1],tC(tmD));}
 const top=[0,LEG+1.5+32,11.5],bot=[0,-.4,52];const rise=top[1]-bot[1],run=bot[2]-top[2];const th=Math.atan2(rise,run),Lr=Math.hypot(rise,run);kput('strutW',[x,bot[1]+rise/2,z+top[2]+run/2],qEuler(th,0,0),[9,1.2,Lr],tC(0xf1dba6));
 for(let k=1;k<6;k++){const t=k/6;const py=bot[1]+rise*t,pz=bot[2]-run*t;if(pz<BASE/2+5)continue;for(const s of [-1,1])beam('strutW',[x+s*6,0,z+pz+6],[x+s*3.6,py-.6,z+pz],1,.8,tC(tmD));}
 for(let k=0;k<10;k++){const t=(k+.5)/10;kput('strip',[x+4.6,bot[1]+rise*t+.2,z+bot[2]-run*t],null,[.4,1,1],CYAN);kput('strip',[x-4.6,bot[1]+rise*t+.2,z+bot[2]-run*t],null,[.4,1,1],CYAN);}});
tpair('palace','Palace fortress',150,true,(P,x,z,orig)=>{const sm=0xd4a05a,sl=0xe6bd7e;
 // RECESSED windows (Travis): a dark reveal set into the face, a warm pane at its back (the citadel is lit), and a proud
 // sandstone surround — two jambs, a lintel with a deco drip band, a sill — so each opening reads as cut into the mass
 const izOne=(px,py,pz,nx,nz,ww,wh)=>{const q=qEuler(0,Math.atan2(nx,nz),0),tx=nz,tz=-nx;
  kput('boxD',[px,py,pz],q,[ww,wh,1.0],null);kput('dot',[px-nx*.35,py,pz-nz*.35],q,[ww/1.5,wh/.8,.3],WARM.clone().multiplyScalar(.75));
  for(const sd of[-1,1])kput('boxW',[px+tx*sd*(ww/2+.3)+nx*.35,py,pz+tz*sd*(ww/2+.3)+nz*.35],q,[.6,wh+.4,.7],tC(sl));
  kput('boxW',[px+nx*.4,py+wh/2+.35,pz+nz*.4],q,[ww+1.4,.7,.8],tC(sl));kput('boxW',[px+nx*.55,py+wh/2+.85,pz+nz*.55],q,[ww+.6,.25,.5],tC(sm,.9));
  kput('boxW',[px+nx*.45,py-wh/2-.25,pz+nz*.45],q,[ww+1.0,.5,.9],tC(sl));};
 const izWin=(cx,cz,w,d,taper,h,y0,rowY,n,ww,wh,skip)=>{const f=(rowY-y0)/h,hw=w/2*(1-(1-taper)*f),hd=d/2*(1-(1-taper)*f);for(let i=0;i<n;i++){const u=((i+.5)/n-.5)*1.7;
   if(!(skip&&skip(cx+u*hw)))izOne(x+cx+u*hw,rowY,z+cz+hd,0,1,ww,wh);izOne(x+cx+u*hw,rowY,z+cz-hd,0,-1,ww,wh);izOne(x+cx+hw,rowY,z+cz+u*hd,1,0,ww,wh);izOne(x+cx-hw,rowY,z+cz+u*hd,-1,0,ww,wh);}};
 // tiers 1-2 solid; tier 3 is built in parts round the HALL (the old hangar, hollow now): rear mass, two flanks, a lintel
 kput('frus93',[x,0,z],null,[96,14,84],tC(sm));kput('frus90',[x+4,14,z-4],null,[68,14,58],tC(sm));
 kput('frus88',[x+8,28,z-15],null,[46,22,26],tC(sm));kput('frus88',[x-12.5,28,z+5],null,[5,22,14],tC(sm));kput('frus88',[x+19.5,28,z+5],null,[23,22,14],tC(sm));kput('frus88',[x-1,39,z+5],null,[18,11,14],tC(sm));
 kput('frus85',[x+16,50,z-10],null,[20,30,20],tC(sm));kput('frus85',[x+16,80,z-10],null,[14,11,14],tC(sl));kput('frus60',[x+16,91,z-10],null,[8,7,8],tC(sm));kput('frusPyr',[x+16,98,z-10],null,[5,6,5],tC(sl));
 kput('boxW',[x,12.6+.75,z],null,[91,1.5,80],tC(sl));kput('boxW',[x+4,26.6+.75,z-4],null,[63,1.5,54],tC(sl));kput('boxW',[x+8,48.6+.75,z-8],null,[42,1.5,37],tC(sl));kput('boxW',[x+16,78.8+.7,z-10],null,[18.5,1.4,18.5],tC(sl));
 izWin(0,0,96,84,.93,14,0,7,9,3,4);izWin(4,-4,68,58,.9,14,14,20,6,3,4);izWin(8,-8,46,40,.88,22,28,34,6,2.2,4,xx=>xx>-11&&xx<9);izWin(8,-8,46,40,.88,22,28,43,6,2.2,3,xx=>xx>-11&&xx<9);for(let i=0;i<3;i++)izWin(16,-10,20,20,.85,30,50,56+i*8,2,3,3);
 // THE HALL (Travis): the hangar converted for entertaining Izani and foreign nobles — 18 x 14 m, 11 m high, open to the
 // terrace: a lit floor, two rows of pale columns, a coffered ceiling of warm lamps, a great doorway into the palace at the back
 {const hy=28.1,hx=x-1,hz=z+5;kput('slab',[hx,hy-.05,hz],null,[9.6,.3,9.6],tC(0xe6d6b0));                      // the floor medallion
  for(const sx of[-6.5,6.5])for(const zz of[-3.2,1.2,5.6])kput('colW',[hx+sx,hy,hz+zz],null,[.9,10.9,.9],tC(sl));
  for(let i=-1;i<=1;i++)for(let j=0;j<3;j++)kput('dot',[hx+i*5,hy+10.6,hz-4.5+j*4.5],qEuler(Math.PI/2,0,0),[1.6,1.6,1],WARM);   // ceiling lamps
  kput('boxD',[hx,hy,z-1.9],null,[7,8,.6],null);kput('boxW',[hx,hy+8,z-1.9],null,[8.4,.9,1.2],tC(sl));for(const sx of[-4.6,4.6])kput('boxW',[hx+sx,hy,z-1.9],null,[1.2,8.6,1.2],tC(sl));   // the great door to the palace
  for(const sx of[-4.6,4.6])kput('dot',[hx+sx,hy+6.5,z-1.4],null,[1,1.4,.5],WARM);
  for(const sx of[-8.3,8.3])for(const zz of[1,7])kput('dot',[hx+sx,hy+5,hz+zz],null,[.5,1.2,1],WARM);              // wall sconces
  kput('boxW',[hx,39.2,z+12.3],null,[19.6,1.2,1.6],tC(sl));for(const sx of[-9.6,9.6])kput('boxW',[hx+sx,hy-.1,z+12.3],null,[1.4,11.4,1.4],tC(sl));   // the hall's frame: lintel and jambs, kept inside the tier's corners
  for(let i=-4;i<=4;i++)kput('dot',[hx+i*2.1,hy-.05,z+13.1],null,[1.2,.25,.5],WARM);                                  // the lit threshold
  // the GREAT AWNING: orange cloth from the lintel out over the terrace on two stone poles, tie rods back to the wall
  kput('vClothB',[hx,50.1-Math.tan(.36)*5.2,z+17.6],qEuler(.36,0,0),[25,.16,11.2],vC(0xe07a2a));
  for(const sx of[-11.5,11.5]){kput('vPostS',[hx+sx,28.1,z+21.4],null,[.55,18.4,.55],tC(sl));kput('vBall',[hx+sx,46.7,z+21.4],null,[.5,.5,.5],vC(0x8a6a2a));beam('vIron',[hx+sx,46.4,z+21.2],[hx+sx*.8,50.4,z+12.4],.06,.06,vC(0x2e2a26));}
  for(let i=0;i<6;i++)kput('vCloth',[hx-10.4+i*4.16,45.6,z+22.9],qEuler(0,0,0),[3.6,1.4,1],vC(i%2?0xd8893c:0xc9442a));}   // the valance
 // THE GARDEN TERRACE on the second tier's roof, either side of the hall's approach: balustrade, planters and hedges,
 // benches, lamp posts, two stairs down to the first tier's roof garden
 {const ty=28.1,front=z+22.4;kput('boxW',[x+4,ty+1.1,front],null,[63,.35,.6],tC(sl));for(let i=0;i<=14;i++)kput('boxW',[x+4-31.5+i*4.5,ty,front],null,[.5,1.1,.5],tC(sl));
  for(const sx of[-27,-19,-11,12,20,28]){vnPlanter(x+sx,ty,z+18,5.2,1.8,0,vC(0x8a6a46));kput('hedge',[x+sx,ty+.6,z+14.6],null,[5.2,1.2,1.2],vC(0x3f6a34));}
  for(const sx of[-23,-15,16,24])kput('vWood',[x+sx,ty+.25,z+16.3],null,[2.4,.5,.6],vC(0x6a4a30));
  for(const sx of[-29,-13,11,27])vnLampPost(x+sx,ty,z+20.6,3.4);
  for(const s of[-1,1]){for(let k=0;k<8;k++)kput('boxW',[x+4+s*33.5,14+k*1.75,z+8-k*1.05],null,[3.2,1.75,1.1],tC(sl));}   // stairs down the flanks
  kput('slab',[x-1,ty-.05,z+16],null,[3.2,.25,3.2],tC(0xe6d6b0));}
 // roof-garden on the first tier's roof: hedges along the parapet, lamp posts; crenellated parapets on both lower tiers
 {const ty=14.1;for(let i=0;i<10;i++){const sx=-40+i*8.9;if(Math.abs(sx-4)<12)continue;kput('hedge',[x+sx,ty+.6,z+36],null,[4.6,1.2,1.4],vC(0x3f6a34));}
  for(const sx of[-40,-24,32,44])vnLampPost(x+sx,ty,z+38.6,3.2);
  for(let i=0;i<22;i++)kput('boxW',[x-44+i*4.2,ty+1.1,z+39.4],null,[1.6,1.0,1.0],tC(sl));for(let i=0;i<15;i++)kput('boxW',[x+4-30+i*4.3,28.1+1.1,z-4-26.4],null,[1.6,1.0,1.0],tC(sl));}
 // banner poles and lamp columns along the front of the base tier
 for(let i=0;i<7;i++){const sx=-42+i*14;vnBannerPole(x+sx,0,z+44.5,0,9,vC(i%2?0xe07a2a:0xc9442a));}
 for(const sx of[-36,-12,12,36])vnLampPost(x+sx,0,z+46,4.2);
 // pyramidal roofs and pavilions on the terrace tops, the beacon (from the Iziz Ancients Mix palace)
 // the terrace pavilions (Travis: develop the bare pyramids and cubes): each PYRAMID becomes an open pavilion — a paved
 // floor, four columns, an architrave, the pyramid roof lifted onto it with a lantern — and each CUBE a belvedere — a
 // windowed room with a cornice, a pyramid cap and a banner. The two that sat inside the hall's masses are gone.
 const izPav=(px,py,pz)=>{kput('slab',[x+px,py+.15,z+pz],null,[6.2,.3,6.2],tC(0xe6d6b0));for(const a of[-1,1])for(const b of[-1,1])kput('colW',[x+px+a*4,py+.3,z+pz+b*4],null,[.55,5.4,.55],tC(sl));
  for(const a of[-1,1]){kput('boxW',[x+px,py+6,z+pz+a*4],null,[9.4,.9,.9],tC(sl));kput('boxW',[x+px+a*4,py+6,z+pz],null,[.9,.9,9.4],tC(sl));}
  kput('frusPyr',[x+px,py+6.45,z+pz],null,[10,6.5,10],tC(sl));kput('boxW',[x+px,py+6.4,z+pz],null,[10.4,.3,10.4],tC(sm,.9));kput('lampI',[x+px,py+4.6,z+pz],null,[.6,.8,.6],WARM);
  for(const a of[-1,1])vnPlanter(x+px+a*5.8,py,z+pz+5.6,2.2,.8,0,vC(0x8a6a46));kput('vWood',[x+px,py+.55,z+pz],null,[2.6,.5,.7],vC(0x6a4a30));};
 const izBelv=(px,py,pz,i)=>{kput('boxW',[x+px,py+4,z+pz],null,[9,8,7.4],tC(sm));kput('boxW',[x+px,py+.4,z+pz],null,[9.8,.8,8.2],tC(sl));
  for(const a of[-1,1]){for(const k of[-2.6,0,2.6])izOne(x+px+k,py+4.6,z+pz+a*3.72,0,a,1.3,2.6);izOne(x+px+a*4.52,py+4.6,z+pz,a,0,1.3,2.6);}
  kput('boxW',[x+px,py+8.2,z+pz],null,[10.2,.6,8.6],tC(sl));kput('boxW',[x+px,py+8.7,z+pz],null,[9.4,.4,7.8],tC(sm,.9));kput('frusPyr',[x+px,py+8.9,z+pz],null,[8.6,5,7],tC(sl));
  vnBannerPole(x+px+4.2,py+8.9,z+pz+3.4,0,5,vC(i%2?0xe07a2a:0xc9442a));};
 [[-36,14,-30],[36,14,-32],[-38,14,-12],[-6,50,-20]].forEach(p=>izPav(p[0],p[1],p[2]));
 [[-38,14,4],[38,14,4],[-4,50,4]].forEach((p,i)=>izBelv(p[0],p[1],p[2],i));
 kput('lampI',[x+16,105,z-10],null,[1.4,2,1.4],WARM);});
tpair('arena','Arena',130,true,(P,x,z,orig)=>{const cc=0xd4a05a,ccL=0xe6bd7e;const A0=48,B0=40;const m=tsand(cc),mL=tsand(ccL);
 mesh(gridSurface((u,v)=>{const th=u*TAU;const s=1-.12*v+.05*Math.sin(Math.PI*v);return[x+A0*s*Math.cos(th)*(1+.03*Math.pow(.5+.5*Math.cos(th*24),3)),v*21,z+B0*s*Math.sin(th)];},144,10,{uS:40,vS:6,hole:(u,v)=>Math.abs(((u*24)%1)-.5)<.18&&v>.12&&v<.62}),m,P);
 mesh(gridSurface((u,v)=>{const th=u*TAU;const s=.86;return[x+A0*s*Math.cos(th),2+v*17,z+B0*s*Math.sin(th)];},96,2,{}),MAT.dark,P);
 for(let k=0;k<36;k++){const th=k/36*TAU;beam('strutW',[x+(A0+8)*Math.cos(th),0,z+(B0+7)*Math.sin(th)],[x+A0*.9*Math.cos(th),21,z+B0*.9*Math.sin(th)],1.6,1.3,tC(cc,.85));}
 mesh(gridSurface((u,v)=>{const th=u*TAU;const s=lerp(.88,.98,v);return[x+A0*s*Math.cos(th),21+v*4,z+B0*s*Math.sin(th)];},96,2,{uS:40}),mL,P);
 for(let k=0;k<24;k++){const th=(k+.5)/24*TAU;kput('strip',[x+A0*.93*Math.cos(th),24.6,z+B0*.93*Math.sin(th)],qEuler(0,-th-Math.PI/2,0),[6,1,1],CYAN);}
 for(let k=0;k<6;k++){const a=A0-9-k*3.1,b=B0-8-k*2.7;mesh(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(a-3.1,a,v);return[x+r*Math.cos(th),12-k*2+(v<.5?2:0),z+r*b/a*Math.sin(th)];},96,2,{}),mL,P);}
 for(let k=0;k<8;k++){const th=(k+.5)/8*TAU;const px=x+A0*.72*Math.cos(th),pz=z+B0*.72*Math.sin(th);mesh(lathe({rFn:yy=>.5*Math.sqrt(1+2*Math.pow((yy-5)/5,2)),H:10,nu:12,nv:4}),mL,P,px,22,pz);
  const Q=new THREE.Group();Q.position.set(px,31,pz);Q.rotation.y=-th;P.add(Q);petalRing(Q,3,.4,3,8,9,1.6,0,0,20+k,tsand(0xf1dba6),null);}
 kput('slab',[x,.2,z],null,[A0-28,.4,B0-24],tC(0xd8c090));for(let k=0;k<4;k++){const th=k/4*TAU+Math.PI/4;kput('archOpen',[x+A0*.98*Math.cos(th),5,z+B0*.98*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1.4,1.1,2],null);}});
// Pueblo: defined for completeness, EXCLUDED from placement (Travis, round 2).
tpair('pueblo','Pueblo (adobe stack)',26,false,(P,x,z,orig)=>{const ac=0xd6a06a;const w=6,d=6,h1=6,h2=4.5;kput('boxW',[x,h1/2,z],null,[w*1.9,h1,d*1.9],tC(ac));kput('boxW',[x,h1-.3,z],null,[w*1.9+.3,.6,d*1.9+.3],tC(ac,1.1));
 kput('boxW',[x-w*.3,h1+h2/2,z-d*.35],null,[w*1.2,h2,d*1.1],tC(ac));kput('boxD',[x+w*.2,1.2,z+d*.95+.1],null,[1.5,2.4,.4],null);});
const TRANS_EXCLUDE={pueblo:1};
// footprint half-extents of each kind at scale 1 (from the Mix's REFHALF), used by the city to fit lots
const TREFHALF={box:[3.4,3.4],tier:[3.6,3.6],domed:[3.4,3.4],barrel:[3.6,4.8],tent:[4.8,4.6],pyr:[3.75,3.75],setback:[7,7],setback2:[3.7,3.7],tyrell:[7,7],wedge:[5,7],pent:[6.6,6.6],hept:[6.6,6.6],hall:[9,7.5],stave:[7.5,7.5],compound:[10.2,10.2],midrise:[5.5,5.5],stall:[3,2.4],fountain:[5.4,5.4],temple:[42,52],palace:[52,46],arena:[56,48]};
const TKINDS={dwelling:['box','tier','domed','barrel','tent','pyr'],tall:['setback','setback2','tyrell','wedge','pent','hept','midrise'],hall:['hall','stave','compound']};
// ---- placement -----------------------------------------------------------------------------------------------------
MAT.tGlassO=new THREE.MeshStandardMaterial({color:0x2a4a66,metalness:.55,roughness:.18,emissive:0x0a1a2a,emissiveIntensity:.5,side:DS});
const TRANS={groups:[],root:null,
 place(scene,kind,mode,x,z,ry,scale,seed,extraTags,y){y=y||0;const p=TBY[kind];if(!p||TRANS_EXCLUDE[kind]){reportErr('TRANS.place: '+kind+' not placeable');return null;}
  if(!TRANS.root){TRANS.root=new THREE.Group();scene.add(TRANS.root);}
  if(kind==='pent'||kind==='hept'){mode=mode==='orig'?'anc':mode==='ruin'?'ancruin':mode==='rehab'?'ancrehab':mode;}   // Travis: only the transplant versions of these two
  const orig=mode==='orig'||mode==='ruin'||mode==='rehab';const wmode=mode==='ruin'||mode==='ancruin'?'ruin':(mode==='rehab'||mode==='ancrehab')?'rehab':null;
  scale=scale||1;ry=ry||0;reseed(seed);const ranges={};for(const n in KIT.items)ranges[n]=KIT.items[n].length;
  const P=new THREE.Group();P.position.set(x,y,z);P.rotation.y=ry;P.scale.setScalar(scale);scene.add(P);P.updateMatrixWorld(true);
  KOFF=[0,0,0];useGroupXF(P);if(scale!==1)KXF.s=scale;
  try{p.fn(P,0,0,orig);}catch(e){reportErr('transplant '+kind+' '+e.stack);}
  endGroupXF();
  if(wmode){try{wreck(P,TRANS.root,ranges,wmode,x,z,seed+1);}catch(e){reportErr('wreck '+kind+' '+e.stack);}}
  P.traverse(m=>{if(m.isMesh&&m.material===MAT.glass)m.material=MAT.tGlassO;});
  TRANS.groups.push(P);
  const isDw=TKINDS.dwelling.includes(kind),isTall=TKINDS.tall.includes(kind);
  const type=kind==='temple'?['religious','civic']:kind==='palace'?['civic','military']:kind==='arena'?['civic']:kind==='hall'?['tavern/inn']:kind==='stall'?['market/shop']:kind==='fountain'?['civic']:isTall?['multi-family dwelling']:kind==='compound'?['single-family dwelling']:kind==='stave'?['civic']:['single-family dwelling'];
  const state=wmode==='ruin'?'destroyed':wmode==='rehab'?'rehabilitated':'intact';
  REG.push({name:p.name+(orig?' — Iziz original':' — Ancients transplant')+(wmode?' — '+state:''),x,y,z,r:p.size*.45*scale,h:p.size*1.2*scale,cls:'building',key:'trans_'+kind,
   tags:Object.assign({culture:orig?'iziz-old':'ancients-transplant',type,wealth:isTall?'middle':'middle',state,lit:wmode!=='ruin'},extraTags||{})});
  return P;},
 // merge every one-off mesh in the placed groups by material into one draw call each (the Mix's ANC.bake)
 bake(scene){const groups=TRANS.groups.slice();if(TRANS.root)groups.push(TRANS.root);const byMat=new Map();const list=[];
  for(const G of groups){G.updateMatrixWorld(true);G.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh)list.push(o);});}
  for(const m of list){const k=m.material.uuid;if(!byMat.has(k))byMat.set(k,{mat:m.material,geos:[]});const geo=(m.geometry.index?m.geometry.toNonIndexed():m.geometry).clone();geo.applyMatrix4(m.matrixWorld);if(!geo.attributes.normal)geo.computeVertexNormals();else geo.computeVertexNormals();if(!geo.attributes.uv)geo.setAttribute('uv',new THREE.Float32BufferAttribute(new Float32Array(geo.attributes.position.count*2),2));byMat.get(k).geos.push(geo);m.parent.remove(m);}
  const out=new THREE.Group();scene.add(out);let calls=0;
  for(const e of byMat.values()){let nv=0;for(const g of e.geos)nv+=g.attributes.position.count;const P=new Float32Array(nv*3),N=new Float32Array(nv*3),U=new Float32Array(nv*2);let o=0;
   for(const g of e.geos){P.set(g.attributes.position.array,o*3);N.set(g.attributes.normal.array,o*3);U.set(g.attributes.uv.array,o*2);o+=g.attributes.position.count;}
   const G=new THREE.BufferGeometry();G.setAttribute('position',new THREE.BufferAttribute(P,3));G.setAttribute('normal',new THREE.BufferAttribute(N,3));G.setAttribute('uv',new THREE.BufferAttribute(U,2));
   const mm=new THREE.Mesh(G,e.mat);mm.frustumCulled=false;out.add(mm);calls++;}
  window._transMerged=calls;return out;},
 kinds:Object.keys(TBY).filter(k=>!TRANS_EXCLUDE[k]),TKINDS,TREFHALF,by:TBY};
// ================================================================= GOVERNMENT v2 — "the Assembly" (all round)
function buildGovernment(scene,gx,gz,d){reseed(9900+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 REGISTER({name:'Government — the Assembly ('+STATE(d)+')',x:0,z:0,r:150,h:120});
 const tiers=[[92,84,14],[66,60,14],[42,38,14]];let y=0;
 tiers.forEach((t,i)=>{const [a,b,h]=t;const hole=holeFn(d*(i===2?1:.5),600+i,null,1.3);
  mesh(lathe({rFn:yy=>a-(a-b)*yy/h,H:h,flutes:24-i*6,amp:.05,sharp:2,nu:120,nv:6,hole:hole?(u,yy)=>hole(u,yy+i*30)&&(u>.15&&u<.42):null}),skin,G,0,y,0);
  if(d>0)mesh(lathe({rFn:yy=>(a-(a-b)*yy/h)*.9,H:h,nu:48,nv:1}),MAT.guts,G,0,y,0);
  kput('slab',[0,y+h,0],null,[b*.99,.6,b*.99],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  const n=Math.round(a*.42);for(let k=0;k<n;k++)for(let row=0;row<2;row++){const th=(k+.5)/n*TAU;const yy=y+3.5+row*6;const r=a-(a-b)*(yy-y)/h+.2;const u=th/TAU;if(hole&&hole(u,yy+i*30))continue;
   if(i===0&&row===0&&Math.abs(th-Math.PI/2)<.5)continue;kput(d>0?'winD':'winI',[r*Math.cos(th),yy,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.9,.9,1],null);}
  stripRing(0,y+h-1.2,0,b*1.01,d,48);if(d>0)mossOnRing(0,y+h+.2,0,b*.9,Math.round(b*.8),2.2);y+=h;});
 // portico: a fan of leaning struts on the +z face, rising to a ring beam at tier 2, roofed by a curved shell that grows out of the tier wall
 const NP=11;const struts=[];for(let k=0;k<NP;k++){const a=Math.PI/2+(k-(NP-1)/2)*.11;const fallen=d>0&&(k===2||k===7);
  const A=[Math.cos(a)*130,0,Math.sin(a)*130],B=[Math.cos(a)*64,29,Math.sin(a)*64];struts.push([a,A,B]);
  if(!fallen)beam(d>0?'strutR':'strutW',A,B,4.5,3.5);else beam('strutR',[A[0],2,A[2]],[A[0]*.7+rr(-8,8),3,A[2]*.72],4.5,3.5);}
 const a0=Math.PI/2-(NP-1)/2*.11-.05,a1=Math.PI/2+(NP-1)/2*.11+.05;
 // ring beam on the strut tops, a light glass roof back to the tier-2 wall, and a comb of bone fins above the beam
 for(let k=0;k<NP-1;k++){const A=struts[k][2],B=struts[k+1][2];beam(d>0?'strutR':'strutW',[A[0],A[1]+1,A[2]],[B[0],B[1]+1,B[2]],3,3.5);}
 if(d===0)mesh(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(40,64,v);return[Math.cos(a)*r,27+3.5*v,Math.sin(a)*r];},30,4,{}),MAT.glass,G);
 for(let k=0;k<NP-1;k++)for(let j=0;j<3;j++){const A=struts[k][2],B=struts[k+1][2];const t=(j+.5)/3;const x=lerp(A[0],B[0],t),z=lerp(A[2],B[2],t);if(d>0&&rng()<.4)continue;
  const a=Math.atan2(z,x);const h=rr(6,11);beam(d>0?'strutR':'strutW',[x,31,z],[x-Math.cos(a)*2,31+h,z-Math.sin(a)*2],1.2,.9);}
 for(let j=0;j<=6;j++){const a=lerp(a0,a1,j/6);beam(d>0?'strutR':'strutW',[Math.cos(a)*40,27,Math.sin(a)*40],[Math.cos(a)*64,30.5,Math.sin(a)*64],1,1.4);}
 for(let k=0;k<7;k++){const a=lerp(a0,a1,(k+.5)/7);const lit=d>0?rng()<.15:true;kput('strip',[Math.cos(a)*70,29.3,Math.sin(a)*70],qEuler(0,-a+Math.PI/2,0),[20,1,1],lit?CYAN:DEAD);}
 kput('archOpen',[0,8,91],qFacing([0,0,1]),[2.2,2.2,3],null);kput('slab',[0,.6,110],null,[40,1.2,40],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
 for(let k=0;k<3;k++)kput(d>0?'boxR':'boxW',[0,.4+k*1.2,88+k*3],null,[30,1.2,3],null);
 // petal council chamber + spire
 const P=new THREE.Group();P.position.set(0,42,0);G.add(P);useGroupXF(P);
 petalRing(P,8,23,36,15,4,1,0,d,650,skin,d>0?(i=>i===1||i===4||i===6):null);
 if(d===0)mesh(lathe({rFn:yy=>19*Math.pow(clamp(1-Math.pow(yy/27,2),0,1),.6),H:27,nu:48,nv:14}),MAT.glass,P,0,1,0);
 else mesh(lathe({rFn:yy=>18*Math.pow(clamp(1-Math.pow(yy/27,2),0,1),.6),H:27,nu:48,nv:14,hole:(u,yy)=>fbm(u*3,yy*.1,660,2)<.5}),MAT.dark,P,0,1,0);
 stripRing(0,4,0,17,d,32);const SH=40,scut=d>0?SH*.45:null;mesh(lathe({rFn:yy=>3*(1-.6*yy/SH)+.4,H:SH,cut:scut,jag:scut?1.5:0,flutes:6,amp:.25,nu:24,nv:16}),skin,P,0,27,0);
 if(!scut)kput('finial',[0,27+SH+2,0],null,[3,5,3],null);endGroupXF();
 if(d>0){const fm=mesh(petalGeo(23,36,15,4,1,holeFn(1,661,null,1.5)),MAT.rust,G,-60,4,70);fm.rotation.set(0,1.2,Math.PI/2*.85);dropFragment(fm);rubbleRing(-60,0,70,5,30,50,2.5);
  scatterMoss(0,0,0,100,190,140,3);rubbleRing(0,0,0,96,150,70,2.5);trees(0,0,120,220,18);}
 figures(0,150,8,10);figures(-70,110,4,5);KOFF=[0,0,0];return G;}

// ================================================================= IZIZ ORIGINAL — the painting's own structures, ported from the Iziz Ancients Mix
// The outer wall with its tetragonal wedge towers, gatehouses and bridges over the moat; the palace curtain wall in the
// ANCIENT style with sentry towers (Travis, round 2); the barracks wedges; the heroic statues; the observation tower in
// ruined colours; the spaceport, ruined. All parametrised on the city's geometry (wallR, gates, terrainH) so the same
// builders serve the original 235 m plateau and the new 470 m one.
MAT.izWall=new THREE.MeshStandardMaterial({map:TEX.stone,color:0xe07a2a,roughness:.95,side:DS});vWorldUV(MAT.izWall,.25);
MAT.izWallDark=new THREE.MeshStandardMaterial({map:TEX.stone,color:0xa8521a,roughness:.95,side:DS});vWorldUV(MAT.izWallDark,.25);
MAT.izCap=new THREE.MeshStandardMaterial({map:TEX.stone,color:0xf2a24a,roughness:.9,side:DS});vWorldUV(MAT.izCap,.25);
MAT.izSand=new THREE.MeshStandardMaterial({map:TEX.stone,color:0xe2b676,roughness:.95,side:DS});vWorldUV(MAT.izSand,.25);
MAT.izRock=new THREE.MeshStandardMaterial({map:TEX.concrete,color:0x6a4a34,roughness:1,side:DS});vWorldUV(MAT.izRock,.125);
MAT.bronze=new THREE.MeshStandardMaterial({color:0x9a7a3c,roughness:.45,metalness:.7});MAT.bronzeDark=new THREE.MeshStandardMaterial({color:0x6e5428,roughness:.5,metalness:.7});
kdef('izWedge',vnWedgeGeo(.36,.28),MAT.izWall);kdef('izWedgeS',vnWedgeGeo(.36,.28),MAT.izSand);kdef('izWedgeD',vnWedgeGeo(.36,.28),MAT.izWallDark);
kdef('izBoxW',VBOX,MAT.izWall);kdef('izBoxD',VBOX,MAT.izWallDark);kdef('izBoxCap',VBOX,MAT.izCap);kdef('izBoxS',VBOX,MAT.izSand);kdef('izRockB',VBOX,MAT.izRock);
kdef('izFrus',vnWedgeGeo(.86,.9),MAT.izWall);kdef('izFrusS',vnWedgeGeo(.85,.85),MAT.izSand);kdef('izFrusCap',vnWedgeGeo(.9,.9),MAT.izCap);kdef('izPyrS',vnWedgeGeo(.06,.06),MAT.izSand);kdef('izOct',new THREE.CylinderGeometry(.86,1,1,8).rotateY(Math.PI/8).translate(0,.5,0),MAT.izSand);kdef('izOctCap',new THREE.CylinderGeometry(1,1,1,8).rotateY(Math.PI/8).translate(0,.5,0),MAT.izCap);
kdef('izOctR',new THREE.CylinderGeometry(.86,1,1,8).rotateY(Math.PI/8).translate(0,.5,0),MAT.concreteR);kdef('izOctRust',new THREE.CylinderGeometry(.9,1,1,8).rotateY(Math.PI/8).translate(0,.5,0),MAT.rust);
kdef('izBronze',VBOX,MAT.bronze);kdef('izBronzeD',VBOX,MAT.bronzeDark);kdef('izBronzeCyl',new THREE.CylinderGeometry(1,1,1,7).translate(0,.5,0),MAT.bronze);kdef('izBronzeOct',new THREE.OctahedronGeometry(1,0),MAT.bronze);kdef('izBronzeCone',new THREE.ConeGeometry(1,1,4).translate(0,.5,0),MAT.bronzeDark);kdef('izBronzeTor',new THREE.TorusGeometry(1,.08,6,20),MAT.bronzeDark);
kdef('izGlow',VBALL,MAT.bulb);kdef('izSteel',new THREE.CylinderGeometry(1,1,1,12).translate(0,.5,0),MAT.rust);kdef('izSteelBox',VBOX,MAT.rust);kdef('izRustB',VBOX,MAT.rust);
const IZ_ORANGE=vC(0xe07a2a);
// the citadel's board-formed concrete, tinted to the palace's sandstone (Travis: the curtain wall matches the palace)
const IZ_CONC_TINT=vC(0xe8b070);
MAT.izConcOrange=MAT.concrete.clone();MAT.izConcOrange.color=new THREE.Color(0xe0a868);if(MAT.concrete.onBeforeCompile)MAT.izConcOrange.onBeforeCompile=MAT.concrete.onBeforeCompile;

// ---- the outer wall: rampart segments merged per material; wedge towers; rock foundation down through the moat ----
function izOuterWall(scene,wallR,cx,cz,n,H,wb,wt,skipFn,towerEvery){
 const shape=new THREE.Shape();shape.moveTo(-wb/2,0);shape.lineTo(wb/2,0);shape.lineTo(wt/2,H);shape.lineTo(-wt/2,H);shape.closePath();
 const segs=[],G=new THREE.Group();scene.add(G);
 for(let i=0;i<n;i++){const t0=i/n*TAU,t1=(i+1)/n*TAU;if(skipFn&&skipFn((t0+t1)/2))continue;
  const a=[cx+wallR(t0)*Math.cos(t0),cz+wallR(t0)*Math.sin(t0)],b=[cx+wallR(t1)*Math.cos(t1),cz+wallR(t1)*Math.sin(t1)];
  const len=Math.hypot(b[0]-a[0],b[1]-a[1]),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);const base=Math.min(terrainH(a[0],a[1]),terrainH(b[0],b[1]))-3;
  const geo=new THREE.ExtrudeGeometry(shape,{depth:len+1.2,bevelEnabled:false});geo.rotateY(Math.PI/2-ang);geo.translate(a[0],base,a[1]);{const u=geo.attributes.uv.array;for(let k=0;k<u.length;k++)u[k]*=.25;}segs.push(geo);   // extrude UVs are metres; the stone tile is 4 m
  const mx=(a[0]+b[0])/2,mz=(a[1]+b[1])/2;
  kput('izRockB',[mx,base-20,mz],qEuler(0,-ang,0),[len+1.4,40.5,wb+3],null);                 // rock foundation down through the moat
  kput('izBoxCap',[mx,base+H+.3,mz],qEuler(0,-ang,0),[len+1.2,1.4,wt+1.2],null);              // parapet band
  if(i%towerEvery===0){const ty=terrainH(a[0],a[1])-3;                                          // tetragonal wedge tower: wide along the wall, pinched to a ridge, blank faces
   kput('izRockB',[a[0],ty-20,a[1]],qEuler(0,-ang,0),[wt+22,40.5,wt+12],null);
   kput('izWedgeD',[a[0],ty,a[1]],qEuler(0,-ang,0),[wt+22,H+22,wt+10],null);
   kput('izBoxCap',[a[0],ty+H+22.45,a[1]],qEuler(0,-ang,0),[(wt+22)*.36+.6,.9,(wt+10)*.28+.6],null);
   REG.push({name:'Outer wall tower '+(i/towerEvery+1|0),x:a[0],y:terrainH(a[0],a[1])-6,z:a[1],r:16,h:H+50,cls:'building',key:'iziz_wall_tower',tags:{culture:'iziz-old',type:['military','infrastructure'],wealth:'civic',lit:false}});}}
 meshMerged(segs,MAT.izWall,G);
 for(let i=0;i<36;i++){const t=i/36*TAU,R=wallR(t);REG.push({name:'Outer wall',x:cx+R*Math.cos(t),y:terrainH(cx+R*Math.cos(t),cz+R*Math.sin(t))-6,z:cz+R*Math.sin(t),r:30,h:H+30,cls:'building',key:'iziz_wall',tags:{culture:'iziz-old',type:['military','infrastructure'],wealth:'civic',lit:false}});}
 return G;}
// ---- outer gate: sloped gatehouse, deco lintel bands, wedge flankers with gun turrets, bridge on piers across the moat ----
function izGate(scene,g,R,plateau,idx){const cx=R*Math.cos(g),cz=R*Math.sin(g);const W=(lx,ly,lz)=>[cx+lx*Math.cos(g)-lz*Math.sin(g),ly,cz+lx*Math.sin(g)+lz*Math.cos(g)];const q=qEuler(0,-g,0);
 const P=(item,lx,ly,lz,sx,sy,sz,c)=>{const p=W(lx,ly,lz);kput(item,[p[0],plateau+ly+sy/2,p[2]],q,[sx,sy,sz],c||null);};
 const F=(item,lx,ly,lz,sx,sy,sz)=>{const p=W(lx,ly,lz);kput(item,[p[0],plateau+ly,p[2]],q,[sx,sy,sz],null);};   // wedge/frustum items: base at y
 [-1,1].forEach(sd=>F('izFrus',0,-2,sd*15.75,28,38,18.5));
 P('izBoxW',0,22,0,26,14,14);F('izFrusCap',0,36,0,24,8,42);
 [-1,1].forEach(sd=>P('izBoxD',0,0,sd*6.7,24,22,.5));P('izBoxD',0,21.6,0,24,.5,13.5);
 P('izRustB',0,29,0,1.4,15,12.6);                                                                   // the door, raised open into the lintel by day
 F('izWedgeD',-2,-2,34,22,52,30);F('izWedgeD',-2,-2,-34,22,52,30);P('izBoxCap',-2,50,34,8.5,.9,9);P('izBoxCap',-2,50,-34,8.5,.9,9);
 [34,-34].forEach(sz=>{const p=W(-2,0,sz);kput('izOct',[p[0],plateau+50.9,p[2]],q,[2.2,1.8,2.2],vC(0x6a5a4a));kput('vBall',[p[0],plateau+53.2,p[2]],null,[1.4,1.4,1.4],vC(0x3a3632));for(const s of[-1,1]){const pp=W(-2+3.2,0,sz+s*.9);kput('vPipe',[pp[0],plateau+52.8,pp[2]],qEuler(0,-g,Math.PI/2-.15),[.3,7,.3],vC(0x2e2a26));}});
 for(let k=0;k<3;k++)P('izBoxCap',14.6-k*.2,22+k*3,0,1,1.4-k*.2,30-k*4);for(let i=-2;i<=2;i++)P('izGlow',14.8,30.5,i*6,.4,2.6,.8);
 P('izRockB',-1,-40,0,32,38.2,52);P('izRockB',10,-40,0,12,38.2,22);
 P('izBoxS',26,-3.2,0,52,3.2,15);P('izBoxCap',26,0,7.2,52,2.2,1.4);P('izBoxCap',26,0,-7.2,52,2.2,1.4);
 for(let i=0;i<4;i++)F('izFrusS',8+i*13,-16,0,6,14,17);
 const gi=idx+1;REG.push({name:'Gatehouse '+gi,x:cx,y:plateau-3,z:cz,r:22,h:52,cls:'building',key:'iziz_gate',tags:{culture:'iziz-old',type:['military','infrastructure'],wealth:'civic',lit:true}});
 [-1,1].forEach((sd,k)=>{const p=W(-2,0,sd*34);REG.push({name:'Gate tower '+(gi*2-1+k),x:p[0],y:plateau-3,z:p[2],r:18,h:58,cls:'building',key:'iziz_gate',tags:{culture:'iziz-old',type:['military'],wealth:'civic',lit:false}});});
 for(const lx of[16,40]){const p=W(lx,0,0);REG.push({name:'Bridge (gate '+gi+')',x:p[0],y:plateau-30,z:p[2],r:15,h:46,cls:'building',key:'iziz_bridge',tags:{culture:'iziz-old',type:['infrastructure'],wealth:'civic',lit:false}});}}
// ---- palace curtain wall in the ANCIENT style: battered board-formed concrete with white-panel cladding bands and cyan
//      strips (the palace still has power), sentry towers — fluted drums with a glass gallery and a light crown ----
function izCurtainWall(scene,rf,cx,cz,n,H,gates,towerEvery,barracksAngles){const G=new THREE.Group();scene.add(G);const segs=[];
 for(let i=0;i<n;i++){const t0=i/n*TAU,t1=(i+1)/n*TAU,tm=(t0+t1)/2;if(gates.some(pg=>angDiff(tm,pg)<.16))continue;if(barracksAngles&&barracksAngles.some(b=>angDiff(tm,b)<.14))continue;
  const a=[cx+rf(t0)*Math.cos(t0),cz+rf(t0)*Math.sin(t0)],b=[cx+rf(t1)*Math.cos(t1),cz+rf(t1)*Math.sin(t1)];const len=Math.hypot(b[0]-a[0],b[1]-a[1]),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
  const base=Math.min(terrainH(a[0],a[1]),terrainH(b[0],b[1]))-3;const mx=(a[0]+b[0])/2,mz=(a[1]+b[1])/2;const q=qEuler(0,-ang,0);
  kput('boxC',[mx,base+H/2,mz],q,[len+.6,H,7],IZ_CONC_TINT);                                      // the concrete rampart, sandstone-tinted
  kput('boxC',[mx,base+H+.5,mz],q,[len+.6,1.0,8.2],IZ_CONC_TINT);
  for(const s of[-1,1]){kput('plateW',[mx-Math.sin(ang)*s*3.6,base+H*.62,mz+Math.cos(ang)*s*3.6],q,[len*.92,H*.36,.3],null);   // panel cladding band, upper half
   kput('strip',[mx-Math.sin(ang)*s*3.75,base+H*.4,mz+Math.cos(ang)*s*3.75],q,[len*.9,1,1],CYAN);}
  if(i%towerEvery===0){const tx=a[0],tz=a[1],ty=terrainH(tx,tz)-3,TH=H+14;
   mesh(lathe({rFn:yy=>4.2*(1-.05*Math.pow(yy/TH,4))*(1+.12*Math.pow(.5+.5*Math.cos(yy*0),1)),H:TH,flutes:12,amp:.09,sharp:2.5,nu:36,nv:8}),MAT.izConcOrange,G,tx,ty,tz);
   mesh(lathe({rFn:()=>4.6,H:2.6,nu:24,nv:1}),MAT.glass,G,tx,ty+TH-3.4,tz);mesh(lathe({rFn:()=>4.2,H:2.6,nu:20,nv:1}),MAT.dark,G,tx,ty+TH-3.4,tz);mullions(tx,ty+TH-3.4,tz,4.6,2.6,14,0);
   kput('slab',[tx,ty+TH-.6,tz],null,[5.2,.6,5.2],vC(0xd8d4cc));stripRing(tx,ty+TH-.2,tz,4.9,0,16);kput('slab',[tx,ty+TH,tz],null,[4.6,.5,4.6],vC(0xd8d4cc));
   mesh(lathe({rFn:yy=>4.0*Math.sqrt(clamp(1-Math.pow(yy/3,2),0,1)),H:3,nu:20,nv:5}),MAT.white,G,tx,ty+TH+.4,tz);kput('finial',[tx,ty+TH+4,tz],null,[.8,1.4,.8],null);
   REG.push({name:'Palace sentry tower',x:tx,y:terrainH(tx,tz)-6,z:tz,r:6,h:TH+8,cls:'building',key:'iziz_curtain_tower',tags:{culture:'ancients',type:['military'],wealth:'civic',lit:true}});}}
 for(let i=0;i<20;i++){const t=i/20*TAU;if(gates.some(pg=>angDiff(t,pg)<.22))continue;REG.push({name:'Palace curtain wall (Ancient)',x:cx+rf(t)*Math.cos(t),y:terrainH(cx+rf(t)*Math.cos(t),cz+rf(t)*Math.sin(t))-6,z:cz+rf(t)*Math.sin(t),r:14,h:H+6,cls:'building',key:'iziz_curtain',tags:{culture:'ancients',type:['military'],wealth:'civic',lit:true}});}
 // gates: an arch through the rampart, strut portico, two lamp-crowned pylons
 for(const pg of gates){const R=rf(pg),gx=cx+R*Math.cos(pg),gz=cz+R*Math.sin(pg),gy=terrainH(gx,gz)-3;const q=qEuler(0,-pg,0);
  kput('boxC',[gx,gy+H/2+2,gz],q,[13,H+4,16],IZ_CONC_TINT);kput('archOpen',[gx,gy+5.5,gz],qFacing([Math.cos(pg),0,Math.sin(pg)]),[1.4,1.2,15],null);
  for(const s of[-1,1]){const px=gx-Math.sin(pg)*s*9.5,pz=gz+Math.cos(pg)*s*9.5;kput('colW',[px,gy,pz],null,[1.6,H+9,1.6],null);kput('finial',[px,gy+H+9.6,pz],null,[.9,1.4,.9],null);
   for(let k=-1;k<=1;k++)kput('strip',[gx+Math.cos(pg)*k*3.4,gy+H+2.6,gz+Math.sin(pg)*k*3.4],q,[11,1,1],CYAN);}
  REG.push({name:'Palace gate',x:gx,y:terrainH(gx,gz)-4,z:gz,r:14,h:H+12,cls:'building',key:'iziz_palace_gate',tags:{culture:'ancients',type:['military','civic'],wealth:'civic',lit:true}});}
 return G;}
function angDiff(a,b){let d=a-b;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;return Math.abs(d);}
// ---- citadel barracks: a real Ancient-style block just inside the curtain wall — three floors, battered concrete with white
//      panel bands, rows of windows (lit: the citadel is electrified), a door under a canopy on the face toward the court,
//      a stair drum at one end, a cyan light strip along the parapet. (x,z) is the block centre, `a` the bearing from the
//      hill centre (the door faces -a), idx numbers it.
function izBarracks(x,z,a,idx){const ty=terrainH(x,z)-.2;const ry=Math.atan2(-Math.cos(a),-Math.sin(a));const q=qEuler(0,ry,0);const W=30,D=14,FL=4.2,NF=3,H=FL*NF;
 const L=(lx,lz)=>loc(x,z,lx,lz,ry);const B=(item,lx,ly,lz,sx,sy,sz,c)=>{const p=L(lx,lz);kput(item,[p[0],ty+ly+sy/2,p[1]],q,[sx,sy,sz],c||null);};
 B('izBoxS',0,0,0,W,H,D);B('izBoxS',0,-1.2,0,W+1.6,1.2,D+1.6);                                   // the block on a low plinth
 for(let f=1;f<=NF;f++)B('izBoxW',0,f*FL-.5,0,W+.4,.6,D+.4);                                     // white panel band at each floor line
 B('izBoxCap',0,H+.1,0,W+.6,.7,D+.6);B('izBoxS',0,H+.8,0,W-2,.9,D-2);                            // parapet, roof upstand
 for(const s of[-1,1])kput('strip',[L(0,s*(D/2+.32))[0],ty+H+.45,L(0,s*(D/2+.32))[1]],q,[W-4,.5,1],CYAN);   // the light strips
 // windows: 6 bays per floor on the court face and the back, 2 on each end; lit panes with a dark reveal
 for(let f=0;f<NF;f++){const wy=f*FL+1.4;
  for(let i=0;i<6;i++){const lx=(i-2.5)*4.4;if(f===0&&(i===2||i===3))continue;                     // the door bay at ground
   for(const s of[-1,1]){B('vDarkB',lx,wy,s*(D/2+.02),1.8,2.2,.3);B('vWinLit',lx,wy+.15,s*(D/2+.1),1.4,1.8,.2);}}
  for(let i=0;i<2;i++)for(const s of[-1,1]){const lz=(i-.5)*5;B('vDarkB',s*(W/2+.02),wy,lz,.3,2.2,1.8);B('vWinLit',s*(W/2+.1),wy+.15,lz,.2,1.8,1.4);}}
 // the door toward the court (+z in the local frame is -a: toward the hill centre), its canopy and steps
 B('vDarkB',0,0,D/2+.05,3.2,3.6,.4);B('izBoxW',0,3.8,D/2+1.2,5.6,.5,2.8);B('izBoxS',0,-1.2,D/2+1.6,5.6,1.2,2.4);B('izBoxS',0,-1.2,D/2+3.2,7,.6,1.4);
 for(const s of[-1,1]){const p=L(s*4.2,D/2+2.4);kput('vPostS',[p[0],ty,p[1]],null,[.45,4.6,.45],vC(0xe2b676));kput('izGlow',[p[0],ty+4.9,p[1]],null,[.45,.45,.45],null);}
 // stair drum at one end, a floor above the roof, with its own strip
 {const p=L(-(W/2+2.2),-D/2+3.5);kput('izOct',[p[0],ty,p[1]],q,[5.2,H+4.6,5.2],null);kput('izBoxCap',[p[0],ty+H+4.7,p[1]],q,[5.6,.5,5.6],null);kput('strip',[p[0],ty+H+4.1,p[1]],q,[4,.4,1],CYAN);}
 REG.push({name:'Citadel barracks '+idx,x,y:ty-2,z,r:Math.hypot(W,D)/2+2,h:H+6,cls:'building',key:'iziz_barracks',tags:{culture:'iziz-old',type:['military','multi-family dwelling'],wealth:'civic',lit:true,state:'intact'}});}
// ---- heroic statues: science-fantasy art deco, stepped pedestal, three poses ----
function izStatue(x,z,h,pose,facing,yBase){const y=yBase!==undefined?yBase:terrainH(x,z)-.3;const s=h/20;const q=qEuler(0,facing,0);
 kput('izFrusCap',[x,y,z],q,[h*.55,h*.12,h*.55],vC(0xe2b676));kput('izFrusCap',[x,y+h*.12,z],q,[h*.4,h*.08,h*.4],vC(0xf0d29a));kput('izOct',[x,y+h*.2,z],q,[h*.13,h*.06,h*.13],vC(0x6e5428));
 const fy=y+h*.26;const L=(lx,ly,lz)=>{const p=loc(x,z,lx*s,lz*s,facing);return[p[0],fy+ly*s,p[1]];};
 for(const lx of[-1.4,1.4]){const p=L(lx,0,0);kput('izBronzeCyl',[p[0],p[1],p[2]],q,[1.3*s,9*s,1.3*s],null);}
 {const p=L(0,9,0);kput('izBronzeCyl',[p[0],p[1],p[2]],q,[3.0*s,9*s,3.0*s],null);}{const p=L(0,9,0);kput('izBronzeD',[p[0],p[1]+.7*s,p[2]],q,[4.2*s,1.4*s,2.6*s],null);}
 {const p=L(0,20.3,0);kput('izBronzeOct',[p[0],p[1],p[2]],q,[1.6*s,2.2*s,1.6*s],null);}{const p=L(0,21.6,0);kput('izBronzeCone',[p[0],p[1],p[2]],q,[1.4*s,3*s,.6*s],null);}
 if(pose===0){const a=L(-3.4,11.5,0);kput('izBronzeCyl',[a[0],a[1],a[2]],q,[.8*s,7*s,.8*s],null);const b=L(3.6,17,1.5);kput('izBronzeCyl',[b[0],b[1],b[2]],q.clone().multiply(qEuler(.4,0,-.6)),[.8*s,7*s,.8*s],null);
  const c=L(5.6,5,3);kput('izBronzeD',[c[0],c[1],c[2]],q,[.4*s,30*s,.4*s],null);const d=L(5.6,35,3);kput('izGlow',[d[0],d[1],d[2]],null,[1.2*s,3*s,1.2*s],null);}
 else if(pose===1){const a=L(0,14.5,2.2);kput('izBronze',[a[0],a[1],a[2]],q.clone().multiply(qEuler(0,0,.25)),[7*s,1.6*s,1.6*s],null);const b=L(0,12.8,2.2);kput('izBronze',[b[0],b[1],b[2]],q.clone().multiply(qEuler(0,0,-.25)),[7*s,1.6*s,1.6*s],null);
  for(const sx of[-1,1]){const w=L(sx*4,10,-2.2);kput('izBronzeD',[w[0],w[1]+8*s,w[2]],q.clone().multiply(qEuler(0,0,sx*.35)),[5*s,16*s,.6*s],null);const w2=L(sx*7.5,10,-2.4);kput('izBronze',[w2[0],w2[1]+5.5*s,w2[2]],q.clone().multiply(qEuler(0,0,sx*.55)),[3*s,11*s,.5*s],null);}}
 else{for(const sx of[-1,1]){const a=L(sx*3,17,1.2);kput('izBronzeCyl',[a[0],a[1],a[2]],q.clone().multiply(qEuler(.35,0,-sx*.45)),[.8*s,8*s,.8*s],null);}const o=L(0,26,3);kput('izGlow',[o[0],o[1],o[2]],null,[2.4*s,2.4*s,2.4*s],null);kput('izBronzeTor',[o[0],o[1],o[2]],q,[3.2*s,3.2*s,3.2*s],null);}
 REG.push({name:'Statue — '+(pose===0?'herald':pose===1?'winged guardian':'orb bearer'),x,y:y-1,z,r:h*.35+2,h:h*2.1+3,cls:'furniture',key:'iziz_statue',tags:{culture:'iziz-old',type:['statue'],place:'outdoor'}});}
// ---- the observation tower (the flared needle), in RUINED colours: rusted steel, dead glass, no beacon ----
function izNeedle(scene,x,z,H){const y=terrainH(x,z);const G=new THREE.Group();G.position.set(x,y,z);scene.add(G);
 kput('izSteel',[x,y,z],null,[3.5,H,3.5],null);for(let k=0;k<3;k++){const t=k*TAU/3;kput('izSteel',[x+7*Math.cos(t),y,z+7*Math.sin(t)],qEuler(Math.sin(t)*.32,0,-Math.cos(t)*.32),[1.3,20,1.3],vC(0x6e6a62));}
 for(let k=1;k<8;k++)kput('ringR',[x,y+k*H/8,z],qEuler(Math.PI/2,0,0),[2.6+1.8*(1-k/8)+.1,2.6+1.8*(1-k/8)+.1,2],null);
 mesh(lathe({rFn:yy=>9+6*yy/3.5,H:3.5,nu:24,nv:2}),MAT.rust,G,0,H+.5,0);mesh(lathe({rFn:()=>15,H:3.6,nu:24,nv:1,hole:holeFn(1,31,null,3)}),MAT.winDead,G,0,H+4.5,0);
 for(let k=0;k<24;k++){const t=k/24*TAU;kput('izSteelBox',[x+15.05*Math.cos(t),y+H+6.3,z+15.05*Math.sin(t)],qEuler(0,-t,0),[.35,3.6,.6],null);}
 mesh(lathe({rFn:yy=>15+1.5*yy/.8,H:.8,nu:24,nv:1}),MAT.rust,G,0,H+6.6,0);kput('ringR',[x,y+H+8.2,z],qEuler(Math.PI/2,0,0),[16.3,16.3,1.2],null);
 for(let k=0;k<32;k++){const t=k/32*TAU;if(rng()<.3)continue;kput('izSteelBox',[x+16.3*Math.cos(t),y+H+7.6,z+16.3*Math.sin(t)],null,[.15,1.2,.15],null);}
 mesh(lathe({rFn:yy=>9-3*yy/3,H:3,nu:16,nv:1}),MAT.rust,G,0,H+7,0);mesh(lathe({rFn:yy=>15.6*Math.sqrt(clamp(1-Math.pow(yy/5.2,2),0,1)),H:5.2,nu:28,nv:7}),MAT.rust,G,0,H+8.4,0);   // the roof dome, whole (Travis), rusted
 kput('izSteel',[x,y+H+14,z],qEuler(.12,0,.08),[.4,10,.4],null);
 for(const sx of[-1.5,1.5])kput('izSteelBox',[x+sx,y+(H+7)/2,z+5.2],null,[.3,H+7,.3],null);kput('izSteelBox',[x,y+H*.35,z+5.2],null,[2.6,3.2,2.4],vC(0x8a7a6a));   // the stalled cabin
 kput('izBoxS',[x,y+1.5,z+7.6],null,[4.6,3,2.4],null);kput('vDarkB',[x,y+1.3,z+8.9],null,[1.8,2.6,.3],null);
 rubbleRing(x,y,z,6,16,26,1.6);vinesOnRing(x,y+H+4,z,15,14,H*.4);scatterMoss(x,y,z,3,14,16,1.2);
 REG.push({name:'Observation tower (ruined)',x,y:y-1,z,r:20,h:H+26,cls:'building',key:'iziz_needle',tags:{culture:'iziz-old',type:['civic'],wealth:'civic',lit:false,state:'ruined'}});}
// ---- the spaceport, RUINED: bunker hub, six pads, fuel farm, control tower stump, broken perimeter, a wrecked freighter ----
function izSpaceport(scene,SP,SPA,y0){const G=new THREE.Group();G.position.set(SP.x,y0,SP.z);scene.add(G);const x=SP.x,z=SP.z;reseed(7777);
 kput('izOctR',[x,y0,z],null,[44,7,44],null);kput('izOctR',[x,y0+7,z],null,[32,5,32],vC(0xb8b0a6));kput('izOctRust',[x,y0+12,z],null,[18,4,18],null);
 mesh(lathe({rFn:yy=>7*Math.sqrt(clamp(1-Math.pow(yy/4,2),0,1)),H:4,nu:20,nv:6,hole:holeFn(1.1,41,null,2.5)}),MAT.concreteR,G,0,16,0);
 for(let i=0;i<8;i++){const t=i/8*TAU+Math.PI/8;kput('vDarkB',[x+18.5*Math.cos(t),y0+2,z+18.5*Math.sin(t)],qEuler(0,-t,0),[4,3,1.2],null);if(rng()<.4)kput('strip',[x+13.6*Math.cos(t),y0+12.2,z+13.6*Math.sin(t)],qEuler(0,-t-Math.PI/2,0),[3,1,1],DEAD);}
 {const ex=-22*Math.cos(SPA),ez=-22*Math.sin(SPA);kput('vDarkB',[x+ex,y0+2.75,z+ez],qEuler(0,Math.PI/2-SPA,0),[10,5.5,3],null);}
 kput('izOctRust',[x+9,y0+12,z-3],qEuler(0,0,.04),[6.5,18,6.5],null);                                          // the control tower, snapped off at 18 m
 kput('izOctRust',[x+28,y0+1.5,z-14],qEuler(Math.PI/2*.92,.4,.3),[6.5,9,6.5],null);kput('vDarkB',[x+28,y0+2.2,z-14],qEuler(Math.PI/2*.92,.4,.3),[6.2,2.4,6.2],null);   // its top, fallen
 for(let i=0;i<6;i++){const t=i/6*TAU+Math.PI/4,px=x+46*Math.cos(t),pz=z+46*Math.sin(t);kput('slabCR',[px,y0+.3,pz],null,[12,.7,12],null);
  if(i%2===0)kput('ringR',[px,y0+.75,pz],qEuler(Math.PI/2,0,0),[11.4,11.4,2],null);for(let k=0;k<4;k++){const a=k/4*TAU+t;if(rng()<.5)kput('izSteelBox',[px+14.5*Math.cos(a),y0+.8,pz+14.5*Math.sin(a)],null,[.7,1.6,.7],null);}
  if(rng()<.5)scatterMoss(px,y0+.7,pz,2,10,12,1.1);
  REG.push({name:'Landing pad '+(i+1)+' (ruined)',x:px,y:y0-1,z:pz,r:15.5,h:8,cls:'building',key:'iziz_spaceport',tags:{culture:'iziz-old',type:['infrastructure'],wealth:'civic',lit:false,state:'ruined'}});}
 {const fa=195*Math.PI/180,fx=x+62*Math.cos(fa),fz=z+62*Math.sin(fa),th=Math.PI/2-fa;kput('boxCR',[fx,y0+.7,fz],qEuler(0,th,0),[34,1.4,22],null);
  for(let i=0;i<6;i++){const lx=-12+(i%3)*12,lz=-5+Math.floor(i/3)*11;const p=loc(fx,fz,lx,lz,th);if(i===2||i===4){kput('vTankR',[p[0]+3,y0+1.4+4.6,p[1]+2],qEuler(Math.PI/2*.95,rng()*.5,0),[4.6,10,4.6],null);}   // two tanks toppled
   else{kput('vTankR',[p[0],y0+1.4,p[1]],null,[4.6,10,4.6],null);kput('vDomeC',[p[0],y0+11.4,p[1]],null,[4.6,2.4,4.6],vC(0x9a8a7a));kput('ringR',[p[0],y0+8.6,p[1]],qEuler(Math.PI/2,0,0),[4.7,4.7,2],null);}}
  REG.push({name:'Fuel farm (ruined)',x:fx,y:y0-1,z:fz,r:20,h:18,cls:'building',key:'iziz_spaceport',tags:{culture:'iziz-old',type:['infrastructure'],wealth:'civic',lit:false,state:'ruined'}});}
 for(let i=0;i<40;i++){const t0=i/40*TAU,t1=(i+1)/40*TAU;if(angDiff((t0+t1)/2,SPA)<.13||angDiff((t0+t1)/2,SPA+Math.PI)<.13)continue;if(rng()<.3)continue;
  const a=[x+88*Math.cos(t0),z+88*Math.sin(t0)],b=[x+88*Math.cos(t1),z+88*Math.sin(t1)];const len=Math.hypot(b[0]-a[0],b[1]-a[1]),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
  kput('boxCR',[(a[0]+b[0])/2,y0+1.3,(a[1]+b[1])/2],qEuler(0,-ang,0),[len+.5,2.6,1.2],null);if(i%4===0)kput('izSteelBox',[a[0],y0+4.5,a[1]],qEuler(rr(-.1,.1),0,rr(-.1,.1)),[.6,9,.6],null);}
 // the wrecked freighter, nose down in the apron
 {const bx=x+66*Math.cos(15*Math.PI/180),bz=z+66*Math.sin(15*Math.PI/180);const q=qEuler(-.12,.7,.18);kput('izOctRust',[bx,y0+1,bz],q,[20,7,44],null);kput('izOctRust',[bx-3,y0+6,bz-6],q,[12,4,24],null);
  for(const s of[-1,1])kput('izSteelBox',[bx+s*14*Math.cos(.7),y0+3.5,bz-s*14*Math.sin(.7)],q,[14,2.2,22],null);rubbleRing(bx,y0,bz,10,30,40,2.2);scatterMoss(bx,y0,bz,4,26,20,1.4);
  REG.push({name:'Wrecked freighter',x:bx,y:y0-1,z:bz,r:26,h:14,cls:'building',key:'iziz_spaceport',tags:{culture:'iziz-old',type:['infrastructure'],wealth:'civic',lit:false,state:'ruined'}});}
 rubbleRing(x,y0,z,20,60,60,1.8);scatterMoss(x,y0,z,8,84,90,1.6);vinesOnRing(x,y0+7,z,44,20,6);
 REG.push({name:'Spaceport hub (ruined)',x,y:y0-1,z,r:46,h:24,cls:'building',key:'iziz_spaceport',tags:{culture:'iziz-old',type:['infrastructure','civic'],wealth:'civic',lit:false,state:'ruined'}});}
// ---- street furniture of the old set: lamp columns (electric — civic streets), banner poles in orange ----
function izLampColumn(x,z){const y=terrainH(x,z)-.3;kput('vPostS',[x,y,z],null,[.5,6,.5],vC(0xe2b676));kput('izBoxCap',[x,y+6.25,z],null,[1.6,.5,1.6],null);kput('izGlow',[x,y+6.9,z],null,[.5,.5,.5],null);}
// ================================================================= bunker: AA battery on the cupola
function aaBattery(G,d,x,y,z,s){s=s||1;kput(d>0?'boxR':'boxW',[x,y+1.2*s,z],null,[6*s,2.4*s,6*s],null);kput('tube',[x,y+3.6*s,z],null,[2.2*s,2.4*s,2.2*s],null);
 const yaw=rr(0,TAU),pitch=d>0?.1:.9;const q=qEuler(0,-yaw,0).multiply(qEuler(0,0,pitch));const bx=x+Math.cos(yaw)*1.5*s,bz=z+Math.sin(yaw)*1.5*s;
 kput(d>0?'boxR':'boxW',[bx,y+5.5*s,bz],q,[8*s,4*s,5*s],null);
 for(let i=0;i<2;i++)for(let j=0;j<4;j++){const off=new THREE.Vector3(0,(i-.5)*1.7*s,(j-1.5)*1.15*s).applyQuaternion(q);const tip=new THREE.Vector3(4.6*s,0,0).applyQuaternion(q);
  kput('tube',[bx+off.x+tip.x*.5,y+5.5*s+off.y+tip.y*.5,bz+off.z+tip.z*.5],q.clone().multiply(qEuler(0,0,-Math.PI/2)),[.7*s,8*s,.7*s],null);}
 kput('tube',[x,y+2.4*s,z],null,[.4*s,7*s,.4*s],null);kput(d>0?'boxR':'boxW',[x,y+6*s,z],qEuler(0,rng()*3,0),[3.5*s,1.6*s,.2*s],null);}

// ================================================================= HOUSES v2
function buildHouses(scene,gx,gz,d){reseed(9400+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 // A — petal house: petals part at the front, a porch of two leaning struts marks the door
 {REGISTER({name:'House A — petal house ('+STATE(d)+')',x:0,z:0,r:14,h:14});
  const P=new THREE.Group();G.add(P);mesh(lathe({rFn:()=>9.5,H:1,nu:40,nv:1}),skin,P);kput('slab',[0,1,0],null,[9.5,.4,9.5],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  mesh(lathe({rFn:()=>5,H:5.5,nu:32,nv:3,hole:holeFn(d*.5,101,null,3)}),skin,P,0,1,0);if(d>0)mesh(lathe({rFn:()=>4.6,H:5.5,nu:16,nv:1}),MAT.dark,P,0,1,0);
  kput('archOpen',[0,3.2,5.1],qFacing([0,0,1]),[.4,.5,1],null);for(let k=1;k<4;k++){const th=k/4*TAU+Math.PI/2;kput(d>0?'winSmD':'winSmI',[Math.cos(th)*5.1,3.6,Math.sin(th)*5.1],qFacing([Math.cos(th),0,Math.sin(th)]),[1.4,1.4,1],null);}
  petalRing(P,8,6.6,11,5.2,1.6,.5,1,d,110,skin,i=>i===2||(d>0&&i===5));petalRing(P,8,3.8,13,3.6,-.6,.4,1,d,120,skin,d>0?(i=>i===6):null);
  beam(d>0?'strutR':'strutW',[-4,1,10],[-2,6,5.5],.8,.6);beam(d>0?'strutR':'strutW',[4,1,10],[2,6,5.5],.8,.6);kput(d>0?'boxR':'boxW',[0,6.2,7.5],qEuler(.3,0,0),[6,.4,5],null);
  kput('slab',[0,.2,14],null,[3,.4,3],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  if(d===0)mesh(lathe({rFn:y=>4.2*Math.sqrt(clamp(1-Math.pow(y/6,2),0,1)),H:6,nu:24,nv:6}),MAT.glass,P,0,6.5,0);
  if(d>0){const fm=mesh(petalGeo(6.6,11,5.2,1.6,.5,null),MAT.rust,P,14,.6,-6);fm.rotation.set(0,.9,Math.PI/2*.9);dropFragment(fm,0,.15);mossOnRing(0,1.4,0,8,14,1.2);}
  stripRing(0,5.5,0,4.3,d,12);}
 // B — hypar-shell house: a real room block inside the two shells, glass gables, door in the front gable
 {REGISTER({name:'House B — hypar-shell house ('+STATE(d)+')',x:70,z:0,r:14,h:14});kput('slab',[70,.5,0],null,[13,.5,13],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  luceShells(G,70,0,16,13,5,d,130,skin);
  kput(d>0?'boxR':'boxW',[70,3.5,0],null,[9,6,7],null);kput('boxD',[70,3.5,0],null,[8.6,5.6,6.6],null);
  kput('archOpen',[70,2.2,4.0],qFacing([0,0,1]),[.35,.4,1],null);kput('archOpen',[70,2.2,4.9],qFacing([0,0,1]),[.35,.4,1],null);
  for(let s=-1;s<=1;s+=2)for(let k=-1;k<=1;k+=2)kput(d>0?'winSmD':'winSmI',[70+k*2.5,4.2,s*3.6],qFacing([0,0,s]),[1.2,1.2,1],null);
  for(let k=-1;k<=1;k+=2)kput(d>0?'winSmD':'winSmI',[70+k*4.6,3.2,0],qFacing([k,0,0]),[1.4,1.6,1],null);
  kput('slab',[70,.2,10],null,[2.5,.4,2.5],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));stripRing(70,8.5,0,2.2,d,8);if(d>0)mossOnRing(70,.9,0,8,10,1.1);}
 // C — lobed cluster house (Goldberg): kept, entry path added
 {REGISTER({name:'House C — lobed cluster house ('+STATE(d)+')',x:140,z:0,r:12,h:12});const P=new THREE.Group();P.position.set(140,0,0);G.add(P);
  mesh(lathe({rFn:()=>2.6,H:10,nu:20,nv:2}),skin,P);
  for(let l=0;l<3;l++){const a=l/3*TAU+.5,ox=Math.cos(a)*4.6,oz=Math.sin(a)*4.6;const gone=d>0&&l===1;
   kput(d>0?'colR':'colW',[140+ox,0,oz],null,[1.1,3.2,1.1],null);if(gone){rubbleRing(140+ox,0,oz,1,5,18,1.2);continue;}
   mesh(lathe({rFn:y=>3.6*(1-.05*Math.pow(y/7,6)),H:7,nu:28,nv:10,hole:holeFn(d,140+l,null,2.5)}),skin,P,ox,3,oz);if(d>0)mesh(lathe({rFn:()=>3.2,H:7,nu:14,nv:1}),MAT.dark,P,ox,3,oz);
   kput(d>0?'ringR':'ringW',[140+ox,10,oz],qEuler(Math.PI/2,0,0),[3.7,3.7,2],null);
   // floor and domed cap: each lobe was a bare tube on a single column, open
   // at the top and at the bottom.
   kput('slab',[140+ox,3,oz],null,[3.7,.5,3.7],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
   if(!(d>0&&l===2))mesh(lathe({rFn:y=>3.7*Math.sqrt(clamp(1-Math.pow(y/2.6,2),0,1)),H:2.6,nu:20,nv:6}),skin,P,ox,10,oz);
   for(let yy=1.5;yy<6;yy+=2.6)for(let k=-1;k<=1;k++){const th=a+k*.55;kput(d>0?'ovalD':'ovalI',[140+ox+3.6*Math.cos(th),3+yy,oz+3.6*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.55,.8,.8],null);}}
  kput('slab',[140,10.2,0],null,[2.8,.5,2.8],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));kput('archOpen',[140-2.6,1.8,0],qFacing([-1,0,0]),[.28,.36,1],null);kput('slab',[132,.2,0],null,[2.5,.4,2.5],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  stripRing(140,8,0,2.2,d,8);if(d>0)mossOnRing(140,.3,0,7,12,1.1);}
 figures(35,14,4,4);KOFF=[0,0,0];return G;}

// ================================================================= KratorSky — the Krator skybox module (from claude/krator-sky.html, verbatim logic)
// Canon (krator-notes): tidally-locked moon of a Neptune–Saturn-class giant, 24 h day, ~40° S, giant fixed at
// altitude 25° azimuth 66° (NE, over Korona), obliquity ~23°, eclipse seasons round each equinox.
// Coordinates: x = east, y = up, z = south (north is −z). Azimuth clockwise from north.
// A target that wants it calls KratorSky.attach(scene,R) once and KratorSky.update(camPos,hour,day,dens) per frame,
// then applies KratorSky.lighting() to its sun / hemi / fog. A target that does not call attach pays nothing.
const KratorSky=(function(){
 const D=Math.PI/180;const LAT=-40*D,OBL=23*D,YEAR=360;
 const GIANT_ALT=25*D,GIANT_AZ=66*D,GIANT_ANG=14*D;
 const giantDir=new THREE.Vector3(Math.sin(GIANT_AZ)*Math.cos(GIANT_ALT),Math.sin(GIANT_ALT),-Math.cos(GIANT_AZ)*Math.cos(GIANT_ALT));
 function sunDir(hour,day){const dec=OBL*Math.sin(2*Math.PI*(day-80)/YEAR);const H=(hour-12)*15*D;
  const e=-Math.cos(dec)*Math.sin(H),n=Math.sin(dec)*Math.cos(LAT)-Math.cos(dec)*Math.sin(LAT)*Math.cos(H),u=Math.sin(dec)*Math.sin(LAT)+Math.cos(dec)*Math.cos(LAT)*Math.cos(H);
  return new THREE.Vector3(e,u,-n).normalize();}
 function altAz(v){return{alt:Math.asin(v.y)/D,az:((Math.atan2(v.x,-v.z)/D)+360)%360};}
 const skyMat=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,
  uniforms:{sun:{value:new THREE.Vector3(0,1,0)},giant:{value:giantDir.clone()},dens:{value:1.6},ecl:{value:0},night:{value:0}},
  vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`varying vec3 vP;uniform vec3 sun,giant;uniform float dens,ecl,night;
  void main(){vec3 d=normalize(vP);float h=clamp(d.y,-0.1,1.0);float sh=sun.y;
   float dayF=smoothstep(-0.12,0.18,sh);float dusk=exp(-pow((sh-0.02)/0.16,2.0));
   float thick=clamp(dens/1.6,0.3,1.6);
   vec3 zenDay=mix(vec3(0.20,0.36,0.62),vec3(0.36,0.46,0.66),clamp((thick-0.7)*1.2,0.,1.));
   vec3 horDay=mix(vec3(0.78,0.84,0.90),vec3(0.86,0.70,0.52),clamp(thick-0.5,0.,1.));
   vec3 zenNight=vec3(0.015,0.02,0.045);vec3 horNight=vec3(0.06,0.05,0.09)*thick;
   float hp=pow(1.0-h,2.2+1.2*thick);
   vec3 day=mix(zenDay,horDay,hp);vec3 nite=mix(zenNight,horNight,hp);
   vec3 c=mix(nite,day,dayF);
   float sd=max(dot(d,normalize(sun)),0.0);
   vec3 duskCol=vec3(1.0,0.45,0.18);c+=duskCol*dusk*pow(sd,3.0)*(0.55+0.5*hp)*(1.0-0.6*ecl);
   c+=vec3(1.0,0.9,0.75)*pow(sd,64.0)*dayF*0.9*(1.0-ecl);c+=vec3(1.0,0.85,0.6)*pow(sd,8.0)*dayF*0.18*thick;
   float gd=max(dot(d,giant),0.0);c+=vec3(0.55,0.5,0.7)*pow(gd,10.0)*(1.0-dayF)*0.12;
   c*=1.0-0.75*ecl*smoothstep(-0.05,0.3,h);
   c=mix(c,c*0.6+vec3(0.12,0.08,0.06)*thick,(1.0-dayF)*0.4*(1.0-h));
   gl_FragColor=vec4(c,1.0);}`});
 const giantTex=(function(){const c=document.createElement('canvas');c.width=64;c.height=512;const g=c.getContext('2d');
  const bands=[[0.00,'#7d8fb0'],[0.08,'#9aa8c4'],[0.15,'#c7c2b6'],[0.22,'#8a98b8'],[0.30,'#dcd4c2'],[0.36,'#7e8db0'],[0.45,'#b9b2a6'],[0.52,'#6f80a6'],[0.60,'#d8cfbb'],[0.68,'#8896b6'],[0.76,'#c4bdb0'],[0.84,'#7688aa'],[0.92,'#a9b0c2'],[1.0,'#6f80a2']];
  const grd=g.createLinearGradient(0,0,0,512);bands.forEach(b=>grd.addColorStop(b[0],b[1]));g.fillStyle=grd;g.fillRect(0,0,64,512);
  for(let i=0;i<200;i++){g.fillStyle='rgba(255,255,255,'+(h3(i,1,2)*.08)+')';g.fillRect(h3(i,2,3)*64,h3(i,3,4)*512,h3(i,4,5)*30+4,h3(i,5,6)*3+1);}
  g.fillStyle='rgba(230,225,215,.35)';g.beginPath();g.ellipse(40,300,9,4,0,0,6.28);g.fill();
  const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;return t;})();
 const giantMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,fog:false,
  uniforms:{map:{value:giantTex},L:{value:new THREE.Vector3(0,0,1)},haze:{value:0.3},ring:{value:1},tilt:{value:0.35},t:{value:0}},
  vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:`varying vec2 vUv;uniform sampler2D map;uniform vec3 L;uniform float haze,ring,tilt,t;
  void main(){vec2 p=(vUv-0.5)*2.0;
   float R=0.62;vec2 q=p/R;float r2=dot(q,q);vec3 col=vec3(0.);float a=0.;
   float cs=cos(tilt),sn=sin(tilt);vec2 rp=vec2(q.x,q.y/max(sn,0.08));float rr=length(rp);
   float inRing=ring*smoothstep(1.35,1.4,rr)*(1.0-smoothstep(2.1,2.2,rr))*(0.55+0.45*sin(rr*40.0));
   float behind=step(0.0,q.y)*step(rr,1.0);
   if(r2<1.0){vec3 n=vec3(q.x,q.y,sqrt(max(0.0,1.0-r2)));
    float lat=asin(clamp(n.y,-1.,1.));float lon=atan(n.x,n.z);
    vec3 base=texture2D(map,vec2(lon/6.2832+t*0.02,lat/3.1416+0.5)).rgb;
    float lit=clamp(dot(n,normalize(L)),-1.0,1.0);float day=smoothstep(-0.08,0.25,lit);
    float limb=pow(max(0.0,n.z),0.45);
    col=base*(0.05+0.95*day)*limb+vec3(0.35,0.3,0.4)*0.05*(1.0-day);
    a=1.0;}
   else{a=0.0;}
   vec3 ringCol=vec3(0.85,0.82,0.78);float ringA=inRing*(1.0-behind)*(r2<1.0?0.0:1.0);
   float ringLit=clamp(dot(vec3(0.,1.,0.),normalize(L))*0.5+0.6,0.15,1.0);
   col=mix(col,ringCol*ringLit,ringA*0.7);a=max(a,ringA*0.7);
   float front=step(q.y,0.0)*step(rr,1.0)*inRing;col=mix(col,ringCol*ringLit,front*0.6);
   a*=1.0-haze;
   gl_FragColor=vec4(col,a);}`});
 const giant=new THREE.Mesh(new THREE.PlaneGeometry(1,1),giantMat);
 const sunTex=(function(){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');const gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(255,250,235,1)');gr.addColorStop(0.18,'rgba(255,240,200,1)');gr.addColorStop(0.3,'rgba(255,200,120,0.35)');gr.addColorStop(1,'rgba(255,160,80,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);return new THREE.CanvasTexture(c);})();
 const sun=new THREE.Sprite(new THREE.SpriteMaterial({map:sunTex,fog:false,depthWrite:false,transparent:true,blending:THREE.AdditiveBlending}));
 const starGeo=new THREE.BufferGeometry();{const p=[],c=[];for(let i=0;i<2600;i++){const u=h3(i,7,1)*2-1,th=h3(i,8,2)*6.2832;const r=Math.sqrt(1-u*u);p.push(r*Math.cos(th),u,r*Math.sin(th));const k=h3(i,9,3);c.push(0.7+0.3*k,0.75+0.2*k,0.9);}
  starGeo.setAttribute('position',new THREE.Float32BufferAttribute(p,3));starGeo.setAttribute('color',new THREE.Float32BufferAttribute(c,3));}
 const stars=new THREE.Points(starGeo,new THREE.PointsMaterial({size:2.2,sizeAttenuation:false,vertexColors:true,transparent:true,opacity:0,fog:false,depthWrite:false}));
 const moon=new THREE.Sprite(new THREE.SpriteMaterial({map:(function(){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.fillStyle='#cfc8bc';g.beginPath();g.arc(32,32,28,0,6.28);g.fill();g.fillStyle='rgba(90,80,80,.35)';for(let i=0;i<8;i++){g.beginPath();g.arc(20+h3(i,1,9)*24,20+h3(i,2,9)*24,2+h3(i,3,9)*4,0,6.28);g.fill();}return new THREE.CanvasTexture(c);})(),fog:false,depthWrite:false,transparent:true}));
 const group=new THREE.Group();const dome=new THREE.Mesh(new THREE.SphereGeometry(1,48,24),skyMat);group.add(dome,giant,sun,stars,moon);group.traverse(o=>{o.userData.probeSkip=true;});
 const state={hour:12,day:200,dens:1.6,sun:new THREE.Vector3(),eclipse:0,ring:true};
 function attach(scene,R){group.scale.setScalar(R);group.userData.R=R;scene.add(group);return group;}
 function update(camPos,hour,day,dens){state.hour=hour;state.day=day;state.dens=dens;group.position.copy(camPos);
  const s=sunDir(hour,day);state.sun.copy(s);skyMat.uniforms.sun.value.copy(s);skyMat.uniforms.dens.value=dens;
  const ang=Math.acos(Math.max(-1,Math.min(1,s.dot(giantDir))));const ecl=s.y>0?Math.max(0,1-ang/GIANT_ANG):0;const eclF=ecl>0?Math.min(1,ecl*1.6):0;state.eclipse=eclF;skyMat.uniforms.ecl.value=eclF*0.9;
  giant.position.copy(giantDir).multiplyScalar(0.96);giant.lookAt(new THREE.Vector3(0,0,0));const size=2*0.96*Math.tan(GIANT_ANG)/0.62;giant.scale.set(size,size,1);
  const right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),giantDir).normalize();const upB=new THREE.Vector3().crossVectors(giantDir,right).normalize();
  giantMat.uniforms.L.value.set(s.dot(right),s.dot(upB),-s.dot(giantDir));giantMat.uniforms.haze.value=0.15+0.35*Math.max(0,dens-1)*0.7;giantMat.uniforms.ring.value=state.ring?1:0;giantMat.uniforms.t.value=hour/24;
  sun.position.copy(s).multiplyScalar(0.95);const ss=0.11*(1+0.5*Math.max(0,0.15-s.y)*6);sun.scale.set(ss,ss,1);sun.material.opacity=s.y>-0.08?1-eclF*0.85:0;
  const night=1-Math.min(1,Math.max(0,(s.y+0.1)/0.28));stars.material.opacity=night*0.9;stars.rotation.set(0,0,0);stars.rotateOnAxis(new THREE.Vector3(0,Math.sin(-LAT),Math.cos(-LAT)).normalize(),hour/24*6.2832);
  const ma=hour/6*6.2832;const md=new THREE.Vector3(Math.cos(ma)*0.9,0.25+0.2*Math.sin(ma*0.5),Math.sin(ma)*0.9).normalize();moon.position.copy(md).multiplyScalar(0.93);moon.scale.set(0.02,0.02,1);moon.material.opacity=md.y>0.05?0.9:0;
  return state;}
 function lighting(){const s=state.sun;const dayF=Math.min(1,Math.max(0,(s.y+0.12)/0.3));const dusk=Math.exp(-Math.pow((s.y-0.02)/0.16,2));const e=state.eclipse;
  const sunCol=new THREE.Color(1,0.96,0.9).lerp(new THREE.Color(1,0.55,0.3),dusk).multiplyScalar(1-0.85*e);
  const thick=Math.min(1.6,Math.max(0.3,state.dens/1.6));const hor=new THREE.Color(0.78,0.84,0.90).lerp(new THREE.Color(0.86,0.70,0.52),Math.min(1,Math.max(0,thick-0.5)));
  const fog=new THREE.Color(0.06,0.05,0.09).lerp(hor,dayF).lerp(new THREE.Color(1,0.5,0.25),dusk*0.5).multiplyScalar(1-0.6*e*dayF);
  return{sunDir:s.clone(),sunIntensity:1.7*dayF*(1-0.85*e),sunColor:sunCol,ambient:0.18+0.55*dayF*(1-0.6*e)+0.08*(1-dayF),fog,giantDir:giantDir.clone(),eclipse:e,isNight:dayF<0.05,dayF,dusk};}
 return{attach,update,lighting,sunDir,altAz,giantDir,state,GIANT_ANG};})();
window.KratorSky=KratorSky;
// ================================================================= APARTMENTS — three variants
function buildApartments(scene,gx,gz,d){reseed(9950+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 // A — midrise terrace stack: eight stacked lobed trays, each shifted and shrunk, on a hyperboloid stem
 {REGISTER({name:'Apartments A — terrace stack, midrise ('+STATE(d)+')',x:0,z:0,r:40,h:60});mesh(lathe({rFn:y=>7*Math.sqrt(1+1.5*Math.pow((y-20)/20,2)),H:40,nu:32,nv:12}),skin,G);
  const aSkin=[],aDark=[];   // one mesh per stack, not two or three per terrace
  for(let s=0;s<8;s++){const y=6+s*5.4;const ox=Math.sin(s*1.3)*5,oz=Math.cos(s*.9)*5;const R=24-s*1.6;const gone=d>0&&s===6;const hole=holeFn(d*.7,700+s,null,2.5);
   if(gone){rubbleRing(ox*3,0,oz*3,10,32,30,2);continue;}
   // floor and ceiling: each tray was an open-ended tube, so from above you
   // looked straight down through all eight of them to the ground.
   kput('slab',[ox,y,oz],null,[R*.99,.35,R*.99],new THREE.Color(d>0?0x4a4038:0xcfcac2));
   kput('slab',[ox,y+4.6,oz],null,[R*.99,.35,R*.99],new THREE.Color(d>0?0x4a4038:0xcfcac2));
   aSkin.push(lathe({rFn:()=>R,H:4.6,flutes:6,amp:.28,sharp:1,nu:72,nv:3,hole}).translate(ox,y,oz));
   if(d>0)aDark.push(lathe({rFn:()=>R*.9,H:4.6,nu:24,nv:1}).translate(ox,y,oz));
   aSkin.push(gridSurface((u,v)=>{const th=u*TAU;const r=R*(1+.28*(.5+.5*Math.cos(6*th)))*(1+v*.1);return[ox+r*Math.cos(th),y+4.6+.4*v,oz+r*Math.sin(th)];},72,1,{}));
   for(let k=0;k<18;k++){const th=(k+.5)/18*TAU;const r=R*(1+.28*(.5+.5*Math.cos(6*th)))+.1;if(hole&&hole(k/18,y))continue;kput(d>0?'winSmD':'winSmI',[ox+r*Math.cos(th),y+2.3,oz+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[2,1.7,1],null);}
   if(s%2===0)stripRing(ox,y+3.5,oz,R*.8,d,18);if(d>0)mossOnRing(ox,y+4.8,oz,R*1.1,10,1.5);}
  meshMerged(aSkin,skin,G);meshMerged(aDark,MAT.dark,G);
  if(d>0){mossOnSurface(aSkin,0,0,0,90,1.8);vinesFromLedge(aSkin,0,0,0,40,12);stainsFromLedge(aSkin,0,0,0,30,9);}
  kput('archOpen',[7,3.5,0],qFacing([1,0,0]),[.5,.5,1],null);}
 // B — honeycomb wall: a long curved slab of hexagonal cells (Beksinski lattice), 12 storeys
 {const bx=150;REGISTER({name:'Apartments B — honeycomb wall, large ('+STATE(d)+')',x:bx,z:0,r:70,h:62});const R=110,a0=-.55,a1=.55,HW=60;
  const hexHole=(u,v)=>{const cx=u*30,cy=v*13;const rowOff=(Math.floor(cy)%2)*.5;const fx=((cx+rowOff)%1)-.5,fy=(cy%1)-.5;return Math.abs(fx)<.32&&Math.abs(fy)<.34&&Math.abs(fx)+Math.abs(fy)*1.2<.52;};
  const wall=(off)=>gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=R+off;return[bx+Math.sin(a)*r,v*HW,Math.cos(a)*r-R*.8];},240,80,{uS:30,vS:13,hole:(u,v)=>hexHole(u,v)||(holeFn(d,710,null,1.5)||(()=>false))(u*3,v*HW)});
  mesh(wall(0),skin,G);mesh(wall(-12),skin,G);
  // cell floors between the skins, dark inner
  mesh(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=R-6;return[bx+Math.sin(a)*r,v*HW,Math.cos(a)*r-R*.8];},60,12,{}),MAT.dark,G);
  const bFloors=[];
  for(let f=0;f<13;f++){const y=f*HW/13;bFloors.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(R-12,R,v);return[bx+Math.sin(a)*r,y,Math.cos(a)*r-R*.8];},60,1,{hole:d>0?(u,v)=>fbm(u*12,f,720+f,2)<.2:null}));}
  // END WALLS AND ROOF. The block is a 12 m sandwich of two perforated skins;
  // without these it was open along both end elevations and across the whole
  // top, so you looked straight into thirteen storeys of floor slab from the
  // side. The skins are the long elevations, not the whole envelope.
  for(let s=0;s<2;s++){const a=lerp(a0,a1,s);
   bFloors.push(gridSurface((u,v)=>{const r=lerp(R-12,R,u);return[bx+Math.sin(a)*r,v*HW,Math.cos(a)*r-R*.8];},10,44,{uS:6,vS:13,hole:d>0?(u,v)=>fbm(u*4+s*3,v*7,714+s,2)<.28:null}));}
  bFloors.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(R-12,R,v);return[bx+Math.sin(a)*r,HW,Math.cos(a)*r-R*.8];},60,4,{uS:20,vS:4,hole:d>0?(u,v)=>fbm(u*9,v*4,716,2)<.24:null}));
  meshMerged(bFloors,skin,G);
  for(let k=0;k<30;k++)for(let f=0;f<13;f++){if(rng()>.35)continue;const a=lerp(a0,a1,(k+.5)/30),y=f*HW/13+2.3;const lit=d>0?rng()<.06:true;
   kput('cell',[bx+Math.sin(a)*(R-5),y,Math.cos(a)*(R-5)-R*.8],qFacing([Math.sin(a),0,Math.cos(a)]),[2,1.6,1],lit?WARM.clone().multiplyScalar(rr(.4,.9)):DEAD);}
  for(let k=0;k<7;k++){const a=lerp(a0,a1,(k+.5)/7);kput(d>0?'colR':'colW',[bx+Math.sin(a)*(R-6),0,Math.cos(a)*(R-6)-R*.8],null,[3,HW+3,3],null);}
  if(d>0){rubbleRing(bx,0,R*.2,10,60,50,2.5);}}
 // C — column cluster: five slim lobed towers (30–48 m) linked by sky bridges
 {const cx=340;REGISTER({name:'Apartments C — column cluster, large ('+STATE(d)+')',x:cx,z:0,r:60,h:52});const cols=[[0,0,48],[26,10,40],[-22,14,36],[8,-26,44],[-18,-18,30]];
  const cBands=[];   // the balcony rings of all five towers in one mesh
  cols.forEach((c,i)=>{const R=7.5,H=c[2];const cut=d>0&&i===1?H*.5:null;const hole=holeFn(d,730+i,cut,2);
   kput(d>0?'colR':'colW',[cx+c[0],0,c[1]],null,[4,10,4],null);
   mesh(lathe({rFn:()=>R,H:H-10,cut:cut?cut-10:null,jag:cut?2:0,flutes:6,amp:.3,sharp:1,nu:60,nv:24,hole,seed:730+i}),skin,G,cx+c[0],10,c[1]);
   if(d>0)mesh(lathe({rFn:()=>R*.85,H:H-10,cut:cut?cut-10:null,jag:2,nu:24,nv:4,seed:730+i}),MAT.guts,G,cx+c[0],10,c[1]);
   for(let s=0;s*4<(cut||H)-14;s++){const y=10+s*4;cBands.push(lathe({rFn:()=>R*1.08,H:.6,flutes:6,amp:.3,sharp:1,nu:60,nv:1,hole:d>0?(u,v)=>fbm(u*8+s,i,740+s,2)<.22:null}).translate(cx+c[0],y+3.4,c[1]));
    for(let k=0;k<6;k++){const th=k/6*TAU;const u=k/6;if(hole&&hole(u,y-10))continue;const r=R*1.3+.1;kput(d>0?'winSmD':'winSmI',[cx+c[0]+r*Math.cos(th),y+1.8,c[1]+r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[1.6,1.6,1],null);}
    if(s%3===0)stripRing(cx+c[0],y+2.3,c[1],R*.85,d,12);}
   if(!cut){kput('slab',[cx+c[0],H+.2,c[1]],null,[R*1.1,.5,R*1.1],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));mesh(lathe({rFn:y=>R*.6*Math.sqrt(clamp(1-Math.pow(y/3,2),0,1)),H:3,nu:20,nv:5}),skin,G,cx+c[0],H+.4,c[1]);}
   else rubbleRing(cx+c[0],0,c[1],9,24,40,2);});
  meshMerged(cBands,skin,G);
  [[0,1,22],[0,2,18],[0,3,26],[2,4,16],[1,3,24]].forEach(b=>{const A=cols[b[0]],B=cols[b[1]];if(b[2]>Math.min(A[2],B[2])-4)return;if(d>0&&b[0]===0&&b[1]===1)return;
   beam(d>0?'strutR':'strutW',[cx+A[0],b[2],A[1]],[cx+B[0],b[2],B[1]],2.4,3);beam('tube',[cx+A[0],b[2]+2,A[1]],[cx+B[0],b[2]+2,B[1]],2,2);});
  kput('slab',[cx,.3,0],null,[50,.6,50],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));if(d>0)scatterMoss(cx,.6,0,0,48,40,1.8);}
 figures(60,40,5,6);figures(300,60,4,5);KOFF=[0,0,0];return G;}

// ================================================================= AMPHITHEATER — "the Bowl"
function buildAmphitheater(scene,gx,gz,d){reseed(9960+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 REGISTER({name:'Amphitheater — the Bowl ('+STATE(d)+')',x:0,z:0,r:110,h:60});
 // SIGHTLINES. Two separate things decided whether a seat could see the stage.
 //
 // 1. THE SWEEP. The acoustic shell is a half-dome occupying z<0 and opening
 //    toward +z, so a seat looks INTO the shell only while its own z>0 — that
 //    is, while |a| < PI/2. The bowl used to sweep +/-2.2 rad (252 deg), which
 //    left the outer 29% of every row sitting behind the shell looking at its
 //    back. The sweep is now +/-1.5 rad (172 deg), a Roman semicircle: every
 //    seat is in front of the opening.
 //
 // 2. THE RAKE. A constant rise per row does NOT give a constant view. The
 //    clearance C — how far a row's sightline passes above the eye of the row
 //    in front — decays roughly as 1/n. With the old flat 1.5 m rise it was
 //    0.58 m at row 1 and 0.071 m by row 15, well under the ~0.12 m a person
 //    needs to see past the head in front, so the back third of the bowl was
 //    looking at the back of someone's skull. Solving
 //        E(n+1) = (D(n+1)/D(n)) * (E(n) + C)
 //    for a fixed C gives the classic parabolic rake, where the rise grows with
 //    the row. E is eye height above the focus, D is eye distance from it.
 //    Rescaled so the top row still lands at y=24 where the rim wall meets it,
 //    so the bowl keeps its old silhouette and the rim and struts still fit.
 const a0=-1.5,a1=1.5;
 const NR=16,TRD=4.2,R0=24,EYE=1.2,SEATIN=2,FOCR=24,FOCY=2.4,CVAL=.18;
 const rowR=t=>R0+t*TRD;                              // inner radius of row t
 const eyeD=t=>rowR(t)+SEATIN-FOCR;                   // eye distance from the focus
 const TH=[1.5];                                      // tread height, row by row
 for(let t=1;t<NR;t++)TH.push((eyeD(t)/eyeD(t-1))*(TH[t-1]+EYE-FOCY+CVAL)+FOCY-EYE);
 {const k=(24+EYE-FOCY)/(TH[NR-1]+EYE-FOCY);          // scale E, not the height
  for(let t=0;t<NR;t++)TH[t]=(TH[t]+EYE-FOCY)*k+FOCY-EYE;}
 // seating: one mesh for every tread and one for every riser, not two per row
 const treads=[],risers=[];
 for(let t=0;t<NR;t++){const r0=rowR(t),r1=r0+TRD;const yb=t?TH[t-1]:0,yt=TH[t];
  const hole=d>0?(u,v)=>fbm(u*6+t,2,800+t,2)<.16:null;
  treads.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(r0,r1-.3,v);return[Math.sin(a)*r,yt,Math.cos(a)*r];},80,1,{hole}));
  risers.push(gridSurface((u,v)=>{const a=lerp(a0,a1,u);return[Math.sin(a)*r0,yb+v*(yt-yb),Math.cos(a)*r0];},80,1,{hole}));
  if(t%4===3)for(let k=0;k<12;k++){const a=lerp(a0,a1,(k+.5)/12);const lit=d>0?rng()<.12:true;kput('strip',[Math.sin(a)*(r0+2),yt+.1,Math.cos(a)*(r0+2)],qEuler(0,a,0),[2.5,1,1],lit?CYAN:DEAD);}}
 meshMerged(treads,CONC(d),G);meshMerged(risers,MAT.dark,G);
 // aisles: a ramp that follows the rake. The old one was a single straight box
 // laid across the bowl, which only sat on the steps while the rise was constant.
 const rakeY=r=>{const t=clamp((r-R0)/TRD,0,NR-1);const i=Math.min(Math.floor(t),NR-2);return lerp(TH[i],TH[i+1],t-i);};
 const aisles=[];
 for(let k=0;k<5;k++){const a=lerp(a0,a1,k/4);const ca=Math.cos(a),sa=Math.sin(a);
  aisles.push(gridSurface((u,v)=>{const r=lerp(R0,rowR(NR-1)+TRD,u),w=(v-.5)*3;
   return[sa*r+ca*w,rakeY(r)+.15,ca*r-sa*w];},48,1,{uS:20}));}
 meshMerged(aisles,skin,G);
 // outer rim: leaning struts and a flared rim wall (Tange). Strut count follows
 // the sweep, so they stay at the same spacing now the bowl is narrower.
 for(let k=0;k<16;k++){const a=lerp(a0,a1,(k+.5)/16);const fallen=d>0&&(k===3||k===11);const A=[Math.sin(a)*103,0,Math.cos(a)*103],B=[Math.sin(a)*93.2,29.5,Math.cos(a)*93.2];   // Iziz: struts meet the rim wall's OUTER face; they used to run through the top rows
  if(!fallen)beam(d>0?'strutR':'strutW',A,B,2.6,2.2);else beam('strutR',[A[0],1.5,A[2]],[A[0]*.8,2,A[2]*.8],2.6,2.2);}
 mesh(gridSurface((u,v)=>{const a=lerp(a0,a1,u);const r=lerp(88,92,v);return[Math.sin(a)*r,24+v*6,Math.cos(a)*r];},80,2,{uS:20,hole:holeFn(d*.7,820,null,2)}),CONC(d),G);
 // stage + petal acoustic shell
 kput('slab',[0,1.2,0],null,[24,2.4,24],new THREE.Color(d>0?0x4a4038:0xcfcac2));
 const AR=24;mesh(lathe({rFn:y=>AR*Math.sqrt(clamp(1-Math.pow(y/AR,2),0,1)),H:AR,nu:64,nv:20,hole:(u,y)=>Math.sin(u*TAU)>.02||(d>0&&fbm(u*5,y*.15,830,2)<.28)||[[.62,.5],[.8,.35],[.72,.75]].some(o=>Math.hypot((u-o[0])*4,y/AR-o[1])<.11)}),CONC(d),G,0,2.4,0);
 mesh(lathe({rFn:y=>AR*.94*Math.sqrt(clamp(1-Math.pow(y/AR,2),0,1)),H:AR,nu:32,nv:10,hole:(u,y)=>Math.sin(u*TAU)>.02}),MAT.dark,G,0,2.4,0);
 for(let k=0;k<5;k++){const a=Math.PI+(k-2)*.5;kput(BOXC(d),[Math.cos(a)*AR*.9,2.4+7,Math.sin(a)*AR*.9],qEuler(0,-a,0),[2,14,4],null);}
 kput(BOXC(d),[0,2.4+AR-2,-4],null,[30,1.2,10],null);
 stripRing(0,4,0,14,d,20);
 if(d>0){scatterMoss(0,0,0,30,120,120,2.2);rubbleRing(0,0,-40,5,60,50,2.2);trees(0,0,105,160,10);}
 figures(0,50,10,20);KOFF=[0,0,0];return G;}

// ================================================================= FUEL STATION — "the Well"
function buildFuelStation(scene,gx,gz,d){reseed(9970+d);KOFF=[gx,0,gz];const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 REGISTER({name:'Fuel station — the Well ('+STATE(d)+')',x:0,z:0,r:60,h:30});
 kput('slab',[0,.3,0],null,[52,.6,52],new THREE.Color(d>0?0x4a4038:0x8a8078));
 // canopy: one hyperboloid mast, a lobed hovering disc with a hole, six pump bays under it
 mesh(lathe({rFn:y=>4*Math.sqrt(1+2*Math.pow((y-9)/9,2)),H:18,nu:32,nv:10}),skin,G);
 mesh(lathe({rFn:y=>lerp(30,34,Math.sin(Math.PI*y/3)),H:3,flutes:6,amp:.22,sharp:1,nu:96,nv:4,hole:(u,y)=>false}),skin,G,0,15,0);
 mesh(lathe({rFn:()=>6,H:3.2,nu:24,nv:1}),MAT.dark,G,0,14.9,0);
 if(d>0)mesh(gridSurface((u,v)=>{const th=u*TAU;const r=lerp(6,30*(1+.22*(.5+.5*Math.cos(6*th))),v);return[r*Math.cos(th),15,r*Math.sin(th)];},96,4,{hole:(u,v)=>fbm(u*5,v*3,900,2)>.55}),MAT.rust,G);
 for(let k=0;k<6;k++){const th=k/6*TAU;const r=20;const x=r*Math.cos(th),z=r*Math.sin(th);const lit=d>0?rng()<.2:true;
  kput('strip',[x,14.6,z],qEuler(0,-th,0),[9,1,1],lit?CYAN:DEAD);
  kput(d>0?'boxR':'boxW',[x,1.6,z],qEuler(0,-th,0),[1.2,2.6,3],null);kput('boxD',[x,2.5,z],qEuler(0,-th,0),[1.3,.8,1.6],null);
  kput('tube',[x,1.6,z+1.8],qEuler(.6,0,0),[.15,3,.15],null);}
 // three storage lobes behind, pipes to the mast
 for(let i=0;i<3;i++){const x=-42+i*16,z=-44;const R=7;const gone=d>0&&i===1;
  if(!gone)mesh(lathe({rFn:y=>R*Math.sqrt(clamp(1-Math.pow((y-R)/R,2),0,1))+.01,H:2*R,nu:28,nv:12,hole:holeFn(d*.7,910+i,null,2)}),skin,G,x,1,z);
  else{const fm=mesh(lathe({rFn:y=>R*Math.sqrt(clamp(1-Math.pow((y-R)/R,2),0,1))+.01,H:2*R,nu:28,nv:12,hole:holeFn(1,911,null,1.5)}),MAT.rust,G,x+3,1,z+4);fm.rotation.set(.5,0,.9);dropFragment(fm,0,1.2);}
  for(let k=0;k<3;k++){const th=k/3*TAU;kput(d>0?'colR':'colW',[x+4*Math.cos(th),0,z+4*Math.sin(th)],null,[.9,1.5,.9],null);}
  kput(d>0?'pipeR':'pipe',[x,1.2,z+22],qEuler(Math.PI/2,0,0),[.5,44,.5],null);}
 kput(d>0?'pipeR':'pipe',[-26,1.2,-44],qEuler(0,0,Math.PI/2),[.6,34,.6],null);
 // kiosk
 mesh(lathe({rFn:y=>5*Math.pow(clamp(1-Math.pow(y/7,2),0,1),.5),H:7,flutes:8,amp:.1,nu:32,nv:8,hole:holeFn(d*.6,920,null,2.5)}),skin,G,34,0,-20);
 kput('archOpen',[29.5,2,-20],qFacing([-1,0,0]),[.3,.35,1],null);stripRing(34,4,-20,3.5,d,10);
 if(d>0){scatterMoss(0,.6,0,0,50,50,1.6);rubbleRing(-42,0,-44,4,20,20,1.5);trees(0,0,60,100,8);}
 figures(0,30,3,4);KOFF=[0,0,0];return G;}

// ================================================================= 2. FACTORY — "the Foundry"
function buildFactory(scene,gx,gz,d){reseed(d>0?9201:9200);KOFF=[gx,0,gz];REGISTER({name:'Factory — the Foundry ('+STATE(d)+')',x:0,z:0,r:260,h:120});const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 // plinth
 const pl=new THREE.CylinderGeometry(190*Math.SQRT2,196*Math.SQRT2,6,4,1);pl.rotateY(Math.PI/4);pl.translate(0,3,0);pl.scale(1,1,.62);mesh(pl,skin,G,-10,0,0);
 // --- great catenary vault hall (ribs + skin) -------------------------------------------------
 const W=90,Hh=55,L=160,hx=-40,z0=-L/2;const yb=6;
 for(let i=0;i<=16;i++){if(d>0&&(i===5||i===6||i===11))continue;kput(d>0?'vaultRibR':'vaultRib',[hx,yb,z0+i*10],null,1,null);}
 const skinFn=(u,v)=>{const x=(u-.5)*(W-2);return[hx+x,yb+(Hh-1.2)*(1-Math.pow(2*x/(W-2),2)),z0+v*L];};
 const ridge=(u)=>Math.abs(u-.5)<.045;
 const skH=holeFn(d,21,null,1.3);
 mesh(gridSurface(skinFn,60,64,{uS:12,vS:20,hole:(u,v)=>ridge(u)||(skH&&skH(u*4,v*L))}),skin,G);
 if(d===0)mesh(gridSurface((u,v)=>skinFn(.455+u*.09,v),8,32,{}),MAT.glass,G);
 if(d>0){mesh(gridSurface((u,v)=>{const p=skinFn(u,v);return[p[0]*.97+hx*.03,yb+(p[1]-yb)*.93,p[2]];},40,32,{uS:12,vS:20}),MAT.guts,G);
  for(let k=0;k<30;k++){const x=rr(-38,38),z=rr(z0+5,z0+L-5);kput('pipeR',[hx+x,yb+(Hh-1.2)*(1-Math.pow(2*x/(W-2),2))*.9,z],qEuler(Math.PI/2,0,0),[.6,rr(10,40),.6],null);}}
 // end walls with big arched glass openings
 [z0,z0+L].forEach((zz,i)=>{const g=paraFill(W,Hh,34,40);const m=mesh(g,skin,G,hx,yb,zz);
  if(d===0){const gl=mesh(paraFill(34,40,0,0),MAT.glass,G,hx,yb,zz+(i?-.3:.3));}
  mullions(hx,yb,zz,0,0,0,d);for(let k=-3;k<=3;k++)kput(d>0?'mullR':'mullW',[hx+k*4.8,yb+19,zz],null,[1,36*(1-Math.pow(k/3.6,2)),1],null);});
 // interior strips along the hall
 for(let k=0;k<12;k++){const z=z0+8+k*13;const lit=d>0?rng()<.12:true;kput('strip',[hx,yb+Hh-4,z],null,[60,1,1],lit?CYAN:DEAD);}
 // --- Goldberg clover silos on hyperboloid legs -----------------------------------------------
 function silo(cx,cz,tilt,seed){const S=new THREE.Group();S.position.set(cx,0,cz);if(tilt)S.rotation.x=tilt;G.add(S);
  const legH=15,lobeH=46,Rl=9.5;
  mesh(lathe({rFn:()=>6.5,H:legH+lobeH+2,nu:24,nv:4}),skin,S);
  for(let l=0;l<4;l++){const a=(l+.5)*Math.PI/2,ox=Math.cos(a)*10.5,oz=Math.sin(a)*10.5;
   kput(d>0?'colR':'colW',[cx+ox,0,cz+oz],null,[3.2,legH,3.2],null);
   const hole=holeFn(d,seed+l,null,1.6);const o={rFn:y=>Rl*(1-.04*Math.pow(clamp(y/lobeH,0,1),6)),H:lobeH,nu:36,nv:24,hole,seed};
   const lm=mesh(lathe(o),skin,S,ox,legH,oz);
   if(d>0)mesh(lathe({rFn:()=>Rl*.9,H:lobeH,nu:20,nv:2}),MAT.guts,S,ox,legH,oz);
   // rim + oval windows facing outward from the core
   kput(d>0?'ringR':'ringW',[cx+ox,legH+lobeH,cz+oz],qEuler(Math.PI/2,0,0),[Rl+.2,Rl+.2,3],null);
   for(let yy=4;yy<lobeH-3;yy+=5.5)for(let k=-2;k<=2;k++){const th=a+k*.42;const u=((th%TAU)+TAU)%TAU/TAU;if(hole&&hole(u,yy))continue;
    kput(d>0?'ovalD':'ovalI',[cx+ox+Rl*Math.cos(th),legH+yy,cz+oz+Rl*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.9,1.4,1],null);}
   if(d>0)vinesOnRing(cx+ox,legH+lobeH,cz+oz,Rl,10,30);}
  kput('slab',[cx,legH+lobeH+2,cz],null,[7,1,7],new THREE.Color(d>0?0x5a4a40:0xd8d4cc));
  if(d>0)mossOnRing(cx,legH+lobeH+2.3,cz,6,10,2);}
 silo(72,-58,0,31);silo(72,0,0,32);silo(72,58,0,33);
 // pipes silos → hall
 for(let i=0;i<3;i++){const z=-58+i*58;kput(d>0?'pipeR':'pipe',[30,34+i*3,z],qEuler(0,0,Math.PI/2),[1.6,70,1.6],null);
  if(d>0&&i===1)continue;kput(d>0?'pipeR':'pipe',[30,34+i*3,z+6],qEuler(0,0,Math.PI/2),[1.1,70,1.1],null);}
 // --- organic stacks (Parc Güell chimneys, industrial scale) ------------------------------------
 for(let i=0;i<4;i++){const cx=22,cz=-75+i*50,H=95+i*6;const cutF=d>0?[.55,null,.7,null][i]:null;const cut=cutF!=null?H*cutF:null;
  const rFn=y=>6.5*(1-.45*y/H)+2.2*clamp((y-H+14)/14,0,1);const hole=holeFn(d,41+i,cut,1.2);
  const o={rFn,H,cut,jag:cut?4:0,flutes:9,amp:.28,sharp:2.5,nu:54,nv:40,hole,seed:41+i};
  mesh(lathe(o),skin,G,cx,6,cz);if(d>0)mesh(lathe({rFn:y=>rFn(y)*.85,H,cut,jag:o.jag,nu:20,nv:8}),MAT.guts,G,cx,6,cz);
  if(cut==null){const rc=rFn(H)+1.2;mesh(lathe({rFn:y=>rc*Math.sqrt(clamp(1-Math.pow(y/8,2),0,1)),H:8,nu:24,nv:8}),skin,G,cx,6+H-.5,cz);}
  else rubbleRing(cx,6,cz,8,22,50,2.5);
  for(let yy=15;yy<H*.9;yy+=22){if(cut&&yy>cut-6)break;kput(d>0?'ringR':'ringW',[cx,6+yy,cz],qEuler(Math.PI/2,0,0),[rFn(yy)*1.07,rFn(yy)*1.07,4],null);}}
 // --- viaduct (parabolic arcade) carrying the conveyor tube --------------------------------------
 const vz=-100;for(let i=0;i<19;i++){const x=-180+i*16;const gone=d>0&&(i===7||i===8||i===9);
  if(!gone)kput(d>0?'archR':'arch',[x,0,vz],null,1,null);else rubbleRing(x,0,vz,1,10,35,2.2);
  if(!gone||d===0)kput(d>0?'pipeR':'pipe',[x,29.5,vz],qEuler(0,0,Math.PI/2),[2.7,16.2,2.7],null);}
 kput(d>0?'pipeR':'pipe',[-180+18*16+8,29.5,vz],qEuler(0,0,Math.PI/2),[3.2,16,3.2],null);
 // conveyor bends into the hall's west wall
 kput(d>0?'pipeR':'pipe',[-172,29.5,vz+8],qEuler(Math.PI/2,0,0),[3.2,16,3.2],null);
 kput(d>0?'pipeR':'pipe',[-172,29.5,z0+40],qEuler(Math.PI/2,0,0),[3.2,84,3.2],null);
 kput(d>0?'pipeR':'pipe',[hx-38,29.5,z0+80],qEuler(0,0,Math.PI/2),[3.2,180,3.2],null);
 for(let x=-160;x<=-100;x+=20)kput(d>0?'colR':'colW',[x,6,z0+80],null,[1.5,22,1.5],null);
 if(d>0){const fx=-180+8*16;const fm=mesh(new THREE.CylinderGeometry(3.2,3.2,40,10),MAT.pipeRust,G,fx+4,2.6,vz+6);fm.rotation.set(.1,0,Math.PI/2+.08);dropFragment(fm,0,.8);}
 factoryExtras(G,d,skin);
 if(d>0){scatterMoss(-10,6,0,0,200,200,3);rubbleRing(0,6,0,20,190,90,2.5);trees(0,0,210,290,24);scatterMoss(0,0,0,205,300,120,3);}
 figures(-120,120,6,8);figures(40,-130,4,5);KOFF=[0,0,0];
 return G;}

// ================================================================= 3. LABORATORY — "the Reliquary"
function buildLab(scene,gx,gz,d){reseed(d>0?9301:9300);KOFF=[gx,0,gz];REGISTER({name:'Laboratory — the Reliquary ('+STATE(d)+')',x:0,z:0,r:40,h:125});REGISTER({name:'Laboratory — reactor hut',x:104,z:0,r:12,h:17});const G=new THREE.Group();G.position.set(gx,0,gz);scene.add(G);const skin=SHELL(d);
 const SH=4.4,NS=6;const phase=s=>s*.55;
 const rW=(th,s)=>30+2.6*Math.sin(7*th+phase(s))+1.1*Math.sin(3*th-phase(s)*.7);
 const lSkin=[],lGuts=[];   // the six storeys become one mesh, not three or four each
 for(let s=0;s<NS;s++){const y0=s*SH;const hole=holeFn(d*(s>=4?1:.35),61+s,null,2);
  lSkin.push(gridSurface((u,v)=>{const th=u*TAU,r=rW(th,s);return[r*Math.cos(th),y0+.3+v*(SH-.3),r*Math.sin(th)];},112,6,{uS:28,vS:.6,hole:hole?(u,v)=>hole(u,y0+v*SH+s*40):null}));
  if(d>0)lGuts.push(gridSurface((u,v)=>{const th=u*TAU,r=rW(th,s)*.9;return[r*Math.cos(th),y0+.3+v*(SH-.3),r*Math.sin(th)];},64,2,{}));
  // undulating balcony: floor annulus + fascia band
  const rB=th=>rW(th,s)+2.4+.9*Math.sin(7*th+phase(s)+1.2);
  const bHole=d>0?(u,v)=>fbm(u*9+s,3,61+s)<.22*d:null;
  lSkin.push(gridSurface((u,v)=>{const th=u*TAU,r=lerp(rW(th,s)-.3,rB(th),v);return[r*Math.cos(th),y0+.3,r*Math.sin(th)];},112,3,{hole:bHole}));
  lSkin.push(gridSurface((u,v)=>{const th=u*TAU,r=rB(th);return[r*Math.cos(th),y0+.3-.5+v*1.6,r*Math.sin(th)];},112,2,{uS:28,hole:bHole}));
  // windows / ground-floor arcade
  const n=s===0?14:21;for(let k=0;k<n;k++){const th=(k+.3)/n*TAU;const u=th/TAU;if(hole&&hole(u,y0+2+s*40))continue;const r=rW(th,s)+.1;
   if(s===0)kput('archOpen',[r*Math.cos(th),4.6,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),[.7,.7,1],null);
   else kput(d>0?'winBigD':'winBigI',[r*Math.cos(th),y0+2.3,r*Math.sin(th)],qFacing([Math.cos(th),0,Math.sin(th)]),1,null);}
  if(s>0)stripRing(0,y0+3.9,0,rW(0,s)*.88,d,28);
  }
 meshMerged(lSkin,skin,G);meshMerged(lGuts,MAT.guts,G);
 apron(G,0,0,32,50,d,1.1);
 // Decay read off the building's own geometry rather than sprayed in rings:
 // moss only where a surface faces the sky, vines and staining only off the
 // outer edge of those surfaces, which is where the balcony ledges are.
 if(d>0){mossOnSurface(lSkin,0,0,0,150,2.0);vinesFromLedge(lSkin,0,0,0,54,16);stainsFromLedge(lSkin,0,0,0,44,13);}
 // roof slab + parapet
 const RY=NS*SH;const roofPts=[];for(let i=0;i<112;i++){const th=i/112*TAU,r=rW(th,NS-1);roofPts.push(new THREE.Vector2(r*Math.cos(th),-r*Math.sin(th)));}
 const roof=new THREE.ShapeGeometry(new THREE.Shape(roofPts));roof.rotateX(-Math.PI/2);mesh(roof,skin,G,0,RY+.3,0);
 mesh(gridSurface((u,v)=>{const th=u*TAU,r=rW(th,NS-1)+.4;return[r*Math.cos(th),RY+.3+v*(1.3+.6*Math.sin(5*th)),r*Math.sin(th)];},112,2,{uS:28}),skin,G);
 if(d>0)mossOnRing(0,RY+.5,0,18,40,2.4);
 // twisted chimney sculptures with helmet caps
 for(let i=0;i<6;i++){const a=i/6*TAU+.4,r=22,cx=r*Math.cos(a),cz=r*Math.sin(a);const fallen=d>0&&(i===2||i===4);
  const ch=lathe({rFn:y=>1.4*(1-.25*y/7)+.6*clamp((y-5)/2,0,1),H:7,flutes:4,amp:.35,sharp:1.5,twist:.5,nu:24,nv:14});
  const m=mesh(ch,skin,G);
  if(!fallen){m.position.set(cx,RY+.3,cz);mesh(lathe({rFn:y=>2.2*Math.sqrt(clamp(1-Math.pow(y/2.4,2),0,1)),H:2.4,nu:16,nv:6}),skin,G,cx,RY+7.2,cz);}
  else{m.position.set(cx*1.1,RY+1.2,cz*1.1);m.rotation.set(0,-a,Math.PI/2*.95);dropFragment(m,RY+.3,.1);}}
 // lattice dome: ribbed outer shell with open panels, blue glass inner (intact)
 const R=17,Hd=22;const dR=y=>R*Math.pow(clamp(1-Math.pow(y/Hd,2),0,1),.62);
 const collapse=d>0?(u,y)=>fbm(u*3+.7,y*.06,77,2)>.62:null;
 const domeHole=(u,y)=>{const panel=Math.cos(u*TAU*24)<.35&&y<Hd*.82&&y>1.5;return panel||(collapse&&collapse(u,y));};
 mesh(lathe({rFn:dR,H:Hd,flutes:24,amp:.07,sharp:2,nu:120,nv:36,hole:domeHole}),skin,G,0,RY+.3,0);
 if(d===0)mesh(lathe({rFn:y=>dR(y)*.94,H:Hd,nu:64,nv:24}),MAT.glass,G,0,RY+.3,0);
 else{mesh(lathe({rFn:y=>dR(y)*.94,H:Hd,nu:64,nv:24,hole:(u,y)=>collapse(u,y)||fbm(u*5,y*.1,78,2)<.55}),MAT.dark,G,0,RY+.3,0);}
 kput('slab',[0,RY+.6,0],null,[R*.95,.4,R*.95],new THREE.Color(0x24262a));
 stripRing(0,RY+2,0,R*.85,d,32);stripRing(0,RY+9,0,dR(9)*.85,d,32);
 // antenna spire (Moebius needle) with rings
 const AH=72;const aR=y=>2.4*Math.pow(clamp(1-y/AH,0,1),.75)+.3;const acut=d>0?AH*.55:null;
 mesh(lathe({rFn:aR,H:AH,cut:acut,jag:acut?2:0,flutes:6,amp:.25,sharp:1.5,nu:24,nv:30,hole:holeFn(d*.6,81,acut,1)}),skin,G,0,RY+Hd-2,0);
 for(let yy=12;yy<AH-8;yy+=12){if(acut&&yy>acut-3)break;kput(d>0?'ringR':'ringW',[0,RY+Hd-2+yy,0],qEuler(Math.PI/2,0,0),[aR(yy)*2.2,aR(yy)*2.2,6],null);}
 if(d===0)kput('finial',[0,RY+Hd-2+AH+2,0],null,[1.8,2.8,1.8],null);
 else{const fm=mesh(lathe({rFn:y=>aR(acut+y),H:AH-acut,flutes:6,amp:.25,sharp:1.5,nu:20,nv:12}),MAT.rust,G,44,1.2,-38);fm.rotation.set(0,.8,Math.PI/2*.9);dropFragment(fm,0,.3);rubbleRing(46,0,-40,2,12,26,1.6);}
 // colonnaded porch → reactor hut
 for(let i=0;i<7;i++)for(let sgn=-1;sgn<=1;sgn+=2){const x=36+i*8.5,z=sgn*5.5;const gone=d>0&&i===3&&sgn>0;
  if(!gone)kput(d>0?'colR':'colW',[x,0,z],null,[.9,6.5,.9],null);else kput('colR',[x+2,.5,z+3],qEuler(Math.PI/2,.4,0),[.9,6.5,.9],null);}
 mesh(gridSurface((u,v)=>[34+u*56,6.6+.7*Math.sin(u*14)+.3*Math.sin(v*6),(v-.5)*14],40,8,{uS:6,vS:2,hole:d>0?(u,v)=>fbm(u*6,v*3,88,2)<.3:null}),skin,G);
 const hut=new THREE.Group();hut.position.set(104,0,0);G.add(hut);
 mesh(lathe({rFn:()=>10,H:5,nu:40,nv:2,hole:holeFn(d*.5,90,null,2)}),skin,hut);
 mesh(lathe({rFn:y=>10*Math.pow(clamp(1-Math.pow(y/11,2),0,1),.6),H:11,flutes:12,amp:.08,nu:48,nv:16,hole:d>0?(u,y)=>fbm(u*3,y*.1,91,2)>.6:null}),skin,hut,0,5,0);
 if(d>0)mesh(lathe({rFn:y=>9.2*Math.pow(clamp(1-Math.pow(y/11,2),0,1),.6),H:11,nu:32,nv:8}),MAT.dark,hut,0,5,0);
 kput('archOpen',[104-10,4.5,0],qFacing([-1,0,0]),[.6,.6,1],null);
 stripRing(104,7,0,7,d,20);
 if(d>0){scatterMoss(0,0,0,34,120,160,2.4);rubbleRing(0,0,0,34,70,50,1.6);trees(0,0,70,150,18);}
 figures(-50,55,5,5);figures(60,22,3,3);KOFF=[0,0,0];
 return G;}

// TARGET: vernacular — the Iziz Vernacular set laid out in rows by family, front (+z) toward the camera.
const TITLE='Iziz Vernacular Set';
const GROUND_C=250;          // z centre of the ground plane
const ROWDEF=[
 ['vern_house_poor_a','vern_house_poor_b','vern_house_poor_c'],
 ['vern_house_mid_a','vern_house_mid_b','vern_house_mid_c'],
 ['vern_house_rich_a','vern_house_rich_b'],
 ['vern_shops','vern_tavern'],
 ['vern_workshop_a','vern_workshop_b','vern_smithy'],
 ['vern_market','vern_warehouse'],
 ['vern_silos','vern_tank','vern_generator'],
 ['vern_school','vern_hospital'],
 ['vern_alchemist'],
 ['vern_barracks'],
 ['vern_farmers_guild','vern_beast_hunters_guild'],
 ['vern_caravanserai','vern_forgemasters_hall'],
 ['port_voth_embassy','port_order_chapterhouse'],
];
const ROWZ=[0,42,96,160,214,268,330,396,466,536,610,680,760,880,1010];
const SITES=[];
ROWDEF.forEach((row,ri)=>{const ws=row.map(k=>VERN.defs[k].w+10);const total=ws.reduce((a,b)=>a+b,0);let x=-total/2;
 row.forEach((k,i)=>{SITES.push({key:k,x:x+ws[i]/2,z:ROWZ[ri],ry:0,o:{v:0}});x+=ws[i];});});
// the two Ancients-reclaimed guilds at the scale the city places them (.5)
SITES.push({key:'anc_salvagers_guild',x:0,z:ROWZ[13],ry:0,o:{v:0,scale:.5},label:"Salvagers' Guild (Ancient laboratory) @ .5"});
SITES.push({key:'anc_mercenary_guild',x:0,z:ROWZ[14],ry:0,o:{v:0,scale:.5},label:'Mercenary Guild (Ancient police station) @ .5'});
// ---------------------------------------------------------------- scene
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();const HAZE=new THREE.Color(0xc8b090);scene.fog=new THREE.FogExp2(HAZE.getHex(),.00055);
const camera=new THREE.PerspectiveCamera(50,innerWidth/innerHeight,.3,6000);
scene.add(new THREE.HemisphereLight(0xffe8d0,0x4a3a2a,.7));
const sun=new THREE.DirectionalLight(0xfff0dc,1.6);sun.position.set(-600,700,400);scene.add(sun);
const fill=new THREE.DirectionalLight(0xb8c8ff,.32);fill.position.set(500,300,-600);scene.add(fill);
// hooks the frame loop runs (city: sky/lighting update); the showcase adds none
const FRAME_HOOKS=[];
// sky dome (the Ancients kit's warm haze sky; the city target swaps in KratorSky and skips this block)
let sky,giant,groundM,LABELS;const SITE_GROUPS=[];
const giantDir=new THREE.Vector3(Math.sin(66*Math.PI/180)*Math.cos(25*Math.PI/180),Math.sin(25*Math.PI/180),-Math.cos(66*Math.PI/180)*Math.cos(25*Math.PI/180));

if(!window.CITY){
const skyMat=new THREE.ShaderMaterial({side:THREE.BackSide,fog:false,depthWrite:false,uniforms:{},
 vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:'varying vec3 vP;void main(){float h=clamp(normalize(vP).y,-.05,1.);vec3 hz=vec3(.84,.66,.48);vec3 zen=vec3(.30,.42,.66);vec3 c=mix(hz,zen,pow(h,.5));gl_FragColor=vec4(c,1.);}'});
sky=new THREE.Mesh(new THREE.SphereGeometry(5000,32,16),skyMat);sky.userData.probeSkip=true;scene.add(sky);
const giantTex=canvasTex(512,512,(g,w,h)=>{g.clearRect(0,0,w,h);const grd=g.createRadialGradient(256,256,0,256,256,256);
 for(let i=0;i<=20;i++){const t=i/20;const b=.8+.2*Math.sin(i*2.1);grd.addColorStop(t*.96,`rgba(${220*b|0},${180*b|0},${150*b|0},${.85*(1-Math.pow(t,6))})`);}
 grd.addColorStop(1,'rgba(220,180,150,0)');g.fillStyle=grd;g.beginPath();g.arc(256,256,250,0,TAU);g.fill();
 g.globalCompositeOperation='source-atop';for(let y=0;y<h;y+=9){g.fillStyle=`rgba(${120+(y*7)%80},${90+(y*3)%50},${70},${.10+.10*Math.sin(y*.3)})`;g.fillRect(0,y,w,5);}});
giantTex.wrapS=giantTex.wrapT=THREE.ClampToEdgeWrapping;
giant=new THREE.Sprite(new THREE.SpriteMaterial({map:giantTex,fog:false,transparent:true,depthWrite:false}));giant.scale.set(1400,1400,1);giant.userData.probeSkip=true;scene.add(giant);

// ground: packed earth, tiled in world units
TEX.dirt.repeat.set(150,150);
groundM=new THREE.Mesh(new THREE.PlaneGeometry(3000,3000),MAT.dirt);groundM.rotation.x=-Math.PI/2;groundM.position.set(0,-.05,GROUND_C);groundM.userData.probeSkip=true;scene.add(groundM);

// ---------------------------------------------------------------- build every site the target lists
// SITES = [{key, x, z, ry, o, label}] from the target's 89z-rows.js
for(const S of SITES){const k=S.key+'/'+((S.o&&S.o.v)||0);TSTAT.cur=k;const r0=REG.length;
 const G=VERN.place(scene,S.key,S.x,S.z,S.ry||0,S.o);if(G)SITE_GROUPS.push({S,G});
 for(let i=r0;i<REG.length;i++)REG[i].type=S.key;TSTAT.cur=null;}
window._registered=REG.length;
kbake(scene);

// site labels come from src/93-labels.js (the atlas over REG)
LABELS=new THREE.Group();LABELS.userData.probeSkip=true;scene.add(LABELS);
}   // end showcase-only block
// ---------------------------------------------------------------- probe (window._api) — same contract as the Ancients kit's, so verify.py runs unchanged
const BUDGET={
 showcase:{tris:3000000,calls:400},
 cls:{small:60000,medium:250000,sky:400000,mega:700000},
 type:{},   // every vernacular key defaults to 'medium'
};
function _probePoints(){
 const pts=[],m=new THREE.Matrix4(),pos=new THREE.Vector3(),q=new THREE.Quaternion(),sc=new THREE.Vector3();const bb=new THREE.Box3();
 scene.traverse(o=>{if(o.userData&&o.userData.probeSkip)return;
  if(o.isInstancedMesh){for(let i=0;i<o.count;i++){o.getMatrixAt(i,m);m.decompose(pos,q,sc);pts.push([pos.x,pos.y,pos.z]);}return;}
  if(!o.isMesh)return;bb.setFromObject(o);if(!isFinite(bb.min.x)||!isFinite(bb.max.x))return;
  pts.push([(bb.min.x+bb.max.x)/2,(bb.min.y+bb.max.y)/2,(bb.min.z+bb.max.z)/2]);
  for(const x of[bb.min.x,bb.max.x])for(const y of[bb.min.y,bb.max.y])for(const z of[bb.min.z,bb.max.z])pts.push([x,y,z]);});
 return pts;}
function regOccupancy(){const BK=100,by={};REG.forEach((r,i)=>{const z0=Math.floor((r.z-r.r)/BK),z1=Math.floor((r.z+r.r)/BK);for(let b=z0;b<=z1;b++)(by[b]||(by[b]=[])).push(i);});
 const n=new Array(REG.length).fill(0);for(const p of _probePoints()){const cand=by[Math.floor(p[2]/BK)];if(!cand)continue;for(const i of cand){const r=REG[i];const dx=p[0]-r.x,dz=p[2]-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p[1]>=r.y-2&&p[1]<=r.y+r.h+5)n[i]++;}}
 return REG.map((r,i)=>({name:r.name,type:r.type,n:n[i]}));}
function nanSweep(){const bad=[];scene.traverse(o=>{if(!o.isMesh||(o.userData&&o.userData.probeSkip))return;const p=o.geometry&&o.geometry.attributes&&o.geometry.attributes.position;if(!p)return;const a=p.array;for(let i=0;i<a.length;i++)if(!isFinite(a[i])){bad.push({geo:o.geometry.type,at:i,n:a.length});break;}});
 return{meshes:bad.length,first:bad.slice(0,8),instances:TSTAT.bad.length,firstInstances:TSTAT.bad.slice(0,8)};}
function typeStats(){const out={};for(const k in TSTAT.by){const t=TSTAT.by[k],base=k.split('/')[0];const cls=BUDGET.type[base]||'medium';out[k]={tris:t.tris,inst:t.inst,meshes:t.meshes,cls,limit:BUDGET.cls[cls],over:t.tris>BUDGET.cls[cls]};}return out;}
// tag audit: every registered volume must carry a classification and the project tags
function tagAudit(){const bad=REG.filter(r=>!r.cls||!r.tags||!r.tags.culture||!r.tags.type||!r.tags.wealth);return{bad:bad.length,first:bad.slice(0,6).map(r=>r.name)};}
window._api={BUDGET,REG,
 get totals(){let tris=0,inst=0,meshes=0;for(const k in TSTAT.by){tris+=TSTAT.by[k].tris;inst+=TSTAT.by[k].inst;meshes+=TSTAT.by[k].meshes;}return{tris,inst,meshes,registered:REG.length,types:Object.keys(TSTAT.by).length};},
 typeStats,regOccupancy,nanSweep,tagAudit,
 setView:(cx,cy,cz,tx,ty,tz)=>setView(cx,cy,cz,tx,ty,tz),views:()=>Object.keys(VIEWS),
 defs:()=>VERN.order.map(k=>{const D=VERN.defs[k];return{key:k,name:D.name,family:D.family,tags:D.tags,w:D.w,d:D.d,h:D.h};})};
const RV=(ri,dist,h,ty)=>[0,h,ROWZ[ri]+dist,0,ty,ROWZ[ri]];
const SITEV=(key,dist,h,ty,dx)=>{const S=SITES.find(s=>s.key===key);return[S.x+(dx||0),h,S.z+dist,S.x,ty,S.z];};
const EYE=(key,dist,dx)=>{const S=SITES.find(s=>s.key===key);return[S.x+(dx||0),1.7,S.z+dist,S.x,3,S.z];};
const VIEWS={
 'Opening':[-95,38,150,-6,8,48],
 'Overview':[-620,330,ROWZ[7]+40,0,10,ROWZ[7]],
 'Poor dwellings':RV(0,44,22,3),'Poor — eye level':EYE('vern_house_poor_a',16,6),
 'Middle dwellings':RV(1,52,26,4),'Middle — eye level':EYE('vern_house_mid_a',18,5),
 'Rich dwellings':RV(2,70,34,5),'Manor — eye level':EYE('vern_house_rich_a',26,8),'Domed house — eye level':EYE('vern_house_rich_b',26,-6),
 'Shops and tavern':RV(3,52,26,4),'Shops — eye level':EYE('vern_shops',16,4),'Tavern — eye level':EYE('vern_tavern',22,6),
 'Workshops and smithy':RV(4,50,26,4),'Smithy — eye level':EYE('vern_smithy',18,6),
 'Market and warehouse':RV(5,60,32,5),'Market — inside':EYE('vern_market',6,3),
 'Silos, tank, generator':RV(6,56,30,5),'Generator — eye level':EYE('vern_generator',16,6),
 'School and hospital':RV(7,72,38,6),'School — eye level':EYE('vern_school',26,4),
 'Alchemist':RV(8,54,30,6),'Alchemist — court':EYE('vern_alchemist',10,3),
 'Barracks':RV(9,68,40,6),'Barracks — gate':EYE('vern_barracks',30,2),
 'Guilds — farmers, beast hunters':RV(10,62,34,6),"Farmers' Guild — eye level":EYE('vern_farmers_guild',24,4),
 'Caravanserai and Forgemasters':RV(11,70,38,6),'Caravanserai — court':EYE('vern_caravanserai',8,2),"Forgemasters' Hall — eye level":EYE('vern_forgemasters_hall',28,6),
 'Voth Embassy and Order Chapterhouse':RV(12,72,40,8),'Embassy — eye level':EYE('port_voth_embassy',26,5),'Chapterhouse — eye level':EYE('port_order_chapterhouse',26,-5),
 "Salvagers' Guild (Ancient laboratory)":RV(13,90,50,20),"Salvagers' — yard":EYE('anc_salvagers_guild',42,6),
 'Mercenary Guild (Ancient police station)':RV(14,90,50,12),'Mercenary — gate':EYE('anc_mercenary_guild',50,3),
};
// ---------------------------------------------------------------- camera, inspector, polygon tool, walk mode
const ctl={target:new THREE.Vector3(0,10,0),theta:0,phi:1.1,radius:120};
function setView(cx,cy,cz,tx,ty,tz){WALK.on=false;ctl.target.set(tx,ty,tz);const dx=cx-tx,dy=cy-ty,dz=cz-tz;ctl.radius=Math.sqrt(dx*dx+dy*dy+dz*dz);ctl.theta=Math.atan2(dx,dz);ctl.phi=Math.acos(clamp(dy/ctl.radius,-1,1));}
function applyCam(){if(WALK.on){camera.position.set(WALK.x,WALK.y,WALK.z);camera.rotation.set(0,0,0);camera.rotation.order='YXZ';camera.rotation.y=WALK.yaw;camera.rotation.x=WALK.pitch;return;}
 const r=ctl.radius,sp=Math.sin(ctl.phi);camera.position.set(ctl.target.x+r*sp*Math.sin(ctl.theta),ctl.target.y+r*Math.cos(ctl.phi),ctl.target.z+r*sp*Math.cos(ctl.theta));
 const gy=terrainH(camera.position.x,camera.position.z)+1.2;if(camera.position.y<gy)camera.position.y=gy;camera.lookAt(ctl.target);}
const ui=document.getElementById('ui');
const sel=document.createElement('select');sel.id='viewsel';for(const k in VIEWS){const o=document.createElement('option');o.textContent=k;sel.appendChild(o);}sel.onchange=()=>setView(...VIEWS[sel.value]);ui.appendChild(sel);
// hidden one-button-per-view list: verify.py drives the camera by clicking these
const hb=document.createElement('div');hb.style.display='none';ui.appendChild(hb);for(const k in VIEWS){const b=document.createElement('button');b.textContent=k;b.onclick=()=>setView(...VIEWS[k]);hb.appendChild(b);}
function uiButton(label,on,fn){const b=document.createElement('button');b.textContent=label;if(on)b.classList.add('on');b.onclick=()=>{const v=fn();if(v!==undefined)b.classList.toggle('on',v);};ui.appendChild(b);return b;}

// ---- inspector: hover shows name · classification · tags (project rule); toggleable, on by default
const INSP={on:true,last:0};const insp=document.getElementById('insp');const ray=new THREE.Raycaster();
function regAt(p){let best=null;for(const r of REG){const dx=p.x-r.x,dz=p.z-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p.y>=r.y-2&&p.y<=r.y+r.h+5){if(!best||r.r<best.r)best=r;}}return best;}
function inspectAt(cx,cy){const v=new THREE.Vector2(cx/innerWidth*2-1,-(cy/innerHeight)*2+1);ray.setFromCamera(v,camera);
 const hits=ray.intersectObjects(scene.children,true).filter(h=>!(h.object.userData&&h.object.userData.probeSkip)&&h.object!==groundM&&!(h.object.userData&&h.object.userData.isGround));
 if(!hits.length){insp.style.display='none';return;}const p=hits[0].point;const r=regAt(p);
 if(!r){insp.style.display='block';insp.innerHTML='<b>unregistered '+(hits[0].object.isInstancedMesh?'instance':'mesh')+'</b>\n'+p.x.toFixed(1)+', '+p.y.toFixed(1)+', '+p.z.toFixed(1);return;}
 const t=r.tags||{};const tagLines=Object.keys(t).map(k=>'<span class="tag">'+k+'</span>: '+(Array.isArray(t[k])?t[k].join(', '):t[k])).join('\n');
 insp.style.display='block';insp.innerHTML='<b>'+r.name+'</b>\n<span class="cls">'+(r.cls||'?')+'</span>'+(r.key?'  ·  '+r.key:'')+'\n'+tagLines+'\n<span style="opacity:.6">'+p.x.toFixed(1)+', '+p.y.toFixed(1)+', '+p.z.toFixed(1)+'</span>';}
uiButton('Inspector',true,()=>{INSP.on=!INSP.on;if(!INSP.on)insp.style.display='none';return INSP.on;});
uiButton('Labels',true,()=>{if(LABELS)LABELS.visible=!LABELS.visible;return LABELS?LABELS.visible:false;});

// ---- polygon tool: click the ground to lay out a polygon; copy-pasteable world coordinates
const POLY={on:false,pts:[],fmt:0,grp:new THREE.Group(),line:null};POLY.grp.userData.probeSkip=true;scene.add(POLY.grp);
const polyEl=document.getElementById('poly'),polyOut=document.getElementById('polyout');
const polyMat=new THREE.MeshBasicMaterial({color:0xff5060}),polyLineMat=new THREE.LineBasicMaterial({color:0xffe060});
function polyRedraw(){while(POLY.grp.children.length)POLY.grp.remove(POLY.grp.children[0]);
 for(const p of POLY.pts){const m=new THREE.Mesh(new THREE.CylinderGeometry(.25,.25,3,8),polyMat);m.position.set(p[0],terrainH(p[0],p[1])+1.5,p[1]);m.userData.probeSkip=true;POLY.grp.add(m);}
 if(POLY.pts.length>1){const g=new THREE.BufferGeometry().setFromPoints(POLY.pts.map(p=>new THREE.Vector3(p[0],terrainH(p[0],p[1])+.4,p[1])));const l=new THREE.Line(g,polyLineMat);l.userData.probeSkip=true;POLY.grp.add(l);}
 const f=p=>POLY.fmt?'{x:'+p[0].toFixed(1)+',z:'+p[1].toFixed(1)+'}':'['+p[0].toFixed(1)+','+p[1].toFixed(1)+']';
 polyOut.value='['+POLY.pts.map(f).join(',')+']';window._poly=POLY.pts.slice();}
function polyAdd(cx,cy){const v=new THREE.Vector2(cx/innerWidth*2-1,-(cy/innerHeight)*2+1);ray.setFromCamera(v,camera);const pl=new THREE.Plane(new THREE.Vector3(0,1,0),0);const hit=new THREE.Vector3();
 const gh=ray.intersectObjects(scene.children,true).find(h=>h.object===groundM||(h.object.userData&&h.object.userData.isGround));if(gh){POLY.pts.push([gh.point.x,gh.point.z]);polyRedraw();}else if(ray.ray.intersectPlane(pl,hit)){POLY.pts.push([hit.x,hit.z]);polyRedraw();}}
uiButton('Polygon',false,()=>{POLY.on=!POLY.on;polyEl.style.display=POLY.on?'block':'none';return POLY.on;});
document.getElementById('polyundo').onclick=()=>{POLY.pts.pop();polyRedraw();};
document.getElementById('polyclear').onclick=()=>{POLY.pts=[];polyRedraw();};
document.getElementById('polyclose').onclick=()=>{if(POLY.pts.length>2){POLY.pts.push(POLY.pts[0].slice());polyRedraw();}};
document.getElementById('polyfmt').onclick=e=>{POLY.fmt^=1;e.target.textContent=POLY.fmt?'Format: {x,z}':'Format: [x,z]';polyRedraw();};
document.getElementById('polycopy').onclick=()=>{polyOut.select();try{navigator.clipboard.writeText(polyOut.value);}catch(e){document.execCommand('copy');}};

// ---- walk mode (F): eye height 1.7 m, WASD, drag to look. The set is meant to be judged from here.
const WALK={on:false,x:0,y:1.7,z:40,yaw:0,pitch:0};
uiButton('Walk (F)',false,()=>{toggleWalk();return WALK.on;});
function toggleWalk(){WALK.on=!WALK.on;if(WALK.on){const d=new THREE.Vector3();camera.getWorldDirection(d);WALK.yaw=Math.atan2(-d.x,-d.z);WALK.pitch=0;
 WALK.x=camera.position.x;WALK.z=camera.position.z;WALK.y=terrainH(WALK.x,WALK.z)+1.7;}else{setView(WALK.x-Math.sin(WALK.yaw)*-30,20,WALK.z-Math.cos(WALK.yaw)*-30,WALK.x-Math.sin(WALK.yaw)*10,4,WALK.z-Math.cos(WALK.yaw)*10);}
 for(const b of ui.querySelectorAll('button'))if(b.textContent.startsWith('Walk'))b.classList.toggle('on',WALK.on);}

setView(...VIEWS[Object.keys(VIEWS)[0]]);
document.title=TITLE;
document.getElementById('cap').textContent=TITLE+' — hover to inspect · drag to orbit · wheel to zoom · right-drag / WASD to move · F walk at eye height · Polygon to mark coordinates';
// input
const cv=renderer.domElement;let drag=null;const keys={};
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,b:e.button};cv.setPointerCapture(e.pointerId);});
cv.addEventListener('pointerup',e=>{if(drag&&Math.abs(e.clientX-drag.sx)<4&&Math.abs(e.clientY-drag.sy)<4){if(drag.b===0&&POLY.on)polyAdd(e.clientX,e.clientY);else if(drag.b===2&&POLY.on){POLY.pts.pop();polyRedraw();}else if(drag.b===0&&!INSP.on)inspectAt(e.clientX,e.clientY);}drag=null;});
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointermove',e=>{if(!drag){if(INSP.on&&performance.now()-INSP.last>90){INSP.last=performance.now();inspectAt(e.clientX,e.clientY);}return;}
 const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;
 if(WALK.on){WALK.yaw-=dx*.004;WALK.pitch=clamp(WALK.pitch-dy*.004,-1.4,1.4);return;}
 if(drag.b===0){ctl.theta-=dx*.005;ctl.phi=clamp(ctl.phi-dy*.005,.05,Math.PI-.05);}
 else{const f=ctl.radius*.0015;const rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta));ctl.target.addScaledVector(rt,-dx*f).addScaledVector(fw,-dy*f);}});
cv.addEventListener('wheel',e=>{if(WALK.on){WALK.speed=clamp((WALK.speed||6)*(e.deltaY>0?.85:1.18),1,40);}else ctl.radius=clamp(ctl.radius*(e.deltaY>0?1.1:.9),2,3000);e.preventDefault();},{passive:false});
addEventListener('keydown',e=>{if(e.target.tagName==='TEXTAREA')return;keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='f')toggleWalk();});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
const hud=document.getElementById('hud');let last=performance.now(),renderErr=false;
function frame(){const now=performance.now(),dt=Math.min(.1,(now-last)/1000);last=now;
 if(WALK.on){const sp=(WALK.speed||6)*(keys.shift?2.5:1)*dt;const fw=new THREE.Vector3(-Math.sin(WALK.yaw),0,-Math.cos(WALK.yaw)),rt=new THREE.Vector3(Math.cos(WALK.yaw),0,-Math.sin(WALK.yaw));
  if(keys.w){WALK.x+=fw.x*sp;WALK.z+=fw.z*sp;}if(keys.s){WALK.x-=fw.x*sp;WALK.z-=fw.z*sp;}if(keys.d){WALK.x+=rt.x*sp;WALK.z+=rt.z*sp;}if(keys.a){WALK.x-=rt.x*sp;WALK.z-=rt.z*sp;}
  if(keys.e)WALK.y+=sp;if(keys.q)WALK.y-=sp;const ge=terrainH(WALK.x,WALK.z)+1.7;if(!keys.e&&!keys.q)WALK.y=ge;else WALK.y=Math.max(ge,WALK.y);}
 else{const sp=ctl.radius*.6*dt;const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta)),rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));
  if(keys.w)ctl.target.addScaledVector(fw,sp);if(keys.s)ctl.target.addScaledVector(fw,-sp);if(keys.d)ctl.target.addScaledVector(rt,sp);if(keys.a)ctl.target.addScaledVector(rt,-sp);
  if(keys.q)ctl.target.y-=sp;if(keys.e)ctl.target.y+=sp;}
 for(const f of FRAME_HOOKS)f(dt,now);
 applyCam();if(sky)sky.position.copy(camera.position);if(giant)giant.position.copy(camera.position).addScaledVector(giantDir,4000);
 try{renderer.render(scene,camera);}catch(e){if(!renderErr){renderErr=true;reportErr('render: '+e.stack);}}
 hud.textContent=`cam ${camera.position.x|0},${camera.position.y|0},${camera.position.z|0}  tgt ${ctl.target.x|0},${ctl.target.y|0},${ctl.target.z|0}${WALK.on?'  WALK':''}\ncalls ${renderer.info.render.calls}  tris ${(renderer.info.render.triangles/1e6).toFixed(2)}M  inst ${window._instances}  reg ${REG.length}`;
 requestAnimationFrame(frame);}
frame();window._ready=true;
// ---------------------------------------------------------------- floating building labels (standard new-world package)
// One label per registered volume (REG), drawn once into a texture atlas and rendered as ONE mesh of camera-facing
// quads: a thousand labels cost one draw call. Labels keep a constant size on screen (150 px; landmarks 260 px)
// and fade out past 300 m, landmarks never. Toggled with the Labels button (they live in the LABELS group).
// A world that already made LABELS (the city) gets the atlas added to it; one that did not gets the group made here.
const LABEL_ATLAS={W:4096,H:4096,cw:409,ch:48};
function labelsBuild(){
 if(!LABELS){LABELS=new THREE.Group();LABELS.userData.probeSkip=true;scene.add(LABELS);}
 const cols=LABEL_ATLAS.W/LABEL_ATLAS.cw,rows=LABEL_ATLAS.H/LABEL_ATLAS.ch,max=cols*rows;
 // which volumes get a label: buildings, farms and furniture; not repeated wall segments (a name seen 8+ times)
 const count={};for(const r of REG)count[r.name]=(count[r.name]||0)+1;
 let list=REG.filter(r=>r.name&&count[r.name]<8&&(!r.cls||r.cls==='building'||r.cls==='farm'||r.cls==='furniture')&&!(r.tags&&r.tags.part==='wall'));
 const isBig=r=>!!(r.tags&&(r.tags.role||r.tags.landmark));
 list.sort((a,b)=>(isBig(b)-isBig(a))||(b.r-a.r));if(list.length>max)list=list.slice(0,max);
 const cv=document.createElement('canvas');cv.width=LABEL_ATLAS.W;cv.height=LABEL_ATLAS.H;const g=cv.getContext('2d');g.clearRect(0,0,cv.width,cv.height);
 const pos=[],apos=[],uv=[],cell=[],big=[],idx=[];
 list.forEach((r,i)=>{const cx=(i%cols)*LABEL_ATLAS.cw,cy=Math.floor(i/cols)*LABEL_ATLAS.ch;const B=isBig(r);
  g.fillStyle=B?'rgba(20,12,6,.72)':'rgba(0,0,0,.55)';g.fillRect(cx+1,cy+1,LABEL_ATLAS.cw-2,LABEL_ATLAS.ch-2);
  g.font=(B?'bold 34px':'bold 28px')+' system-ui,sans-serif';g.fillStyle=B?'#ffe2b0':'#f4e8d4';g.textAlign='center';g.textBaseline='middle';
  let t=r.name;while(g.measureText(t).width>LABEL_ATLAS.cw-10&&t.length>4)t=t.slice(0,-2);if(t!==r.name)t=t.slice(0,-1)+'…';g.fillText(t,cx+LABEL_ATLAS.cw/2,cy+LABEL_ATLAS.ch/2+1);
  const y=(r.y||0)+r.h+3,b=i*4;
  for(const c of[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]]){pos.push(c[0],c[1],0);apos.push(r.x,y,r.z);uv.push((cx+(c[0]+.5)*LABEL_ATLAS.cw)/LABEL_ATLAS.W,1-(cy+(0.5-c[1])*LABEL_ATLAS.ch)/LABEL_ATLAS.H);cell.push(0,0);big.push(B?1:0);}
  idx.push(b,b+1,b+2,b,b+2,b+3);});
 if(!list.length)return null;
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('aPos',new THREE.Float32BufferAttribute(apos,3));
 geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setAttribute('aBig',new THREE.Float32BufferAttribute(big,1));geo.setIndex(idx);
 // the uv above already addresses the cell, so the shader only flips nothing: cell offsets are baked in
 const tex=new THREE.CanvasTexture(cv);tex.minFilter=THREE.LinearFilter;tex.generateMipmaps=false;
 const mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,depthTest:true,fog:false,
  uniforms:{map:{value:tex},uPxToWorld:{value:1}},
  vertexShader:`attribute vec3 aPos;attribute float aBig;uniform float uPxToWorld;varying vec2 vUv;varying float vA;
   void main(){vec4 mv=modelViewMatrix*vec4(aPos,1.0);float dist=-mv.z;float w=aBig>0.5?240.0:170.0;float k=dist*uPxToWorld;
    mv.xy+=position.xy*vec2(w*k,w*k*48.0/409.0);vA=aBig>0.5?1.0:(1.0-smoothstep(320.0,560.0,dist));vUv=uv;gl_Position=projectionMatrix*mv;}`,
  fragmentShader:`uniform sampler2D map;varying vec2 vUv;varying float vA;void main(){vec4 c=texture2D(map,vUv);c.a*=vA;if(c.a<0.02)discard;gl_FragColor=c;}`});
 const m=new THREE.Mesh(geo,mat);m.frustumCulled=false;m.userData.probeSkip=true;m.name='labels';m.renderOrder=10;LABELS.add(m);
 FRAME_HOOKS.push(()=>{mat.uniforms.uPxToWorld.value=2*Math.tan(camera.fov*Math.PI/360)/innerHeight;});
 window._labels=list.length;return m;}
labelsBuild();
