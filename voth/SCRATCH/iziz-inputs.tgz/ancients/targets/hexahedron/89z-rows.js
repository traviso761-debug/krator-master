// TARGET: hexahedron — Soleri's sheet 28, intact and sheared open, with one
// Ironbark hypertree imported from Mav's Refuge purely as a scale reference.
const TITLE='Hexahedron — the double pyramid';
const GROUND_C=0;
const DECAYS=[0,2];
const ROWS={
 hex:{z:0,s:1500,r:1100,t:4600},
 mav:{z:620,s:2620,r:240},            // no .t, so it is built once, by the intact one
};
// RUINS greens the ground texture under each site. The d=0 site is at -s, so
// that is the sign to pass; every other target passes +s and greens the wrong
// side of the map (logged in KNOWN_ISSUES).
const RUINS=Object.values(ROWS).flatMap(r=>r.t?[[-r.s,r.z,r.r],[r.t,r.z,r.r*1.3]]:[[-r.s,r.z,r.r]]);
const EXTRA_BUILDERS={hex:buildHexahedron,mav:buildHypertree};
