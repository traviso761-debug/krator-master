// TARGET: dalab — view presets. First entry is the opening shot.
const VIEWS={
 'The compound':[0,300,760,0,60,0],
 'Great dome':[0,120,330,0,70,0],
 'The breach':[210,90,150,40,55,10],
 'Section':[150,70,95,20,45,5],
 'Inside the breach':[95,52,58,0,44,0],
 'The chamber':[0,34,140,0,14,0],
 'Satellite domes':[230,80,190,120,30,60],
 'A passageway':[150,26,60,80,14,20],
 'The wall':[330,22,190,180,16,80],
 'From the plain':[0,110,900,0,70,0],
};
