# Krator Ancients — known issues

`- [ ]` items are printed by `build.py` on every build. Close one by fixing it
and ticking it, not by deleting it.

## Found by the split (pre-existing in the single-file kit)

- [ ] **Seed collision: Library and Campus.** `buildLibrary` calls
      `reseed(d>0?9801:9800)` and `buildCampus` calls `reseed(9800+d)`, so the
      two share a PRNG stream: the campus's decay pattern is a copy of the
      library's. Fix by moving the campus to a free block (9810). Whitelisted in
      `build.py: SEED_COLLISION_EXCEPTIONS` so the build stays green; remove the
      entry with the fix. Not fixed in the split round because it changes output.
- [ ] **Seed collision: Megastructure and Gate.** `buildMega` uses `9995+d` and
      `buildArc` uses `9996+d`; they overlap at 9996. Same treatment — move the
      Gate to 9990 or push Mega down. Also whitelisted.
- [x] ~~Materials built inline instead of in `MAT`.~~ The bunker berm, House F's
      slope, the campus hill, the mega's root mound, the dam's spillway sheet and
      the kit's `slab` now use `MAT.mud/.turf/.rock/.spray/.slab`. They were flat
      untextured colour and washed out badly once the lighting had real roughness
      to work with. A few inline materials remain in ruin-only one-offs.
- [ ] **`build.py` cannot check syntax.** `node` is not installed on this
      machine, so `node --check` never runs. `build.py` says so instead of
      claiming "syntax OK". The only syntax check this project actually has is
      `verify.py` reading the on-screen error panel — always run it.

## The Flatiron

- [x] `src/66b-flatiron.js`: a wedge-plan tower -- rounded prow, broad transom,
      stepped setbacks, cells and glazing on every level, lit galleries every
      fourth setback, an entrance colonnade on the transom, and a crowned top.
      Sized from one rule: width grows 0.536 per unit of length, a 15-degree
      taper each side, which is what lets it sit exactly on an acute corner
      instead of overhanging both edges of it. Designed for the Screamers'
      Hexahedron and brought back here intact as a type in its own right.
- [ ] Decay 2 shortens it but does not topple it, unlike the other towers.

## Non-ground placement

- [x] `buildSkyE` and `buildSkyF` take `gy` (lift the whole tower), `noPlinth`
      (skip the ground plinth, apron and figures) and `hcut` (decay 1 cuts the
      body at that fraction of H instead of 0.8). `kput` adds all three
      components of `KOFF` and `bodyGroup` already routes instanced pieces
      through `useGroupXF`, so lifting both `KOFF` and the group moves merged
      meshes and instances together. `src/70b-perch.js` is the worked example:
      a fluted podium 90 m tall carrying a Skyscraper E with no plinth of its
      own, and a half-height ruined Skyscraper F on a lower shoulder.
- [ ] Only these two builders take the parameters. The other 31 still assume
      the ground, and several call `skyPlinth`/`apron` unconditionally.

## Budgets

Budgets are a target, not a gate (this is a showcase). `verify.py` reports an
exceeded ceiling as `OVER`; `--strict-budget` makes it fail.

- [ ] **Scene triangles over 6M again: 6 242 534.** The Perch adds a podium and
      two more towers to a showcase that was already sitting at 5 999 834, i.e.
      166 triangles under its ceiling, and the Flatiron adds a third. The two
      examples are worth the 4%; trimming them away would mean deleting the
      demonstration and the new type.
- [x] ~~Scene triangles over 6M.~~ 6 015 160 → **5 757 024**, under the ceiling.
      Theodiga moving to its own target accounts for most of it; the rest is
      dead geometry removed from Skyscraper F (see NOTES).
- [x] ~~Draw calls over 900.~~ Worst view **1129 → 615** (`Robotics factory`)
      across rounds 2–3, against a 900 ceiling; opening view 770 → 507. Every
      view measured is under. Got there by merging per-storey geometry in
      Skyscraper B/F, Apartments, Hotel, Lab, Skyscraper D and both Offices.
- [ ] **Further draw-call headroom, if it is ever wanted.** The builders that
      still emit the most meshes are `fac` (109) and `skyD/0` (30);
      `verify.py --assert` prints the per-type mesh counts, which is the list to
      work down. Note the ~50 kit InstancedMeshes are `frustumCulled = false`
      and always draw, so about 50 calls are a floor merging cannot reach.

## Dalab (`--target dalab`)

- [ ] **The great dome's size is a guess.** "Wider and taller than the Voth
      palace" needs that project's dimensions; built at DR=110 / DH=95 and
      rescalable by those two constants alone.
- [ ] Room fit-out inside the section is legible but small — beds and benches
      read as blocks at any distance. Wants a closer preset or larger fittings.
- [ ] Only the domes exist. Mounds, settlements, streets, embassies, the Halls
      of Reformation and the life layer are all still to do.

## Veladiga (`--target veladiga`)

- [x] ~~Piers read flatter than the sheets.~~ They are now swept from a five-point
      X section whose half-width follows the bay opening and whose projection
      peaks at the springing, so they splay toward the foot as the sheets draw.
- [x] ~~The city-centre wheel reads as a cluster of blocks.~~ Removed from
      Veladiga at the user's direction and rebuilt at its own scale as the
      Cultural centre in the kit and repaired targets (`src/67-cultural.js`).
- [x] ~~The park downstream is a flat plane.~~ Seven terraces and a tailrace
      channel, both driven off one parameterisation of z (see NOTES round 10).
- [x] ~~The span did not contain the water.~~ 129-219 m of open canyon at each
      abutment; arc radius 760 to 1000 at A=1.0 rad closes it against rock at
      759-841 m.
- [x] ~~Floating polygons at the crest.~~ The highway band sat 16 m above the
      deck and the promenade blocks stood 34 m clear of the downstream face. The
      deck is now a real corbelled cantilever out to ~96 m and carries both.
- [x] ~~The floor plates spanned the breach as full-width shelves.~~ Each level
      now keeps only a ragged, drooping stub off each edge, sized in metres
      (2.5-16 m) rather than as a fraction of the tear width, with whole levels
      missing where the plate went clean.
- [ ] The breach tear is driven by `fbm` on a fixed axis, so the rip widens with
      height but does not undercut -- a real failure would scallop back under
      the crest on both sides of the notch.
- [ ] The scour plume downstream is a Gaussian widening with distance. It reads,
      but it does not braid or deposit a bar, and it ignores the terrace steps
      it cuts through.

## Hexahedron (`--target hexahedron`)

- [x] ~~The two pyramids are turned 60 deg, not 120.~~ Superseded: the two
      plans now share a base vertex with each base lying along the other's leg,
      verified numerically (collinear to a dot product of 1.000000, closest
      distinct tips 482 m apart).
- [x] ~~The apex is a sharp point.~~ It is a ridge, with the cultural centre
      running along it as elevation 3 draws.
- [x] ~~The upper apex cantilevers past the ground works with nothing under it.~~
      Not a defect: the supports cluster on the computed centre of mass, and
      in-world the structure is reinforced with long-lost carbon nanomaterials,
      so the imbalance is intended and held.
- [x] ~~Both pyramids were open shells.~~ Great soffit under the upper city,
      deck over the lower city, floor to the lower truncation, and the summit
      closes to a point. Both new faces are dressed rather than left blank.
- [ ] `RUINS` greens the ground under `+r.s` in every target except hexahedron,
      while the intact site is built at `-r.s`. The greening lands on the empty
      mirror position. Fixed only in `targets/hexahedron/89z-rows.js`.
- [x] ~~Windows were inserted into the balconies.~~ They sit on the terrace wall
      below each tread now, three storeys to a 20 m riser.
- [ ] The terrace cells are still boxes on a ring, clustered by one fbm with
      streets cut through, sky bridges out to pods, and gardens on the
      promenade levels. The sheets' bridges span BETWEEN faces across open air;
      these only cantilever outward.
- [ ] No interiors behind the promenade bands, and the cultural centre at the
      summit is a single block rather than the hall the sections draw.
- [ ] The imported hypertree is one species (Ironbark) and one specimen. Mav's
      Refuge has four, and its lower crown hangs off structural branches that
      were not imported, so this one's crown is grown rather than ported.
- [x] ~~Shafts did not reach the soffit.~~ They run to the waist inside the
      closed lower shell, so the connection cannot depend on a continuous
      inverse agreeing with a stepped surface. Capitals and footings added.
- [ ] The collapsed flank tears the soffit above it, but the mass does not sag
      or tilt toward the hole -- the survivors are drawn as though nothing
      moved. In-world the nanomaterial spine holds, so this may be correct.
- [ ] Camera presets hard-code targets, so any preset aimed at a computed
      feature (the shaft bundle, the shear face, the crater) goes stale when the
      computation changes. Three have needed re-aiming so far.

## The Span (`--target canyon`)

- [ ] The three fallen payloads are small against the canyon floor and could use
      heavier debris fields and more broken-open interiors.
- [ ] Payload sway in the rusted variant is a fixed tilt, not a hang angle
      derived from the cable — fine at these angles, wrong if a cable ever
      snaps on one side only.

## Rehabilitated (`--target repaired`)

- [ ] The repaired pass dresses **every** type identically. A police station and
      a cathedral-scale laboratory get the same vocabulary of lean-tos and water
      butts; some types would read better with their own accretion (a factory
      wants scrap yards, a starport wants tents on the aprons).
- [ ] Patches sample the wall faces, not the actual holes, so a patch can land
      on intact fabric. Reads fine — people board over cracks too — but a true
      hole-aware patch would need `holeFn` to record where it punched.

## Vashtir, the recursive spire (`--target spire`)

- [x] ~~Open child bases.~~ Capped, swept from the same `rOf()` as the shell
      because the rim is a star, not a circle.
- [x] ~~Proportion is broader than the reference.~~ **This was my misreading**,
      not a defect: the reference is itself about as wide as it is tall. What it
      actually needed was translucency, now supplied by the parasol fans.
- [ ] Radial symmetry is visible if you orbit directly overhead (44 kerb blocks,
      6 causeways and 6 stairs make a regular rosette). Not visible from any
      preset.
- [ ] Intact contrast is low — white on white at distance, and nothing in this
      kit casts shadows, so all form comes from facet normals.

## From the brief (the detail pass, not yet started)

- [x] ~~Materials are first-pass canvases.~~ Done in round 4: panel seams and
      fasteners with per-sheet roughness breakup, rust keyed to the bottom of
      each tile (= under every ledge), verdigris split into its own copper
      material, board-formed concrete with tie holes and damp stains, brick in
      common bond, and a fresnel rim on the glass. See NOTES.md for the three
      traps (sRGB on data maps, metalness with no envMap, clone() dropping
      onBeforeCompile).
- [ ] No Gaudí bone-work yet: window mouldings, finials, bulb tops, bone-rib
      buttresses, and the `moulding(profile, path)` sweep helper they need.
- [ ] Interiors are floor slabs only — no corridor light strips, touchpad
      panels, conduit bundles or machinery silhouettes behind the openings.
- [x] ~~Decay is uniform rings.~~ Round 5: `rubbleRing` now banks rubble against
      the wall it fell from (same signature, so all 33 types improved at once);
      `upFaces`/`ledgePoints` sample a structure's own flat surfaces so moss
      lands only where something faces the sky and vines and water-staining come
      off real ledges. Applied to the Laboratory, Hotel and Apartments A.
- [ ] **Glass shards in ruined window openings** — the one decay sub-item still
      outstanding. Unlike the rest it cannot be done in a shared helper: the
      windows are `kput` directly at ~15 call sites, so it needs either a
      `deadWindow()` wrapper threaded through them or shards baked into the
      `winD`/`winBigD`/`winSmD` geometry itself.
- [x] ~~No ground contact.~~ `terrainH(x,z)` exists (returns 0) and everything
      meeting the ground asks it. `apron()` lays a graded skirt; it is inside
      `skyPlinth`, so all eight skyscrapers have one, plus the Laboratory and
      Starport. **Remaining types still meet the ground on a hard line** — the
      call is one line each where it is wanted.
- [ ] Campus wings should bend (UFM); the data-centre fin row needs hatches and
      ducts; the Gate deck needs an organic lattice; Megastructure "Unnamed"
      wants irregular Beksiński warts; the robot chassis are placeholders;
      Skyscraper B's crown is undersized.
- [x] ~~Theodiga wants light tunnels, an irregular fin mosaic and a rougher
      canyon.~~ All three done. The canyon now carries bedding planes, vertical
      gullies and a talus of fallen blocks; the fin cells cluster into patches
      and bands instead of scattering by coin-flip; and the light tunnels are
      punched clean through the downstream face with collars, open shafts and a
      recessed glow. `buildDam` is shared source in `src/77-dam.js`, so this
      lands in any future kit that places the dam again.
- [x] ~~Vegetation is lollipop trees.~~ `VEG.tree(x,y,z,species,h)` is the hand-off
      point, with a cheap default; `trees()` and every planting call go through
      it, so the flora pass is one assignment.
- [ ] `dist/ancients-lib.js` (builders + kit, no scene) does not exist yet, and
      the builders still take `(scene, gx, gz, d)` rather than the
      `(parent, {x,z,yaw,decay,seed,terrainH})` contract in the brief.
- [x] ~~**Darco is the only near-black type in the kit.**~~ Repalletted. The
      four skin/deck materials were near-black (`0x100e0c`), about a thirteenth
      of the kit's own concrete; they are now roughly half of it on the same
      warm grey (`0x625a52` intact, `0x786e64` ruined). Still the darkest type
      by a wide margin, still dark enough for the ember openings to read
      against, but the same stone as everything else. It also made the
      cellular skin far more legible at distance than the charcoal did.
      `MAT.darcoVoid` stays at `0x030405` — recesses should still be black.
- [x] ~~**The Forest Arcology's planted rings are hexagonal, not circular.**~~
      Resolved by splitting the type rather than changing it. The hexagonal one
      is now the **Forest Tower**; the circular-torus reading is the **Forest
      Ring**, its own type on a barrel. A hexagonal plan is correct for the
      Tower — the six columns ARE the hexagon's corners.
- [x] ~~Canopy blobs are coarse at eye height.~~ `lumpy()` displaces each
      crown and scrub geometry ONCE at kdef time by an fbm of its own vertex
      position, with the underside pulled in harder than the top. Two crowns
      and two scrubs, picked per plant. Costs nothing per instance (an
      Icosahedron is non-indexed, so coincident vertices displace together and
      the shell stays closed) and the forest stopped reading as a bag of
      marbles.
- [ ] **The Forest Tower is within 7 000 triangles of its 700 000 ceiling**
      (693 652 ruined / 691 542 intact). The tower took ~95 000 and the budget
      for it came off the bole geometry (24 triangles to 10, open-ended: both
      caps were buried) and the plinth groves, which are 90% under the building
      where nobody can see them. There is no easy headroom left: the next
      addition to this type has to be paid for by a matching cut, and the
      obvious remaining candidate is `figH`, a 48-triangle sphere for a head.
- [ ] **The Forest Tower's shear reveals a flat back wall.** The dark
      `MAT.guts` lining and its floor plates give the bite depth and a proper
      cross-section read, but the lining is one smooth surface — no cell walls,
      no partitions, no fallen slabs hanging. Compare the Veladiga breach,
      which has the same problem solved only slightly better.

## Forest Ring (`--target ring`)

Built by an agent over several rounds; transcribed here because it was told not
to edit this file. Verified independently at each round. Final: **660 058
intact / 672 852 ruined** of 700 000, worst **42** draw calls over 22 views, all
six invariants PASS, error panel clean, 32 registered volumes. `dist/forest.html`
re-verified byte-identical afterwards (693 652 tris, 47 180 instances), which
confirms this type's cheap-geometry helpers (`frArcGeo`, `frDoorGeo`) are local
and did not touch shared `arcShape` / `arcWindowGeo`.

- [ ] **The wheel hides the barrel's belly.** A 1440 m half-torus at the
      barrel's own mid-height is wider than the 808 m hub, so from any normal
      three-quarter view the bulge is occluded and the barrel reads as a tapered
      drum. Only `'The barrel'`, from just above the deck, shows the full
      profile. Inherent to the instruction, not a defect — but the type's two
      ideas cannot both be seen at once from the ground.
- [ ] **The cutaway floors do not read as a building section.** Twelve plates at
      8 m centres exist in the crown's wedge and the fix history behind them is
      sound (the inner shell had to be punched by the same predicate; the plates
      had to be pale concrete, not void-black; each needed a dark soffit). But
      the crown is a SHALLOW STEPPED MASS — it steps up as it steps in — so
      there is never 96 m of solid material at any one radius to cut through,
      and what shows is three or four ledges in the slot wall, not a stack.
      A real section needs deep fabric, which this form does not have.
      I re-aimed `'The section'` myself: it looked 38 degrees DOWN into the
      wedge, which shows the slot's floor and rubble and none of its side faces.
      It now runs nearly level along the slot at mid-stack height.
- [ ] **Nothing connects.** The four bridges land on the rim but there is no
      stair, ramp or gate down into the town's street, and the barrel-end
      landing is a balcony on a blank wall. The eight radial stairs in the crown
      have no landings or handrails. 236 houses on the rim are still effectively
      unreachable — the bridges made this better-looking, not solved.
- [ ] **The under-truss is decorative** — a sagging line of boxes with
      verticals; the deck would not stand on it. Spokes are single straight
      boxes whose roll `beam` leaves to `setFromUnitVectors`, so a
      near-horizontal strut's cross-section is arbitrarily oriented.
- [ ] **The half-torus has no interior**, and the ruin's cut face is a plain
      half-disc — the cutaway treatment given to the crown and shoulder stops at
      the wheel.
- [ ] **The wheel's wood is open woodland, not forest** — 450 m² a plant against
      the crown's 170, because the annulus at crown density would be 200k
      triangles alone. The town is one building type in two even rows on one
      circular street: no squares, side lanes, or corner treatment.
- [ ] **A stepped crown cannot be seen into below 36 degrees of depression**, so
      the three-torus idea reads properly only from the air. The two inner
      toruses carry 24 m of planting against torus 0's 36.
- [ ] **The arches and doors are visibly faceted from directly underneath** — 8
      and 5 curve segments instead of 24 and 12. This bought 81k triangles to
      pay for the wheel (445 arches, ~680 doorways). Worth knowing the lever
      exists; worth knowing it shows.
- [ ] **ring/1 is at 96% of budget** — ~27k of headroom. Anything further wants
      something taken out first.
- [ ] The ruined shell thins toward the foot: `holeFn` has no height term
      without a `cut`. A `holeFn` limitation that will recur in any type eroding
      a tall shell. The breach is a single wedge that widens inward but never
      undercuts — as logged against Veladiga. Decay 2 unsupported.
- [ ] **Canopy coarse at eye level on BOTH forest types.** `frCrown` and
      `foCrown` are each a displaced 80-triangle icosahedron. Raising the
      displacement frequency fixed the "green boulder" read, but at 10 m they
      are still faceted lumps. **This wants a different tree, not a different
      amplitude, and it should be fixed once in shared code rather than twice.**

### Worth keeping
`scratchpad/ringagent/jscheck.py` — compiles the built script with Chromium's
`new Function()`, which parses without executing. A real syntax check in ~3
seconds instead of a 7-minute verify round. This is the closest thing the kit
has to the `node --check` it cannot run, and the single most useful tool any
agent has added to this repo. It belongs in the repo proper, not a scratchpad.

## Arcbeam (`--target arcbeam`)

The canyon bridge-city. Transcribed from the builder's hand-back; it was told
not to edit this file. Verified independently: 644 102 intact / 646 314 ruined
of 700 000, worst 45 draw calls over 16 views, all six invariants PASS, error
panel clean, 31 registered volumes.

**Measured against the sheet rather than asserted:** raycast at mid-beam height
at three z stations gives a clear span of 939 / 961 / 974 m, mean 961, against
the sheet's 960. The first cut measured 874–908 because the canyon wall's relief
eats 25–45 m off each face — the nominal rock line is now set 33 m back so the
OPENING is 960, not the centreline spacing. Section 96 x 270 m = 1 : 2.81,
which satisfies "thinner than it is tall".

- [ ] **Neither "Section across" nor the collapsed bay is a section, and
      neither can be.** At mid-beam height everything outside the gorge is rock,
      so a true transverse section has nowhere to stand; and the beam is a box —
      two skins with an inner skin 17 m behind each and 30 m of void between —
      so there is nowhere more than ~17 m of solid to cut. You get a torn hole
      with floor plates hanging in it. **This is the third type in a row where a
      cutaway was attempted and could not read** (Forest Tower's shear, Forest
      Ring's crown wedge, now this). The pattern is clear: a section needs deep
      solid fabric, and none of these forms has any. Stop attempting cutaways on
      thin-skinned types; model a real interior or leave the opening dark.
- [ ] **The dropped span reads as a fairly intact white box** on the gorge
      floor. `holeFn` at d=1 eats the faces less than intended at that grid
      resolution, so its new interior plates are barely visible. It needs the
      shell broken open at one end, not merely perforated.
- [ ] **"Both" is a poor shot and three attempts did not fix it.** Two 1 200 m
      cities cannot be framed at 50 deg from closer than ~3 500 m, where
      `FogExp2` at 0.00022 leaves transmittance 0.55. Legible but washed out,
      with both outer ends cropped. This is a general problem with the
      two-site showcase convention at this scale, not an Arcbeam bug.
- [ ] **The rockfall scar is the weakest ruin feature** — smoother than the
      bedded wall around it, and the buried section it was meant to lay open is
      mostly hidden behind the portal frame. It is a rockfall beside the
      landing, not a cutaway of the buried city.
- [ ] Canyon walls are soft at close range (13 m grid columns; gullies are the
      finest feature that survives). Roof decks are under-furnished — 1 200 x
      82 m of pale paving per beam. The industrial yards are the same layout
      four times, mirrored, which is obvious from the plan view.
- [ ] **Vegetation is the kit default** and reads as toys close up; hedges are
      flat green boxes. The agent deliberately stayed off `foCrown`/`foBole`
      because they belong to another builder. **That restraint is correct per
      fragment but wrong for the kit** — see the shared-tree item below.
- [ ] **Both decays sit at 92% of ceiling.** The biggest single line item is
      moss: `MAT.moss` on `IcosahedronGeometry(1,1)` is 80 triangles a blob, and
      the ruin's moss and tree counts were already cut by a third to fit.
- [ ] `figures()` places people at y=0 on a gorge floor at y=14–26, so the two
      ground-level crowds are knee-deep in it. Never visible from a preset.

## Plymouth (`--target plymouth`)

The residential mountain. Verified independently: 476 402 intact / 454 346
ruined of 700 000, worst 44 draw calls over 16 views, all six invariants PASS,
error panel clean, 23 registered volumes, 103 517 baked instances — the densest
type in the kit and the one furthest UNDER budget, because the dwelling detail
is 2-triangle panes on `MAT.dot` rather than boxes.

Measured, not estimated: 3 390 bays x 5 storeys = 16 950 cells on the outer
risers over 21 702 m of perimeter, giving 65 678 window/door panes, 7 303
balconies, 4 391 washing lines, 693 arcade arches, 188 stair runs.

- [ ] **The silhouette is more regular than a hill should be.** Four independent
      setback rates give real asymmetry numerically (summit centre offset ~25 m;
      crown 199 x 100 on a 732 x 524 base), but at distance it still reads as a
      stepped cone. A hill wants a spur or a saddle and there is none.
- [ ] **The light court does not read from overhead** — nothing in this kit
      casts shadows, so a 185 m shaft is just a bright patch from the zenith.
      The `Plan` preset is tilted 17 deg off vertical to get some depth into it,
      which is a dodge, not a fix. **This is a kit-wide consequence of having no
      shadows and will defeat any deep vertical void in any type.**
- [ ] **Everything is bright.** Decks are three material steps darker than the
      walls and still come back near-white under a 1.7-intensity sun. Lit
      windows cannot out-shine a sunlit wall, so this type's intended warm glow
      only works in the covered street and the court. Same root cause as the
      kit-wide "intact contrast is low" item.
- [ ] **The assembly hall is thin** — a drum, a dome, a colonnade and a portal,
      and it is the only civic object in a settlement of 17 000 homes.
- [ ] **The ruin is "intact with patches" above the slump.** Below level 6
      nothing has gone but fabric; a mountain abandoned for millennia would have
      lost far more terraces, parapets and maisonettes.
- [ ] Crown's near end is sparse and the mast has no guys; terrace clutter is
      seven item types on a weighted roll, so at 16 000 bays the eye starts
      seeing the same water butt; chamfer correspondence between levels is
      approximate (decks lerp between two octagons at equal arc length, which
      skews slightly at the corners — invisible at every preset).

### Bugs this type found in SHARED kit code — still unfixed
- [ ] **`stripRing()` aims each strip radially**, so a ring of light strips
      renders as a starburst of spokes pointing at the viewer rather than a line
      following the ring. Plymouth worked around it with a local tangential
      `lring()`; **the shared `stripRing` still has the bug** and every other
      type using it has the same starburst. The Forest Tower hit this too and
      carries its own `TAN()`/`lring()` for the same reason. Fix it once.
- [ ] **`stainsFromLedge()` is unusable on a rectangular plan** — it orients
      each streak radially, laying 22 m decals flat across the terraces. Only
      correct on a circular plan.
- [ ] **`holeFn`'s `u` is multiplied by ~7 internally.** Fed a `u` normalised
      over a 2.3 km perimeter it ate 330 m rectangles out of whole terraces.
      Callers must feed it arc length / ~216, which is documented nowhere.


## Launch (`--target launch`)

The city that meant to leave. Verified independently: 417 072 intact / 473 360
ruined of 700 000, worst **55** draw calls over 18 views (the highest of the
four new types, still far under 900), all six invariants PASS, error panel
clean, 45 registered volumes.

The ruin is one quaternion: the whole vehicle group tilted 0.082 rad about a
pivot at the throat, so the shroud tip swings 62 m off axis, the skirt rim goes
20 m down and 10 m THROUGH its own apron, and the collar, clamps, mast and gash
all follow from that single rotation rather than being modelled separately.

- [ ] **Everything facing down is brown.** The hemisphere light's ground colour
      is 0x6a3a2a and nothing casts shadows, so collar soffits and the plug
      ceiling read warm brown. Dropping `lxBell`'s metalness from 1 to 0.5 put
      the diffuse back and helped — a fully metallic soffit with no envMap is
      flat brown — but this is mitigation, not a fix, and it affects **every
      type with a large soffit**, not just this one.
- [ ] **Six-fold symmetry is exact** — six trenches, masts, towers and umbilical
      bearings. From directly overhead it is a perfect rosette; only the three
      spheres and two ramps break it.
- [ ] Scoop back walls are single surfaces with no thickness — blast walls from
      the ground, thin dark sails from overhead. The payload frame inside the
      broken shroud is a smooth lathe. The fallen mast head and downed service
      tower are chains of jittered beams: wreckage at distance, a scribble up
      close. Trench slag, apron debris and crater rubble share one hue band with
      no concrete/metal distinction.
- [ ] **The six flame-trench volumes are the thinnest in the registry** (27
      probe samples each) because the trench geometry is inside one merged mesh
      and only its `kput` coping contributes points. They pass, but they are the
      closest thing in the kit to a false negative on
      `registered-volumes-non-empty`.
- [ ] "Look down off the top terrace at the pad" is **geometrically
      unachievable** and was dropped: from 8 m above a 20 m deck the deck fills
      the downward view before the parapet does, and raising the camera enough
      to clear it stops it being a view from the terrace.


## Cross-cutting, and now overdue

- [ ] **One shared tree.** Three types have now independently hit the same wall:
      `foCrown` (Forest Tower), `frCrown` (Forest Ring) and the kit default
      (Arcbeam) are all coarse at eye level, and Arcbeam duplicated the problem
      rather than reuse a neighbour's item because per-fragment ownership said
      not to. A single good tree in shared code — not a displaced icosahedron —
      fixes all three at once and stops the fourth type repeating it.
- [ ] **A cheap 80-triangle moss/foliage blob is now the top budget line in two
      types.** Same fix, same place.
- [x] ~~**`jscheck.py` belongs in the repo.**~~ Installed at `./jscheck.py` and
      documented in README as a required step between `build.py` and
      `verify.py`. It hands `build.py`'s own `.syntax-<target>.js` to headless
      Chromium's `new Function()`, which parses and compiles without executing:
      measured at **5.2 s on the 9 993-line launch build** against a ~7 minute
      verify round. Three agents relied on it from a scratchpad that would have
      been deleted with the session.
- [ ] **`beam(name,a,b,w,dp)` — `w` is the beam's DEPTH, not its width.**
      Verified in source: it emits `kput(name, mid, q, [w, L, dp])` where `q` is
      `setFromUnitVectors(+Y, axis)`. For a HORIZONTAL beam that shortest-arc
      rotation carries local X onto the vertical, so `w` sets how deep the beam
      is and `dp` how wide. The launch agent had it backwards for most of its
      build and shipped 175 m access bridges 9 m tall and 4.6 m wide — a camera
      placed on one was inside a box. Checked the Forest Tower: its beams are
      all near-square (5.2/5.6, 4.4/5.0, 3.0/3.4), so nothing there is visibly
      wrong, but any caller using a deliberately flat section has it flipped.
      Rename the parameters or document them.
- [ ] **`build.py`'s reseed scan does not skip comments.** Writing a rejected
      `reseed(NNNN+d)` call literally in a header comment creates a phantom
      seed collision that fails the build for every target. Paraphrase seeds in
      prose, or teach the scanner to strip comments.
- [ ] **No invariant can see a placement error.** Between them the four agents
      shipped, and caught only by reading a render: furniture buried inside the
      mass with its roofs poking through; tank spheres pushed to a merge list
      after that list was merged, so only their fittings drew; a trench cut 3 m
      wider than the trench, leaking the green ground plane along six lips; a
      hexagonal berm toe against a circular apron skirt, leaking a 60 m annulus
      of green on three bearings; a crater with no floor. `--assert` was green
      through every one. **Reading the shots is not optional and never has
      been.**
