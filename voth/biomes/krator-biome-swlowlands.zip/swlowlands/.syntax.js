
// ==================== 10-core-head.js
// ================================================================= BIOME CORE — head
// The engine-independent kit every Krator biome fragment is written against.
// Nothing below names a world's kit. The host hands in what a biome needs
// through BIO.init(...) (see BIOME-API.md) and everything else lives here.
var BIO={host:null,stats:{},cur:null,version:'eastabyss-1'};
// EVERYTHING BELOW IS LOCAL. The core declares no generic global (rng, clamp,
// TAU...): a world that already has those would be clobbered. Biome fragments
// pull what they need from BIO.fn at the top of their own closure.
(function(){
const TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t, mix=lerp;
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};

// ---------------------------------------------------------------- PRNG
// The biome's OWN stream. A host that adds a biome must not see its rubble
// move, so the biome never draws from the host's generator.
let _bseed=1234567;
function reseed(s){_bseed=s>>>0;}
function rng(){_bseed|=0;_bseed=_bseed+0x6D2B79F5|0;let t=Math.imul(_bseed^_bseed>>>15,1|_bseed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}
function rr(a,b){return a+(b-a)*rng();}
function ri(a,b){return a+Math.floor(rng()*(b-a+1));}
function pick(arr){return arr[Math.floor(rng()*arr.length)%arr.length];}

// ---------------------------------------------------------------- noise
function h3(x,y,z){const s=Math.sin(x*12.9898+y*78.233+z*37.719)*43758.5453;return s-Math.floor(s);}
function vnoise(x,y,z){const xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),xf=x-xi,yf=y-yi,zf=z-zi;
 const sm=t=>t*t*(3-2*t);const u=sm(xf),v=sm(yf),w=sm(zf);const l=(a,b,t)=>a+(b-a)*t;
 return l(l(l(h3(xi,yi,zi),h3(xi+1,yi,zi),u),l(h3(xi,yi+1,zi),h3(xi+1,yi+1,zi),u),v),
          l(l(h3(xi,yi,zi+1),h3(xi+1,yi,zi+1),u),l(h3(xi,yi+1,zi+1),h3(xi+1,yi+1,zi+1),u),v),w);}
function fbm(x,y,z,o){o=o||3;let a=0,f=1,s=0;for(let i=0;i<o;i++){a+=vnoise(x*f,y*f,z*f)/f;s+=1/f;f*=2.03;}return a/s;}

// ---------------------------------------------------------------- host binding
// host = { THREE, scene, terrainH(x,z), mask(x,z), obstacles[], ticks(fn), seed,
//          origin[x,z], err(msg), stat(key,tris,inst) }
BIO.init=function(h){
 if(!h||!h.THREE)throw new Error('BIO.init: host needs THREE');
 // scene may arrive later (a world that creates its scene after its kit loads
 // calls BIO.setScene before build); it is only needed at bake
 BIO.host={
  THREE:h.THREE,scene:h.scene||null,
  terrainH:h.terrainH||((x,z)=>0),
  mask:h.mask||((x,z)=>1),
  obstacles:h.obstacles||[],
  ticks:h.ticks||(fn=>{}),
  seed:h.seed==null?1:h.seed,
  // origin: [x,z] or a LIST of [x,z] -- the LOD curve is measured from the
  // nearest one, so a long showcase (a lake shore, a river) can keep detail
  // along a spine instead of round one point. center: the disc the grids
  // cover (default: the first origin).
  origin:(h.origin&&typeof h.origin[0]==='number')?[h.origin]:(h.origin||[[0,0]]),
  center:h.center||null,
  // fields: optional climate fields a multi-zone biome asks for, each
  // (x,z)->0..1. Missing ones fall back to BIO.fieldDefault. wet: 0 arid ..
  // 1 saturated; salt: 0 .. 1 crust; upland: 0 basin floor .. 1 the high edge.
  fields:h.fields||{},
  err:h.err||(m=>console.error(m)),
  stat:h.stat||null};
 reseed(BIO.host.seed*7919+11);
 return BIO;};
BIO.setScene=function(s){BIO.host.scene=s;};
BIO.err=function(m){if(BIO.host)BIO.host.err(m);else console.error(m);};
BIO.terrainH=function(x,z){return BIO.host?BIO.host.terrainH(x,z):0;};
BIO.mask=function(x,z){return BIO.host?BIO.host.mask(x,z):1;};
// distance from the LOD origin, for the detail curve
BIO.lodD=function(x,z){const O=BIO.host?BIO.host.origin:[[0,0]];let m=1e9;for(let i=0;i<O.length;i++){const d=Math.hypot(x-O[i][0],z-O[i][1]);if(d<m)m=d;}return m;};
BIO.center=function(){const h=BIO.host;return h?(h.center||h.origin[0]):[0,0];};
BIO.fieldDefault={wet:(x,z)=>BIO.terrainH(x,z)<2?1:.6,salt:(x,z)=>0,upland:(x,z)=>0};
BIO.field=function(n,x,z){const f=BIO.host&&BIO.host.fields[n];return f?f(x,z):BIO.fieldDefault[n](x,z);};
// LOD is a CURVE, not two steps: full detail under ~700 m, a quarter by 3 km.
BIO.lod=function(x,z){return clamp(1.18-BIO.lodD(x,z)/2600,.22,1);};

// ---------------------------------------------------------------- accounting
// Every instance and merged triangle is charged to BIO.cur ('jungle/hyper',
// 'jungle/floor'...), so a probe can assert per-pass budgets.
BIO.tally=function(tris,inst,meshes){const k=BIO.cur||'biome';
 const t=BIO.stats[k]||(BIO.stats[k]={tris:0,inst:0,meshes:0});
 t.tris+=tris||0;t.inst+=inst||0;t.meshes+=meshes||0;
 if(BIO.host&&BIO.host.stat)BIO.host.stat(k,tris||0,inst||0);};
BIO.totals=function(){let tris=0,inst=0,meshes=0;for(const k in BIO.stats){tris+=BIO.stats[k].tris;inst+=BIO.stats[k].inst;meshes+=BIO.stats[k].meshes;}return{tris,inst,meshes};};

BIO.fn={TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm};
})();

// ==================== 20-core-kit.js
// ================================================================= BIOME CORE — kit
// Two ways to put geometry in the world, both cheap:
//   INSTANCED ITEMS   BIO.def(name,geo,mat) once, BIO.put(name,...) thousands of
//                     times, one InstancedMesh per item at bake. Per-instance
//                     colour, and optional per-instance extras (aN normal, aC2
//                     second colour) for the foliage shaders.
//   MERGED BUCKET     BIO.tri/quad/tube/lathe/surf write vertex-coloured
//                     triangles into a bucket per material family; one Mesh per
//                     family at bake. Boles, limbs, logs, boulders go here.
// Both are charged to BIO.cur by the accounting in 10-core-head.js.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm}=BIO.fn;
BIO.defs={};BIO.order=[];BIO.items={};
BIO.def=function(name,geo,mat,opt){opt=opt||{};
 if(BIO.defs[name])BIO.err('BIO.def: '+name+' defined twice');
 const g=geo.index?geo.toNonIndexed():geo;
 BIO.defs[name]={geo:g,mat,tris:g.attributes.position.count/3,attrs:opt.attrs||null,label:opt.label||name};
 BIO.items[name]={m:[],c:[],n:[],c2:[],count:0};BIO.order.push(name);};
const _bm=new (function(){return {}})();   // scratch holder, filled after THREE binds
BIO._scratch=function(){const T=BIO.host.THREE;if(!_bm.m){_bm.m=new T.Matrix4();_bm.q=new T.Quaternion();_bm.e=new T.Euler();_bm.p=new T.Vector3();_bm.s=new T.Vector3();_bm.c=new T.Color();_bm.up=new T.Vector3(0,1,0);_bm.v=new T.Vector3();}return _bm;};
// rotation helpers: qEuler(rx,ry,rz) or qFacing([nx,ny,nz]) (local +z toward n)
function qEuler(rx,ry,rz){const S=BIO._scratch();S.e.set(rx||0,ry||0,rz||0,'YXZ');return new BIO.host.THREE.Quaternion().setFromEuler(S.e);}
function qFacing(n){const T=BIO.host.THREE,v=new T.Vector3(n[0],n[1],n[2]).normalize();return new T.Quaternion().setFromUnitVectors(new T.Vector3(0,0,1),v);}
function qUp(n){const T=BIO.host.THREE,v=new T.Vector3(n[0],n[1],n[2]).normalize();return new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v);}
// put(name, [x,y,z], quat|null, [sx,sy,sz]|s, colour(hex|Color|null), extra{n:[..], c2:hex})
BIO.put=function(name,pos,q,sc,col,extra){
 const it=BIO.items[name];if(!it){BIO.err('BIO.put: no item '+name);return;}
 if(!(isFinite(pos[0])&&isFinite(pos[1])&&isFinite(pos[2]))){BIO.err('BIO.put: NaN position for '+name);return;}
 const S=BIO._scratch();
 S.p.set(pos[0],pos[1],pos[2]);
 if(typeof sc==='number')S.s.set(sc,sc,sc);else S.s.set(sc[0],sc[1],sc[2]);
 S.m.compose(S.p,q||S.q.set(0,0,0,1),S.s);
 const e=S.m.elements;for(let i=0;i<16;i++)it.m.push(e[i]);
 if(col==null)it.c.push(1,1,1);
 else{if(col.isColor)S.c.copy(col);else S.c.set(col);S.c.convertSRGBToLinear();it.c.push(S.c.r,S.c.g,S.c.b);}
 const def=BIO.defs[name];
 if(def.attrs){
  if(def.attrs.indexOf('aN')>=0){const n=(extra&&extra.n)||[0,1,0];it.n.push(n[0],n[1],n[2]);}
  if(def.attrs.indexOf('aC2')>=0){const c2=extra&&extra.c2;if(c2==null)it.c2.push(S.c.r,S.c.g,S.c.b);else{if(c2.isColor)S.c.copy(c2);else S.c.set(c2);S.c.convertSRGBToLinear();it.c2.push(S.c.r,S.c.g,S.c.b);}}}
 it.count++;BIO.tally(def.tris,1,0);};
// a beam of instanced item `name` (a unit cylinder along y, centred) from a to b
BIO.beam=function(name,a,b,r0,r1,col){const T=BIO.host.THREE,S=BIO._scratch();
 const dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],L=Math.hypot(dx,dy,dz);if(L<1e-4)return;
 S.v.set(dx/L,dy/L,dz/L);const q=new T.Quaternion().setFromUnitVectors(S.up,S.v);
 BIO.put(name,[(a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2],q,[r0*2,L,(r1==null?r0:r1)*2],col);};

// ---------------------------------------------------------------- merged buckets
BIO.buckets={};
BIO.bucket=function(fam,mat,opt){opt=opt||{};
 if(!BIO.buckets[fam])BIO.buckets[fam]={mat,pos:[],nor:[],uv:[],col:[],tris:0,label:opt.label||fam,uvScale:opt.uvScale||[3,3]};
 return BIO.buckets[fam];};
const _lc={r:1,g:1,b:1};
// COLOURS ARE sRGB IN, LINEAR OUT. r128 sends instance and vertex colours to
// the shader untouched, and the renderer encodes its output to sRGB, so a raw
// hex would render a stop too bright. Everything passed here is a designer's
// sRGB colour (hex, Color, or [r,g,b] already linear) and is converted once.
function _col3(c){const S=BIO._scratch();if(c==null)return[1,1,1];if(Array.isArray(c))return c;
 if(c.isColor)S.c.copy(c);else S.c.set(c);S.c.convertSRGBToLinear();return[S.c.r,S.c.g,S.c.b];}
// one triangle, flat normal unless `n` is given; a,b,c CCW from outside
BIO.tri=function(fam,a,b,c,col,n){const K=BIO.buckets[fam];if(!K){BIO.err('BIO.tri: no bucket '+fam);return;}
 let nx,ny,nz;if(n){nx=n[0];ny=n[1];nz=n[2];}else{const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  nx=uy*vz-uz*vy;ny=uz*vx-ux*vz;nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;}
 const cc=_col3(col);
 [a,b,c].forEach(p=>{K.pos.push(p[0],p[1],p[2]);K.nor.push(nx,ny,nz);K.uv.push(p[3]||0,p[4]||0);K.col.push(cc[0],cc[1],cc[2]);});
 K.tris++;BIO.tally(1,0,0);};
BIO.quad=function(fam,a,b,c,d,col){BIO.tri(fam,a,b,c,col);BIO.tri(fam,a,c,d,col);};
// TUBE along pts [{x,y,z,r,col?}], parallel-transport frames, constant texture
// repeat along the length (so a bole shows no shear bands where the radius
// changes). opt: seg, cap, rfn(i,ang,pt)->radius multiplier, vscale
BIO.tube=function(fam,pts,col,opt){opt=opt||{};const T=BIO.host.THREE,K=BIO.buckets[fam];if(!K){BIO.err('BIO.tube: no bucket '+fam);return 0;}
 const seg=opt.seg||8,sc=K.uvScale,n=pts.length;if(n<2)return 0;
 const Tn=[],N=[],Bn=[];
 for(let i=0;i<n;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(n-1,i+1)];Tn.push(new T.Vector3(b.x-a.x,b.y-a.y,b.z-a.z).normalize());}
 const ref=Math.abs(Tn[0].y)>.9?new T.Vector3(1,0,0):new T.Vector3(0,1,0);
 N[0]=new T.Vector3().crossVectors(Tn[0],ref).normalize();Bn[0]=new T.Vector3().crossVectors(Tn[0],N[0]).normalize();
 for(let j=1;j<n;j++){const nn=N[j-1].clone().sub(Tn[j].clone().multiplyScalar(N[j-1].dot(Tn[j]))).normalize();N[j]=nn;Bn[j]=new T.Vector3().crossVectors(Tn[j],nn).normalize();}
 const rt=pts[Math.min(n-1,Math.floor(n*.3))].r||1;   // one u-repeat count for the whole tube
 const rings=[];let vAcc=0;
 for(let q=0;q<n;q++){if(q>0)vAcc+=Math.hypot(pts[q].x-pts[q-1].x,pts[q].y-pts[q-1].y,pts[q].z-pts[q-1].z);
  const ring=[];const urep=Math.max(1,Math.round(TAU*rt/sc[0]));
  for(let s=0;s<=seg;s++){const ang=s/seg*TAU,rad=pts[q].r*(opt.rfn?opt.rfn(q,ang,pts[q]):1);
   const cx=Math.cos(ang),sx=Math.sin(ang);const nx=N[q].x*cx+Bn[q].x*sx,ny=N[q].y*cx+Bn[q].y*sx,nz=N[q].z*cx+Bn[q].z*sx;
   ring.push({p:[pts[q].x+nx*rad,pts[q].y+ny*rad,pts[q].z+nz*rad],n:[nx,ny,nz],uv:[s/seg*urep,vAcc/(opt.vscale||sc[1])]});}
  rings.push(ring);}
 const pv=(v,c)=>{K.pos.push(v.p[0],v.p[1],v.p[2]);K.nor.push(v.n[0],v.n[1],v.n[2]);K.uv.push(v.uv[0],v.uv[1]);K.col.push(c[0],c[1],c[2]);};
 const cc=_col3(col);let tris=0;
 for(let r2=0;r2<n-1;r2++){const c0=pts[r2].col!=null?_col3(pts[r2].col):cc,c1=pts[r2+1].col!=null?_col3(pts[r2+1].col):cc;
  for(let s2=0;s2<seg;s2++){const a0=rings[r2][s2],a1=rings[r2][s2+1],b0=rings[r2+1][s2],b1=rings[r2+1][s2+1];
   pv(a0,c0);pv(b1,c1);pv(b0,c1);pv(a0,c0);pv(a1,c0);pv(b1,c1);tris+=2;}}
 if(opt.cap){[[0,-1],[n-1,1]].forEach(e=>{const ri2=rings[e[0]],ctr=[pts[e[0]].x,pts[e[0]].y,pts[e[0]].z];
  for(let s3=0;s3<seg;s3++){if(e[1]>0)BIO.tri(fam,ctr,ri2[s3].p,ri2[s3+1].p,opt.capCol!=null?opt.capCol:col);else BIO.tri(fam,ctr,ri2[s3+1].p,ri2[s3].p,opt.capCol!=null?opt.capCol:col);}});}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};
// LATHE from rings [{x,y,z,yy,col}], radius rad(ring,ang), ambient-occlusion aof(ring,ang);
// true surface normals so fluting and buttress fins shade
BIO.lathe=function(fam,rings,seg,rep,vs,rad,aof){const K=BIO.buckets[fam];if(!K){BIO.err('BIO.lathe: no bucket '+fam);return 0;}
 const n=rings.length,P=[];
 for(let i=0;i<n;i++){const row=[];for(let s=0;s<seg;s++){const a=s/seg*TAU,r=rad(rings[i],a);row.push([rings[i].x+Math.cos(a)*r,rings[i].y,rings[i].z+Math.sin(a)*r]);}P.push(row);}
 const V=[];
 for(let i=0;i<n;i++){const vr=[],lc=_col3(rings[i].col);
  for(let s=0;s<=seg;s++){const s0=s%seg,pa=P[i][(s0+1)%seg],pb=P[i][(s0+seg-1)%seg],pu=P[Math.min(n-1,i+1)][s0],pd=P[Math.max(0,i-1)][s0];
   const ax=pa[0]-pb[0],ay=pa[1]-pb[1],az=pa[2]-pb[2],ux=pu[0]-pd[0],uy=pu[1]-pd[1],uz=pu[2]-pd[2];
   let nx=uy*az-uz*ay,ny=uz*ax-ux*az,nz=ux*ay-uy*ax;const nl=Math.hypot(nx,ny,nz)||1;const ao=aof?aof(rings[i],s0/seg*TAU):1;
   vr.push({p:P[i][s0],n:[nx/nl,ny/nl,nz/nl],u:s/seg*rep,v:rings[i].yy/vs,c:[lc[0]*ao,lc[1]*ao,lc[2]*ao]});}
  V.push(vr);}
 const pv=q=>{K.pos.push(q.p[0],q.p[1],q.p[2]);K.nor.push(q.n[0],q.n[1],q.n[2]);K.uv.push(q.u,q.v);K.col.push(q.c[0],q.c[1],q.c[2]);};
 let tris=0;
 for(let i=0;i<n-1;i++)for(let s=0;s<seg;s++){const a0=V[i][s],a1=V[i][s+1],b0=V[i+1][s],b1=V[i+1][s+1];pv(a0);pv(b1);pv(a1);pv(a0);pv(b0);pv(b1);tris+=2;}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};
// a parametric SURFACE fn(u,v)->[x,y,z] over nu x nv cells, smooth normals, uv scaled
BIO.surf=function(fam,fn,nu,nv,col,opt){opt=opt||{};const K=BIO.buckets[fam];if(!K){BIO.err('BIO.surf: no bucket '+fam);return 0;}
 const P=[];for(let i=0;i<=nu;i++){const row=[];for(let j=0;j<=nv;j++)row.push(fn(i/nu,j/nv));P.push(row);}
 const nrm=(i,j)=>{const a=P[Math.min(nu,i+1)][j],b=P[Math.max(0,i-1)][j],c=P[i][Math.min(nv,j+1)],d=P[i][Math.max(0,j-1)];
  const ux=a[0]-b[0],uy=a[1]-b[1],uz=a[2]-b[2],vx=c[0]-d[0],vy=c[1]-d[1],vz=c[2]-d[2];
  let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;return[nx/l,ny/l,nz/l];};
 const cc=_col3(col),uS=opt.uS||1,vS=opt.vS||1;let tris=0;
 const pv=(i,j)=>{const p=P[i][j],n=nrm(i,j);const c=opt.colFn?_col3(opt.colFn(i/nu,j/nv,p)):cc;
  K.pos.push(p[0],p[1],p[2]);K.nor.push(n[0],n[1],n[2]);K.uv.push(i/nu*uS,j/nv*vS);K.col.push(c[0],c[1],c[2]);};
 for(let i=0;i<nu;i++)for(let j=0;j<nv;j++){if(opt.hole&&opt.hole((i+.5)/nu,(j+.5)/nv))continue;
  pv(i,j);pv(i+1,j+1);pv(i+1,j);pv(i,j);pv(i,j+1);pv(i+1,j+1);tris+=2;}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};

// ---------------------------------------------------------------- bake
// Turns the stores into meshes. Call once per host after every biome has
// built; a second call only emits what arrived since the first.
BIO.baked=[];
BIO.bake=function(){const T=BIO.host.THREE,scene=BIO.host.scene;if(!scene)throw new Error('BIO.bake: no scene (BIO.init({scene}) or BIO.setScene first)');let calls=0,inst=0;
 for(const name of BIO.order){const it=BIO.items[name];if(!it.count)continue;const def=BIO.defs[name];
  const geo=def.geo.clone();
  if(def.attrs&&it.n.length)geo.setAttribute('aN',new T.InstancedBufferAttribute(new Float32Array(it.n),3));
  if(def.attrs&&it.c2.length)geo.setAttribute('aC2',new T.InstancedBufferAttribute(new Float32Array(it.c2),3));
  const im=new T.InstancedMesh(geo,def.mat,it.count);
  im.instanceMatrix.array.set(it.m);im.instanceMatrix.needsUpdate=true;
  im.instanceColor=new T.InstancedBufferAttribute(new Float32Array(it.c),3);
  im.frustumCulled=false;im.userData.biome=true;im.userData.inspectLabel=def.label;im.name='biome:'+name;
  scene.add(im);BIO.baked.push(im);calls++;inst+=it.count;
  BIO.items[name]={m:[],c:[],n:[],c2:[],count:0};}
 for(const fam in BIO.buckets){const K=BIO.buckets[fam];if(!K.pos.length)continue;
  const g=new T.BufferGeometry();
  g.setAttribute('position',new T.Float32BufferAttribute(K.pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(K.nor,3));
  g.setAttribute('uv',new T.Float32BufferAttribute(K.uv,2));g.setAttribute('color',new T.Float32BufferAttribute(K.col,3));
  g.computeBoundingSphere();
  const m=new T.Mesh(g,K.mat);m.frustumCulled=false;m.userData.biome=true;m.userData.inspectLabel=K.label;m.name='biome:'+fam;
  scene.add(m);BIO.baked.push(m);calls++;
  K.pos=[];K.nor=[];K.uv=[];K.col=[];}
 BIO.lastBake={calls,inst};return BIO.lastBake;};

Object.assign(BIO.fn,{qEuler,qFacing,qUp});
})();

// ==================== 30-core-foliage.js
// ================================================================= BIOME CORE — foliage
// What makes a card read as leaves. Ported from Girder's 60-trees.js and the
// Hexahedron's 71b-flora.js, with the three lessons those cost:
//   - LAMBERT, never Standard: a Standard card keeps a 4% specular at any
//     roughness and goes white at grazing angles, i.e. from under the canopy.
//   - two-sided light MIX, not a flip: a leaf seen from below is a lit,
//     translucent leaf, not the ground-hemisphere shadow a flipped normal gives.
//   - low-alpha texels carry the species' MID colour, or mipmapping bleeds a
//     black fringe round every leaf at distance; and alpha is boosted with
//     distance, or the far canopy thins to lace.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
BIO.WIND={t:{value:0}};
BIO.SUN={value:null};                 // set by BIO.setSun([x,y,z]); defaults at first use
BIO.setSun=function(v){const T=BIO.host.THREE;if(!BIO.SUN.value)BIO.SUN.value=new T.Vector3();BIO.SUN.value.set(v[0],v[1],v[2]).normalize();};
BIO._windTicked=false;
BIO._tickWind=function(){if(BIO._windTicked)return;BIO._windTicked=true;BIO.host.ticks(dt=>{BIO.WIND.t.value+=dt;});};

// ---------------------------------------------------------------- alpha textures
// draw(g,S) paints GREYSCALE leaves on a transparent canvas; the material's
// per-instance colour tints them. fillRGB fills the transparent texels.
BIO.alphaTex=function(S,draw,fillRGB){const T=BIO.host.THREE;
 const c=document.createElement('canvas');c.width=c.height=S;const g=c.getContext('2d');g.clearRect(0,0,S,S);draw(g,S);
 const d=g.getImageData(0,0,S,S).data,out=new Uint8Array(S*S*4);
 for(let o=0;o<out.length;o+=4){const a=d[o+3];
  if(a<48){out[o]=fillRGB[0];out[o+1]=fillRGB[1];out[o+2]=fillRGB[2];}else{out[o]=d[o];out[o+1]=d[o+1];out[o+2]=d[o+2];}
  out[o+3]=a;}
 const t=new T.DataTexture(out,S,S,T.RGBAFormat);
 t.encoding=T.sRGBEncoding;t.generateMipmaps=true;t.minFilter=T.LinearMipmapLinearFilter;t.magFilter=T.LinearFilter;
 t.anisotropy=4;t.needsUpdate=true;t.wrapS=t.wrapT=T.RepeatWrapping;return t;};
// a COLOUR canvas texture (bark, ground), repeat-wrapped
BIO.canvasTex=function(w,h,fn,rep){const T=BIO.host.THREE;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');fn(g,w,h);
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=8;t.encoding=T.sRGBEncoding;if(rep)t.repeat.set(rep,rep);return t;};
// drawing helpers for leaf textures
BIO.tex={
 grey(l){l=clamp(Math.round(l),0,255);return'rgb('+l+','+l+','+l+')';},
 leaf(g,x,y,len,wid,ang,lum,rib){g.save();g.translate(x,y);g.rotate(ang);
  g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.45,wid,len,0);g.quadraticCurveTo(len*.45,-wid,0,0);g.fill();
  if(rib){g.strokeStyle=BIO.tex.grey(lum*.72);g.lineWidth=1;g.beginPath();g.moveTo(0,0);g.lineTo(len*.92,0);g.stroke();}
  g.restore();},
 cl:[],
 clusters(S,n,k){BIO.tex.cl=[];for(let i=0;i<n;i++){const a=i/n*TAU+rr(-.3,.3),r=S*.5*k*(i%3===0?rr(0,.35):rr(.55,1));BIO.tex.cl.push([S/2+Math.cos(a)*r,S/2+Math.sin(a)*r]);}},
 clPt(S,sd,lim){const c=pick(BIO.tex.cl),a=rr(0,TAU),r=sd*S*Math.sqrt(-2*Math.log(1-rng()*.98))*.6;
  let x=c[0]+Math.cos(a)*r,y=c[1]+Math.sin(a)*r;const d=Math.hypot(x-S/2,y-S/2),m=S*.5*lim;if(d>m){x=S/2+(x-S/2)*m/d;y=S/2+(y-S/2)*m/d;}
  return[x,y,Math.atan2(y-c[1],x-c[0])];},
 discPt(S,k){const a=rr(0,TAU),r=S*.5*k*Math.sqrt(rng());return[S/2+Math.cos(a)*r,S/2+Math.sin(a)*r,a];}
};

// ---------------------------------------------------------------- card geometries
BIO.geo={};
// leaf clump: a tripod of three tilted unit quads
BIO.geo.clump=function(){const T=BIO.host.THREE,pos=[],uv=[],nor=[];
 for(let k=0;k<3;k++){const az=k/3*TAU+.3,tilt=.92,ca=Math.cos(az),sa=Math.sin(az);
  const n=[Math.sin(tilt)*ca,Math.cos(tilt),Math.sin(tilt)*sa],u=[-sa,0,ca],v=[-Math.cos(tilt)*ca,Math.sin(tilt),-Math.cos(tilt)*sa];
  const c=[n[0]*.10,n[1]*.10-.04,n[2]*.10];
  const P=[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]].map(q=>[c[0]+u[0]*q[0]+v[0]*q[1],c[1]+u[1]*q[0]+v[1]*q[1],c[2]+u[2]*q[0]+v[2]*q[1],q[0]+.5,q[1]+.5]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(n[0],n[1],n[2]);});}
 return BIO.geo._make(pos,nor,uv);};
BIO.geo._make=function(pos,nor,uv,col){const T=BIO.host.THREE,g=new T.BufferGeometry();
 g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(nor,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
 if(col)g.setAttribute('color',new T.Float32BufferAttribute(col,3));return g;};
// hanging raceme / strand: two crossed quads, local y 0 (hung) .. -1
BIO.geo.hang=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<2;k++){const ca=Math.cos(k*Math.PI/2+.4),sa=Math.sin(k*Math.PI/2+.4);
  const P=[[-.5,0],[.5,0],[.5,-1],[-.5,-1]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,-q[1]]);
  [0,2,1,0,3,2].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a hanging RIBBON: origin at the top, running down to y=-1 in nseg tapering
// quads, drifting in z so a curtain of them is not a plank; texture repeats
// once per segment so a long one reads as a chain of leaves
BIO.geo.ribbon=function(nseg,taper,drift){const pos=[],uv=[],nor=[];nseg=nseg||4;taper=taper==null?.55:taper;drift=drift==null?.18:drift;
 const P=[];for(let i=0;i<=nseg;i++){const t=i/nseg,w=.5*lerp(1,taper,t),z=Math.sin(t*3.1)*drift;P.push([-w,-t,z],[w,-t,z]);}
 for(let i=0;i<nseg;i++){const a=P[2*i],b=P[2*i+1],c=P[2*i+2],d=P[2*i+3];
  [[a,0,0],[c,0,1],[b,1,0],[b,1,0],[c,0,1],[d,1,1]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,0,1);});}
 return BIO.geo._make(pos,nor,uv);};
// an arching FROND: pinned at the origin, arching along +x to x=1 and down
BIO.geo.frond=function(nseg){const pos=[],uv=[],nor=[];nseg=nseg||3;
 const P=[];for(let i=0;i<=nseg;i++){const t=i/nseg,w=.16*Math.sin(t*Math.PI)*.9+.02,y=.32*Math.sin(t*2.2)-.22*t*t;P.push([t,y,-w],[t,y,w]);}
 for(let i=0;i<nseg;i++){const a=P[2*i],b=P[2*i+1],c=P[2*i+2],d=P[2*i+3];
  [[a,0,0],[b,1,0],[c,0,1],[b,1,0],[d,1,1],[c,0,1]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a MOSS MAT: a fan of quads in the xz plane, front face UP (winding matters:
// the Hexahedron lost 18k of these to a reversed fan). Flip pi about x for a soffit.
BIO.geo.mat=function(){const pos=[],uv=[],nor=[];const N=7;
 for(let s=0;s<N;s++){const a0=s/N*TAU,a1=(s+1)/N*TAU,r0=rr(.7,1),r1=rr(.7,1);
  const A=[0,0,0],B=[Math.cos(a0)*r0,rr(0,.08),Math.sin(a0)*r0],C=[Math.cos(a1)*r1,rr(0,.08),Math.sin(a1)*r1];
  [[A,.5,.5],[C,.5+C[0]*.5,.5+C[2]*.5],[B,.5+B[0]*.5,.5+B[2]*.5]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a BUSH LOBE: a squat 6-sided dome, origin at the ground
BIO.geo.lobe=function(){const T=BIO.host.THREE;const g=new T.SphereGeometry(1,7,4,0,TAU,0,Math.PI*.55);g.scale(1,.8,1);return g;};
// a BLOOM: a diamond of two quads, origin at the centre
BIO.geo.bloom=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<2;k++){const ca=Math.cos(k*Math.PI/2),sa=Math.sin(k*Math.PI/2);
  const P=[[-.5,0],[0,.5],[.5,0],[0,-.5]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,q[1]+.5]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a POD on its stalk: local y 0 (hung) .. -1, vertex-coloured (stalk dark, pod white)
BIO.geo.pod=function(){const T=BIO.host.THREE;
 const parts=[[new T.CylinderGeometry(.012,.012,.5,3,1,true).translate(0,-.25,0),.16],[new T.SphereGeometry(.15,6,4).scale(1,1.75,1).translate(0,-.735,0),1]];
 const pos=[],nor=[],col=[],uv=[];
 parts.forEach(p=>{const g=p[0].toNonIndexed(),a=g.attributes.position.array,b=g.attributes.normal.array,u=g.attributes.uv.array;
  for(let i=0;i<a.length;i+=3){pos.push(a[i],a[i+1],a[i+2]);nor.push(b[i],b[i+1],b[i+2]);
   const sh=p[1]===1?(.78+.22*Math.sin(Math.atan2(a[i+2],a[i])*5))*lerp(.72,1,clamp((a[i+1]+1)/.5,0,1)):p[1];col.push(sh,sh,sh);}
  for(let j=0;j<u.length;j++)uv.push(u[j]);});
 return BIO.geo._make(pos,nor,uv,col);};
// a unit cylinder along y, centred (for BIO.beam)
BIO.geo.rod=function(n){const T=BIO.host.THREE;return new T.CylinderGeometry(.5,.5,1,n||7);};
// a tapering trunk from y=0 up to y=1
BIO.geo.trunk=function(n){const T=BIO.host.THREE;return new T.CylinderGeometry(.16,.4,1,n||8).translate(0,.5,0);};

// ---------------------------------------------------------------- the foliage hook
// o: { aN:bool, irid:bool, swayW:'glsl expr', swayA:0.2, axis:0|1, dist:bool }
//   swayW  weight of the displacement per vertex: '1.0' for a clump, '(-position.y)'
//          for something hung from y=0, '(position.x)' for a frond pinned at x=0
//   axis   which instanceMatrix column sets the amplitude (1 for a long thin hang)
BIO.foliageHook=function(o){o=o||{};
 return function(sh){
  sh.uniforms.uWindT=BIO.WIND.t;
  if(!BIO.SUN.value)BIO.setSun([.45,.72,-.52]);
  sh.uniforms.uSunDir=BIO.SUN;
  sh.vertexShader=sh.vertexShader
   .replace('#include <common>','#include <common>\nuniform float uWindT;\nvarying vec3 vFlWP;\nvarying float vFlD;\n'+
    (o.aN?'attribute vec3 aN;\nvarying vec3 vFlN;\n':'')+(o.irid?'attribute vec3 aC2;\nvarying vec3 vFlC2;\n':''))
   .replace('#include <project_vertex>',[
    'vec4 mvPosition = vec4( transformed, 1.0 );',
    'float _sc = 1.0; float _ph = 0.0;',
    '#ifdef USE_INSTANCING',
    '  mvPosition = instanceMatrix * mvPosition;',
    '  _ph = dot(instanceMatrix[3].xyz, vec3(0.131,0.073,0.117));',
    '  _sc = length(instanceMatrix['+(o.axis||0)+'].xyz);',
    '#endif',
    'float _wg = '+(o.swayW||'1.0')+';',
    'mvPosition.xyz += _wg * _sc * vec3(',
    '   sin(uWindT*0.9+_ph) + 0.45*sin(uWindT*2.3+_ph*1.7+position.x*5.0),',
    '   0.40*sin(uWindT*1.6+_ph*0.6+position.z*5.0),',
    '   cos(uWindT*0.7+_ph*1.3) + 0.45*sin(uWindT*2.9+_ph+position.y*5.0) ) * '+(o.swayA==null?.06:o.swayA).toFixed(3)+';',
    'vFlWP = (modelMatrix * mvPosition).xyz;',
    o.aN?'vFlN = aN;':'',o.irid?'vFlC2 = aC2;':'',
    'mvPosition = modelViewMatrix * mvPosition;',
    'vFlD = -mvPosition.z;',
    'gl_Position = projectionMatrix * mvPosition;'].join('\n'));
  // the lighting normal: the clump's own (aN, world space, so it shades as a
  // lit mass), or the card normal bent toward world-up for anything without one
  if(o.aN)sh.vertexShader=sh.vertexShader.replace('#include <defaultnormal_vertex>','vec3 transformedNormal = normalize(normalMatrix * aN);');
  else sh.vertexShader=sh.vertexShader.replace('#include <defaultnormal_vertex>','#include <defaultnormal_vertex>\n'+
   '{vec3 _up=normalize(normalMatrix*vec3(0.0,1.0,0.0)); transformedNormal=normalize(mix(normalize(transformedNormal),_up,0.45));}');
  sh.fragmentShader=sh.fragmentShader
   .replace('#include <common>','#include <common>\nuniform float uWindT;\nuniform vec3 uSunDir;\nvarying vec3 vFlWP;\nvarying float vFlD;\n'+
    (o.aN?'varying vec3 vFlN;\n':'')+(o.irid?'varying vec3 vFlC2;\n':''))
   .replace('#include <map_fragment>','#include <map_fragment>\n diffuseColor.a *= 1.0 + clamp(vFlD/650.0, 0.0, 1.1);')
   .replace('reflectedLight.indirectDiffuse += ( gl_FrontFacing ) ? vIndirectFront : vIndirectBack;','reflectedLight.indirectDiffuse += 0.72*vIndirectFront + 0.28*vIndirectBack;')
   .replace('reflectedLight.directDiffuse = ( gl_FrontFacing ) ? vLightFront : vLightBack;','reflectedLight.directDiffuse = vLightFront + 0.30*vLightBack;');
  // IRIDESCENCE (prism gum): green facing the sun, the second colour away from
  // it and at grazing view angles, shimmering slowly in the wind
  if(o.irid)sh.fragmentShader=sh.fragmentShader.replace('#include <color_fragment>',[
   '#include <color_fragment>',
   '{ vec3 _V = normalize(cameraPosition - vFlWP); vec3 _N = normalize('+(o.aN?'vFlN':'vec3(0.0,1.0,0.0)')+');',
   '  float _fr = 1.0 - abs(dot(_N,_V));',
   '  float _sf = dot(_N, uSunDir)*0.5 + 0.5;',
   '  float _sh = 0.16*sin(uWindT*0.8 + dot(vFlWP, vec3(0.045,0.083,0.037))) + 0.08*sin(uWindT*1.9 + dot(vFlWP, vec3(-0.21,0.13,0.17)));',
   '  float _k = smoothstep(0.22, 0.78, _sf*1.15 - _fr*0.80 + 0.30 + _sh);',
   '  diffuseColor.rgb *= mix(vFlC2, vColor, _k) / max(vColor, vec3(0.004)); }'].join('\n'));
 };};
// a foliage MATERIAL: Lambert, alpha-tested, double-sided, hooked. Each key
// compiles its own program (different hooks on different materials need
// different cache keys or three silently shares one).
BIO.leafMat=function(tex,key,o){const T=BIO.host.THREE;o=o||{};
 const m=new T.MeshLambertMaterial({color:0xffffff,map:tex||null,alphaTest:o.alphaTest==null?.42:o.alphaTest,side:T.DoubleSide,vertexColors:!!o.vertexColors});
 m.onBeforeCompile=BIO.foliageHook(o);m.customProgramCacheKey=function(){return'biofol|'+key;};
 BIO._tickWind();return m;};
// a BARK / WOOD material for merged buckets: Lambert, vertex-coloured, textured
BIO.barkMat=function(tex,col){const T=BIO.host.THREE;return new T.MeshLambertMaterial({color:col==null?0xffffff:col,map:tex||null,vertexColors:true,side:T.DoubleSide});};
// a plain material for instanced solids (rods, lobes, boulders)
BIO.solidMat=function(tex,col){const T=BIO.host.THREE;return new T.MeshLambertMaterial({color:col==null?0xffffff:col,map:tex||null,side:T.DoubleSide});};

})();

// ==================== 40-core-place.js
// ================================================================= BIOME CORE — placement
// Where things go. Ported from the Hexahedron's forest rebuild (the forest is
// PLACEMENT, not plants) and Girder's keep-clear tests.

// SPECIES COME IN STANDS. A per-tree random draw mixes species so evenly the
// eye integrates them back into one colour; an fbm patch field a few hundred
// metres across picks a dominant species with a fraction off-pattern.
// fbm is bell-shaped (mean .5, sd ~.11): splitting its raw value n ways gave
// 1/27/53/20 % for four species. The value is stretched through the middle of
// the bell first so the n bands come out roughly even.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
BIO.standAt=function(x,z,n,scale,seed){scale=scale||.0017;const f=fbm(x*scale+31,z*scale-19,seed||9483,2);
 const u=smooth(.30,.70,f);return clamp(Math.floor(u*n),0,n-1);};
BIO.stand=function(x,z,n,off,scale,seed){return rng()<(off==null?.26:off)?Math.floor(rng()*n):BIO.standAt(x,z,n,scale,seed);};

// A JITTERED GRID over a disc [rIn,rOut] round the origin: one candidate per
// cell, jittered, tested against the host mask, an fbm patch mask (the floor
// is patchy) and `accept(x,z,d)->0..1`. Even coverage with no clumps of
// rejection-sampling luck, and the count is predictable from the cell size.
BIO.grid=function(cell,rIn,rOut,accept,fn,opt){opt=opt||{};const o=opt.center||BIO.center(),N=Math.ceil(rOut*2/cell);let n=0;
 const pk=opt.patch==null?.85:opt.patch,ps=opt.patchScale||.016;
 const B=opt.box;   // optional [x0,z0,x1,z1] window (a zone strip); cells outside it cost nothing
 let ix0=0,ix1=N-1,iz0=0,iz1=N-1;
 if(B){ix0=Math.max(0,Math.floor((B[0]-(o[0]-rOut))/cell));ix1=Math.min(N-1,Math.ceil((B[2]-(o[0]-rOut))/cell));iz0=Math.max(0,Math.floor((B[1]-(o[1]-rOut))/cell));iz1=Math.min(N-1,Math.ceil((B[3]-(o[1]-rOut))/cell));}
 for(let iz=iz0;iz<=iz1;iz++)for(let ix=ix0;ix<=ix1;ix++){
  const x=o[0]-rOut+(ix+rng())*cell,z=o[1]-rOut+(iz+rng())*cell,u=rng();
  if(B&&(x<B[0]||z<B[1]||x>B[2]||z>B[3]))continue;
  const d=Math.hypot(x-o[0],z-o[1]);if(d<rIn||d>rOut)continue;
  const m=opt.noMask?1:BIO.mask(x,z);if(m<=0)continue;
  const patch=pk>0?(1-pk*.5)+pk*fbm(x*ps+7,z*ps-3,9484,2):1;
  const a=accept?accept(x,z,d):1;
  if(u>a*m*clamp(patch,0,1.15))continue;
  if(!BIO.clearOf(x,z,opt.pad||0))continue;
  fn(x,BIO.terrainH(x,z),z,d);n++;}
 return n;};
// POISSON-ish scatter of n points with a minimum spacing, area-uniform in the
// annulus, biased outward by `pow` (>1 pushes the crowd out)
BIO.scatter=function(n,rIn,rOut,minD,fn,opt){opt=opt||{};const o=opt.center||BIO.center(),P=[];let tries=0;
 while(P.length<n&&tries++<n*40){const a=rng()*TAU,u=Math.pow(rng(),opt.pow||1);
  const r=Math.sqrt(lerp(rIn*rIn,rOut*rOut,u)),x=o[0]+Math.cos(a)*r,z=o[1]+Math.sin(a)*r;
  if(rng()>BIO.mask(x,z))continue;if(!BIO.clearOf(x,z,opt.pad||0))continue;
  let ok=true;for(const q of P)if(Math.hypot(x-q[0],z-q[1])<minD){ok=false;break;}
  if(!ok)continue;P.push([x,z]);fn(x,BIO.terrainH(x,z),z,r);}
 return P;};
// keep-clear: outside every host obstacle cylinder (plus pad), on the ground
BIO.clearOf=function(x,z,pad){const O=BIO.host.obstacles;pad=pad||0;
 for(let i=0;i<O.length;i++){const q=O[i];if(Math.hypot(x-q.x,z-q.z)<q.r+pad)return false;}return true;};
// keep-clear in 3D: a blob of horizontal radius rad, half-height vr at (x,y,z)
BIO.clearOf3=function(x,y,z,rad,vr){const O=BIO.host.obstacles;
 for(let i=0;i<O.length;i++){const q=O[i];if(q.y0!=null&&(y+vr<q.y0||y-vr>q.y1))continue;
  if(Math.hypot(x-q.x,z-q.z)<q.r+rad)return false;}return true;};

// ---------------------------------------------------------------- surface sampling
// For growing on a structure the host hands over as BufferGeometry[] in world
// space. Samples by triangle area, then filters by facing:
//   upFaces    normal.y > minUp   (ledges, treads, roofs)      -> moss, plants
//   downFaces  normal.y < -minDown (soffits, ceilings)          -> mats, curtains
//   sideFaces  |normal.y| < .35                                 -> vines, brackets
// Each sample: {p:[x,y,z], n:[nx,ny,nz], a:area}
BIO.faceSamples=function(geos,n,filt){const out=[];const F=[];let tot=0;
 for(const g of geos){const p=g.attributes.position;if(!p)continue;const idx=g.index?g.index.array:null;const cnt=idx?idx.length:p.count;
  for(let i=0;i<cnt;i+=3){const a=idx?idx[i]:i,b=idx?idx[i+1]:i+1,c=idx?idx[i+2]:i+2;
   const ax=p.getX(a),ay=p.getY(a),az=p.getZ(a),bx=p.getX(b),by=p.getY(b),bz=p.getZ(b),cx=p.getX(c),cy=p.getY(c),cz=p.getZ(c);
   const ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az;
   let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz);if(l<1e-9)continue;nx/=l;ny/=l;nz/=l;
   if(filt&&!filt(nx,ny,nz))continue;
   const ar=l*.5;tot+=ar;F.push([ax,ay,az,bx,by,bz,cx,cy,cz,nx,ny,nz,ar,tot]);}}
 if(!F.length)return out;
 for(let k=0;k<n;k++){const r=rng()*tot;let lo=0,hi=F.length-1;while(lo<hi){const m=(lo+hi)>>1;if(F[m][13]<r)lo=m+1;else hi=m;}
  const f=F[lo];let u=rng(),v=rng();if(u+v>1){u=1-u;v=1-v;}const w=1-u-v;
  out.push({p:[f[0]*w+f[3]*u+f[6]*v,f[1]*w+f[4]*u+f[7]*v,f[2]*w+f[5]*u+f[8]*v],n:[f[9],f[10],f[11]],a:f[12]});}
 return out;};
BIO.upFaces=function(geos,n,minUp){return BIO.faceSamples(geos,n,(nx,ny,nz)=>ny>(minUp==null?.62:minUp));};
BIO.downFaces=function(geos,n,minDown){return BIO.faceSamples(geos,n,(nx,ny,nz)=>ny<-(minDown==null?.62:minDown));};
BIO.sideFaces=function(geos,n){return BIO.faceSamples(geos,n,(nx,ny,nz)=>Math.abs(ny)<.35);};
// LEDGE POINTS: the outer edges of up-facing faces -- where a vine roots and
// hangs off. Found as up-face samples that have empty air just outboard of them
// (no up-face within `gap` metres in the direction away from the surface's centroid).
BIO.ledgePoints=function(geos,n,gap){gap=gap||2.5;const S=BIO.upFaces(geos,n*4,.62);if(!S.length)return[];
 let cx=0,cz=0;S.forEach(s=>{cx+=s.p[0];cz+=s.p[2];});cx/=S.length;cz/=S.length;
 const cell=gap,H={};const key=(x,y,z)=>(Math.floor(x/cell))+','+(Math.floor(y/(cell*2)))+','+(Math.floor(z/cell));
 S.forEach(s=>{H[key(s.p[0],s.p[1],s.p[2])]=1;});
 const out=[];
 for(const s of S){if(out.length>=n)break;const dx=s.p[0]-cx,dz=s.p[2]-cz,l=Math.hypot(dx,dz)||1;const ox=dx/l,oz=dz/l;
  if(!H[key(s.p[0]+ox*gap,s.p[1],s.p[2]+oz*gap)])out.push({p:s.p,n:[ox,0,oz]});}
 return out;};

})();

// ==================== 45-host-stage.js
// ================================================================= HOST — stage
// The ideal-type host for the SOUTHWESTERN LOWLANDS: everything a world
// provides that a biome does not. Renderer, lights, fog, the terrain with
// terrainH(), the climate fields the biome asks for, the water (one plane at
// y=0 for the inland sea, the bayou and the river's lowland reach, plus a
// ribbon where the river runs down through the hills), the painted ground, the
// tick list, the error panel. A real world replaces this whole section with its
// own; the biome fragments never read anything from it except through BIO.host
// (see 88-host-build.js).
//
// THE MAP (x east, z south, origin mid-lowland, R 3000). One axis does the
// work: s runs NW -> SE (s=(x+z)/sqrt2), t across it toward the NE (t=(x-z)/sqrt2).
// We are in Krator's SW quadrant: the Inner Wall stands off to the NE (+t),
// the Outer Wall to the SW (-t), and the lowlands run between them.
//   s < ~-1900        the INLAND SEA (its shore wobbles; coves; a delta)
//   -1900 .. -1150    a brief strip of RAINFOREST: mangroves in the brackish
//                     shallows, bayou pools and sloughs, the parasol kapoks
//   -1150 .. +700     HUMID SUBTROPICAL: sprawl oaks, pillar figs, veil willows
//                     on the river and the oxbows, a gentle rise
//   +700 .. +3000     MEDITERRANEAN hills: chaparral, madrones, cork oaks,
//                     skirt palms in the draws and at the springs
// One river comes down out of the SE hills and reaches the sea through a delta.
const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,fbm,qEuler,qFacing,qUp}=BIO.fn;
const ERRS=document.getElementById('errs');
function reportErr(m){ERRS.style.display='block';ERRS.textContent+=m+'\n';}
window.onerror=(m,s,l,c,e)=>reportErr((e&&e.stack)||(m+' @'+l+':'+c));
window.addEventListener('unhandledrejection',e=>reportErr('promise: '+(e.reason&&e.reason.stack||e.reason)));
const TICKS=[];
function tick(fn){TICKS.push(fn);}
const REG=[];function REGISTER(o){REG.push(o);}

const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.04;document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();const HAZE=new THREE.Color(0xc6ccc0);scene.fog=new THREE.FogExp2(HAZE.getHex(),.00020);
const camera=new THREE.PerspectiveCamera(50,innerWidth/innerHeight,1,14000);
scene.add(new THREE.HemisphereLight(0xc8d4d0,0x4a4030,.62));
const sun=new THREE.DirectionalLight(0xfff0d2,1.45);sun.position.set(-1200,900,-600);scene.add(sun);   // WNW, over the sea
const fill=new THREE.DirectionalLight(0xb4cec4,.30);fill.position.set(800,400,900);scene.add(fill);

// ---------------------------------------------------------------- the axis, the sea, the river
const TERR={R:3000};
const RT2=Math.SQRT1_2;
const sOf=(x,z)=>(x+z)*RT2, tOf=(x,z)=>(x-z)*RT2;
const xzOf=(s,t)=>[(s+t)*RT2,(s-t)*RT2];
// the zone coordinate: s, wobbled along t so no boundary is a ruled line
function sw(x,z){const t=tOf(x,z);return sOf(x,z)+110*Math.sin(t*.0012+.4)+45*Math.sin(t*.0041);}
// the shore: s of the waterline as a function of t (coves and a delta bulge)
function shoreS(t){return -1900+170*(fbm(t*.0011+3,1.7,41,3)-.5)*2+40*Math.sin(t*.006)+90*smooth(420,60,Math.abs(t-RIVER_T(-1900)));}
// signed distance-ish to the shore in metres, negative out in the sea
function seaIn(x,z){const t=tOf(x,z);return sOf(x,z)-shoreS(t);}
// the river: t as a function of s, meandering down from the SE hills to the delta
function RIVER_T(s){return -120+260*Math.sin(s*.00115+.6)+90*Math.sin(s*.0043+1.3)+30*Math.sin(s*.011);}
function riverD(x,z){const s=sOf(x,z),t=tOf(x,z);if(s>TERR.R*1.2)return 1e9;
 let d=Math.abs(t-RIVER_T(s));
 // the delta: two distributaries fan out over the last 500 m
 const sh=shoreS(RIVER_T(s)),f=smooth(sh+520,sh+40,s);
 if(f>0){d=Math.min(d,Math.abs(t-(RIVER_T(s)+f*210)),Math.abs(t-(RIVER_T(s)-f*170)));}
 return d;}
// the river's width grows toward the sea
function riverW(x,z){const s=sOf(x,z);return mix(9,26,smooth(1800,-1500,s));}
// a bayou: sloughs and pools in the coastal lowland, oxbow ponds up the valley
function swampK(x,z){const s=sw(x,z),sh=shoreS(tOf(x,z));return smooth(-1050,-1350,s)*smooth(sh+10,sh+90,sOf(x,z));}
// THE OAK AVENUE: a dirt road across the plain toward the tower, t as a function of s.
// The host owns the road; the biome plants its two rows (SWLOW.build({avenues})).
const ROAD_S=[-1000,-420];
function ROAD_T(s){return 300+22*Math.sin(s*.006);}
function roadD(x,z){const s=sOf(x,z),t=tOf(x,z);if(s<ROAD_S[0]-60||s>ROAD_S[1]+60||Math.abs(t-300)>90)return 1e9;
 const sc=clamp(s,ROAD_S[0],ROAD_S[1]),slope=22*.006*Math.cos(sc*.006);return Math.hypot(s-sc,(t-ROAD_T(sc))/Math.sqrt(1+slope*slope));}
// THE CORK GROVE: a harvested planting on the first slopes of the hills (the biome plants it)
const CORK_GROVE={center:xzOf(1250,-260),r:70,spacing:16,angle:.35,species:'corkoak',stripped:true};
const ROAD=[];for(let s=ROAD_S[0];s<=ROAD_S[1]+.1;s+=20)ROAD.push(xzOf(s,ROAD_T(s)));
// ---------------------------------------------------------------- terrain
function baseH(x,z){const s=sw(x,z);
 // the lowland shelf, the gentle subtropical rise, then the hills
 return 1.25+2.8*smooth(-1500,-300,s)+7*smooth(-400,700,s)+60*smooth(500,1900,s)+75*smooth(1600,3200,s);}
function hillH(x,z){const s=sw(x,z),k=smooth(300,1300,s);
 return k*(46*(fbm(x*.0016+2,z*.0016-4,63,3)-.5)+14*(fbm(x*.006-1,z*.006+7,64,2)-.5))+(1-k)*(1.6*(fbm(x*.004,z*.004,65,2)-.5));}
function terrainH(x,z){
 let h=baseH(x,z)+hillH(x,z);const h0=h;
 const s=sOf(x,z),rd=riverD(x,z),W=riverW(x,z);
 // bayou pools and sloughs: standing water a few tens of metres across
 const sk=swampK(x,z);if(sk>0){const pool=fbm(x*.0068+11,z*.0068-7,313,2);h-=sk*3.6*smooth(.43,.29,pool);}
 // oxbow ponds up the subtropical valley, near the river only
 const ox=smooth(-1100,-700,sw(x,z))*smooth(600,300,sw(x,z))*smooth(420,120,rd);if(ox>0){const p=fbm(x*.011-3,z*.011+5,317,2);h-=ox*4.2*smooth(.70,.665,p);}
 // the valley the river cut (wider in the hills), and the channel itself
 const vk=smooth(W*9+120,W*1.2,rd)*smooth(200,900,sw(x,z));h-=vk*Math.max(0,h-baseH(x,z)*.8)*.55;
 const bank=smooth(W+10,W*.6,rd);
 // in the lowland the bed drops under the water plane; up in the hills it is a 2.8 m trench the ribbon runs in
 if(bank>0){const lowland=smooth(250,-150,sw(x,z));h=mix(h,Math.min(h-.2,mix(h-2.8,-2.2,lowland)),bank);}
 // the sea: a sandy shelf then the deep
 const si=seaIn(x,z);if(si<30){const bed=-.4-1.6*smooth(0,-160,si)-9*smooth(-160,-700,si)+.8*(fbm(x*.004,z*.004,71,2)-.5)*smooth(-20,-150,si);
  h=mix(h,Math.min(bed,-.25),smooth(30,-12,si));}
 // the road: a level bed, a hand's depth under the verge, no ponds on it
 const rdd=roadD(x,z);if(rdd<16)h=mix(h,h0-.12,smooth(16,5,rdd));
 return h;}
// ---------------------------------------------------------------- the climate fields
// wet 0..1 (annual moisture), tropic 0..1 (frost-free and hot: 1 in the
// rainforest), dry 0..1 (summer drought: 1 in the Mediterranean hills), salt
// (brackish ground at the sea), flow (river banks), upland (0 lowland .. 1 hilltops)
const FIELD={
 tropic:(x,z)=>smooth(-300,-1500,sw(x,z)),   // the rainforest proper is where this passes ~.75 (s < ~-1150)
 dry:(x,z)=>smooth(450,1150,sw(x,z)),
 wet:(x,z)=>{const s=sw(x,z),rd=riverD(x,z),h=terrainH(x,z);
  let w=mix(.96,.80,smooth(-1400,-600,s));w=mix(w,.34,smooth(450,1300,s));w=mix(w,.22,smooth(1800,2900,s));
  // the north-facing draws hold water in the hills: madrone and sycamore country
  w+=.14*smooth(600,1400,s)*(fbm(x*.0021-6,z*.0021+2,66,2)-.5)*2;
  w=Math.max(w,.97*smooth(W_R(x,z)*4+60,W_R(x,z),rd),.95*smooth(1.2,-.4,h)*smooth(-600,-1000,s));return clamp(w,0,1);},
 salt:(x,z)=>{const si=seaIn(x,z);return clamp(smooth(170,0,si)*(1-smooth(60,20,riverD(x,z))*.5),0,1);},
 flow:(x,z)=>clamp(smooth(W_R(x,z)*5+90,W_R(x,z)+4,riverD(x,z)),0,1),
 upland:(x,z)=>clamp((terrainH(x,z)-8)/150,0,1)};
function W_R(x,z){return riverW(x,z);}
// ---------------------------------------------------------------- the host binding
const OBSTACLES=[];
BIO.init({THREE:THREE,scene:scene,terrainH:terrainH,
 mask:(x,z)=>{if(roadD(x,z)<11.5)return 0;const h=terrainH(x,z);return h<.12?0:h<.6?(h-.12)/.48:1;},   // nothing on the road or its mown verges   // nothing rooted under water (the mangrove pass asks past the mask itself)
 obstacles:OBSTACLES,ticks:tick,seed:11,
 // the LOD spine: a row of origins down the NW -> SE axis, sea to hills
 origin:[-2300,-1650,-1000,-350,300,950,1600,2250].map(s=>xzOf(s,0)),center:[0,0],
 fields:FIELD,err:reportErr});
BIO.setSun([-1200,900,-600]);
// ---------------------------------------------------------------- the ground
// One mesh, painted from a coarse cache of the fields (each costs fbm calls),
// with a tiled grain texture multiplied in. The red soils of the hills are
// the same family of colours as the bark.
const FC=(function(){const N=320,S=TERR.R*2.2,a={wet:new Float32Array(N*N),dry:new Float32Array(N*N),tr:new Float32Array(N*N),rd:new Float32Array(N*N),si:new Float32Array(N*N),up:new Float32Array(N*N),sk:new Float32Array(N*N)};
 for(let j=0;j<N;j++)for(let i=0;i<N;i++){const x=(i/(N-1)-.5)*S,z=(j/(N-1)-.5)*S,k=j*N+i;
  a.wet[k]=FIELD.wet(x,z);a.dry[k]=FIELD.dry(x,z);a.tr[k]=FIELD.tropic(x,z);a.rd[k]=riverD(x,z);a.si[k]=seaIn(x,z);a.up[k]=FIELD.upland(x,z);a.sk[k]=swampK(x,z);}
 const at=(arr,x,z)=>{const u=clamp((x/S+.5)*(N-1),0,N-1.001),v=clamp((z/S+.5)*(N-1),0,N-1.001),i=Math.floor(u),j=Math.floor(v),fu=u-i,fv=v-j;
  return arr[j*N+i]*(1-fu)*(1-fv)+arr[j*N+i+1]*fu*(1-fv)+arr[(j+1)*N+i]*(1-fu)*fv+arr[(j+1)*N+i+1]*fu*fv;};
 return{N,S,a,at};})();
const TEX_GROUND=BIO.canvasTex(1536,1536,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;const S=TERR.R*2.2;
 const c=new THREE.Color(),t=new THREE.Color();
 const MUD=new THREE.Color(0x352c20),LIT=new THREE.Color(0x3a281c),LITG=new THREE.Color(0x3c4424),
  SUB=new THREE.Color(0x4c4630),SUBG=new THREE.Color(0x56643a),
  GOLD=new THREE.Color(0xb49656),GOLD2=new THREE.Color(0x9c8048),OCHRE=new THREE.Color(0x96704a),REDSOIL=new THREE.Color(0x8a4a32),SCRUB=new THREE.Color(0x5c5e3a),
  SAND=new THREE.Color(0xd6c6a0),WETSAND=new THREE.Color(0x8e7c5c),SILT=new THREE.Color(0x7a6a50),BED=new THREE.Color(0x9a8a62);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const wx=(x/w-.5)*S,wz=(y/h-.5)*S;
  const n=fbm(x/26,y/26,.3,2)-.5,n2=(BIO.fn.h3(x,y,3)-.5),n3=fbm(x/90,y/90,1.7,2)-.5;
  const tr=FC.at(FC.a.tr,wx,wz),dry=FC.at(FC.a.dry,wx,wz),wet=FC.at(FC.a.wet,wx,wz),rd=FC.at(FC.a.rd,wx,wz),si=FC.at(FC.a.si,wx,wz),sk=FC.at(FC.a.sk,wx,wz);
  // subtropical: leaf litter under the oaks, grass in the glades
  c.copy(SUB).lerp(SUBG,clamp(.5+n3*2.4+n*.8,0,1));
  // the rainforest: dark red litter
  t.copy(LIT).lerp(LITG,clamp(.45+n*1.8,0,1));c.lerp(t,tr);
  // the bayou: mud
  c.lerp(MUD,sk*.7);
  // the Mediterranean: golden grass, ochre and red soil where it is bare, scrub where it is wetter
  t.copy(GOLD).lerp(GOLD2,clamp(.5+n*1.8,0,1)).lerp(OCHRE,clamp(n3*2.2,0,.6)).lerp(REDSOIL,smooth(.16,.3,n3)*.8).lerp(SCRUB,smooth(.3,.5,wet)*.55);c.lerp(t,dry);
  // river banks: silt; the beach: sand, darker where the sea wets it
  c.lerp(SILT,smooth(60,14,rd)*.7);
  c.lerp(SAND,smooth(150,40,si)*(1-sk)*(1-smooth(80,20,rd)));c.lerp(WETSAND,smooth(25,0,si)*.8);
  c.lerp(BED,smooth(0,-40,si));
  const k=1+n*.10+n2*.05;
  d[i]=clamp(c.r*255*k,0,255);d[i+1]=clamp(c.g*255*k,0,255);d[i+2]=clamp(c.b*255*k,0,255);d[i+3]=255;}
 g.putImageData(id,0,0);});
const TEX_DETAIL=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=232+(fbm(x/9,y/9,5,2)-.5)*36+(BIO.fn.h3(x,y,9)-.5)*20;d[i]=d[i+1]=d[i+2]=clamp(v,0,255);d[i+3]=255;}
 g.putImageData(id,0,0);});
const MAT_GROUND=new THREE.MeshLambertMaterial({map:TEX_GROUND,color:0x9a9890});
MAT_GROUND.onBeforeCompile=sh=>{sh.uniforms.uDetail={value:TEX_DETAIL};
 sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vGWP;').replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvGWP=(modelMatrix*vec4(transformed,1.0)).xyz;');
 sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D uDetail;varying vec3 vGWP;')
  .replace('#include <map_fragment>','#include <map_fragment>\n{vec3 dt=texture2D(uDetail,vGWP.xz*0.165).rgb;vec3 dt2=texture2D(uDetail,vGWP.xz*0.021+0.37).rgb;diffuseColor.rgb*=mix(vec3(1.0),dt*dt2*1.12,0.85);}');};
(function(){const N=400,S=TERR.R*2.2,g=new THREE.PlaneGeometry(S,S,N,N);g.rotateX(-Math.PI/2);
 const p=g.attributes.position;for(let i=0;i<p.count;i++)p.setY(i,terrainH(p.getX(i),p.getZ(i)));
 g.computeVertexNormals();const m=new THREE.Mesh(g,MAT_GROUND);m.userData.probeSkip=true;m.userData.inspectLabel='The lowland floor';scene.add(m);})();

// ---------------------------------------------------------------- the water
// One plane at y=0 carries the inland sea, the bayou and the river's lowland
// reach; its vertex colour is the water's own: a clear green-blue sea over
// sand, tea-dark in the bayou, silty in the river. Where the river runs down
// through the hills it is a ribbon in the same material.
const SEA_SHALLOW=new THREE.Color(0x4aa89a),SEA_MID=new THREE.Color(0x24707a),SEA_DEEP=new THREE.Color(0x103e52),SEA_PALE=new THREE.Color(0x9ed0bc);
const BAYOU_COL=new THREE.Color(0x3a3a22),RIVER_COL=new THREE.Color(0x5a6040);
const MAT_WATER=new THREE.ShaderMaterial({fog:true,vertexColors:true,
 uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{uT:{value:0},uSun:{value:new THREE.Vector3(-1200,900,-600).normalize()},uSky:{value:new THREE.Color(0xd8e2dc)}}]),
 vertexShader:['#include <fog_pars_vertex>','varying vec3 vWP;varying vec3 vCol;',
  'void main(){vCol=color;vec4 wp=modelMatrix*vec4(position,1.0);vWP=wp.xyz;vec4 mvPosition=viewMatrix*wp;gl_Position=projectionMatrix*mvPosition;','#include <fog_vertex>','}'].join('\n'),
 fragmentShader:['#include <fog_pars_fragment>','uniform float uT;uniform vec3 uSun,uSky;varying vec3 vWP;varying vec3 vCol;',
  'void main(){',
  ' float dcam=length(cameraPosition-vWP);float rk=1.0-smoothstep(120.0,420.0,dcam);',   // ripples fade with range or they alias into a moire
  ' vec3 n=normalize(vec3(rk*(0.035*sin(vWP.x*0.31+uT*1.1)+0.02*sin(vWP.z*0.53-uT*0.7+vWP.x*0.11)),1.0,rk*(0.035*cos(vWP.z*0.27+uT*0.9)+0.02*sin(vWP.x*0.47+uT*1.3))));',
  ' vec3 V=normalize(cameraPosition-vWP);float fr=pow(1.0-max(dot(n,V),0.0),3.0);',
  ' vec3 col=mix(vCol,uSky,0.08+fr*0.62);',
  ' vec3 H=normalize(uSun+V);col+=pow(max(dot(n,H),0.0),140.0)*0.75*vec3(1.0,0.96,0.86);',
  ' gl_FragColor=vec4(col,1.0);','#include <fog_fragment>','}'].join('\n')});
MAT_WATER.uniforms.fogColor.value=scene.fog.color;MAT_WATER.uniforms.fogDensity.value=scene.fog.density;
TICKS.push(dt=>{MAT_WATER.uniforms.uT.value+=dt;});
function waterColorAt(x,z,out){const h=terrainH(x,z),d=Math.max(0,-h),si=seaIn(x,z),rd=riverD(x,z);
 const shoal=fbm(x*.0031+2,z*.0031-4,505,2);
 out.copy(SEA_SHALLOW).lerp(SEA_PALE,Math.max(smooth(.5,.68,shoal)*smooth(2.2,.3,d),smooth(.5,.08,d)*.6)).lerp(SEA_MID,smooth(1.4,4,d)).lerp(SEA_DEEP,smooth(4.5,10,d));
 out.lerp(BAYOU_COL,smooth(-30,60,si)*.9);                                   // everything inland of the shore is fresh and dark
 out.lerp(RIVER_COL,smooth(60,15,rd)*smooth(-200,20,si)*.85);return out;}
(function(){const N=300,S=TERR.R*2.2,g=new THREE.PlaneGeometry(S,S,N,N);g.rotateX(-Math.PI/2);
 const p=g.attributes.position,col=new Float32Array(p.count*3),c=new THREE.Color();
 for(let i=0;i<p.count;i++){waterColorAt(p.getX(i),p.getZ(i),c);c.convertSRGBToLinear();col[i*3]=c.r;col[i*3+1]=c.g;col[i*3+2]=c.b;}
 g.setAttribute('color',new THREE.BufferAttribute(col,3));
 const m=new THREE.Mesh(g,MAT_WATER);m.userData.probeSkip=true;m.userData.inspectLabel='The inland sea';m.renderOrder=1;scene.add(m);
 // the river down through the hills: a ribbon at bed+0.6 wherever the bed is above the plane
 const pos=[],cc=[],rc=RIVER_COL.clone().convertSRGBToLinear(),ds=24;
 for(let s=-300;s<TERR.R*1.25;s+=ds){const t0=RIVER_T(s),t1=RIVER_T(s+ds);
  const a=xzOf(s,t0),b=xzOf(s+ds,t1),w=riverW(a[0],a[1])*.8;
  const ya=terrainH(a[0],a[1])+.6,yb=terrainH(b[0],b[1])+.6;if(ya<.05&&yb<.05)continue;
  // the across-stream offset is along t, i.e. (RT2,-RT2) in x,z
  const ox=RT2*w,oz=-RT2*w;
  pos.push(a[0]-ox,ya,a[1]-oz, b[0]-ox,yb,b[1]-oz, b[0]+ox,yb,b[1]+oz,  a[0]-ox,ya,a[1]-oz, b[0]+ox,yb,b[1]+oz, a[0]+ox,ya,a[1]+oz);for(let k=0;k<6;k++)cc.push(rc.r,rc.g,rc.b);}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(cc,3));geo.computeVertexNormals();
 const rm=new THREE.Mesh(geo,MAT_WATER);rm.userData.probeSkip=true;rm.userData.inspectLabel='The river';scene.add(rm);})();
// ---------------------------------------------------------------- the road
// A ribbon a few cm over the ground in its own dirt texture: two wheel ruts, a grassy
// crown, leaf litter, pale sand. (The ground canvas is ~4 m a pixel; a road needs its own.)
// the height of the RENDERED ground (400 cells of ~16 m, split on the same diagonal as PlaneGeometry):
// between its vertices it rides above or below terrainH, and a road laid on terrainH sinks into it
function meshH(x,z){const N=400,S=TERR.R*2.2,c=S/N,u=(x+S/2)/c,v=(z+S/2)/c,i=Math.floor(u),j=Math.floor(v),fu=u-i,fv=v-j,X=k=>-S/2+k*c;
 const h00=terrainH(X(i),X(j)),h10=terrainH(X(i+1),X(j)),h01=terrainH(X(i),X(j+1)),h11=terrainH(X(i+1),X(j+1));
 return fu+fv<=1?h00+(h10-h00)*fu+(h01-h00)*fv:h11+(h01-h11)*(1-fu)+(h10-h11)*(1-fv);}
(function(){const TEX=BIO.canvasTex(256,512,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,u=x/w,q=(u-.5)/.4+.5,rut=Math.max(smooth(.12,0,Math.abs(q-.28)),smooth(.12,0,Math.abs(q-.72))),crown=smooth(.1,0,Math.abs(q-.5)),verge=smooth(.19,.22,Math.abs(u-.5));
   const n=(fbm(x/14,y/14,2.1,3)-.5)*40+(BIO.fn.h3(x,y,5)-.5)*22;let r=206+n-rut*26,g2=190+n-rut*24,b=152+n-rut*20;   // the road in the middle 40%, mown grass verges either side
   r=mix(r,120,crown*.45);g2=mix(g2,132,crown*.45);b=mix(b,70,crown*.45);
   const gn=(fbm(x/8,y/8,4.4,2)-.5)*50;r=mix(r,96+gn*.6,verge);g2=mix(g2,118+gn,verge);b=mix(b,62+gn*.4,verge);
   if(fbm(x/6,y/6,7.7,2)>.62){r*=.72;g2*=.64;b*=.52;}   // fallen oak leaves
   d[i]=clamp(r,0,255);d[i+1]=clamp(g2,0,255);d[i+2]=clamp(b,0,255);d[i+3]=255;}
  g.putImageData(id,0,0);});
 const pos=[],uv=[],W=11;let v=0;
 for(let s=ROAD_S[0];s<ROAD_S[1];s+=4){const a=xzOf(s,ROAD_T(s)),b=xzOf(s+4,ROAD_T(s+4)),dx=b[0]-a[0],dz=b[1]-a[1],L=Math.hypot(dx,dz),nx=-dz/L*W,nz=dx/L*W;
  const P=[[a[0]-nx,a[1]-nz,0,v],[a[0]+nx,a[1]+nz,1,v],[b[0]+nx,b[1]+nz,1,v+L/44],[b[0]-nx,b[1]-nz,0,v+L/44]];   // one tile per 44 m along, ~22 m across: texels square
  [0,2,1,0,3,2].forEach(k=>{const p=P[k];pos.push(p[0],Math.max(terrainH(p[0],p[1]),meshH(p[0],p[1]))+.08,p[1]);uv.push(p[2],p[3]);});v+=L/44;}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();
 const m=new THREE.Mesh(g,new THREE.MeshLambertMaterial({map:TEX,color:0xaaa498,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
 m.userData.probeSkip=true;m.userData.inspectLabel='The oak avenue';scene.add(m);})();

// ==================== 50-biome-swlowlands-species.js
// ================================================================= SOUTHWESTERN LOWLANDS — species (data + kit items)
// Krator's southwestern lowlands: the shore of the inland sea, a brief strip of
// rainforest and bayou, a broad humid-subtropical plain, and Mediterranean
// hills under the Outer Wall. A more terrestrial country than the hyperjungle
// or the abyss, and the plants are nearly ones we know -- live oak, banyan,
// willow, mangrove, cypress, manzanita, madrone, cork oak, fan palm -- but two
// things say this is not Earth:
//   WIDTH.  The mature trees are enormously WIDE rather than tall. A sprawl oak
//           is twenty-odd metres high and eighty across; its limbs run out along
//           the ground and rise again. You are small here by width.
//   BARK.   Brown, pale, and blood red, in every shade and finish: lacquered
//           red mangrove roots, charred-and-red manzanita, madrone and gum
//           flayed red over green-white, copper ringbark banded with pale
//           lenticels, cork oaks stripped to a raw orange-red.
// Everything here is DATA and kit definitions; no placement. Tags follow the
// project rule (climate / aridity / abyssal / riparian) and are honoured by
// the placement passes.
var SWLOW={};
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
SWLOW.TAGS={climate:'tropic..temperate',aridity:'semiarid..humid',abyssal:false,riparian:'both'};

// ---------------------------------------------------------------- the climate this biome reads
// Beyond the core's wet / salt / upland the lowlands zone themselves on
// tropic (frost-free heat), dry (summer drought) and flow. A world that binds
// none of them still gets a sensible default: humid subtropical everywhere.
// (Additive: the core's own defaults are left alone.)
const FD=BIO.fieldDefault;
if(!FD.tropic)FD.tropic=(x,z)=>0;
if(!FD.dry)FD.dry=(x,z)=>0;
if(!FD.flow)FD.flow=(x,z)=>0;

// ---------------------------------------------------------------- palettes
const PAL=SWLOW.PAL={
 // foliage, by habit
 oak:[0x2c4824,0x34522a,0x263f1f,0x3c5a2e,0x304a30],
 fig:[0x2d5a2a,0x386a30,0x264e28,0x42703a],
 mangrove:[0x2c5a30,0x366a36,0x244e2a,0x3e7040],
 kapok:[0x4e7c38,0x5a8a3e,0x426e32,0x6a9444],
 cypress:[0x5a7a34,0x66883c,0x4e6e2e,0x728e44],
 gum:[0x4a6a54,0x587460,0x40604e,0x5e7a58],          // a blue-grey-green, glaucous
 willow:[0x7a9c44,0x8aaa4c,0x6a8c3a,0x9ab658],
 ring:[0x4a6c30,0x567a36,0x3e602a],
 sycamore:[0x5a7c3a,0x688a42,0x4e6e34],
 manz:[0x788e6e,0x86a07a,0x6a8468,0x94aa84],          // grey-green, leathery
 madrone:[0x365a2a,0x40662e,0x2e5026,0x4a7034],
 cork:[0x3a4c36,0x44563c,0x32442e,0x4c5e42],
 palm:[0x5a7c52,0x68885a,0x4e6c48,0x7a9460,0x8aa4a8,0x9ab4b4],   // the last two: a silver-blue fan (Bismarck)
 needle:[0x2c4a3e,0x345444,0x284238,0x3c5a48],
 pineNeedle:[0x5a7a3a,0x668a42,0x4e6e34],
 crimson:[0x9a1e18,0xb02a1c,0x8a1a1a,0xc03a20,0xa82818],
 mimosa:[0x6a8a3a,0x7a9a44,0x5e7e34],
 glossy2:[0x3a6a30,0x447a36,0x325e2a,0x4e8440],
 stargum:[0x3e6a2e,0x4a7a34,0x5a8a3a,0x8a4a26,0x9a3a22],   // green with a flush of red stars
 bay:[0x4a5e3e,0x546a46,0x405436,0x5e7450],
 magnolia:[0x264622,0x2e5228,0x223e1e,0x365a2c],
 flame:[0xe8401c,0xf0501e,0xd83018,0xf07020],
 jacaranda:[0x8a70d8,0x9a80e0,0x7a60c8,0xa890e8],
 magWhite:[0xf6f2e6,0xf2ecdc,0xfaf6ee],
 cane:[0x3a7a3a,0x488a40,0x2e6a34,0x56943e],
 // a flush of new growth: bronze and red on the oaks, figs and madrones
 flush:[0x8a4a2a,0x9a5a30,0x7a3a26,0xa0643a],
 // understorey
 fern:[0x2f5a2c,0x3c6a30,0x27482a,0x486f34,0x5a7a2e],
 shrub:[0x1e3a20,0x27482a,0x305a30,0x224426,0x3a5a2c],
 aroid:[0x2e6a34,0x3a7a3a,0x286030,0x468440],
 palmetto:[0x4a7a4a,0x5a8a50,0x3e6a42,0x6a9a5a],
 grassGreen:[0x5a7a34,0x6a8a3a,0x4a6a2c,0x7a9a44],
 grassGold:[0xb89a58,0xc8aa62,0xa88a4a,0xd0b46c,0x9a8448],
 chapRed:[0x8a3a24,0x9a4a2a,0x7a3020,0xa85a30],
 stipa:[0xd8d0a4,0xe4dcb4,0xccc294],
 mullein:[0xf0d030,0xf4dc48,0xe8c428],
 aloe:[0xf06a1c,0xf48a24,0xe85418],
 pincushion:[0xe8401c,0xf0601e,0xd83018],
 sage:[0x8a9a88,0x9aaa96,0x7a8a7a,0xa4b09c],
 chap:[0x3e4e30,0x4a5a36,0x36462c,0x546440],
 agave:[0x6a8a8a,0x7a9a96,0x5a7a7c,0x88a4a0],
 reed:[0x5a7a34,0x6a8a3a,0x4a6a2c,0x7a9a44,0x3e5a28],
 // blooms (Krator saturates them a notch)
 azalea:[0xe0508a,0xf06aa0,0xd8406c,0xf4f0f0,0xe87830],
 heliconia:[0xd8301c,0xe85a1c,0xf0b020,0xc81e3a],
 poppy:[0xf08a1c,0xf4a020,0xe8701a,0xf4c040],
 lupin:[0x6a50c0,0x7a60d0,0x5a44a8,0x8a70d8],
 blossom:[0xf4c8d4,0xf0b0c4,0xf8e4ea,0xe898b4],
 iris:[0x7a4ac8,0x6a3ab0,0x9a6ad8],
 hyacinth:[0x9a7ae0,0xaa8ae8,0x8a6ad0],
 cream:[0xf4ecd4,0xf0e4c4,0xe8dcb8],
 berry:[0xc82a1e,0xd8401e,0xb01c18],
 // everything else
 moss:[0x4f6a2c,0x5a7a30,0x3f5a26,0x6a8a3a,0x557a3c],
 mossPale:[0x8a9a7a,0x9aa888,0x7a8a6e,0xa4ae92],       // Spanish moss: grey-green
 duckweed:[0x6a9a2a,0x7aaa32,0x5a8a24],
 pad:[0x3a6a3a,0x4a7a40,0x2e5a30,0x5a8a44],
 rock:[0x8a7a66,0x7a6c5a,0x9a8a74,0x6c5e4e],          // sandstone
 rockRed:[0x9a5a3e,0x8a4e36,0xa86a4a],
 litter:[0x4a3624,0x5a4028,0x3a2c1c,0x6a4a2e],
 fungus:[0xa08464,0x8d6a5e,0xb89a70,0xd8b878],
 deadwood:[0x6a5a4a,0x5a4c3e,0x7a6856,0x8a7a66],     // silvered
 vine:[0x3d5a2a,0x2f4a24,0x4a6a30],
};

// ---------------------------------------------------------------- the tree species
// H height band, rb bole radius, crownR, bk the bark bucket, bark the
// designer's colours (what the bark should LOOK like: the material does the
// light rig's arithmetic), leaf the foliage set.
SWLOW.SPECIES=[
 /*0*/{key:'mangrove',name:'Lantern mangrove',H:[9,16],rb:[.45,.8],crownR:[9,15],bk:'bk_lacquer',bark:[0x8e2418,0x9a2e1a,0x7a1e16,0xa83a20],
  leaf:PAL.mangrove,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*1*/{key:'cypress',name:'Knee-cypress',H:[26,40],rb:[1.3,2.1],crownR:[14,22],bk:'bk_stringy',bark:[0x8a5a3e,0x7a4e36,0x9a6a4a],
  leaf:PAL.cypress,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*2*/{key:'kapok',name:'Parasol kapok',H:[48,66],rb:[2.2,3.2],crownR:[28,40],bk:'bk_pale',bark:[0xa8aa96,0x9aa08a,0xb4b4a0],
  leaf:PAL.kapok,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'no'}},
 /*3*/{key:'gum',name:'Ribbon gum',H:[38,56],rb:[1.1,1.8],crownR:[14,20],bk:'bk_strip',bark:[0xa03226,0xb03c2a,0x8a2a26,0x9a4a34],
  leaf:PAL.gum,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*4*/{key:'canepalm',name:'Lacquer cane palm',H:[5,12],rb:[.08,.14],crownR:[2.6,4.2],bk:'bk_cane',bark:[0xc8b040,0xb8a438,0xd4c050],
  crownshaft:[0xc81e14,0xd82818,0xb81810],leaf:PAL.cane,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*5*/{key:'sprawloak',name:'Sprawl oak',H:[28,38],rb:[2.5,3.8],crownR:[36,50],bk:'bk_furrow',bark:[0x4a3226,0x563a2a,0x40302a,0x5e3a2a],
  leaf:PAL.oak,moss:1,touch:.45,tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 /*6*/{key:'pillarfig',name:'Pillar fig',H:[22,32],rb:[1.6,2.4],crownR:[26,40],bk:'bk_pale',bark:[0x9a9a8a,0x8e9082,0xa6a494],
  leaf:PAL.fig,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*7*/{key:'willow',name:'Veil willow',H:[14,22],rb:[.9,1.4],crownR:[12,18],bk:'bk_furrow',bark:[0x6a4a30,0x5a4030,0x7a5234],
  leaf:PAL.willow,twig:[0xd07a2a,0xe08a30,0xc86a24],tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*8*/{key:'ringbark',name:'Copper ringbark',H:[9,16],rb:[.35,.6],crownR:[8,13],bk:'bk_ring',bark:[0x8a3a22,0x9a4424,0x7a3020,0xa4502a],
  leaf:PAL.ring,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*9*/{key:'sycamore',name:'Ghost sycamore',H:[20,32],rb:[.9,1.5],crownR:[14,22],bk:'bk_mottle',bark:[0x8a8458,0x7a7a52,0x9a8e62],
  leaf:PAL.sycamore,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'yes'}},
 /*10*/{key:'manzanita',name:'Ember manzanita',H:[3,7],rb:[.12,.26],crownR:[3,6],bk:'bk_ember',bark:[0xb0301a,0xc03c1e,0x9a2a18,0xc84a24],
  leaf:PAL.manz,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*11*/{key:'madrone',name:'Flayed madrone',H:[13,22],rb:[.6,1.0],crownR:[10,16],bk:'bk_flay',bark:[0xb84a24,0xc4582a,0xa83e22],
  leaf:PAL.madrone,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*12*/{key:'corkoak',name:'Cork oak',H:[9,16],rb:[.7,1.1],crownR:[10,16],bk:'bk_cork',bark:[0x8a8274,0x7e766a,0x968c7c],
  stripped:[0xc4401e,0xb83818,0xd0521e,0x9a3a20],leaf:PAL.cork,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*13*/{key:'skirtpalm',name:'Skirt palm',H:[4,9],rb:[.45,.75],crownR:[5,8],bk:'bk_fibre',bark:[0x6a5a48,0x5e5040,0x7a6a54],
  leaf:PAL.palm,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'both'}},
 /*14*/{key:'coastoak',name:'Coast oak',H:[15,22],rb:[1.1,1.8],crownR:[16,28],bk:'bk_furrow',bark:[0x5a5048,0x4e463e,0x665a50],
  leaf:PAL.cork,moss:.25,touch:.15,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*15*/{key:'pompom',name:'Pompom cycad',H:[4,8],rb:[.35,.6],crownR:[2.4,3.6],bk:'bk_fibre',bark:[0x7a6a58,0x6a5c4c,0x86765e],
  leaf:[0x2e5a34,0x386a3a,0x2a5030,0x44703e],bloom:[0xc8201c,0xd8301e,0xb81818],tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*16*/{key:'cedar',name:'Tier cedar',H:[18,30],rb:[1.0,1.6],crownR:[16,26],bk:'bk_furrow',bark:[0x5a4a44,0x4e4240,0x66564c],
  leaf:PAL.needle,tiers:[4,6],item:'needle',tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*17*/{key:'pine',name:'Flatwood pine',H:[24,34],rb:[.42,.7],crownR:[6,10],bk:'bk_plate',bark:[0x9a4a2e,0x8a4230,0xa85a38],
  leaf:PAL.pineNeedle,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*18*/{key:'crimson',name:'Crimson ghost',H:[12,20],rb:[.7,1.1],crownR:[12,18],bk:'bk_crack',bark:[0xe2d8c2,0xd8ceb6,0xece2cc],
  leaf:PAL.crimson,tiers:[3,5],item:'glossy',tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*19*/{key:'rattlepod',name:'Rattle-pod',H:[8,14],rb:[.4,.7],crownR:[10,16],bk:'bk_furrow',bark:[0x5a4a3e,0x4e4036,0x66564a],
  leaf:PAL.mimosa,pod:[0x8a2a1c,0x9a3a22,0x7a2418,0xa84a2a],tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*20*/{key:'eyed',name:'Eyed beech',H:[16,26],rb:[.6,1.0],crownR:[10,15],bk:'bk_ocelli',bark:[0xb09a78,0xa48e6c,0xbca684],
  leaf:PAL.sycamore,tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 // the crown-flowering trees: flowers at the branch ends, in the crown, as a flowering tree has them
 /*21*/{key:'flame',name:'Flame parasol',H:[10,15],rb:[.7,1.1],crownR:[16,24],bk:'bk_pale',bark:[0x9a948a,0x8e887e,0xa8a296],
  leaf:PAL.mimosa,flower:PAL.flame,bloomK:.45,pod:[0x3a2a1c,0x4a3424,0x2e2218],tags:{climate:'tropic',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*22*/{key:'jacaranda',name:'Violet jacaranda',H:[12,18],rb:[.5,.85],crownR:[11,16],bk:'bk_furrow',bark:[0x6a5a4e,0x5e5046,0x76665a],
  leaf:PAL.mimosa,flower:PAL.jacaranda,bloomK:.72,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*23*/{key:'magnolia',name:'Lantern magnolia',H:[18,26],rb:[.7,1.1],crownR:[9,14],bk:'bk_pale',bark:[0x8e928a,0x82867e,0x9a9e94],
  leaf:PAL.magnolia,flower:PAL.magWhite,tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 // canopy cover for the plain and the hills
 /*24*/{key:'sunburn',name:'Sunburn tree',H:[16,24],rb:[.9,1.4],crownR:[14,20],bk:'bk_lacquer',bark:[0xb0482a,0xa04028,0xc05a34,0x9a3c2a],
  leaf:PAL.glossy2,tags:{climate:'tropic',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*25*/{key:'stargum',name:'Star gum',H:[24,34],rb:[.9,1.4],crownR:[12,18],bk:'bk_cork',bark:[0x8a8478,0x7e786e,0x968e80],
  leaf:PAL.stargum,tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 /*26*/{key:'baylaurel',name:'Bay laurel',H:[14,22],rb:[.8,1.3],crownR:[12,20],bk:'bk_pale',bark:[0x8e948a,0x82887e,0x9aa094],
  leaf:PAL.bay,moss:.1,touch:.08,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'both'}},
];

// ---------------------------------------------------------------- leaf textures
// Greyscale on transparent canvases (BIO.alphaTex); the per-instance colour tints them.
reseed(510011);
const TX={};
/* dense small elliptic leaves -- the oaks */
TX.oakleaf=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,12,.68);   // small leaves: a live oak's are a few cm, and a clump is 8 m across
 for(let i=0;i<1500;i++){const c=BIO.tex.clPt(S,.12,.94),lum=lerp(95,240,i/1500)+rr(-20,12);
  g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.ellipse(c[0],c[1],rr(4.5,7),rr(2.5,4),rr(0,TAU),0,TAU);g.fill();}},[150,150,150]);
/* broad glossy ovate leaves in clusters -- figs, mangroves, madrones */
TX.glossy=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,8,.60);
 for(let i=0;i<60;i++){const c=BIO.tex.clPt(S,.10,.74),lum=lerp(105,242,i/60)+rr(-15,12),n=ri(3,5),a0=rr(0,TAU);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(40,58),rr(15,20),a0+(k-(n-1)/2)*.8,lum*rr(.9,1.05),true);}},[160,160,160]);
/* broad lobed leaves -- kapok, sycamore, ringbark */
TX.broad=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,8,.60);
 for(let i=0;i<54;i++){const c=BIO.tex.clPt(S,.10,.72),lum=lerp(110,238,i/54)+rr(-15,12),n=ri(3,5),a0=rr(0,TAU);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(44,66),rr(16,22),a0+(k-(n-1)/2)*.75,lum*rr(.9,1.05),true);}},[165,165,165]);
/* feathery sprays -- the cypress */
TX.feather=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.62);
 for(let i=0;i<78;i++){const p=BIO.tex.clPt(S,.09,.62),a=p[2]+rr(-.7,.7),L=rr(50,86),lum=lerp(110,235,i/78)+rr(-18,18);
  g.strokeStyle=BIO.tex.grey(lum*.55);g.lineWidth=2.2;g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[0]+Math.cos(a)*L,p[1]+Math.sin(a)*L);g.stroke();
  for(let s=4;s<L;s+=3.4){const t=s/L,nl=lerp(14,5,t),bx=p[0]+Math.cos(a)*s,by=p[1]+Math.sin(a)*s;g.strokeStyle=BIO.tex.grey(lum*rr(.85,1.08));g.lineWidth=1.8;
   for(let sd=-1;sd<=1;sd+=2){const na=a+sd*1.15;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(na)*nl,by+Math.sin(na)*nl);g.stroke();}}}},[130,130,130]);
/* hanging sickle leaves in loose bunches -- the flayed gum */
TX.lance=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.62);
 for(let i=0;i<70;i++){const c=BIO.tex.clPt(S,.10,.74),lum=lerp(110,238,i/70)+rr(-15,12),n=ri(4,7);
  for(let k=0;k<n;k++){const a=Math.PI/2+rr(-.6,.6),L=rr(50,80),x=c[0]+rr(-8,8),y=c[1];g.fillStyle=BIO.tex.grey(lum*rr(.9,1.05));
   g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+Math.cos(a)*L*.5+9,y+Math.sin(a)*L*.5,x+Math.cos(a)*L+rr(-6,6),y+Math.sin(a)*L);g.quadraticCurveTo(x+Math.cos(a)*L*.5-4,y+Math.sin(a)*L*.5,x,y);g.fill();}}},[150,150,150]);
/* small leathery leaves on crooked twigs -- manzanita */
TX.manz=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.64);
 for(let i=0;i<110;i++){const c=BIO.tex.clPt(S,.12,.8),a=c[2]+rr(-.8,.8),L=rr(40,80),lum=lerp(110,238,i/110);
  g.strokeStyle=BIO.tex.grey(70);g.lineWidth=2.4;g.beginPath();g.moveTo(c[0],c[1]);const ex=c[0]+Math.cos(a)*L,ey=c[1]+Math.sin(a)*L;g.lineTo(ex,ey);g.stroke();
  for(let s=6;s<L;s+=7){const bx=c[0]+Math.cos(a)*s,by=c[1]+Math.sin(a)*s;for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lum*rr(.88,1.06));
   g.beginPath();g.ellipse(bx+Math.cos(a+sd*1.2)*6,by+Math.sin(a+sd*1.2)*6,8.5,5.5,a+sd*1.2,0,TAU);g.fill();}}}},[150,150,150]);
/* weeping willow: fine strands of narrow leaves, tileable top to bottom (v=0 at the top of a ribbon) */
TX.willow=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';   // a few strands with air between them: a veil, not a plank
 for(let k=0;k<8;k++){const x0=12+(k+rr(-.25,.25))*(S-24)/7,lum=lerp(115,238,rng());
  for(let off=-S;off<=S;off+=S){let x=x0,y=off;g.strokeStyle=BIO.tex.grey(lum*.7);g.lineWidth=1.3;g.beginPath();g.moveTo(x,y);
   const pts=[];while(y<off+S){const nx=x+rr(-3,3),ny=y+rr(8,14);g.lineTo(nx,ny);pts.push([nx,ny]);x=nx;y=ny;}g.stroke();
   pts.forEach(p=>{for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lum*rr(.88,1.08));g.beginPath();g.ellipse(p[0]+sd*3.5,p[1]+4,1.8,8,sd*.4,0,TAU);g.fill();}});}}},[150,150,150]);
/* cherry blossom: small five-petalled flowers in dense clusters */
TX.blossom=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,9,.64);
 for(let i=0;i<260;i++){const c=BIO.tex.clPt(S,.10,.9),lum=lerp(170,250,rng()),r=rr(6,10);
  for(let p=0;p<5;p++){const a=p/5*TAU+c[2];g.fillStyle=BIO.tex.grey(lum*rr(.92,1.02));g.beginPath();g.ellipse(c[0]+Math.cos(a)*r*.6,c[1]+Math.sin(a)*r*.6,r*.55,r*.38,a,0,TAU);g.fill();}
  g.fillStyle=BIO.tex.grey(lum*.72);g.beginPath();g.arc(c[0],c[1],r*.2,0,TAU);g.fill();}},[210,210,210]);
/* a pinnate palm frond along +x */
TX.palmfrond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.19+.31*f);g.strokeStyle=BIO.tex.grey(95);g.lineWidth=3;g.beginPath();g.moveTo(3,y);g.lineTo(S-3,y+rr(-3,3));g.stroke();
  for(let x=6;x<S-4;x+=5){const t=x/S,L=lerp(30,10,Math.pow(t,1.2))*rr(.9,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(120,232,rng()));g.lineWidth=3.2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+L*.35,y+sd*L*.55,x+L*.55,y+sd*L);g.stroke();}}}},[140,140,140]);
/* a fan: a half-disc of radial ribs, base at the bottom centre (skirt palm, palmetto) */
TX.fan=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';const bx=S/2,by=S*.96,n=34;
 for(let k=0;k<n;k++){const a=-Math.PI*.5+(k/(n-1)-.5)*Math.PI*.96+rr(-.02,.02),L=S*.88*(.8+.2*Math.sin(k/(n-1)*Math.PI));
  g.strokeStyle=BIO.tex.grey(lerp(120,235,rng()));g.lineWidth=rr(3.5,6);g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(a)*L,by+Math.sin(a)*L);g.stroke();
  if(rng()<.5){g.lineWidth=1;g.strokeStyle=BIO.tex.grey(200);g.beginPath();g.moveTo(bx+Math.cos(a)*L,by+Math.sin(a)*L);g.lineTo(bx+Math.cos(a)*L*1.06+rr(-4,4),by+Math.sin(a)*L*1.06+10);g.stroke();}}   // the filaments at the tips
 g.strokeStyle=BIO.tex.grey(90);g.lineWidth=4;g.beginPath();g.moveTo(bx,by);g.lineTo(bx,by-S*.32);g.stroke();},[150,150,150]);
/* an elephant-ear: one big heart-shaped leaf, base at the bottom centre */
TX.heart=BIO.alphaTex(256,(g,S)=>{const cx=S/2;g.fillStyle=BIO.tex.grey(170);
 g.beginPath();g.moveTo(cx,S*.98);g.bezierCurveTo(S*1.02,S*.72,S*.9,S*.02,cx,S*.2);g.bezierCurveTo(S*.1,S*.02,-S*.02,S*.72,cx,S*.98);g.fill();
 g.strokeStyle=BIO.tex.grey(215);g.lineWidth=3;g.beginPath();g.moveTo(cx,S*.95);g.lineTo(cx,S*.24);g.stroke();
 g.lineWidth=1.6;for(let k=0;k<7;k++){const y=lerp(S*.85,S*.3,k/6);for(let sd=-1;sd<=1;sd+=2){g.beginPath();g.moveTo(cx,y);g.quadraticCurveTo(cx+sd*S*.18,y-S*.03,cx+sd*S*.34*Math.sin((k+1)/8*Math.PI),y-S*.1);g.stroke();}}},[160,160,160]);
/* stiff blades from the base: yucca, agave, iris, sawgrass (vertical tuft card) */
TX.spike=BIO.alphaTex(256,(g,S)=>{for(let k=0;k<20;k++){const a=-Math.PI/2+rr(-.75,.75),L=S*rr(.55,.95),w=rr(5,9),lum=lerp(110,235,rng()),x0=S/2+rr(-6,6);
 g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.moveTo(x0-w/2,S);g.lineTo(x0+Math.cos(a)*L,S+Math.sin(a)*L);g.lineTo(x0+w/2,S);g.fill();}},[150,150,150]);
/* lupin: a spike of pea-flowers over a few palmate leaves (vertical tuft card) */
TX.lupin=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<5;k++){const x0=S/2+rr(-40,40),top=S*rr(.08,.3);g.strokeStyle=BIO.tex.grey(90);g.lineWidth=3;g.beginPath();g.moveTo(x0,S);g.lineTo(x0,top);g.stroke();
  for(let y=top;y<S*.62;y+=7){const w=lerp(4,13,(y-top)/(S*.62-top));for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lerp(170,240,rng()));g.beginPath();g.ellipse(x0+sd*w*.6,y,w*.55,4,0,0,TAU);g.fill();}}}},[150,150,150]);
/* reeds, grass, fern, generic understorey, bloom, moss, beard: the kit's common set */
TX.reed=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<26;k++){const x0=S/2+rr(-16,16),a=-Math.PI/2+rr(-.28,.28),L=S*rr(.72,.98),lum=lerp(105,235,rng());
  g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(2.4,4.2);g.beginPath();g.moveTo(x0,S);g.quadraticCurveTo(x0+Math.cos(a)*L*.5,S+Math.sin(a)*L*.55,x0+Math.cos(a)*L+rr(-10,10)*Math.sign(Math.cos(a)||1),S+Math.sin(a)*L);g.stroke();
  if(rng()<.35){g.fillStyle=BIO.tex.grey(lum*.75);g.beginPath();g.ellipse(x0+Math.cos(a)*L,S+Math.sin(a)*L,3.2,12,a+Math.PI/2,0,TAU);g.fill();}}},[140,140,140]);
TX.grass=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<44;k++){const x0=S/2+rr(-20,20),a=-Math.PI/2+rr(-.5,.5),L=S*rr(.5,.95),lum=lerp(120,240,rng());
  g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(1.4,2.6);g.beginPath();g.moveTo(x0,S);g.quadraticCurveTo(x0+Math.cos(a)*L*.5,S+Math.sin(a)*L*.6,x0+Math.cos(a)*L*1.1,S+Math.sin(a)*L);g.stroke();}},[150,150,150]);
TX.frond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.2+.3*f);g.strokeStyle=BIO.tex.grey(90);g.lineWidth=3;g.beginPath();g.moveTo(4,y);g.lineTo(S-4,y+rr(-6,6));g.stroke();
  for(let x=8;x<S-6;x+=7){const t=x/S,L=lerp(28,6,Math.pow(t,1.4))*rr(.8,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(120,230,rng()));g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+L*.35,y+sd*L);g.stroke();}}}},[140,140,140]);
TX.bigfrond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.19+.31*f);g.strokeStyle=BIO.tex.grey(85);g.lineWidth=3.2;g.beginPath();g.moveTo(3,y);g.lineTo(S-3,y+rr(-4,4));g.stroke();
  for(let x=6;x<S-4;x+=5.2){const t=x/S,L=lerp(34,7,Math.pow(t,1.3))*rr(.85,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(115,225,rng()));g.lineWidth=3.4;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+L*.25,y+sd*L*.6,x+L*.45,y+sd*L);g.stroke();}}}},[140,140,140]);
TX.under=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,7,.62);
 for(let i=0;i<64;i++){const c=BIO.tex.clPt(S,.11,.70),base=c[2]+rr(-1,1),lum=lerp(100,235,i/64),n=ri(4,7);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(40,70),rr(10,16),base+(k-(n-1)/2)*.55,lum+rr(-20,15),true);}},[150,150,150]);
TX.bloom=BIO.alphaTex(128,(g,S)=>{const cx=S/2,cy=S/2;
 for(let p=0;p<5;p++){const a=p/5*TAU;g.fillStyle=BIO.tex.grey(lerp(170,235,rng()));g.beginPath();g.ellipse(cx+Math.cos(a)*S*.22,cy+Math.sin(a)*S*.22,S*.2,S*.13,a,0,TAU);g.fill();}
 g.fillStyle=BIO.tex.grey(120);g.beginPath();g.arc(cx,cy,S*.09,0,TAU);g.fill();g.fillStyle=BIO.tex.grey(250);g.beginPath();g.arc(cx,cy,S*.05,0,TAU);g.fill();},[200,200,200]);
TX.moss=BIO.alphaTex(128,(g,S)=>{for(let i=0;i<260;i++){const x=S/2+(rng()-.5)*S*.96,y=S/2+(rng()-.5)*S*.96;if(Math.hypot(x-S/2,y-S/2)>S*.47)continue;
 g.fillStyle=BIO.tex.grey(lerp(110,220,rng()));g.beginPath();g.arc(x,y,rr(6,14),0,TAU);g.fill();}},[150,150,150]);
/* Spanish moss: stringy strands hanging (v=0 at the top) */
TX.beard=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<34;k++){const x0=rr(10,S-10),lum=lerp(120,225,rng());g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(1.2,2.4);
  g.beginPath();g.moveTo(x0,0);let x=x0,y=0;while(y<S*rr(.6,1)){const nx=x+rr(-9,9),ny=y+rr(10,22);g.lineTo(nx,ny);x=nx;y=ny;}g.stroke();
  for(let j=0;j<6;j++){const yy=rr(0,S*.9);g.beginPath();g.moveTo(x0+rr(-8,8),yy);g.lineTo(x0+rr(-16,16),yy+rr(6,18));g.stroke();}}},[150,150,150]);
/* needles in flat sprays -- cedar and pine pads */
TX.needle=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,10,.66);
 for(let i=0;i<140;i++){const c=BIO.tex.clPt(S,.10,.8),lum=lerp(105,235,i/140),a0=rr(0,TAU);g.strokeStyle=BIO.tex.grey(lum*rr(.88,1.05));g.lineWidth=1.6;
  for(let k=0;k<14;k++){const a=a0+rr(-1.2,1.2),L=rr(14,26);g.beginPath();g.moveTo(c[0],c[1]);g.lineTo(c[0]+Math.cos(a)*L,c[1]+Math.sin(a)*L);g.stroke();}}},[140,140,140]);
/* a forking fern (Dicranopteris): a frond that branches in pairs, along +x */
TX.forkfern=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 const arm=(x,y,a,L,dep)=>{const ex=x+Math.cos(a)*L,ey=y+Math.sin(a)*L;g.strokeStyle=BIO.tex.grey(90);g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();
  if(dep>0){for(let s=4;s<L;s+=4){const bx=x+Math.cos(a)*s,by=y+Math.sin(a)*s;for(let sd=-1;sd<=1;sd+=2){g.strokeStyle=BIO.tex.grey(lerp(140,235,rng()));g.lineWidth=2.2;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(a+sd*1.3)*9,by+Math.sin(a+sd*1.3)*9);g.stroke();}}}
  if(dep<2){arm(ex,ey,a-.6,L*.8,dep+1);arm(ex,ey,a+.6,L*.8,dep+1);}};
 arm(4,S/2,0,S*.22,0);},[150,150,150]);
/* a staghorn fern: antler-forked lobes from a round shield at the bottom centre */
TX.staghorn=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';g.lineJoin='round';
 const lobe=(x,y,a,L,w,dep)=>{const ex=x+Math.cos(a)*L,ey=y+Math.sin(a)*L;g.strokeStyle=BIO.tex.grey(lerp(150,220,rng()));g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();
  if(dep<3){lobe(ex,ey,a-rr(.35,.6),L*.72,w*.72,dep+1);lobe(ex,ey,a+rr(.35,.6),L*.72,w*.72,dep+1);}};
 for(let k=0;k<5;k++)lobe(S/2,S*.8,-Math.PI/2+(k-2)*.5,S*.2,16,0);
 g.fillStyle=BIO.tex.grey(185);g.beginPath();g.ellipse(S/2,S*.82,S*.2,S*.14,0,0,TAU);g.fill();},[160,160,160]);
SWLOW.TEX=TX;

// ---------------------------------------------------------------- TWO-TONE BARK
// A bark canvas here carries TWO things: R = the relief (grey, normalised by
// its own mean in the shader so the vertex colour is the albedo), G = a MASK
// that swaps the vertex colour for the bucket's second colour. That is how a
// madrone is red with green-white flayed patches, a manzanita red with char
// streaks, a ringbark copper with pale lenticels, a cypress cinnamon with grey
// weathered strands -- one draw call per look, species colours per vertex.
// uGain folds in the light rig: sun + hemisphere render an albedo about twice
// as bright as it is written, so a designer's colour is multiplied down here
// and the palettes above stay what the bark should look like. uGloss adds a
// sun highlight (manzanita, lacquered mangrove, the ringbark's sheen).
function wrap9(W,H,fn){for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++)fn(i*W,j*H);}
function blob(g,x,y,w,h,wob,sl){g.beginPath();const n=14,sd=w*1.7+h*.31;for(let k=0;k<=n;k++){const a=k/n*TAU,r=1+wob*(h3(sd,k%n,7)-.5)*2;   // shape from its size only: every wrapped copy is identical
 const px=Math.cos(a)*w*r,py=Math.sin(a)*h*r;const X=x+px+py*sl,Y=y+py;k?g.lineTo(X,Y):g.moveTo(X,Y);}g.closePath();g.fill();}
const PAINT={
 ember(L,M,W,H){   // smooth, twisting sheen; char streaks
  for(let i=0;i<8;i++){const x=rng()*W;L.fillStyle='rgba(190,190,190,.10)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,oy,rr(10,40),H));}
  for(let i=0;i<260;i++){const x=rng()*W,y=rng()*H,l=rng()<.5?'70,70,70':'200,200,200';L.strokeStyle='rgba('+l+','+rr(.08,.25).toFixed(2)+')';L.lineWidth=rr(.8,2);
   const len=rr(40,200),dx=rr(-10,10);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.quadraticCurveTo(x+ox+dx,y+oy+len*.5,x+ox+dx*.4,y+oy+len);L.stroke();});}
  M.fillStyle='#fff';for(let i=0;i<16;i++){const x=rng()*W,y=rng()*H,w=rr(5,26),h=rr(50,220),sl=rr(-.12,.12);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.45,sl));}
  M.strokeStyle='#fff';for(let i=0;i<30;i++){const x=rng()*W,y=rng()*H;M.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{M.beginPath();M.moveTo(x+ox,y+oy);M.lineTo(x+ox+rr(-6,6),y+oy+rr(20,70));M.stroke();});}},
 lacquer(L,M,W,H){   // smooth, faint ripples and lenticels; a little pale lichen
  for(let i=0;i<30;i++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'120,120,120':'165,165,165')+',.25)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(3,14)));}
  for(let i=0;i<90;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,.45)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(5,16),rr(1.5,3)));}
  M.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<10;i++){const x=rng()*W,y=rng()*H,r=rr(4,12);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.2,.5,0));}},
 flay(L,M,W,H){   // flame-shaped flakes peeling off red to a pale underbark (red dominant: the pale shows in flakes)
  for(let i=0;i<140;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba(110,110,110,.25)';L.lineWidth=1;wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-4,4),y+oy+rr(20,60));L.stroke();});}
  for(let i=0;i<17;i++){const x=rng()*W,y=rng()*H,w=rr(8,24),h=rr(30,100),sl=rr(-.35,.35),l=Math.round(rr(120,170));
   wrap9(W,H,(ox,oy)=>{M.fillStyle='#fff';blob(M,x+ox,y+oy,w,h,.35,sl);L.fillStyle='rgba('+l+','+l+','+l+',.6)';blob(L,x+ox,y+oy,w,h,.35,sl);
    L.strokeStyle='rgba(50,50,50,.55)';L.lineWidth=1.4;L.stroke();});}},
 mottle(L,M,W,H){   // sycamore jigsaw: rounder, more of the pale showing
  for(let i=0;i<46;i++){const x=rng()*W,y=rng()*H,w=rr(14,40),h=rr(18,60),l=Math.round(rr(115,175));
   const mf=rng()<.8?'#fff':'#888',sl=rr(-.2,.2);wrap9(W,H,(ox,oy)=>{M.fillStyle=mf;blob(M,x+ox,y+oy,w,h,.5,sl);L.fillStyle='rgba('+l+','+l+','+l+',.55)';blob(L,x+ox,y+oy,w,h,.5,sl);});}},
 ring(L,M,W,H){   // copper sheen banded with pale lenticels; peeling curls
  for(let i=0;i<20;i++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'125,125,125':'175,175,175')+',.3)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(4,18)));}
  for(let i=0;i<150;i++){const x=rng()*W,y=rng()*H,w=rr(10,46),h=rr(2,4);
   wrap9(W,H,(ox,oy)=>{L.fillStyle='rgba(70,70,70,.6)';L.fillRect(x+ox,y+oy+h*.6,w,h*.6);M.fillStyle='#fff';M.fillRect(x+ox,y+oy,w,h);});}
  for(let i=0;i<7;i++){const x=rng()*W,y=rng()*H,w=rr(20,60),h=rr(8,20);wrap9(W,H,(ox,oy)=>{M.fillStyle='rgba(255,255,255,.85)';blob(M,x+ox,y+oy,w,h,.6,0);L.fillStyle='rgba(60,60,60,.5)';L.fillRect(x+ox-w*.8,y+oy+h,w*1.6,2.5);});}},
 furrow(L,M,W,H){   // deep furrows, blocky ridges; grey-green lichen
  for(let i=0;i<34;i++){const x=rng()*W;L.strokeStyle='rgba(40,40,40,.75)';L.lineWidth=rr(3,7);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+rr(-14,14),oy+H*.33,x+ox+rr(-14,14),oy+H*.66,x+ox+rr(-6,6),oy+H+10);L.stroke();});}
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(45,45,45,.6)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(8,22),rr(2,4)));}
  for(let i=0;i<40;i++){const x=rng()*W;L.strokeStyle='rgba(185,185,185,.35)';L.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.lineTo(x+ox+rr(-8,8),oy+H);L.stroke();});}
  M.fillStyle='rgba(255,255,255,.18)';for(let i=0;i<6;i++){const x=rng()*W,y=rng()*H,r=rr(18,40);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.6,.6,0));}},   // lichen: a faint stain, never a pattern
 stringy(L,M,W,H){   // cypress: long fibres, weathered grey strands over cinnamon
  for(let i=0;i<300;i++){const x=rng()*W,d=rng();L.strokeStyle='rgba('+(d<.5?'55,55,55':'170,170,170')+','+(.3+rng()*.5).toFixed(2)+')';L.lineWidth=d<.5?rr(2,5):rr(1,2);
   wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+rr(-10,10),oy+H*.33,x+ox+rr(-10,10),oy+H*.66,x+ox+rr(-8,8),oy+H+10);L.stroke();});}
  M.fillStyle='#fff';for(let i=0;i<50;i++){const x=rng()*W,y=rng()*H,w=rr(2,7),h=rr(60,300);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.3,rr(-.03,.03)));}},
 pale(L,M,W,H){   // smooth pale, horizontal lenticels, a bloom of green algae
  L.fillStyle='#9c9c9c';L.fillRect(0,0,W,H);
  for(let k=0;k<22;k++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'130,130,130':'175,175,175')+',.35)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(4,22)));}
  for(let i=0;i<120;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,'+(.3+rng()*.4).toFixed(2)+')';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(6,24),rr(1.5,3.5)));}
  M.fillStyle='rgba(255,255,255,.3)';for(let i=0;i<9;i++){const x=rng()*W,y=rng()*H,r=rr(14,40);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.8,.6,0));}},   // algae: a faint wash, not camouflage
 cork(L,M,W,H){   // thick spongy cork: a network of deep fissures with red-brown in their floors
  L.fillStyle='#9a9a9a';L.fillRect(0,0,W,H);
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H,r=rr(12,30),l=Math.round(rr(130,185));L.fillStyle='rgba('+l+','+l+','+l+',.5)';wrap9(W,H,(ox,oy)=>blob(L,x+ox,y+oy,r,r*1.4,.4,0));}
  const P=[];for(let i=0;i<34;i++)P.push([rng()*W,rng()*H]);
  for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const a=P[i],b=P[j];if(Math.hypot(a[0]-b[0],a[1]-b[1])>90||rng()<.4)continue;const lw=rr(4,9);
   wrap9(W,H,(ox,oy)=>{L.strokeStyle='rgba(35,35,35,.85)';L.lineWidth=lw;L.beginPath();L.moveTo(a[0]+ox,a[1]+oy);L.quadraticCurveTo((a[0]+b[0])/2+ox+rr(-10,10),(a[1]+b[1])/2+oy+rr(-10,10),b[0]+ox,b[1]+oy);L.stroke();
    M.strokeStyle='#fff';M.lineWidth=lw*.55;M.beginPath();M.moveTo(a[0]+ox,a[1]+oy);M.lineTo(b[0]+ox,b[1]+oy);M.stroke();});}},
 strip(L,M,W,H){   // ribbon gum: long vertical flames of red over white, some slanted
  for(let i=0;i<120;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba(110,110,110,.2)';L.lineWidth=1;wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-2,2),y+oy+rr(30,90));L.stroke();});}
  for(let i=0;i<22;i++){const x=rng()*W,y=rng()*H,w=rr(6,20),h=rr(120,300),sl=rr(-.12,.12),l=Math.round(rr(150,185));
   wrap9(W,H,(ox,oy)=>{M.fillStyle='#fff';blob(M,x+ox,y+oy,w,h,.3,sl);L.fillStyle='rgba('+l+','+l+','+l+',.6)';blob(L,x+ox,y+oy,w,h,.3,sl);L.strokeStyle='rgba(60,60,60,.35)';L.lineWidth=1;L.stroke();});}},
 ocelli(L,M,W,H){   // the eyed beech: smooth tan, dark ringed eyes and chevrons
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,.3)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(6,18),rr(1.5,3)));}
  const dx=42,dy=46;for(let j=-1;j<=H/dy+1;j++)for(let i=-1;i<=W/dx+1;i++){const x=i*dx+(j%2?dx/2:0)+rr(-5,5),y=j*dy+rr(-5,5),r=rr(9,15);if(rng()<.15)continue;
   M.fillStyle='#fff';M.beginPath();M.ellipse(x,y,r,r*1.15,0,0,TAU);M.fill();M.fillStyle='#000';M.beginPath();M.ellipse(x,y,r*.62,r*.72,0,0,TAU);M.fill();
   M.fillStyle='#fff';M.beginPath();M.ellipse(x,y,r*.28,r*.32,0,0,TAU);M.fill();L.fillStyle='rgba(90,90,90,.35)';L.beginPath();L.ellipse(x,y+2,r*1.05,r*1.2,0,0,TAU);L.fill();}},
 crack(L,M,W,H){   // the crimson ghost: cream bark split in a gold-orange network
  L.fillStyle='#9e9e9e';L.fillRect(0,0,W,H);
  const P=[];for(let i=0;i<40;i++)P.push([rng()*W,rng()*H]);
  for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const a=P[i],b=P[j],dd=Math.hypot(a[0]-b[0],(a[1]-b[1])*.5);if(dd>70||rng()<.35)continue;const lw=rr(2.5,6),mx=rr(-8,8),my=rr(-8,8);
   wrap9(W,H,(ox,oy)=>{M.strokeStyle='#fff';M.lineWidth=lw;M.beginPath();M.moveTo(a[0]+ox,a[1]+oy);M.quadraticCurveTo((a[0]+b[0])/2+ox+mx,(a[1]+b[1])/2+oy+my,b[0]+ox,b[1]+oy);M.stroke();
    L.strokeStyle='rgba(70,70,70,.5)';L.lineWidth=lw*.35;L.stroke();});}},
 plate(L,M,W,H){   // flatwood pine: red plates, dark fissures, pale flaking edges
  L.fillStyle='#909090';L.fillRect(0,0,W,H);
  for(let j=0;j<16;j++)for(let i=0;i<5;i++){const x=i*W/5+rr(-8,8)+(j%2?W/10:0),y=j*H/16+rr(-5,5),w=W/5*rr(.8,.98),h=H/16*rr(.9,1.6),l=Math.round(rr(125,175));
   wrap9(W,H,(ox,oy)=>{L.fillStyle='rgba('+l+','+l+','+l+',.85)';blob(L,x+ox,y+oy,w*.5,h*.5,.25,0);M.fillStyle='rgba(255,255,255,.55)';M.fillRect(x+ox-w*.45,y+oy-h*.5,w*.9,2.5);});}
  for(let i=0;i<30;i++){const x=rng()*W;L.strokeStyle='rgba(30,30,30,.7)';L.lineWidth=rr(2,4);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.lineTo(x+ox+rr(-12,12),oy+H);L.stroke();});}},
 cane(L,M,W,H){   // a cane: fine vertical striations, two nodes per tile
  for(let i=0;i<90;i++){const x=rng()*W;L.strokeStyle='rgba('+(rng()<.5?'110,110,110':'170,170,170')+',.35)';L.lineWidth=rr(1,2.5);L.beginPath();L.moveTo(x,0);L.lineTo(x,H);L.stroke();}
  [0,H/2].forEach(y=>{L.fillStyle='rgba(50,50,50,.8)';L.fillRect(0,y,W,5);L.fillRect(0,y+H-1,W,1);L.fillStyle='rgba(200,200,200,.7)';L.fillRect(0,y+5,W,4);M.fillStyle='#fff';M.fillRect(0,y-3,W,10);});M.fillRect(0,H-3,W,3);},
 fibre(L,M,W,H){   // palm trunk: leaf-base scars in a lattice, fibres between
  for(let i=0;i<300;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba('+(rng()<.5?'60,60,60':'170,170,170')+','+(.3+rng()*.4).toFixed(2)+')';L.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-6,6),y+oy+rr(14,50));L.stroke();});}
  const dx=64,dy=64;for(let j=-1;j<=H/dy+1;j++)for(let i=-1;i<=W/dx+1;i++){const x=i*dx+(j%2?dx/2:0),y=j*dy;L.strokeStyle='rgba(40,40,40,.55)';L.lineWidth=3;L.beginPath();L.moveTo(x-dx*.45,y);L.quadraticCurveTo(x,y+dy*.25,x+dx*.45,y);L.stroke();}},
};
function barkTex2(kind){const W=256,H=512,cl=document.createElement('canvas'),cm=document.createElement('canvas');cl.width=cm.width=W;cl.height=cm.height=H;
 const L=cl.getContext('2d'),M=cm.getContext('2d');L.fillStyle='#8c8c8c';L.fillRect(0,0,W,H);M.fillStyle='#000';M.fillRect(0,0,W,H);
 PAINT[kind](L,M,W,H);
 const Ld=L.getImageData(0,0,W,H).data,Md=M.getImageData(0,0,W,H).data,out=L.createImageData(W,H),o=out.data;let s=0;
 for(let i=0;i<o.length;i+=4){o[i]=Ld[i];o[i+1]=Md[i];o[i+2]=Ld[i];o[i+3]=255;s+=Ld[i];}
 const c=document.createElement('canvas');c.width=W;c.height=H;c.getContext('2d').putImageData(out,0,0);
 const t=new T3.CanvasTexture(c);t.wrapS=t.wrapT=T3.RepeatWrapping;t.anisotropy=8;t.encoding=T3.LinearEncoding;t.biomeMean=s/(W*H)/255;return t;}   // r128 textures have no userData
SWLOW.barkMat2=function(tex,key,o){o=o||{};
 const m=new T3.MeshLambertMaterial({color:0xffffff,map:tex,vertexColors:true,side:T3.DoubleSide});
 const alt=C(o.alt==null?0x808080:o.alt).convertSRGBToLinear();
 m.onBeforeCompile=sh=>{
  sh.uniforms.uAlt={value:alt};sh.uniforms.uMean={value:tex.biomeMean||.55};sh.uniforms.uGain={value:o.gain==null?.52:o.gain};sh.uniforms.uGloss={value:o.gloss||0};
  if(!BIO.SUN.value)BIO.setSun([.45,.72,-.52]);sh.uniforms.uSunDir=BIO.SUN;
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vBWP;varying vec3 vBWN;')
   .replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvBWP=(modelMatrix*vec4(transformed,1.0)).xyz;vBWN=normalize(mat3(modelMatrix)*objectNormal);');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform vec3 uAlt,uSunDir;uniform float uMean,uGain,uGloss;varying vec3 vBWP;varying vec3 vBWN;')
   .replace('#include <map_fragment>','vec4 _bt=texture2D(map,vUv);float _bl=_bt.r/uMean;float _bm=_bt.g;')
   .replace('#include <color_fragment>','diffuseColor.rgb*=mix(vColor,uAlt,_bm)*_bl*uGain;')
   .replace('#include <envmap_fragment>','{vec3 _V=normalize(cameraPosition-vBWP);vec3 _N=normalize(vBWN);if(dot(_N,_V)<0.0)_N=-_N;vec3 _H=normalize(uSunDir+_V);'+
    'float _sp=pow(max(dot(_N,_H),0.0),26.0)*step(0.0,dot(_N,uSunDir));outgoingLight+=uGloss*_sp*vec3(1.0,0.93,0.8)*(1.0-_bm*0.8)*_bl;}\n#include <envmap_fragment>');};
 m.customProgramCacheKey=function(){return'swlbark|'+key;};return m;};
const BK={ember:barkTex2('ember'),lacquer:barkTex2('lacquer'),flay:barkTex2('flay'),mottle:barkTex2('mottle'),ring:barkTex2('ring'),
 furrow:barkTex2('furrow'),strip:barkTex2('strip'),ocelli:barkTex2('ocelli'),crack:barkTex2('crack'),plate:barkTex2('plate'),stringy:barkTex2('stringy'),pale:barkTex2('pale'),cork:barkTex2('cork'),cane:barkTex2('cane'),fibre:barkTex2('fibre')};
SWLOW.BARKTEX=BK;
// greyscale canvases for the instanced small trunks and the logs/rocks (the kit's usual tint() path)
SWLOW.FIBRETEX=BIO.canvasTex(256,512,(g,w,h)=>{g.fillStyle='#8c8c8c';g.fillRect(0,0,w,h);
 for(let i=0;i<420;i++){const x=rng()*w,y=rng()*h;g.strokeStyle='rgba('+(rng()<.5?'50,50,50':'170,170,170')+','+(.3+rng()*.5).toFixed(2)+')';g.lineWidth=rr(1,3);g.beginPath();g.moveTo(x,y);g.lineTo(x+rr(-6,6),y+rr(14,60));g.stroke();}
 for(let i=0;i<60;i++){g.fillStyle='rgba(40,40,40,.5)';g.beginPath();g.ellipse(rng()*w,rng()*h,rr(5,12),rr(3,6),0,0,TAU);g.fill();}});
SWLOW.SMOOTHTEX=BIO.canvasTex(256,512,(g,w,h)=>{g.fillStyle='#8c8c8c';g.fillRect(0,0,w,h);
 for(let k=0;k<26;k++){const y=rng()*h;g.fillStyle='rgba('+(rng()<.5?'120,120,120':'165,165,165')+',.35)';g.fillRect(0,y,w,rr(4,26));}
 for(let i=0;i<110;i++){const x=rng()*w,y=rng()*h;g.fillStyle='rgba(60,60,60,'+(.4+rng()*.4).toFixed(2)+')';g.fillRect(x,y,rr(6,26),rr(1.5,3.5));}});
SWLOW.WOODTEX=BIO.canvasTex(256,256,(g,w,h)=>{g.fillStyle='#8a8074';g.fillRect(0,0,w,h);
 for(let i=0;i<220;i++){const y=rng()*h;g.strokeStyle='rgba('+(rng()<.5?'60,52,44':'170,160,150')+','+(.2+rng()*.4).toFixed(2)+')';g.lineWidth=1+rng()*2;
  g.beginPath();g.moveTo(-4,y);g.lineTo(w+4,y+rr(-5,5));g.stroke();}});
SWLOW.ROCKTEX=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=120+(fbm(x/22,y/22,3.3,3)-.5)*70+(fbm(x/4,y/4,9,1)-.5)*24+8*Math.sin(y*.35+fbm(x/40,y/40,5,2)*8);d[i]=v;d[i+1]=v*.97;d[i+2]=v*.92;d[i+3]=255;}
 g.putImageData(id,0,0);});

// ---------------------------------------------------------------- geometries local to this biome
const G={};
// a TUFT: three crossed vertical quads, origin at the base, up to y=1
G.tuft=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<3;k++){const a=k/3*Math.PI+.2,ca=Math.cos(a),sa=Math.sin(a);
  const P=[[-.5,0],[.5,0],[.5,1],[-.5,1]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,1-q[1]]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a FAN: one vertical quad, base at the origin, up to y=1, local +z its face
G.fan=function(){const pos=[],uv=[],nor=[];const P=[[-.5,0],[.5,0],[.5,1],[-.5,1]].map(q=>[q[0],q[1],0,q[0]+.5,1-q[1]]);
 [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(0,0,1);});return BIO.geo._make(pos,nor,uv);};
// a DROOPING FAN: the fan card bent in three bands so it arches out and hangs (the skirt palm's wide hanging leaves)
G.droop=function(){const pos=[],uv=[],nor=[];const R=[[0,0,0],[0,.22,.30],[0,.16,.62],[0,-.22,.84]];   // (x unused, y, z) of each row's spine: out, over, and down
 const rows=R.map((r,i)=>{const t=i/(R.length-1),w=.5*Math.min(1,.35+t*1.1);return[[-w,r[1],r[2],.5-w,1-t*1],[w,r[1],r[2],.5+w,1-t]];});
 for(let i=0;i<rows.length-1;i++){const a=rows[i][0],b=rows[i][1],c=rows[i+1][1],d=rows[i+1][0];
  [a,b,c,a,c,d].forEach(p=>{pos.push(p[0],p[1],p[2]);uv.push(p[3],p[4]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a ROSETTE: three tiers of fleshy bent leaves, vertex-coloured pale at the base (agave, bromeliad)
G.rosette=function(tiers){const pos=[],nor=[],uv=[],col=[];
 tiers=tiers||[[10,1.0,.30,.55],[8,.70,.55,.40],[6,.42,.85,.28]];
 tiers.forEach((tr,ti)=>{const n=tr[0],R=tr[1],el=tr[2],wd=tr[3];const a0=ti*.31;
  for(let k=0;k<n;k++){const a=a0+k/n*TAU,ca=Math.cos(a),sa=Math.sin(a),px=-sa,pz=ca;
   const tip=[ca*R,Math.sin(el)*R*.9+.05,sa*R],mid=[ca*R*.5,Math.sin(el)*R*.35+.04,sa*R*.5],base=[ca*.08,.02,sa*.08];
   const W=wd*R;
   const q=[[base[0]-px*W*.25,base[1],base[2]-pz*W*.25],[base[0]+px*W*.25,base[1],base[2]+pz*W*.25],[mid[0]+px*W*.5,mid[1],mid[2]+pz*W*.5],[mid[0]-px*W*.5,mid[1],mid[2]-pz*W*.5],tip];
   const nrm=[-Math.sin(el)*ca,Math.cos(el),-Math.sin(el)*sa];
   const push=(p,c)=>{pos.push(p[0],p[1],p[2]);nor.push(nrm[0],nrm[1],nrm[2]);uv.push(0,0);col.push(c,c,c);};
   push(q[0],.55);push(q[1],.55);push(q[2],.85);push(q[0],.55);push(q[2],.85);push(q[3],.85);
   push(q[3],.85);push(q[2],.85);push(q[4],1.0);}});
 return BIO.geo._make(pos,nor,uv,col);};
// a LILY PAD: a flat disc with a notch, unit radius, vertex-coloured (lighter centre)
G.pad=function(){const pos=[],nor=[],uv=[],col=[];const n=11;
 for(let k=0;k<n;k++){const a0=(k/n)*TAU*.92+.25,a1=((k+1)/n)*TAU*.92+.25;
  const r0=1+.06*Math.sin(k*3.1),r1=1+.06*Math.sin((k+1)*3.1);
  [[0,0,0,1.12],[Math.cos(a1)*r1,0,Math.sin(a1)*r1,.92],[Math.cos(a0)*r0,0,Math.sin(a0)*r0,.92]].forEach(p=>{pos.push(p[0],p[1],p[2]);nor.push(0,1,0);uv.push(0,0);col.push(p[3],p[3],p[3]);});}
 return BIO.geo._make(pos,nor,uv,col);};
// a CONE: origin at the base (cypress knees, kapok spines, mangrove pneumatophores)
G.cone=function(){const g=new T3.ConeGeometry(.5,1,6,1);g.translate(0,.5,0);return g;};
SWLOW.G=G;

// ---------------------------------------------------------------- materials
const M=SWLOW.MAT={
 bk:{
  ember:SWLOW.barkMat2(BK.ember,'ember',{alt:0x141110,gloss:.40}),
  lacquer:SWLOW.barkMat2(BK.lacquer,'lacquer',{alt:0x9a8a78,gloss:.32}),
  flay:SWLOW.barkMat2(BK.flay,'flay',{alt:0xc8d2b4,gloss:.18}),
  mottle:SWLOW.barkMat2(BK.mottle,'mottle',{alt:0xe8e6dc,gloss:.05}),
  ring:SWLOW.barkMat2(BK.ring,'ring',{alt:0xd8c498,gloss:.60}),
  furrow:SWLOW.barkMat2(BK.furrow,'furrow',{alt:0x5c5c4c,gloss:0}),
  stringy:SWLOW.barkMat2(BK.stringy,'stringy',{alt:0x9a968c,gloss:0}),
  pale:SWLOW.barkMat2(BK.pale,'pale',{alt:0x6a7a4e,gloss:.08}),
  cork:SWLOW.barkMat2(BK.cork,'cork',{alt:0x5a2a1c,gloss:0}),
  cane:SWLOW.barkMat2(BK.cane,'cane',{alt:0x4a4a26,gloss:.45}),
  fibre:SWLOW.barkMat2(BK.fibre,'fibre',{alt:0x404040,gloss:0}),
  strip:SWLOW.barkMat2(BK.strip,'strip',{alt:0xe6e6dc,gloss:.12}),
  ocelli:SWLOW.barkMat2(BK.ocelli,'ocelli',{alt:0x2a2018,gloss:.05}),
  crack:SWLOW.barkMat2(BK.crack,'crack',{alt:0xd88a2a,gloss:.15}),
  plate:SWLOW.barkMat2(BK.plate,'plate',{alt:0xc8b8a0,gloss:0})},
 wood:BIO.barkMat(SWLOW.WOODTEX),
 rock:BIO.barkMat(SWLOW.ROCKTEX),
 oakleaf:BIO.leafMat(TX.oakleaf,'swl-oakleaf',{aN:true,swayW:'1.0',swayA:.10}),
 glossy:BIO.leafMat(TX.glossy,'swl-glossy',{aN:true,swayW:'1.0',swayA:.12}),
 broad:BIO.leafMat(TX.broad,'swl-broad',{aN:true,swayW:'1.0',swayA:.14}),
 feather:BIO.leafMat(TX.feather,'swl-feather',{aN:true,swayW:'1.0',swayA:.12}),
 lance:BIO.leafMat(TX.lance,'swl-lance',{aN:true,swayW:'1.0',swayA:.16}),
 manz:BIO.leafMat(TX.manz,'swl-manz',{aN:true,swayW:'1.0',swayA:.05}),
 needle:BIO.leafMat(TX.needle,'swl-needle',{aN:true,swayW:'1.0',swayA:.08}),
 forkfern:BIO.leafMat(TX.forkfern,'swl-forkfern',{swayW:'(position.x)',swayA:.06}),
 staghorn:BIO.leafMat(TX.staghorn,'swl-staghorn',{swayW:'(position.y)',swayA:.03,alphaTest:.45}),
 pod:BIO.leafMat(null,'swl-pod',{swayW:'(-position.y)',swayA:.35,alphaTest:0,vertexColors:true}),
 blossom:BIO.leafMat(TX.blossom,'swl-blossom',{aN:true,swayW:'1.0',swayA:.10}),
 veil:BIO.leafMat(TX.willow,'swl-veil',{swayW:'(-position.y)',swayA:.10,axis:1,alphaTest:.36}),
 palmfrond:BIO.leafMat(TX.palmfrond,'swl-palmfrond',{swayW:'(position.x)',swayA:.10}),
 fan:BIO.leafMat(TX.fan,'swl-fan',{swayW:'(position.y)',swayA:.08,alphaTest:.45}),
 droop:BIO.leafMat(TX.fan,'swl-droop',{swayW:'(position.z)',swayA:.10,alphaTest:.45}),
 heart:BIO.leafMat(TX.heart,'swl-heart',{swayW:'(position.y)',swayA:.07,alphaTest:.45}),
 spike:BIO.leafMat(TX.spike,'swl-spike',{swayW:'(position.y)',swayA:.03,alphaTest:.42}),
 lupin:BIO.leafMat(TX.lupin,'swl-lupin',{swayW:'(position.y)',swayA:.08,alphaTest:.42}),
 reed:BIO.leafMat(TX.reed,'swl-reed',{swayW:'(position.y)',swayA:.11,alphaTest:.4}),
 grass:BIO.leafMat(TX.grass,'swl-grass',{swayW:'(position.y)',swayA:.12,alphaTest:.4}),
 frond:BIO.leafMat(TX.frond,'swl-frond',{swayW:'(position.x)',swayA:.07}),
 bigfrond:BIO.leafMat(TX.bigfrond,'swl-bigfrond',{swayW:'(position.x)',swayA:.09}),
 under:BIO.leafMat(TX.under,'swl-under',{swayW:'1.0',swayA:.06}),
 beard:BIO.leafMat(TX.beard,'swl-beard',{swayW:'(-position.y)',swayA:.12,axis:1,alphaTest:.35}),
 hang:BIO.leafMat(TX.under,'swl-hang',{swayW:'(-position.y)',swayA:.055,axis:1}),
 moss:BIO.leafMat(TX.moss,'swl-moss',{swayW:'1.0',swayA:.012,alphaTest:.3}),
 bloom:BIO.leafMat(TX.bloom,'swl-bloom',{swayW:'1.0',swayA:.05,alphaTest:.4}),
 rosette:BIO.leafMat(null,'swl-rosette',{swayW:'0.0',swayA:0,alphaTest:0,vertexColors:true}),
 pad:BIO.leafMat(null,'swl-pad',{swayW:'1.0',swayA:.02,alphaTest:0,vertexColors:true}),
 solid:BIO.solidMat(null,0xffffff),
};
[['ember','Ember bark (manzanita)',[.9,2.4]],['lacquer','Lacquered bark (mangrove, stripped cork)',[2,4]],['flay','Flayed bark (madrone, gum)',[2.2,4.5]],
 ['mottle','Mottled bark (sycamore)',[3,5]],['ring','Ringbark',[1.4,2.4]],['furrow','Furrowed bark (oaks, willow)',[2.4,3.4]],['stringy','Stringy bark (cypress)',[2.4,5]],
 ['pale','Pale bark (kapok, fig)',[3,5]],['strip','Ribbon bark (gum)',[2.4,6]],['ocelli','Eyed bark',[2.2,2.6]],['crack','Cracked ghost bark',[2.2,3.2]],['plate','Plated bark (pine)',[1.8,3.4]],['cork','Cork',[1.8,2.4]],['cane','Cane-palm stems',[.5,.9]],['fibre','Palm trunks',[2,3]]]
 .forEach(b=>BIO.bucket('bk_'+b[0],M.bk[b[0]],{label:b[1],uvScale:b[2]}));
BIO.bucket('wood',M.wood,{label:'Dead wood',uvScale:[3,4]});
BIO.bucket('rock',M.rock,{label:'Boulders',uvScale:[6,6]});
BIO.bucket('far',BIO.barkMat(null),{label:'Far trees (impostors)'});

// ---------------------------------------------------------------- instanced items
BIO.def('oakleaf',BIO.geo.clump(),M.oakleaf,{attrs:['aN'],label:'Oak foliage'});
BIO.def('glossy',BIO.geo.clump(),M.glossy,{attrs:['aN'],label:'Glossy foliage (fig, mangrove, madrone)'});
BIO.def('broad',BIO.geo.clump(),M.broad,{attrs:['aN'],label:'Broadleaf foliage'});
BIO.def('feather',BIO.geo.clump(),M.feather,{attrs:['aN'],label:'Cypress foliage'});
BIO.def('lance',BIO.geo.clump(),M.lance,{attrs:['aN'],label:'Gum foliage'});
BIO.def('manz',BIO.geo.clump(),M.manz,{attrs:['aN'],label:'Manzanita foliage'});
BIO.def('needle',BIO.geo.clump(),M.needle,{attrs:['aN'],label:'Needle pads (cedar, pine)'});
BIO.def('forkfern',BIO.geo.frond(3),M.forkfern,{label:'Forking ferns'});
BIO.def('staghorn',G.fan(),M.staghorn,{label:'Staghorn ferns'});
BIO.def('pod',BIO.geo.pod(),M.pod,{label:'Seed pods'});
BIO.def('pompom',new T3.IcosahedronGeometry(1,1),M.solid,{label:'Pompom cones'});
BIO.def('blossom',BIO.geo.clump(),M.blossom,{attrs:['aN'],label:'Blossom'});
BIO.def('veil',BIO.geo.ribbon(6,.45,.10),M.veil,{label:'Willow veils'});
BIO.def('palmfrond',BIO.geo.frond(4),M.palmfrond,{label:'Palm fronds'});
BIO.def('fan',G.fan(),M.fan,{label:'Fan fronds'});
BIO.def('droop',G.droop(),M.droop,{label:'Skirt-palm leaves'});
BIO.def('heart',G.fan(),M.heart,{label:'Elephant ears'});
BIO.def('spike',G.tuft(),M.spike,{label:'Blade leaves (yucca, iris, sawgrass)'});
BIO.def('lupin',G.tuft(),M.lupin,{label:'Lupins'});
BIO.def('reed',G.tuft(),M.reed,{label:'Reeds'});
BIO.def('grass',G.tuft(),M.grass,{label:'Grass'});
BIO.def('frond',BIO.geo.frond(3),M.frond,{label:'Fern fronds'});
BIO.def('bigfrond',BIO.geo.frond(4),M.bigfrond,{label:'Giant fern fronds'});
BIO.def('ucard',BIO.geo.clump(),M.under,{label:'Understorey foliage'});
BIO.def('beard',BIO.geo.ribbon(4,.6,.12),M.beard,{label:'Spanish moss'});
BIO.def('ribbon',BIO.geo.ribbon(4,.55,.18),M.hang,{label:'Hanging growth'});
BIO.def('strand',BIO.geo.ribbon(2,.4,.05),M.hang,{label:'Lianas and strands'});
BIO.def('mossmat',BIO.geo.mat(),M.moss,{label:'Moss'});
BIO.def('lobe',BIO.geo.lobe(),M.solid,{label:'Shrub lobes'});
BIO.def('bloom',BIO.geo.bloom(),M.bloom,{label:'Blooms'});
BIO.def('rosette',G.rosette(),M.rosette,{label:'Agaves'});
BIO.def('brom',G.rosette([[12,1.0,.55,.26],[9,.72,.85,.22],[6,.45,1.15,.2]]),M.rosette,{label:'Bromeliads'});
BIO.def('pad',G.pad(),M.pad,{label:'Lily pads and hyacinths'});
BIO.def('cone',G.cone(),M.solid,{label:'Knees and spines'});
BIO.def('rod',BIO.geo.rod(6),M.solid,{label:'Roots and stems'});
BIO.def('trunk',BIO.geo.trunk(8),BIO.solidMat(SWLOW.FIBRETEX),{label:'Small trunks (fibrous)'});
BIO.def('trunk2',BIO.geo.trunk(8),BIO.solidMat(SWLOW.SMOOTHTEX),{label:'Small trunks (smooth)'});
BIO.def('fungus',new T3.SphereGeometry(1,9,5,0,TAU,0,Math.PI*.5),M.solid,{label:'Bracket fungus'});
BIO.def('boulder',new T3.IcosahedronGeometry(1,1),BIO.solidMat(SWLOW.ROCKTEX),{label:'Boulders (small)'});
})();

// ==================== 55-biome-swlowlands-trees.js
// ================================================================= SOUTHWESTERN LOWLANDS — trees
// The twenty-one tree species of the lowlands, each with its own builder (a
// few share one), placed by zone from the host's climate fields (wet / tropic
// / dry / salt / flow / upland) and terrainH. The zone weights are computed
// HERE from those fields, never from the host's map: a world that binds the
// same fields gets the same zoning. The wide species are what the biome is:
// a limb here is a long sinuous tube that can run out along the ground and
// rise again (limbPts), and the crowns sit on the limbs, not on a sphere.
// Beyond the LOD spine the canopy species become blob impostors in the 'far'
// bucket; the small species thin out with distance and stop.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const SP=SWLOW.SPECIES,PAL=SWLOW.PAL,GOLD=2.399963;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
SWLOW.TREES=[];

// ---------------------------------------------------------------- zones from the fields
// Each weight 0..1. Aridity tags are honoured by which weight a species reads:
// the 'semiarid' species read med (summer-dry ground), the 'humid' ones rain,
// swamp or sub, never med's dry slopes.
const Y=(x,z)=>BIO.terrainH(x,z);
function zones(x,z){const wet=BIO.field('wet',x,z),tropic=BIO.field('tropic',x,z),dry=BIO.field('dry',x,z),salt=BIO.field('salt',x,z),flow=BIO.field('flow',x,z),up=BIO.field('upland',x,z),h=Y(x,z);
 const trop=smooth(.68,.86,tropic),fresh=1-smooth(.45,.8,salt);
 // patch fields: pine flatwoods in the subtropical plain; chaparral vs woodland in the hills
 const pineK=smooth(.54,.64,fbm(x*.0016+14,z*.0016-9,4401,2)),chapK=smooth(.46,.58,fbm(x*.0021-3,z*.0021+6,4402,2)+(.5-wet)*.6);
 return{wet,tropic,dry,salt,flow,up,h,pineK,chapK,
  rain:trop*smooth(.72,.86,wet)*fresh,
  swamp:smooth(.84,.94,wet)*smooth(3.2,1.2,h)*(1-dry)*fresh*smooth(.3,.6,tropic+.25),
  sub:(1-trop)*(1-dry)*smooth(.45,.65,wet),
  med:dry,
  mang:smooth(.25,.6,salt)*smooth(.4,.7,tropic),
  beach:smooth(.55,.9,salt)*smooth(-.2,.6,h)*(1-smooth(.4,.7,tropic)*.6),
  rip:flow*(1-smooth(.5,.8,salt))};}
SWLOW.zones=zones;

// ---------------------------------------------------------------- colour
function shade(hex,f){const c=hex.isColor?hex.clone():C(hex);if(f>=0)c.lerp(C(0xffffff),f);else c.lerp(C(0x120f0a),-f);return c;}
function bright(col,k){const c=col.isColor?col.clone():C(col);c.convertSRGBToLinear();c.r=Math.min(1,c.r*k);c.g=Math.min(1,c.g*k);c.b=Math.min(1,c.b*k);return c.convertLinearToSRGB();}
const _hsl={h:0,s:0,l:0};
function vary(hex,dh,ds,dl){const c=hex.isColor?hex.clone():C(hex);c.getHSL(_hsl);c.setHSL(((_hsl.h+rr(-dh,dh))%1+1)%1,clamp(_hsl.s+rr(-ds,ds),0,1),clamp(_hsl.l+rr(-dl,dl),.03,.97));return c;}
function texMean(tex){const im=tex&&tex.image;if(!im||!im.getContext)return[.25,.25,.25];
 const d=im.getContext('2d').getImageData(0,0,im.width,im.height).data;let r=0,g=0,b=0,n=0;
 for(let i=0;i<d.length;i+=4*13){r+=d[i];g+=d[i+1];b+=d[i+2];n++;}
 const c=C(0).setRGB(r/n/255,g/n/255,b/n/255).convertSRGBToLinear();return[c.r,c.g,c.b];}
// the sRGB tint that renders `hex` on a greyscale texture of linear mean m (the instanced small trunks, logs, rocks)
function tint(hex,m,k){const c=hex.isColor?hex.clone():C(hex);c.convertSRGBToLinear();k=k==null?1:k;
 c.setRGB(Math.min(1,c.r*k/Math.max(.02,m[0])),Math.min(1,c.g*k/Math.max(.02,m[1])),Math.min(1,c.b*k/Math.max(.02,m[2])));return c.convertLinearToSRGB();}
let MEAN=null;
function means(){if(MEAN)return MEAN;MEAN={fibre:texMean(SWLOW.FIBRETEX),smooth:texMean(SWLOW.SMOOTHTEX),wood:texMean(SWLOW.WOODTEX),rock:texMean(SWLOW.ROCKTEX)};return MEAN;}
Object.assign(SWLOW,{means,tint,bright,shade,vary});
// the two-tone bark buckets take the designer's colour as it should look (their material does the light arithmetic)
const barkC=(S,k)=>vary(C(S.bark[(k==null?ri(0,99):k)%S.bark.length]),.01,.05,.04);
// an untextured rod in a species' bark colour, a shade down for the rig
const rodCol=(hex)=>shade(vary(hex,.01,.05,.04),-.3);
const leafCol=(set,k)=>bright(vary(pick(set),.025,.10,.06),k==null?1.3:k);

// ---------------------------------------------------------------- keep-clear between trees
const HC=120,HASH={};
function hkey(x,z){return Math.floor(x/HC)+','+Math.floor(z/HC);}
function hadd(o){const R=o.r+40;for(let z=Math.floor((o.z-R)/HC);z<=Math.floor((o.z+R)/HC);z++)for(let x=Math.floor((o.x-R)/HC);x<=Math.floor((o.x+R)/HC);x++){const k=x+','+z;(HASH[k]||(HASH[k]=[])).push(o);}}
function blocked(x,z,pad){const L=HASH[hkey(x,z)];if(!L)return false;for(let i=0;i<L.length;i++){const o=L[i];if(Math.hypot(x-o.x,z-o.z)<o.r+pad)return true;}return false;}
// the floor asks only about the bole (rt); the trees ask about each other's ground (r)
function blockedTrunk(x,z,pad){const L=HASH[hkey(x,z)];if(!L)return false;for(let i=0;i<L.length;i++){const o=L[i];if(Math.hypot(x-o.x,z-o.z)<(o.rt||o.r)+pad)return true;}return false;}
SWLOW.blocked=blockedTrunk;SWLOW.blockedGround=blocked;
const clear3=(x,y,z,rad,vr)=>BIO.clearOf3(x,y,z,rad,vr);
const okPts=pts=>{for(let i=1;i<pts.length;i++)if(!clear3(pts[i].x,pts[i].y,pts[i].z,pts[i].r+1.5,pts[i].r+1.5))return false;return true;};

// ---------------------------------------------------------------- the LIMB
// A sinuous limb from o toward azimuth a at elevation el, len metres long,
// radius r0 -> r1 over n segments. sag bends it down with distance (a live
// oak's limbs run out level and droop); rise lifts the last part again; wig
// wanders it sideways. A limb that meets the ground RESTS on it -- the
// sprawl oak's limbs lie along the ground for metres and climb again.
function limbPts(o,a,el,len,r0,r1,n,sag,wig,rise){const ca=Math.cos(a),sa=Math.sin(a),ce=Math.cos(el),se=Math.sin(el),sx=-sa,sz=ca;
 const w1=rr(-1,1)*wig,w2=rr(-1,1)*wig,v1=rr(-1,1)*wig*.6,pts=[];let rested=0;
 for(let k=0;k<=n;k++){const t=k/n,hd=len*ce*t,lat=(w1*Math.sin(t*Math.PI)+w2*Math.sin(t*TAU))*len;
  let y=o.y+len*(se*t+sag*t*t)+(rise||0)*len*Math.pow(smooth(.5,1,t),2)+v1*len*Math.sin(t*TAU)*.5;
  const x=o.x+ca*hd+sx*lat,z=o.z+sa*hd+sz*lat,r=mix(r0,r1,Math.pow(t,.8));
  const gy=Y(x,z)+r*.75;if(k>0&&y<gy){y=gy;rested++;}
  pts.push({x,y,z,r});}
 pts.rested=rested;return pts;}
// a limb's direction at point i (for secondaries)
function limbDir(pts,i){const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)],dx=b.x-a.x,dz=b.z-a.z;return Math.atan2(dz,dx);}

// ---------------------------------------------------------------- foliage and epiphytes
function clumpAt(item,x,y,z,size,flat,col,cx,cy,cz,ex,ey){
 const dx=(x-cx)/ex,dy=(y-cy)/ey,dz=(z-cz)/ex,qq=Math.hypot(dx,dy,dz);
 const ao=mix(.5,1,smooth(.3,.95,qq))*mix(.8,1,smooth(-.6,.35,dy))*rr(.88,1.1);
 const nx=dx*.9+rr(-.3,.3),ny=dy*.7+.75+rr(-.15,.2),nz=dz*.9+rr(-.3,.3),nn=Math.hypot(nx,ny,nz)||1;
 BIO.put(item,[x,y,z],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[size,size*flat,size],bright(col,ao*1.3),{n:[nx/nn,ny/nn,nz/nn]});}
function frondAt(item,x,y,z,a,L,pitch,col,wid){BIO.put(item,[x,y,z],qEuler(rr(-.1,.1),-a,pitch),[L,L*rr(.85,1.05),L*(wid||rr(1.1,1.4))],col);}
// the foliage colour of a clump: the species' set, with the odd flush of bronze new growth
function crownCol(S,flush){return C(rng()<(flush||0)?pick(PAL.flush):pick(S.leaf));}
// Spanish moss off a limb point: how much depends on the species and how wet the ground is
function mossAt(p,k,wet,st,Lmax){const n=Math.round(rr(0,2.2)*k*smooth(.45,.9,wet));
 for(let i=0;i<n;i++){const L=rr(1.5,Lmax||7);BIO.put('beard',[p.x+rr(-.7,.7),p.y-(p.r||.3)*.6,p.z+rr(-.7,.7)],qEuler(0,rr(0,TAU),0),[rr(1,2.2),L,1],bright(vary(pick(PAL.mossPale),.02,.08,.06),1.02));st.moss++;}}
// a staghorn fern on a bole: a shield and antlers, facing out
function staghorn(x,y,z,a,R,s,st){const nx=Math.cos(a),nz=Math.sin(a);
 BIO.put('staghorn',[x+nx*(R+.05),y-s*.3,z+nz*(R+.05)],qFacing([nx,rr(-.1,.25),nz]),[s,s,1],leafCol(PAL.aroid,1.35));
 BIO.put('staghorn',[x+nx*(R+.1),y-s*.2,z+nz*(R+.1)],qFacing([nx,-.6,nz]),[s*.9,s*1.2,1],leafCol(PAL.aroid,1.3));st.epi++;}
// a bromeliad perched on a bough
// grey-green tank bromeliads and air plants only: a red rosette on a bough reads as a flower
// growing out of the bark, which is not how these trees flower
function brom(p,st){const R=rr(.35,.8),c=rng()<.5?vary(pick(PAL.mossPale),.02,.06,.05):vary(pick(PAL.aroid),.03,.1,.06);
 BIO.put('brom',[p.x,p.y+p.r*.8,p.z],qEuler(rr(-.2,.2),rr(0,TAU),rr(-.2,.2)),[R,R*1.1,R],bright(c,1.1));st.epi++;}
// ---------------------------------------------------------------- the crown, ON its branches
// A clump's centre sits within a third of its own size of a real branch point,
// a little above it: no foliage hangs in the air. twigs() sprouts short
// three-sided tips off a branch point where a crown needs more to carry.
function twigs(fam,S,p,a0,n,len,elLo,elHi,st,out){for(let k=0;k<n;k++){const a=a0+rr(-1.4,1.4),el=rr(elLo,elHi),L=len*rr(.7,1.2),r=Math.max(.05,(p.r||.2)*.5);
  const tip={x:p.x+Math.cos(a)*Math.cos(el)*L,y:p.y+Math.sin(el)*L,z:p.z+Math.sin(a)*Math.cos(el)*L,r:.04};
  if(!clear3(tip.x,tip.y,tip.z,1,1))continue;st.limb+=BIO.tube(fam,[{x:p.x,y:p.y,z:p.z,r},tip],barkC(S),{seg:3});out.push(tip);}}
function crownOn(item,spots,sz0,flat,colFn,T,cy,ex,ey,dens,st){let n=0;
 for(const p of spots){const m=Math.floor(dens)+(rng()<dens%1?1:0);
  for(let c=0;c<m;c++){const sz=sz0*rr(.85,1.2),a=rr(0,TAU),d=sz*.3*Math.sqrt(rng()),x=p.x+Math.cos(a)*d,z=p.z+Math.sin(a)*d,y=p.y+sz*flat*rr(.1,.35);
   if(!clear3(x,y,z,sz*.5,sz*flat*.5))continue;clumpAt(item,x,y,z,sz,flat,colFn(),T.x,cy,T.z,ex,ey);st.clumps++;n++;}}
 return n;}
// a LEADER: an upright limb from the bole to the crown's top, so the top of a crown is carried
function leader(fam,S,T,from,top,r0,st,all){const el=Math.PI/2-rr(.1,.32),len=(top-from.y)/Math.sin(el);if(len<1.5)return null;
 const pts=limbPts({x:from.x,y:from.y,z:from.z},rr(0,TAU),el,len,r0,.1,4,-.02,.05,0);if(!okPts(pts))return null;
 st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});if(all)all.push(...pts);return pts;}
// an ARCH: a vault limb, parametrised by what it does -- out to `reach`, up to `peak` metres
// over its origin at fraction pT of the way, and down to `end` metres over the origin at the tip
function archPts(o,a,reach,peak,pT,end,r0,r1,n,wig){const ca=Math.cos(a),sa=Math.sin(a),sx=-sa,sz=ca,w1=rr(-1,1)*wig,w2=rr(-1,1)*wig,pts=[];
 for(let k=0;k<=n;k++){const t=k/n,lat=(w1*Math.sin(t*Math.PI)+w2*Math.sin(t*TAU))*reach;
  const f=t<=pT?1-Math.pow(1-t/pT,2):1-(1-end/peak)*Math.pow((t-pT)/(1-pT),2);
  const x=o.x+ca*reach*t+sx*lat,z=o.z+sa*reach*t+sz*lat,r=mix(r0,r1,Math.pow(t,.8));let y=o.y+peak*f+Math.sin(t*9+w1*7)*reach*.012;
  const gy=Y(x,z)+r*.75;if(k>0&&y<gy)y=gy;pts.push({x,y,z,r});}
 return pts;}
function spread(T,pts){let s=T.crownR*.5;for(const p of pts){const d=Math.hypot(p.x-T.x,p.z-T.z);if(d>s)s=d;}return s;}
function reg(T,S){if(typeof REGISTER==='function')REGISTER({name:S.name,kind:'tree',label:S.name,x:T.x,z:T.z,y:T.y0,r:Math.max(T.spread||0,T.crownR*.6),h:T.H});}
// the bole: a lathe with a flared, lobed foot; closed at the top with a dome ring (never an open pipe)
function bole(fam,T,S,top,rb,flare,fh,lobes,seg,vs,lean){const nl=lobes||0,L=[],ti=T.seed%3;for(let k=0;k<nl;k++)L.push({a:k/nl*TAU+rr(-.3,.3),amp:rr(.5,1.1)});
 const lobeSum=ang=>{let s=0;for(const q of L){const c=Math.cos(ang-q.a);if(c>0)s+=q.amp*Math.pow(c,5);}return s;};
 const la=rr(0,TAU),lx=Math.cos(la)*(lean||0),lz=Math.sin(la)*(lean||0);
 const rAt=u=>rb*(1-.35*u)*(1+flare*Math.exp(-u*top/fh)),rings=[],step=Math.max(.8,Math.min(vs*.5,top/7));
 for(let yy=0;yy<top;yy+=(yy<fh*1.5?Math.min(step,fh*.5):step))rings.push({x:T.x+lx*yy,y:T.y0+yy,z:T.z+lz*yy,r:rAt(yy/top),yy:yy,col:barkC(S,Math.floor(yy/9)+ti)});
 const r1=rAt(1);rings.push({x:T.x+lx*top,y:T.y0+top,z:T.z+lz*top,r:r1,yy:top,col:barkC(S,1)},{x:T.x+lx*top,y:T.y0+top+r1*.8,z:T.z+lz*top,r:.05,yy:top+1,col:barkC(S,1)});
 const tris=BIO.lathe(fam,rings,seg,Math.max(1,Math.round(TAU*rb/3)),vs,(R,ang)=>R.r*(1+(nl?flare*.9*Math.exp(-R.yy/fh)*lobeSum(ang):0)+.03*Math.sin(5*ang+R.yy*.2)),
  nl?(R,ang)=>mix(1,.6+.4*clamp(lobeSum(ang),0,1),Math.exp(-R.yy/fh)):null);
 return{tris,top:{x:T.x+lx*top,y:T.y0+top,z:T.z+lz*top},rAt,lx,lz};}

// ---------------------------------------------------------------- the builders
// Each: (T, st, lv) where T={x,z,y0,sp,H,rb,crownR,seed,wet} and lv 2 near / 1 mid
const B=[];
// 5 / 14 the SPRAWL OAK (and the smaller coast oak): a short massive bole and a handful
// of enormous limbs of three habits. VAULT limbs climb steeply, arch over and come down
// at the tips: together they make the high tunnel of a live-oak avenue. SWEEP limbs run
// out low, rest on the ground and climb again. A few UPRIGHT limbs fill the top. The
// crown is carried on secondaries and twigs along all of them; Spanish moss hangs from
// every limb in the wet. An avenue oak (T.bias, the direction of the road) leans its
// vaults over the road and keeps its sweeping limbs off it.
B[5]=B[14]=B[26]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,coast=T.sp!==5,bias=T.bias;
 const hc=rr(3.5,6)*(coast?.75:1),bo=bole(fam,T,S,hc,rb,.7,1.4,ri(4,6),lv===2?12:8,3.4,bias==null?rr(0,.06):0);st.trunk+=bo.tris;
 const nL=lv===2?ri(6,9):ri(4,6),a0=bias==null?rr(0,TAU):bias,spots=[],all=[],hk=H/26;
 for(let k=0;k<nL;k++){const r=rng(),kind=r<(coast?.5:.6)?'vault':r<(coast?.68:.84)?'sweep':'up';
  let a=a0+k*GOLD+rr(-.25,.25);
  if(bias!=null){if(kind==='vault'&&rng()<.6)a=bias+rr(-.75,.75);if(kind==='sweep')a=bias+Math.PI+rr(-1.2,1.2);}
  const r0=rb*rr(.42,.58),o={x:bo.top.x+Math.cos(a)*rb*.45,y:T.y0+hc*rr(.75,1),z:bo.top.z+Math.sin(a)*rb*.45},n=lv===2?10:6;let pts;
  // an avenue oak keeps its vault tips high (the tunnel stays open to a rider); a wild one lets them come down
  if(kind==='vault')pts=archPts(o,a,T.crownR*rr(.8,1.05),rr(8,12.5)*hk*(coast?.75:1),rr(.38,.55),bias!=null?rr(5,9):rr(-2.5,3),r0,.14,n,.09);
  else if(kind==='sweep'){const rise=rng()<S.touch*1.6?rr(.25,.45):rr(0,.1);pts=limbPts(o,a,rr(.15,.35),T.crownR*rr(.7,.95),r0,.14,n,-rr(.7,1.0),.09,rise);}
  else pts=limbPts(o,a,rr(1.0,1.25),T.crownR*rr(.4,.55),r0*.8,.14,Math.max(4,n-3),-rr(.05,.15),.08,0);
  if(!okPts(pts))continue;
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?(r0>.9?8:6):5,cap:true});all.push(...pts);st.limbs++;
  // secondaries out and a little up off the limb, twigs off those: the crown sits on them
  for(let i=2;i<pts.length;i+=lv===2?1:2){const p=pts[i],t=i/(pts.length-1),ad=limbDir(pts,i)+(rng()<.5?-1:1)*rr(.5,1.3),len2=Math.min(9,T.crownR*rr(.13,.22)*(1.2-t*.4));
   const sp=limbPts({x:p.x,y:p.y+p.r*.4,z:p.z},ad,rr(-.05,.55),len2,Math.max(.1,p.r*.55),.06,3,-.3,.14,.08);
   if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});
   spots.push(sp[1],sp[2],sp[3]);if(lv===2&&i%2)twigs(fam,S,sp[3],ad,2,len2*.4,.05,.8,st,spots);
   if(lv>=1&&i%2)mossAt(sp[2],S.moss*.7,T.wet,st,coast?3:7);}
  for(let i=3;i<pts.length;i+=2){spots.push(pts[i]);if(lv>=1)mossAt(pts[i],S.moss*.6,T.wet,st,coast?3:8);}
  if(lv===2&&!coast){for(let i=2;i<pts.length;i+=3){BIO.put('frond',[pts[i].x,pts[i].y+pts[i].r*.8,pts[i].z],qEuler(rr(.1,.4),rr(0,TAU),0),[rr(.8,1.5),.8,1],leafCol(PAL.fern,1.5));}}}   // resurrection fern and bromeliads on the limbs
 // leaders carry the top of the crown to H
 for(let k=0;k<(lv===2?2:1);k++){const L=leader(fam,S,T,{x:bo.top.x,y:T.y0+hc,z:bo.top.z},T.y0+H-2.5,rb*.4,st,all);if(L){spots.push(L[2],L[3],L[4]);if(lv===2)twigs(fam,S,L[4],rr(0,TAU),3,4,-.1,.5,st,spots);}}
 const cy=T.y0+H*.72,ex=T.crownR,ey=H*.35,sz0=coast?rr(6,8):rr(7,9.5);
 if(!crownOn('oakleaf',spots,sz0,.58,()=>crownCol(S,.015),T,cy,ex,ey,lv===2?1.3:.8,st)){clumpAt('oakleaf',bo.top.x,T.y0+hc+2,bo.top.z,sz0,.55,crownCol(S),T.x,cy,T.z,ex,ey);st.clumps++;}
 if(lv===2&&!coast&&T.wet>.6&&rng()<.6){const a=rr(0,TAU);staghorn(T.x,T.y0+hc*.7,T.z,a,bo.rAt(.7),rr(1.2,2),st);}
 T.spread=spread(T,all);reg(T,S);};
// 6 the PILLAR FIG: a fused, fluted bole, level limbs, and roots dropping from the
// limbs to the ground to become new trunks -- one tree that is a grove
B[6]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.3,.42),bo=bole(fam,T,S,hc,rb,1.1,2.2,ri(6,9),lv===2?14:9,3.6,0);st.trunk+=bo.tris;
 const nL=lv===2?ri(7,10):ri(5,6),a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.25,.25),el=rr(.05,.32),len=T.crownR*rr(.7,1.0),r0=rb*rr(.35,.5);
  const o={x:T.x+Math.cos(a)*rb*.5,y:T.y0+hc*rr(.75,1),z:T.z+Math.sin(a)*rb*.5},pts=limbPts(o,a,el,len,r0,.14,lv===2?9:6,-rr(.1,.3),.1,rr(.05,.2));
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?7:5,cap:true});all.push(...pts);st.limbs++;
  for(let i=2;i<pts.length;i++){const p=pts[i],t=i/(pts.length-1);
   // the pillars: some thick, most thin, all straight down to the ground
   if(lv>=1&&t>.3&&rng()<(lv===2?.55:.3)){const gy=Y(p.x,p.z);if(p.y-gy>2&&BIO.clearOf(p.x,p.z,.5)){
    if(rng()<.35){const rr0=rr(.25,.8)*(1-t*.4);const col=barkC(S);st.limb+=BIO.tube(fam,[{x:p.x,y:p.y,z:p.z,r:rr0*.7},{x:p.x+rr(-.2,.2),y:mix(p.y,gy,.5),z:p.z+rr(-.2,.2),r:rr0},{x:p.x,y:gy-.4,z:p.z,r:rr0*1.35}],col,{seg:lv===2?7:5});st.pillars++;}
    else{for(let j=0,m=ri(1,3);j<m;j++){const ox=rr(-.6,.6),oz=rr(-.6,.6);BIO.beam('rod',[p.x+ox,p.y,p.z+oz],[p.x+ox,gy-.2,p.z+oz],rr(.05,.14),null,rodCol(pick(S.bark)));}st.roots++;}}}
   if(lv===2&&rng()<.3)BIO.put('strand',[p.x,p.y-p.r,p.z],qEuler(0,rr(0,TAU),0),[rr(.2,.5),rr(2,6),1],rodCol(0x8a7a5a));
   // secondaries up into the dome
   if(i%2===0){const ad=limbDir(pts,i)+rr(-1,1),len2=len*rr(.2,.35),sp=limbPts({x:p.x,y:p.y,z:p.z},ad,rr(.5,1.1),len2,Math.max(.1,p.r*.55),.06,3,-.08,.1,0);
    if(okPts(sp)){st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});spots.push(sp[2],sp[3]);if(lv===2)twigs(fam,S,sp[3],ad,2,len2*.4,.1,.9,st,spots);}}
   else spots.push(p);}}
 for(let k=0;k<(lv===2?3:1);k++){const L=leader(fam,S,T,{x:T.x+rr(-1,1),y:T.y0+hc,z:T.z+rr(-1,1)},T.y0+H-2.5,rb*.35,st,all);if(L){spots.push(L[2],L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),lv===2?4:2,T.crownR*.22,-.1,.4,st,spots);}}
 const cy=T.y0+H*.72,ex=T.crownR,ey=H*.3,sz0=rr(7.5,10),dens=lv===2?1.7:1;
 crownOn('glossy',spots,sz0,.6,()=>crownCol(S,.05),T,cy,ex,ey,dens,st);
 if(lv===2){for(let k=0,m=ri(1,3);k<m;k++)staghorn(T.x,T.y0+rr(3,hc*.9),T.z,rr(0,TAU),bo.rAt(.5),rr(1.2,2.2),st);}
 T.spread=spread(T,all);reg(T,S);};
// 2 the PARASOL KAPOK: a pale plank-buttressed column, spines, and at two thirds of its
// height a flat parasol of level boughs in two tiers, bromeliads along them
B[2]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.58,.66),bo=bole(fam,T,S,hc,rb,1.6,5.5,ri(4,6),lv===2?14:9,5,0);st.trunk+=bo.tris;
 if(lv===2){for(let k=0,m=ri(14,26);k<m;k++){const u=rr(.05,.6),a=rr(0,TAU),R=bo.rAt(u),yy=T.y0+hc*u;BIO.put('cone',[T.x+Math.cos(a)*R*.95,yy,T.z+Math.sin(a)*R*.95],qFacing([Math.cos(a),0,Math.sin(a)]).multiply(qEuler(Math.PI/2,0,0)),[.16,.35,.16],rodCol(pick(S.bark)));}}
 const spots=[],all=[],tiers=[[hc*rr(.95,1),ri(5,7),1],[H*rr(.74,.8),ri(3,5),.62]];
 tiers.forEach((tr,ti)=>{const a0=rr(0,TAU);for(let k=0;k<(lv===2?tr[1]:Math.min(4,tr[1]));k++){const a=a0+k/tr[1]*TAU+rr(-.3,.3),el=rr(.04,.22),len=T.crownR*tr[2]*rr(.75,1),r0=rb*(ti?.28:.38);
  const pts=limbPts({x:T.x+Math.cos(a)*rb*.3,y:T.y0+tr[0],z:T.z+Math.sin(a)*rb*.3},a,el,len,r0,.14,lv===2?7:5,-rr(.02,.12),.06,rr(.05,.15));
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?7:5,cap:true});all.push(...pts);st.limbs++;
  for(let i=1;i<pts.length;i++){const p=pts[i];spots.push(p);if(lv===2&&i%2)twigs(fam,S,p,a,2,len*.15,.05,.45,st,spots);
   if(i%2===0){const ad=limbDir(pts,i)+rr(-1.2,1.2),len2=len*rr(.2,.32),sp=limbPts({x:p.x,y:p.y,z:p.z},ad,rr(.15,.45),len2,Math.max(.1,p.r*.5),.06,3,-.05,.08,0);
    if(okPts(sp)){st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});spots.push(sp[2],sp[3]);}}
   if(lv===2&&rng()<.22)brom(p,st);if(lv>=1)mossAt(p,.35,T.wet,st,5);}}});
 // a leader to the top of the parasol
 const lead=limbPts({x:T.x,y:T.y0+hc,z:T.z},0,Math.PI/2-.05,H-hc,rb*.3,.15,4,0,.03,0);if(okPts(lead)){st.limb+=BIO.tube(fam,lead,barkC(S),{seg:6,cap:true});spots.push(lead[3],lead[4]);twigs(fam,S,lead[4],rr(0,TAU),4,T.crownR*.2,-.05,.3,st,spots);}
 const cy=T.y0+H*.85,ex=T.crownR,ey=H*.12,sz0=rr(8.5,12),dens=lv===2?1.4:.8;
 crownOn('broad',spots,sz0,.4,()=>crownCol(S),T,cy,ex,ey,dens,st);
 if(lv===2){for(let k=0,m=ri(3,7);k<m;k++){const a=rr(0,TAU),u=rr(.2,.9);BIO.put('strand',[T.x+Math.cos(a)*bo.rAt(u),T.y0+hc*u,T.z+Math.sin(a)*bo.rAt(u)],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(.25,.5),rr(6,18),1],leafCol(PAL.vine,1.1));}
  for(let k=0,m=ri(1,3);k<m;k++)staghorn(T.x,T.y0+rr(8,hc*.8),T.z,rr(0,TAU),bo.rAt(.3),rr(1.4,2.4),st);}
 T.spread=spread(T,all);reg(T,S);};
// 3 the RIBBON GUM: a tall straight bole striped red over white, three or four
// ascending limbs, an open hanging crown; ribbons of shed bark hanging
B[3]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.45,.58),bo=bole(fam,T,S,hc,rb,.5,2.2,0,lv===2?11:8,6,rr(0,.04));st.trunk+=bo.tris;
 const nL=lv===2?ri(3,4):3,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k/nL*TAU+rr(-.3,.3),len=(H-hc)*rr(.75,1.05),pts=limbPts(bo.top,a,rr(.95,1.25),len,rb*.55,.14,5,-.1,.07,0);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?7:5,cap:true});all.push(...pts);
  for(let i=2;i<=5;i++){const p=pts[i],ad=a+rr(-1.2,1.2),len2=len*rr(.25,.4),sp=limbPts(p,ad,rr(.4,.9),len2,Math.max(.1,p.r*.55),.05,3,-.12,.1,0);
   if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});spots.push(sp[2],sp[3]);if(lv===2)twigs(fam,S,sp[3],ad,2,len2*.35,-.3,.4,st,spots);}
  if(lv===2)for(let j=0;j<ri(1,3);j++){const p=pts[ri(0,3)];BIO.put('strand',[p.x+rr(-.3,.3),p.y,p.z+rr(-.3,.3)],qEuler(0,rr(0,TAU),0),[rr(.3,.6),rr(2,5),1],shade(C(pick(S.bark)),-.2));}}
 const cy=T.y0+H*.85,ex=T.crownR,ey=H*.2,sz0=rr(5,7);
 crownOn('lance',spots,sz0,.8,()=>crownCol(S),T,cy,ex,ey,lv===2?1.6:1,st);
 T.spread=spread(T,all);reg(T,S);};
// 1 the KNEE-CYPRESS: a flaring, fluted foot (standing in the water as often as not),
// a flat-topped crown of feathery sprays, beards of moss, knees round the base
B[1]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.62,.78),bo=bole(fam,T,S,hc,rb,1.8,2.4,ri(5,8),lv===2?12:8,5,0);st.trunk+=bo.tris;
 const nL=lv===2?ri(6,9):ri(4,5),a0=rr(0,TAU),spots=[],all=[],beards=[];
 for(let k=0;k<nL;k++){const u=mix(.72,.98,(k+rr(0,.9))/nL),a=a0+k*GOLD+rr(-.3,.3),el=rr(-.02,.3),len=T.crownR*rr(.6,1.0)*(1.1-u*.3),r0=clamp(bo.rAt(u)*.4,.2,1);
  const pts=limbPts({x:T.x+Math.cos(a)*bo.rAt(u)*.6,y:T.y0+hc*u,z:T.z+Math.sin(a)*bo.rAt(u)*.6},a,el,len,r0,.1,4,-.15,.08,.05);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  for(let s=1;s<=4;s++){spots.push(pts[s]);if(lv===2&&s>1)twigs(fam,S,pts[s],a,2,len*.2,-.1,.35,st,spots);if(s>1)beards.push(pts[s]);}}
 {const L=leader(fam,S,T,bo.top,T.y0+H*.95,bo.rAt(1)*.7,st,all);if(L){spots.push(L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),3,T.crownR*.25,-.1,.2,st,spots);}}
 const cy=T.y0+H*.85,ex=T.crownR,ey=H*.15,sz0=rr(5,7);
 crownOn('feather',spots,sz0,.42,()=>crownCol(S),T,cy,ex,ey,lv===2?1.5:.7,st);
 if(lv>=1)beards.forEach(p=>{if(lv===1&&rng()<.5)return;mossAt(p,1.6,Math.max(T.wet,.9),st,10);});
 if(lv===2){for(let k=0,m=ri(5,12);k<m;k++){const a=rr(0,TAU),d=rb*rr(1.8,5),x=T.x+Math.cos(a)*d,z=T.z+Math.sin(a)*d,y=Y(x,z);if(y<-1.8||!BIO.clearOf(x,z,.5))continue;
   const h=rr(.5,1.6)+Math.max(0,-y);BIO.put('cone',[x,y-.25,z],qEuler(rr(-.15,.15),rr(0,TAU),rr(-.15,.15)),[h*.45,h+.25,h*.45],rodCol(pick(S.bark)));st.knees++;}}
 T.spread=spread(T,all);reg(T,S);};
// 0 the LANTERN MANGROVE: a short lacquer-red trunk on a cage of arching prop roots
// in the brackish shallows, drop roots from the boughs, a wide low dome of glossy leaves
B[0]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,gy=T.y0,base=Math.max(gy,0)+rr(.8,1.8);
 const T2=Object.assign({},T,{y0:base-.2});const hc=H*rr(.3,.42),bo=bole(fam,T2,S,hc,rb,.3,1.2,0,lv===2?8:6,3,rr(0,.06));st.trunk+=bo.tris;
 const nR=lv===2?ri(10,16):6;
 for(let k=0;k<nR;k++){const a=k/nR*TAU+rr(-.25,.25),R=rr(1.6,4.2)*(rb/.6),gx=T.x+Math.cos(a)*R,gz=T.z+Math.sin(a)*R,gyy=Math.min(Y(gx,gz),base-1),h0=base+rr(.3,2.2);
  const pts=[{x:T.x+Math.cos(a)*rb*.7,y:h0,z:T.z+Math.sin(a)*rb*.7,r:rb*.24},{x:T.x+Math.cos(a)*R*.3,y:h0+rr(.8,1.8),z:T.z+Math.sin(a)*R*.3,r:rb*.2},
   {x:T.x+Math.cos(a)*R*.62,y:h0+rr(.2,1),z:T.z+Math.sin(a)*R*.62,r:rb*.17},{x:T.x+Math.cos(a)*R*.88,y:mix(h0,gyy,.6),z:T.z+Math.sin(a)*R*.88,r:rb*.15},{x:gx,y:gyy-.4,z:gz,r:rb*.14}];
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?5:4});st.roots++;}
 const nL=lv===2?ri(5,7):4,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD,len=T.crownR*rr(.6,.95),pts=limbPts(bo.top,a,rr(.3,.7),len,rb*.4,.1,5,-.35,.1,0);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  for(let i=2;i<pts.length;i++){spots.push(pts[i]);if(lv===2&&i%2)twigs(fam,S,pts[i],a,2,len*.18,0,.5,st,spots);
   if(lv===2&&rng()<.14){const p=pts[i];BIO.beam('rod',[p.x,p.y,p.z],[p.x+rr(-.2,.2),-.6,p.z+rr(-.2,.2)],rr(.025,.05),null,shade(C(0x5a2a1a),-.2));}}}
 {const L=leader(fam,S,T,bo.top,T.y0+H*.92,rb*.35,st,all);if(L){spots.push(L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),3,T.crownR*.3,-.1,.3,st,spots);}}
 const cy=base+H*.7,ex=T.crownR,ey=H*.25,sz0=rr(4,5.5);
 crownOn('glossy',spots,sz0,.6,()=>crownCol(S),T,cy,ex,ey,lv===2?1.6:1,st);
 T.spread=spread(T,all);if(lv===2)reg(T,S);};
// 4 the LACQUER CANE PALM: a clump of slender ringed stems, yellow-green below and
// lipstick red at the crownshaft, each with a few arching pinnate fronds
B[4]=function(T,st,lv){const S=SP[T.sp],H=T.H,n=lv===2?ri(4,8):2;
 for(let k=0;k<n;k++){const a=rr(0,TAU),d=k?rr(.3,1.6):0,la=a,lk=rr(.02,.12)*(k?1:.3),h=H*(k?rr(.45,1):1),x=T.x+Math.cos(a)*d,z=T.z+Math.sin(a)*d,y=Y(x,z)-.2,r=rr(.07,.13);
  const cs=C(pick(S.crownshaft)),lo=vary(C(pick(S.bark)),.02,.08,.06),pts=[];
  for(let i=0;i<=5;i++){const u=i/5;pts.push({x:x+Math.cos(la)*lk*h*u*u,y:y+h*u,z:z+Math.sin(la)*lk*h*u*u,r:r*(1-.25*u),col:u>.8?cs:(u>.62?lo.clone().lerp(cs,.5):lo)});}
  st.limb+=BIO.tube('bk_cane',pts,lo,{seg:5,cap:true});
  const e=pts[5],nf=lv===2?ri(5,7):4,a0=rr(0,TAU),hc=vary(C(pick(S.leaf)),.02,.08,.05);
  for(let f=0;f<nf;f++){const af=a0+f/nf*TAU+rr(-.2,.2);frondAt('palmfrond',e.x,e.y,e.z,af,T.crownR*rr(.8,1.1),rr(-.95,-.25),bright(hc,1.4),1.1);}
  st.fronds+=nf;}};
// 7 the VEIL WILLOW: a short leaning bole, limbs rising and arching over, and a curtain
// of hanging strands from every limb almost to the ground (golden twigs among the green)
B[7]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.25,.35),bo=bole(fam,T,S,hc,rb,.6,1.2,ri(3,5),lv===2?10:7,3,rr(.05,.2));st.trunk+=bo.tris;
 const nL=lv===2?ri(5,7):4,a0=rr(0,TAU),all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.25,.25),len=T.crownR*rr(.8,1.15),pts=limbPts(bo.top,a,rr(.75,1.1),len,rb*.45,.08,6,-rr(.6,.9),.08,0);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  const nv=lv===2?ri(16,24):7;
  for(let v=0;v<nv;v++){const i=ri(2,pts.length-1),p=pts[i],px=p.x+rr(-1.8,1.8),pz=p.z+rr(-1.8,1.8),gy=Y(px,pz),L=Math.max(1.5,(p.y-gy)*rr(.55,.95));
   const col=rng()<.08?shade(vary(C(pick(S.twig)),.02,.08,.05),-.1):leafCol(S.leaf,1.25);
   BIO.put('veil',[px,p.y+rr(0,1),pz],qEuler(0,rr(0,TAU),0),[rr(.45,.85),L*rr(.7,1),1],col);st.veils++;}
  clumpAt('lance',pts[3].x,pts[3].y+1,pts[3].z,rr(4,6),.7,C(pick(S.leaf)),T.x,T.y0+H*.8,T.z,T.crownR,H*.3);st.clumps++;}
 T.spread=spread(T,all);reg(T,S);};
// 8 / 20 the VASE: several stems from the foot, leaning out and forking (copper
// ringbark: pale-banded, peeling, sometimes in blossom; eyed beech: ringed eyes)
B[8]=B[20]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,ring=T.sp===8,bloom=ring&&rng()<.35;
 const nS=lv===2?ri(3,5):3,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nS;k++){const a=a0+k/nS*TAU+rr(-.3,.3),len=H*rr(.5,.62),o={x:T.x+Math.cos(a)*rb*.4,y:T.y0,z:T.z+Math.sin(a)*rb*.4};
  const pts=limbPts(o,a,Math.PI/2-rr(.2,.45),len,rb*rr(.7,1),rb*.5,5,-.04,.06,0);if(!okPts(pts))continue;
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?7:5});all.push(...pts);
  const e=pts[5];for(let f=0;f<(lv===2?3:2);f++){const af=a+rr(-1,1),len2=H*rr(.3,.45),sp=limbPts(e,af,rr(.5,1.1),len2,rb*.45,.07,4,-.12,.1,0);
   if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:5,cap:true});all.push(...sp);spots.push(sp[2],sp[3],sp[4]);if(lv===2)twigs(fam,S,sp[4],af,2,len2*.3,.1,.8,st,spots);}
  if(lv===2&&ring)for(let j=0;j<ri(2,4);j++){const p=pts[ri(0,4)],aa=rr(0,TAU);BIO.put('strand',[p.x+Math.cos(aa)*p.r,p.y,p.z+Math.sin(aa)*p.r],qFacing([Math.cos(aa),0,Math.sin(aa)]),[rr(.2,.45),rr(.4,1.2),1],shade(C(0xb0906a),-.1));}}   // peeling curls
 const cy=T.y0+H*.8,ex=T.crownR,ey=H*.3,sz0=rr(5,7);
 const inBloom=bloom?spots.filter(()=>rng()<.7):[],inLeaf=bloom?spots.filter(p=>inBloom.indexOf(p)<0):spots;
 crownOn('broad',inLeaf,sz0,.65,()=>crownCol(S),T,cy,ex,ey,lv===2?1.6:1,st);if(bloom)crownOn('blossom',inBloom,sz0,.65,()=>C(pick(PAL.blossom)),T,cy,ex,ey,lv===2?1.6:1,st);
 T.spread=spread(T,all);reg(T,S);};
// 9 / 11 the BROADLEAF: a leaning bole and sinuous limbs (ghost sycamore: mottled
// white; flayed madrone: red over green-white, cream panicles, red berries)
B[9]=B[11]=B[24]=B[25]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,mad=T.sp===11,sprawl=mad&&rng()<.3;
 const hc=H*(sprawl?rr(.15,.25):rr(.32,.45)),bo=bole(fam,T,S,hc,rb,.5,1.5,0,lv===2?10:7,4,sprawl?rr(.25,.45):rr(.04,.18));st.trunk+=bo.tris;
 const nL=lv===2?ri(4,6):3,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.3,.3),len=T.crownR*rr(.65,1.0)*(sprawl?1.2:1),el=sprawl?rr(.1,.5):rr(.45,.9);
  const pts=limbPts(bo.top,a,el,len,rb*.5,.1,6,-rr(.1,.35),.12,sprawl?rr(.2,.4):.05);if(!okPts(pts))continue;
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?6:5,cap:true});all.push(...pts);
  for(let i=2;i<pts.length;i+=lv===2?1:2){const p=pts[i],len2=len*rr(.22,.36),sp=limbPts(p,limbDir(pts,i)+rr(-1,1),rr(.3,.9),len2,Math.max(.08,p.r*.55),.05,3,-.1,.12,0);
   if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});spots.push(sp[2],sp[3]);if(lv===2)twigs(fam,S,sp[3],limbDir(pts,i),2,len2*.35,.1,.7,st,spots);}}
 if(!sprawl){const L=leader(fam,S,T,bo.top,T.y0+H*.92,rb*.4,st,all);if(L){spots.push(L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),3,T.crownR*.25,-.1,.4,st,spots);}}
 const cy=T.y0+H*.72,ex=T.crownR,ey=H*.3,sz0=mad?rr(5.5,7):rr(6.5,8.5),item=(mad||T.sp===24)?'glossy':'broad';
 crownOn(item,spots,sz0,.62,()=>crownCol(S,mad?.06:0),T,cy,ex,ey,lv===2?1.6:1,st);
 // the madrone's cream panicles and red berries, at the branch tips
 if(mad&&lv===2)spots.forEach(p=>{if(rng()>.22)return;const fl=rng()<.55,col=C(pick(fl?PAL.cream:PAL.berry));for(let j=0;j<ri(4,8);j++)BIO.put('bloom',[p.x+rr(-1,1)*sz0*.35,p.y+sz0*rr(.25,.5),p.z+rr(-1,1)*sz0*.35],qEuler(rr(-.4,.4),rr(0,TAU),rr(-.4,.4)),fl?rr(.3,.5):rr(.15,.25),col);st.blooms++;});
 T.spread=spread(T,all);reg(T,S);};
// 10 the EMBER MANZANITA: a knot of crooked stems, smooth blood-red and charred
// black, small grey-green leaves, urn flowers and red berries
B[10]=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,n=lv===2?ri(4,7):2,spots=[],a0=rr(0,TAU),seg=lv===2?4:3,all=[];
 for(let k=0;k<n;k++){const a=a0+k/n*TAU+rr(-.4,.4),len=H*rr(.55,.85),dead=rng()<.12,col=dead?C(0x2a2420):barkC(S);
  const pts=limbPts({x:T.x+rr(-.3,.3),y:T.y0+.1,z:T.z+rr(-.3,.3)},a,rr(.8,1.35),len,rb*rr(.7,1),rb*.35,4,-.12,.16,.05);
  st.limb+=BIO.tube('bk_ember',pts,col,{seg,cap:true});all.push(...pts);
  const e=pts[4];for(let f=0;f<(lv===2?2:0);f++){const len2=len*rr(.35,.55),sp=limbPts(pts[ri(2,3)],a+rr(-1.2,1.2),rr(.5,1.1),len2,rb*.35,.03,3,-.15,.18,0);
   st.limb+=BIO.tube('bk_ember',sp,col,{seg:3});if(!dead)spots.push(sp[3]);}
  if(!dead)spots.push(e);}
 const hc=C(pick(S.leaf)),sz0=T.crownR*rr(.7,.95);
 spots.push({x:T.x,y:T.y0+H*.6,z:T.z});
 spots.forEach(p=>{clumpAt('manz',p.x,p.y+sz0*.1,p.z,sz0*rr(.8,1.15),.75,hc,T.x,T.y0+H*.7,T.z,T.crownR,H*.4);st.clumps++;
  if(lv===2&&rng()<.3){const fl=rng()<.5,col=C(fl?0xf4dce0:pick(PAL.berry));for(let j=0;j<ri(3,6);j++)BIO.put('bloom',[p.x+rr(-.6,.6),p.y+rr(-.2,.4),p.z+rr(-.6,.6)],qEuler(rr(-.4,.4),rr(0,TAU),rr(-.4,.4)),rr(.1,.2),col);}});
 T.spread=spread(T,all)+T.crownR*.3;if(lv===2&&rng()<.5)reg(T,S);};
// 12 the CORK OAK: thick grey cork, gnarled limbs, a dense dark rounded crown. Only a
// HARVESTED tree (T.stripped: a grove the host asked for) has its lower bole stripped
// to raw red-orange; a wild cork oak keeps its cork.
B[12]=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,stripped=!!T.stripped;
 const hs=stripped?rr(1.8,3.2):0,hc=rr(3,5);let tris=0;
 if(stripped){const SS=Object.assign({},S,{bark:S.stripped});tris+=bole('bk_lacquer',T,SS,hs,rb,.3,1,0,lv===2?11:8,2.5,0).tris;}
 const T2=Object.assign({},T,{y0:T.y0+hs}),bo=bole('bk_cork',T2,S,hc-hs+.5,rb*1.18,stripped?.05:.3,1,ri(3,5),lv===2?11:8,2.2,0);st.trunk+=tris+bo.tris;
 const nL=lv===2?ri(4,6):3,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.3,.3),len=T.crownR*rr(.6,.95),pts=limbPts(bo.top,a,rr(.3,.75),len,rb*.55,.1,5,-.25,.14,.08);
  if(!okPts(pts))continue;st.limb+=BIO.tube('bk_cork',pts,barkC(S),{seg:lv===2?6:5,cap:true});all.push(...pts);
  for(let i=2;i<pts.length;i++){const p=pts[i],len2=len*rr(.25,.4),sp=limbPts(p,limbDir(pts,i)+rr(-1,1),rr(.4,1),len2,Math.max(.08,p.r*.55),.05,3,-.1,.12,0);
   if(!okPts(sp))continue;st.limb+=BIO.tube('bk_cork',sp,barkC(S),{seg:4});spots.push(sp[2],sp[3],p);if(lv===2)twigs('bk_cork',S,sp[3],limbDir(pts,i),2,len2*.4,.1,.8,st,spots);}}
 {const L=leader('bk_cork',S,T,bo.top,T.y0+H*.9,rb*.45,st,all);if(L){spots.push(L[3],L[4]);twigs('bk_cork',S,L[4],rr(0,TAU),3,T.crownR*.3,-.1,.4,st,spots);}}
 const cy=T.y0+H*.7,ex=T.crownR,ey=H*.35,sz0=rr(5.5,7.5);
 crownOn('oakleaf',spots,sz0,.7,()=>crownCol(S),T,cy,ex,ey,lv===2?1.6:1,st);
 T.spread=spread(T,all);reg(T,S);};
// 13 the SKIRT PALM: short and stout, a skirt of dead leaves, and a head of wide
// fan leaves arching out and hanging (a quarter of them the silver-blue kind)
B[13]=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,la=rr(0,TAU),lk=rr(0,.12),blue=rng()<.25;
 const pts=[];for(let i=0;i<=4;i++){const u=i/4;pts.push({x:T.x+Math.cos(la)*lk*H*u*u,y:T.y0+H*u,z:T.z+Math.sin(la)*lk*H*u*u,r:rb*(1+.35*Math.exp(-u*6))*(1-.12*u)});}
 st.trunk+=BIO.tube('bk_fibre',pts,barkC(S),{seg:lv===2?9:6});
 const e=pts[4],set=blue?PAL.palm.slice(4):PAL.palm.slice(0,4),hc=vary(C(pick(set)),.02,.06,.05);
 // the skirt
 for(let k=0,m=lv===2?ri(14,24):8;k<m;k++){const a=rr(0,TAU),L=H*rr(.25,.6);BIO.put('ribbon',[e.x+Math.cos(a)*rb*1.05,e.y-.2,e.z+Math.sin(a)*rb*1.05],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(1,1.8),L,1],bright(vary(C(0x9a8462),.02,.08,.08),1.1));}
 // the leaves: two tiers of drooping fans, a few upright spears in the middle
 const nf=lv===2?ri(16,24):10,a0=rr(0,TAU);
 for(let k=0;k<nf;k++){const a=a0+k*GOLD,up=k%2===0,L=T.crownR*rr(.85,1.15),yaw=Math.atan2(Math.cos(a),Math.sin(a));
  BIO.put('droop',[e.x,e.y+(up?.3:-.1),e.z],qEuler(up?rr(-.55,-.15):rr(.05,.45),yaw,rr(-.1,.1)),[L*.95,L*.8,L],bright(vary(hc,.02,.05,.05),1.4));}
 for(let k=0;k<(lv===2?4:2);k++){const a=rr(0,TAU);BIO.put('fan',[e.x,e.y+.2,e.z],qEuler(rr(-.3,-.05),Math.atan2(Math.cos(a),Math.sin(a)),0),[T.crownR*.5,T.crownR*.6,1],bright(shade(hc,.1),1.4));}
 if(lv===2&&rng()<.35)for(let k=0;k<ri(2,4);k++){const a=rr(0,TAU);BIO.put('strand',[e.x+Math.cos(a)*1.2,e.y,e.z+Math.sin(a)*1.2],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(.3,.6),rr(2,3.5),1],C(pick(PAL.cream)));}
 st.fronds+=nf;};
// 15 the POMPOM CYCAD: a shaggy trunk forking into a few arms, a stiff frond crown on
// each, and over each crown a red pompom on a stalk
B[15]=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,hf=H*rr(.3,.5);
 const trunk=[{x:T.x,y:T.y0-.2,z:T.z,r:rb*1.3},{x:T.x,y:T.y0+hf*.5,z:T.z,r:rb},{x:T.x,y:T.y0+hf,z:T.z,r:rb*.9}];
 st.trunk+=BIO.tube('bk_fibre',trunk,barkC(S),{seg:lv===2?8:6});
 const n=ri(2,4),a0=rr(0,TAU);
 for(let k=0;k<n;k++){const a=a0+k/n*TAU+rr(-.3,.3),arm=limbPts(trunk[2],a,rr(.8,1.2),(H-hf)*rr(.8,1.1),rb*.7,rb*.55,4,-.05,.06,.15);
  st.limb+=BIO.tube('bk_fibre',arm,barkC(S),{seg:6,cap:true});const e=arm[4],hc=vary(C(pick(S.leaf)),.02,.08,.05),nf=lv===2?ri(10,16):7,f0=rr(0,TAU);
  for(let f=0;f<nf;f++)frondAt('palmfrond',e.x,e.y,e.z,f0+f/nf*TAU+rr(-.2,.2),T.crownR*rr(.8,1.1),rr(-.9,-.1),bright(hc,1.35),.8);
  const sh=rr(1,2.2);BIO.beam('rod',[e.x,e.y,e.z],[e.x,e.y+sh,e.z],.05,.04,rodCol(0x5a6a3a));
  BIO.put('pompom',[e.x,e.y+sh+.35,e.z],qEuler(0,rr(0,TAU),0),[rr(.4,.6),rr(.45,.7),rr(.4,.6)],bright(C(pick(S.bloom)),.8));
  if(lv===2)for(let j=0;j<ri(3,6);j++){const aa=rr(0,TAU);BIO.put('ribbon',[e.x+Math.cos(aa)*rb*.6,e.y-.3,e.z+Math.sin(aa)*rb*.6],qFacing([Math.cos(aa),0,Math.sin(aa)]),[rr(.6,1),rr(1,2.5),1],bright(C(0x8a7458),1.05));}
  st.fronds+=nf;}};
// 16 / 18 the TIERED tree: a column carrying level limbs in tiers, each limb bearing flat
// pads, the lowest tiers widest (tier cedar: blue-green needles; crimson ghost: cream
// bark cracked with gold, pads of crimson leaves)
B[16]=B[18]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,crim=T.sp===18;
 const bo=bole(fam,T,S,H*.88,rb,.5,1.6,crim?0:ri(3,5),lv===2?10:7,4,rr(0,.05));st.trunk+=bo.tris;
 const nT=ri(S.tiers[0],S.tiers[1]),all=[],hc=C(pick(S.leaf));
 for(let t=0;t<nT;t++){const f=t/(nT-1||1),yy=T.y0+H*mix(crim?.35:.28,.9,f),nL=lv===2?ri(3,5):3,a0=rr(0,TAU);
  for(let k=0;k<nL;k++){const a=a0+k/nL*TAU+rr(-.4,.4),len=T.crownR*mix(1,.4,Math.pow(f,1.2))*rr(.7,1),pts=limbPts({x:T.x+bo.lx*(yy-T.y0),y:yy,z:T.z+bo.lz*(yy-T.y0)},a,rr(-.02,.18),len,rb*mix(.45,.25,f),.08,4,-.06,.08,.1);
   if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?5:4,cap:true});all.push(...pts);
   for(let i=1;i<pts.length;i++){const p=pts[i],sz=Math.max(4,len*rr(.38,.55))*(crim?1.15:1);if(!clear3(p.x,p.y+1,p.z,sz*.5,sz*.2))continue;
    for(let c=0;c<(lv===2?3:1);c++)clumpAt(S.item,p.x+rr(-1,1)*sz*.3,p.y+sz*rr(.05,.2),p.z+rr(-1,1)*sz*.3,sz*rr(.85,1.15),crim?.32:.26,crim?C(pick(S.leaf)):hc,T.x,p.y-1,T.z,T.crownR,H*.15);st.clumps+=lv===2?2:1;}}}
 clumpAt(S.item,bo.top.x,T.y0+H*.95,bo.top.z,T.crownR*.3,.35,hc,T.x,T.y0+H*.8,T.z,T.crownR,H*.2);st.clumps++;
 T.spread=spread(T,all);reg(T,S);};
// 17 the FLATWOOD PINE: a tall straight red-plated pole, a few stubs, a small crown of needle pads
B[17]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const bo=bole(fam,T,S,H*.92,rb,.25,1.2,0,lv===2?7:5,4,rr(0,.02));st.trunk+=bo.tris;
 const n=lv===2?ri(5,7):3,a0=rr(0,TAU);
 for(let k=0;k<n;k++){const a=a0+k*GOLD,yy=T.y0+H*rr(.68,.9),len=T.crownR*rr(.6,1),pts=limbPts({x:T.x+bo.lx*(yy-T.y0),y:yy,z:T.z+bo.lz*(yy-T.y0)},a,rr(.1,.5),len,rb*.25,.06,3,-.1,.1,.2);
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:4,cap:true});
  for(let i=1;i<=3;i++)clumpAt('needle',pts[i].x,pts[i].y+.6,pts[i].z,rr(3.4,4.6),.6,C(pick(S.leaf)),T.x,T.y0+H*.9,T.z,T.crownR,H*.12);st.clumps+=2;}
 clumpAt('needle',bo.top.x,T.y0+H*.93,bo.top.z,rr(3,4),.8,C(pick(S.leaf)),T.x,T.y0+H*.9,T.z,T.crownR,H*.12);st.clumps++;
 if(lv===2)for(let k=0;k<ri(2,5);k++){const a=rr(0,TAU),yy=T.y0+H*rr(.3,.6);BIO.beam('rod',[T.x+bo.lx*(yy-T.y0),yy,T.z+bo.lz*(yy-T.y0)],[T.x+Math.cos(a)*rr(1,2.2),yy+rr(-.2,.4),T.z+Math.sin(a)*rr(1,2.2)],.07,.03,C(0x3a3430));}
 T.spread=T.crownR;if(lv===2)reg(T,S);};
// 19 the RATTLE-POD: a short trunk, rising limbs spread into a wide flat top of feathery
// leaves, clusters of long red pods hanging under it
B[19]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const bo=bole(fam,T,S,H*.35,rb,.4,1,0,lv===2?9:6,3,rr(.02,.12));st.trunk+=bo.tris;
 const nL=lv===2?ri(4,6):3,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.3,.3),len=T.crownR*rr(.75,1.05),pts=limbPts(bo.top,a,rr(.5,.85),len,rb*.5,.08,5,-.3,.08,.05);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  for(let i=2;i<pts.length;i++){spots.push(pts[i]);if(lv===2)twigs(fam,S,pts[i],a,1,len*.2,.3,1,st,spots);}}
 const cy=T.y0+H*.9,sz0=rr(4.5,6),hc=C(pick(S.leaf));
 crownOn('feather',spots,sz0,.3,()=>hc,T,cy,T.crownR,H*.15,lv===2?1.5:1,st);
 spots.forEach(p=>{
  if(lv>=1&&rng()<.45){const pc=C(pick(S.pod));for(let j=0,m=ri(3,7);j<m;j++){const L=rr(.9,1.6);BIO.put('pod',[p.x+rr(-.8,.8),p.y-.2,p.z+rr(-.8,.8)],qEuler(rr(-.15,.15),rr(0,TAU),rr(-.15,.15)),[L*.5,L,L*.5],bright(vary(pc,.02,.08,.06),.9));st.pods++;}}});
 T.spread=spread(T,all);reg(T,S);};

// 21 / 22 the FLOWERING PARASOL (flame parasol: scarlet; violet jacaranda: lilac): a
// short bole, limbs spreading out and low into a very wide flat dome of fine leaves,
// and the flowers where a flowering tree has them -- over the top of the crown, at the
// branch ends. The flame parasol hangs long dark pods under it.
B[21]=B[22]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb,flame=T.sp===21;
 const hc=H*rr(.25,.35),bo=bole(fam,T,S,hc,rb,.6,1.2,flame?ri(3,5):0,lv===2?10:7,3,rr(.02,.1));st.trunk+=bo.tris;
 const nL=lv===2?ri(5,7):4,a0=rr(0,TAU),spots=[],all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.25,.25),pts=archPts({x:bo.top.x+Math.cos(a)*rb*.4,y:T.y0+hc,z:bo.top.z+Math.sin(a)*rb*.4},a,T.crownR*rr(.8,1),(H-hc)*rr(.55,.8),rr(.45,.6),(H-hc)*rr(.2,.45),rb*.5,.08,lv===2?7:5,.1);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?6:5,cap:true});all.push(...pts);
  for(let i=2;i<pts.length;i++){const p=pts[i],sp=limbPts(p,limbDir(pts,i)+rr(-1.2,1.2),rr(.3,.9),T.crownR*rr(.15,.25),Math.max(.07,p.r*.55),.04,3,-.1,.12,0);
   if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:4});spots.push(sp[2],sp[3]);if(lv===2)twigs(fam,S,sp[3],a,2,2.5,.2,.9,st,spots);}}
 {const L=leader(fam,S,T,bo.top,T.y0+H*.92,rb*.4,st,all);if(L){spots.push(L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),4,T.crownR*.25,0,.4,st,spots);}}
 // the flowers take the TOP of the crown: the highest share of the branch ends
 const ys=spots.map(p=>p.y).sort((a,b)=>a-b),cut=ys[Math.floor(ys.length*(1-S.bloomK))]||1e9;
 const inBloom=spots.filter(p=>p.y>=cut&&rng()<.85),inLeaf=spots.filter(p=>inBloom.indexOf(p)<0);
 const cy=T.y0+H*.85,ex=T.crownR,ey=H*.18,sz0=rr(5,6.5);
 crownOn('feather',spots,sz0,.32,()=>C(pick(S.leaf)),T,cy,ex,ey,lv===2?1.2:.8,st);
 crownOn('blossom',inBloom,sz0*.85,.3,()=>vary(C(pick(S.flower)),.01,.05,.04),T,cy,ex,ey,lv===2?1.3:.9,st);st.blooms+=inBloom.length;
 if(flame&&lv===2)inLeaf.forEach(p=>{if(rng()>.25)return;for(let j=0,m=ri(3,6);j<m;j++){const L=rr(1.2,2);BIO.put('pod',[p.x+rr(-.8,.8),p.y-.2,p.z+rr(-.8,.8)],qEuler(rr(-.15,.15),rr(0,TAU),rr(-.15,.15)),[L*.35,L,L*.35],C(pick(S.pod)));st.pods++;}});
 T.spread=spread(T,all);reg(T,S);};
// 23 the LANTERN MAGNOLIA: a straight grey column, short limbs up its length into a
// broad dome of big glossy leaves, and at the branch ends big cream-white flowers
// held upright like lanterns
B[23]=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const bo=bole(fam,T,S,H*.8,rb,.4,1.4,0,lv===2?10:7,4,rr(0,.04));st.trunk+=bo.tris;
 const spots=[],all=[],nT=lv===2?ri(9,13):6;
 for(let k=0;k<nT;k++){const u=mix(.25,.85,k/(nT-1)),yy=T.y0+H*.8*u,a=k*GOLD+rr(-.3,.3),len=T.crownR*mix(1,.45,u)*rr(.75,1.05);
  const pts=limbPts({x:T.x+bo.lx*(yy-T.y0),y:yy,z:T.z+bo.lz*(yy-T.y0)},a,rr(.25,.7),len,rb*mix(.4,.22,u),.07,4,-.15,.1,.15);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?5:4,cap:true});all.push(...pts);spots.push(pts[2],pts[3],pts[4]);
  if(lv===2)twigs(fam,S,pts[4],a,2,len*.25,.2,.9,st,spots);}
 spots.push(bo.top);
 crownOn('glossy',spots,rr(4.5,6),.65,()=>C(pick(S.leaf)),T,T.y0+H*.6,T.crownR,H*.4,lv===2?1.4:.9,st);
 // flowers at the branch ends, on the OUTSIDE of the dome where they are seen, cupped and facing up
 // each flower on its own twig, grown from the branch end outward and up to where it shows
 if(lv>=1)spots.forEach(p=>{if(rng()>(lv===2?.6:.3))return;const s=rr(.5,.8),dx=p.x-T.x,dz=p.z-T.z,dl=Math.hypot(dx,dz)||1,o=rr(2,3),tip={x:p.x+dx/dl*o,y:p.y+rr(1.2,2.2),z:p.z+dz/dl*o,r:.035};
  st.limb+=BIO.tube(fam,[{x:p.x,y:p.y,z:p.z,r:Math.max(.05,(p.r||.1)*.6)},{x:mix(p.x,tip.x,.6),y:mix(p.y,tip.y,.45),z:mix(p.z,tip.z,.6),r:.05},tip],barkC(S),{seg:3});
  BIO.put('bloom',[tip.x,tip.y+s*.15,tip.z],qEuler(rr(-.35,.35)+Math.PI/2*.85,rr(0,TAU),rr(-.3,.3)),[s,s,s],bright(C(pick(S.flower)),1.05));st.blooms++;});
 T.spread=spread(T,all);reg(T,S);};

// ---------------------------------------------------------------- impostors (the far canopy)
// Blobs in the 'far' bucket. The wide species get flattened, overlapping blobs out
// to their real width, so the silhouette from the hills reads WIDE too.
let ICO=null;
function buildFar(T,fi,st){const K=BIO.bucket('far');if(!ICO)ICO=new T3.IcosahedronGeometry(1,1).attributes.position.array;const ip=ICO;
 const S=SP[T.sp],cheap=BIO.lodD(T.x,T.z)>2200;let tris=0;
 function vtx(x,y,z,nx,ny,nz,r,g,b){K.pos.push(x,y,z);K.nor.push(nx,ny,nz);K.uv.push(0,0);K.col.push(r,g,b);}
 function blob(x,y,z,rx,ry,colA,colB,sd){const ca=C(colA).convertSRGBToLinear(),cb=C(colB).convertSRGBToLinear(),k1=sd*7.3,k2=sd*3.1;
  for(let i=0;i<ip.length;i+=3){const dx=ip[i],dy=ip[i+1],dz=ip[i+2];
   const m=1+.20*Math.sin(dx*4.1+k1)*Math.cos(dz*3.7+k2)+.14*Math.sin(dy*6.3+k2+dx*2);
   const sh=(.50+.50*smooth(-.7,.8,dy))*(.9+.2*Math.sin(dx*9+dz*7+k1)),t=smooth(-.2,.7,dy+.3*Math.sin(dx*5+k2));
   const ny=dy*.7+.45,nl=Math.hypot(dx,ny,dz)||1;
   vtx(x+dx*rx*m,y+dy*ry*m,z+dz*rx*m,dx/nl,ny/nl,dz/nl,mix(cb.r,ca.r,t)*sh,mix(cb.g,ca.g,t)*sh,mix(cb.b,ca.b,t)*sh);}
  tris+=ip.length/9;}
 const bc=C(S.bark[fi%S.bark.length]).convertSRGBToLinear(),seg=cheap?4:6,shape={5:'wide',14:'wide',26:'wide',24:'wide',6:'wide',2:'parasol',1:'flat',16:'tier',18:'tier',17:'pine',19:'flat',7:'weep',21:'flat',22:'flat'}[T.sp]||'round';
 const top=T.y0+T.H*(shape==='wide'?.25:shape==='pine'?.9:.6),rings=[];
 [0,.06,.5,1].forEach(u=>{const y=T.y0+(top-T.y0)*u,r=Math.max(.4,T.rb*(1-.5*u)*(u<.08?1.5:1)),ring=[];for(let s=0;s<=seg;s++){const a=s/seg*TAU;ring.push([T.x+Math.cos(a)*r,y,T.z+Math.sin(a)*r,Math.cos(a),Math.sin(a)]);}rings.push(ring);});
 for(let r2=0;r2<rings.length-1;r2++)for(let s2=0;s2<seg;s2++){const A=rings[r2][s2],Bq=rings[r2][s2+1],D=rings[r2+1][s2],E=rings[r2+1][s2+1],sh=.45*(.7+.3*(r2/rings.length));
  [A,D,E,A,E,Bq].forEach(p=>vtx(p[0],p[1],p[2],p[3],.05,p[4],bc.r*sh,bc.g*sh,bc.b*sh));tris+=2;}
 const L=(S.flower&&T.sp!==23?S.flower:S.leaf).map(h=>bright(h,.85)),R=T.crownR,H=T.H,a0=(T.seed%628)/100,n=L.length;
 if(shape==='wide'){const m=cheap?3:5;blob(T.x,T.y0+H*.75,T.z,R*.55,H*.22,L[fi%n],L[(fi+2)%n],fi);
  for(let k=0;k<m;k++){const a=a0+k/m*TAU;blob(T.x+Math.cos(a)*R*.58,T.y0+H*mix(.5,.68,(k*7%5)/5),T.z+Math.sin(a)*R*.58,R*.42,H*.18,L[(k+fi)%n],L[(k+1)%n],fi+k);}}
 else if(shape==='parasol'){blob(T.x,T.y0+H*.85,T.z,R*.85,H*.09,L[fi%n],L[(fi+1)%n],fi);if(!cheap)blob(T.x,T.y0+H*.72,T.z,R*.55,H*.07,L[1%n],L[2%n],fi+3);}
 else if(shape==='tier'){for(let k=0;k<(cheap?2:3);k++)blob(T.x,T.y0+H*mix(.4,.88,k/2),T.z,R*mix(.9,.4,k/2),H*.06,L[(k+fi)%n],L[(k+1)%n],fi+k);}
 else if(shape==='pine'){blob(T.x,T.y0+H*.92,T.z,R*.8,H*.1,L[fi%n],L[(fi+1)%n],fi);}
 else if(shape==='flat'){blob(T.x,T.y0+H*.86,T.z,R*.9,H*.12,L[fi%n],L[(fi+1)%n],fi);}
 else if(shape==='weep'){blob(T.x,T.y0+H*.55,T.z,R*.85,H*.42,L[fi%n],L[(fi+1)%n],fi);}
 else{blob(T.x,T.y0+H*.72,T.z,R*.85,H*.25,L[fi%n],L[(fi+2)%n],fi);}
 K.tris+=tris;BIO.tally(tris,0,0);st.far+=tris;}

// the SMALL species far off: one 20-triangle blob in the leaf colour, so the chaparral
// and the palm groves still read at range instead of stopping at the band edge
let ICO0=null;
function buildFarSmall(T,st){const K=BIO.bucket('far');if(!ICO0)ICO0=new T3.IcosahedronGeometry(1,0).attributes.position.array;const S=SP[T.sp],ip=ICO0;
 const ca=bright(C(pick(S.leaf)),.85).convertSRGBToLinear(),cb=ca.clone().multiplyScalar(.55),R=T.crownR*.85,H=T.H,cy=T.y0+H*.62;
 for(let i=0;i<ip.length;i+=3){const dx=ip[i],dy=ip[i+1],dz=ip[i+2],t=smooth(-.5,.7,dy),ny=dy*.7+.45,nl=Math.hypot(dx,ny,dz)||1;
  K.pos.push(T.x+dx*R,cy+dy*Math.max(R*.6,H*.38),T.z+dz*R);K.nor.push(dx/nl,ny/nl,dz/nl);K.uv.push(0,0);K.col.push(mix(cb.r,ca.r,t),mix(cb.g,ca.g,t),mix(cb.b,ca.b,t));}
 const tris=ip.length/9;K.tris+=tris;BIO.tally(tris,0,0);st.far+=tris;}

// ---------------------------------------------------------------- the pass
SWLOW.buildTrees=function(R,q,opt){opt=opt||{};
 reseed(550021);q=q==null?1:q;R=R||2850;means();
 const st={trunk:0,limb:0,far:0,limbs:0,clumps:0,blooms:0,pods:0,moss:0,fronds:0,knees:0,veils:0,pillars:0,roots:0,epi:0,heroes:0,fars:0,byS:SP.map(()=>0)};
 const TREES=SWLOW.TREES;TREES.length=0;for(const k in HASH)delete HASH[k];
 const mk=(x,y,z,sp)=>{const S=SP[sp];return{x:x,z:z,y0:y-.4,sp:sp,H:rr(S.H[0],S.H[1]),rb:rr(S.rb[0],S.rb[1]),crownR:rr(S.crownR[0],S.crownR[1]),seed:ri(0,999999),wet:BIO.field('wet',x,z)};};
 // one species pass: a jittered grid over the whole disc, the zone weight as
 // acceptance; hero/mid say where it becomes an impostor (far:true) or stops.
 // inWater:[lo,hi] roots it on the bed between those heights, past the mask.
 // DENS: the showcase's overall stocking at q=1, measured against the budget (KNOWN_ISSUES);
 // the sprawl oaks are exempt -- they are what the lowlands are
 const DENS=.75;
 function pass(sp,cell,accept,opt){opt=opt||{};let n=0;const pad=opt.pad==null?4:opt.pad;
  BIO.grid(cell,0,R,(x,z,d)=>{const Z=zones(x,z);const a=accept(Z,x,z);if(a<=0)return 0;
    return a*(opt.lodK?lerp(1,BIO.lod(x,z),opt.lodK):1)*q*(opt.dens==null?DENS:opt.dens);},
   (x,y,z,d)=>{if(!opt.inWater&&y<.3)return;if(opt.inWater&&(y<opt.inWater[0]||y>opt.inWater[1]))return;
    if(blocked(x,z,pad))return;if(!BIO.clearOf(x,z,pad+2))return;
    const T=mk(x,y,z,sp),ld=BIO.lodD(x,z);T.lv=ld<opt.hero?2:(ld<opt.mid?1:0);
    if(T.lv===0&&!opt.far)return;
    TREES.push(T);hadd({x:x,z:z,r:(opt.own==null?T.rb*1.5+1:T.crownR*opt.own),rt:T.rb*1.6+.8});n++;},{patch:opt.patch==null?.5:opt.patch,patchScale:opt.patchScale||.01,noMask:!!opt.inWater,pad:1});
  return n;}
 // AVENUES (allées) first: the host may ask for rows of a species along a path, e.g. a
 // live-oak avenue down a road. {path:[[x,z],...], spacing, offset, species}. Each tree
 // knows the road's direction (T.bias) and arches over it.
 (opt.avenues||[]).forEach(av=>{const P=av.path,sp=SP.findIndex(S=>S.key===(av.species||'sprawloak')),gap=av.spacing||22,off=av.offset||13;let carry=gap*.5;
  for(let i=0;i<P.length-1;i++){const a=P[i],b=P[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]),ux=(b[0]-a[0])/L,uz=(b[1]-a[1])/L;let d=carry;
   for(;d<L;d+=gap*rr(.9,1.1))[-1,1].forEach(side=>{const o=off+rr(-.8,1.8),dj=d+rr(-2,2),x=a[0]+ux*dj-uz*side*o,z=a[1]+uz*dj+ux*side*o,y=Y(x,z);
    if(y<.3||!BIO.clearOf(x,z,6)||blocked(x,z,3))return;const T=mk(x,y,z,sp);T.bias=Math.atan2(-side*ux,side*uz);
    const ld=BIO.lodD(x,z);T.lv=ld<1100?2:ld<1700?1:0;TREES.push(T);hadd({x,z,r:T.crownR*.4,rt:T.rb*1.6+.8});st.avenue=(st.avenue||0)+1;});
   carry=d-L;}});
 // GROVES: a planted, harvested stand. {center:[x,z], r, spacing, species, stripped}.
 // Rows on a jittered square grid (a planting, not a wild stand); stripped:true marks the
 // cork oaks as harvested -- the only stripped cork in the biome.
 (opt.groves||[]).forEach(gv=>{const sp=SP.findIndex(S=>S.key===(gv.species||'corkoak')),g=gv.spacing||16,r=gv.r||60,c=gv.center,ang=gv.angle||0,ca=Math.cos(ang),sa=Math.sin(ang);
  for(let i=-Math.ceil(r/g);i<=Math.ceil(r/g);i++)for(let j=-Math.ceil(r/g);j<=Math.ceil(r/g);j++){const u=i*g+rr(-1.5,1.5),v=j*g+rr(-1.5,1.5);if(Math.hypot(u,v)>r)continue;
   const x=c[0]+u*ca-v*sa,z=c[1]+u*sa+v*ca,y=Y(x,z);if(y<.3||BIO.mask(x,z)<=0||!BIO.clearOf(x,z,4)||blocked(x,z,2))continue;
   const T=mk(x,y,z,sp);T.stripped=!!gv.stripped;T.crownR*=.8;const ld=BIO.lodD(x,z);T.lv=ld<1100?2:ld<1700?1:0;TREES.push(T);hadd({x,z,r:g*.45,rt:T.rb*1.6+.8});st.grove=(st.grove||0)+1;}});
 // the giants first: they claim their ground (own: a share of the crown radius is kept clear of other giants)
 pass(2,170,Z=>Z.rain*.55,{hero:1100,mid:1800,far:true,pad:14,own:.55,patch:.2});                          // parasol kapok
 pass(5,105,Z=>Z.sub*(1-Z.pineK)*.56*smooth(.55,.8,Z.wet),{hero:800,mid:1500,far:true,pad:12,own:.5,patch:.3,dens:1}); // sprawl oak
 pass(6,150,Z=>(Z.sub*smooth(.25,.55,Z.tropic)+Z.rain*.25)*.7,{hero:1000,mid:1600,far:true,pad:14,own:.55,patch:.3}); // pillar fig
 pass(14,90,Z=>Z.med*(1-Z.chapK)*.42*smooth(.3,.5,Z.wet+.1),{hero:900,mid:1500,far:true,pad:9,own:.45,patch:.4});   // coast oak
 pass(16,110,Z=>Z.med*smooth(.3,.6,Z.up)*.55,{hero:1000,mid:1700,far:true,pad:10,own:.45,patch:.4});              // tier cedar
 pass(18,210,Z=>(Z.sub*.35+Z.med*.4)*(1-Z.chapK*.5),{hero:1000,mid:1700,far:true,pad:8,own:.4,patch:.2});         // crimson ghost: rare
 // the bayou and the shore
 pass(0,32,Z=>Z.mang*.85,{hero:900,mid:1400,far:true,pad:2,inWater:[-1.7,.3],own:.3,patch:.6});                 // lantern mangrove
 pass(1,52,Z=>Z.swamp*.45+Z.rain*smooth(.9,.97,Z.wet)*.18,{hero:900,mid:1400,far:true,pad:5,inWater:[-1.9,3.5],own:.35,patch:.5}); // knee-cypress
 pass(3,70,Z=>Z.rain*.4+Z.sub*smooth(.3,.6,Z.tropic)*.15,{hero:900,mid:1500,far:true,pad:6,patch:.4});          // ribbon gum
 pass(4,30,Z=>Z.rain*.5+Z.swamp*.25+Z.sub*smooth(.2,.5,Z.tropic)*.12,{hero:700,mid:1100,far:true,pad:1.5,lodK:.5});   // lacquer cane palm
 // the plain
 pass(7,40,Z=>(Z.rip*.7+smooth(.9,.97,Z.wet)*smooth(4,1.5,Z.h)*.3)*(1-Z.med*.7)*(1-Z.rain*.7),{hero:900,mid:1400,far:true,pad:4,own:.35});   // veil willow
 pass(17,34,Z=>Z.sub*Z.pineK*.6,{hero:800,mid:1400,far:true,pad:2,patch:.3});                                    // flatwood pine
 pass(20,80,Z=>Z.sub*.18*smooth(.6,.8,Z.wet),{hero:900,mid:1500,far:true,pad:5,patch:.5});                        // eyed beech
 pass(8,55,Z=>Z.sub*.14+Z.med*.12*smooth(.3,.5,Z.wet),{hero:850,mid:1300,far:true,pad:3,lodK:.5,patch:.5});     // copper ringbark
 // the hills
 pass(9,48,Z=>Z.rip*(Z.med+Z.sub*.4)*.7,{hero:900,mid:1500,far:true,pad:4});                                      // ghost sycamore
 pass(11,60,Z=>Z.med*(1-Z.chapK)*.45*smooth(.28,.45,Z.wet),{hero:900,mid:1500,far:true,pad:4,patch:.5});         // flayed madrone
 pass(12,64,Z=>Z.med*(1-Z.chapK*.7)*.35,{hero:900,mid:1500,far:true,pad:4,patch:.5});                             // cork oak
 pass(19,90,Z=>Z.med*.22*(1-Z.up)+Z.sub*.03,{hero:900,mid:1500,far:true,pad:5,patch:.5});                         // rattle-pod
 pass(13,32,Z=>Z.med*(Z.rip*.7+.05)+Z.sub*.03+Z.beach*.08,{hero:1000,mid:1600,far:true,pad:2.5,lodK:.4,patch:.6});// skirt palm
 pass(24,85,Z=>(Z.sub*smooth(.25,.6,Z.tropic)+Z.rain*.15)*.55,{hero:1000,mid:1700,far:true,pad:6,own:.35,patch:.4});   // sunburn tree
 pass(25,70,Z=>Z.sub*.3*smooth(.6,.8,Z.wet)*(1-Z.pineK),{hero:1000,mid:1700,far:true,pad:5,patch:.4});                 // star gum
 pass(26,70,Z=>Z.med*(1-Z.chapK*.6)*.5*smooth(.28,.5,Z.wet+.08),{hero:1000,mid:1700,far:true,pad:6,own:.35,patch:.4}); // bay laurel
 pass(21,95,Z=>(Z.sub*smooth(.3,.6,Z.tropic)+Z.rain*.12)*.4,{hero:1000,mid:1700,far:true,pad:6,own:.4,patch:.4});   // flame parasol
 pass(22,85,Z=>Z.sub*.1+Z.med*.14*smooth(.3,.5,Z.wet),{hero:1000,mid:1600,far:true,pad:5,own:.35,patch:.45});    // violet jacaranda
 pass(23,75,Z=>Z.sub*.22*smooth(.6,.8,Z.wet)*(1-Z.pineK),{hero:1000,mid:1600,far:true,pad:5,patch:.45});          // lantern magnolia
 pass(15,60,Z=>Z.med*Z.chapK*.28,{hero:800,mid:1200,far:true,pad:2,lodK:.5,patch:.6});                            // pompom cycad
 pass(10,20,Z=>Z.med*Z.chapK*.5,{hero:600,mid:1000,far:true,pad:.8,lodK:.6,patch:.35});                          // ember manzanita
 // build
 const trisS=SP.map(()=>0),cur=()=>{const t=BIO.stats[BIO.cur||'biome'];return t?t.tris:0;};
 const SMALL={4:1,8:1,10:1,13:1,15:1};
 TREES.forEach((T,i)=>{const t0=cur();if(T.lv===0){if(SMALL[T.sp])buildFarSmall(T,st);else buildFar(T,i,st);st.fars++;}else{B[T.sp](T,st,T.lv);st.heroes++;}st.byS[T.sp]++;trisS[T.sp]+=cur()-t0;});
 return{trees:TREES.length,avenue:st.avenue||0,grove:st.grove||0,heroes:st.heroes,far:st.fars,bySpecies:SP.map((S,i)=>S.key+':'+st.byS[i]).join(' '),trisBySpecies:SP.map((S,i)=>S.key+':'+Math.round(trisS[i]/1000)+'k').join(' '),limbs:st.limbs,clumps:st.clumps,moss:st.moss,pillars:st.pillars,veils:st.veils,
  tris:{trunk:st.trunk,limbs:st.limb,far:st.far}};};
SWLOW._canopyH=function(x,z){let h=0;for(const T of SWLOW.TREES){if(Math.hypot(x-T.x,z-T.z)<Math.max(40,T.crownR))h=Math.max(h,T.y0+T.H);}return h||10;};
})();

// ==================== 60-biome-swlowlands-floor.js
// ================================================================= SOUTHWESTERN LOWLANDS — floor
// Everything under the trees, by zone, from the same climate fields the tree
// pass reads (SWLOW.zones):
//   the BEACH       sea oats and dune grass, beach vine with lilac flowers
//   the RAINFOREST  elephant ears, heliconias in red and gold, ferns and forking
//                   ferns, bromeliads on the ground, young cane palms, moss
//   the BAYOU       saw palmetto, ferns, purple flag iris, sedge, moss
//   the WATER       lily pads carpeting the still bayou, water hyacinth, duckweed,
//                   reeds in the shallows
//   the PLAIN       green glades, saw-palmetto carpets under the flatwood pines,
//                   ferns, azaleas in flower, leaf litter
//   the HILLS       chaparral (dark and red scrub, yuccas with tall flower stalks)
//                   in patches through golden grass with feather-grass tussocks,
//                   poppies, lupins, salvia, mullein spikes, sage, agaves, aloes,
//                   pincushion shrubs, sandstone and red rock
// Three LOD bands along the spine (near / mid / far) at 7 / 14 / 30 m cells.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const PAL=SWLOW.PAL,zones=SWLOW.zones,blocked=SWLOW.blocked;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
const {bright,shade,vary,tint,means}=SWLOW;
const Y=(x,z)=>BIO.terrainH(x,z);
const leafCol=(set,k,dh)=>bright(vary(pick(set),dh==null?.05:dh,.14,.07),k==null?1.3:k);
const rockTint=(set,k)=>tint(vary(pick(set||PAL.rock),.02,.06,.06),means().rock,k==null?rr(.35,.6):k);
const rodCol=(hex)=>shade(vary(hex,.02,.08,.06),rr(-.45,-.2));
const okGround=(x,z,pad)=>!blocked(x,z,pad)&&BIO.clearOf(x,z,pad);
// patch fields local to the floor
const poppyK=(x,z)=>smooth(.5,.64,fbm(x*.0045-5,z*.0045+2,3131,2));
const lupinK=(x,z)=>smooth(.52,.66,fbm(x*.0051+9,z*.0051-3,3132,2));
const dampK=(x,z)=>fbm(x*.0062+21,z*.0062+13,777,2);

// ---------------------------------------------------------------- small plants
function card(x,y,z,s,sy,col,tilt){BIO.put('ucard',[x,y,z],qEuler(rr(-(tilt||.2),tilt||.2),rr(0,TAU),rr(-(tilt||.2),tilt||.2)),[s,sy==null?s:sy,s],col);}
function tuft(item,x,y,z,h,w,col){BIO.put(item,[x,y-.05,z],qEuler(rr(-.06,.06),rr(0,TAU),rr(-.06,.06)),[w||h*.8,h,w||h*.8],col);}
function groundMoss(x,y,z,r,set){BIO.put('mossmat',[x,y+.06,z],qEuler(rr(-.06,.06),rr(0,TAU),rr(-.06,.06)),r,leafCol(set||PAL.moss,.95,.03));}
function blooms(x,y,z,r,n,set,sz,h){const c=bright(vary(pick(set),.03,.1,.08),1.15);
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=r*Math.sqrt(rng()),s=sz?rr(sz[0],sz[1]):rr(.16,.34);BIO.put('bloom',[x+Math.cos(a)*d,y+rr(.05,h==null?.4:h),z+Math.sin(a)*d],qEuler(rr(-.4,.4),rr(0,TAU),rr(-.4,.4)),s,c);}}
function frondCrown(x,y,z,Rf,n,p0,p1,col,item){const a0=rr(0,TAU);
 for(let k=0;k<n;k++){const a=a0+k/n*TAU+rr(-.25,.25),L=Rf*rr(.8,1.1);BIO.put(item||'frond',[x,y,z],qEuler(rr(-.18,.18),-a,rr(p0,p1)),[L,L*rr(.85,1.05),L*rr(1.1,1.5)],bright(col,rr(.86,1.1)));}}
function fern(x,y,z,lv,set,item){const hc=vary(pick(set||PAL.fern),.06,.14,.07);
 frondCrown(x,y-.1,z,rr(1.6,3.2)*(item==='forkfern'?1.3:1),lv===2?ri(5,7):lv===1?4:3,.05,.45,bright(hc,1.7),item);}
function giantFern(x,y,z,lv){const hc=vary(pick(PAL.fern),.05,.14,.07),R=rr(3,5);
 frondCrown(x,y-.1,z,R,lv===2?ri(6,8):4,-.02,.4,bright(hc,1.6),'bigfrond');}
function shrub(x,y,z,lv,set,k){const hc=vary(pick(set||PAL.shrub),.07,.14,.07),Rs=rr(1.2,2.8)*(k||1);
 if(lv===2){if(rng()<.6)BIO.put('lobe',[x,y-.3,z],qEuler(0,rr(0,TAU),0),[Rs,Rs*rr(.7,1),Rs],shade(vary(hc,.03,.1,.05),-.15));
  for(let i=0;i<2;i++){const a=rr(0,TAU),d=i?Rs*rr(.3,.7):0;card(x+Math.cos(a)*d,y+Rs*rr(.45,.7),z+Math.sin(a)*d,Rs*rr(1.5,1.9),Rs*rr(1.1,1.5),bright(vary(hc,.04,.1,.06),1.45),.25);}}
 else{const s=Rs*1.7;card(x,y+s*.35,z,s,s*.75,bright(hc,1.4));}
 return Rs;}
function palmetto(x,y,z,lv,st){const hc=vary(pick(PAL.palmetto),.03,.1,.06),n=lv===2?ri(5,9):lv===1?4:3,a0=rr(0,TAU),L=rr(1.1,2);
 for(let k=0;k<n;k++){const a=a0+k/n*TAU+rr(-.3,.3);BIO.put('fan',[x+Math.cos(a)*.3,y-.1,z+Math.sin(a)*.3],qEuler(rr(.15,.9),Math.atan2(Math.cos(a),Math.sin(a)),rr(-.1,.1)),[L*rr(.9,1.2),L*rr(.9,1.1),1],bright(vary(hc,.02,.06,.05),1.45));}st.palmettos++;}
function earCluster(x,y,z,lv,st){const n=lv===2?ri(3,6):2,hc=vary(pick(PAL.aroid),.03,.1,.06);
 for(let k=0;k<n;k++){const a=rr(0,TAU),L=rr(1,2.2),stem=rr(.4,1.2),px=x+Math.cos(a)*.3,pz=z+Math.sin(a)*.3;
  if(lv===2)BIO.beam('rod',[px,y,pz],[px+Math.cos(a)*.3,y+stem,pz+Math.sin(a)*.3],.03,.02,rodCol(0x4a6a3a));
  BIO.put('heart',[px+Math.cos(a)*.3,y+stem,pz+Math.sin(a)*.3],qEuler(rr(.5,1.1),Math.atan2(Math.cos(a),Math.sin(a)),rr(-.2,.2)),[L*.8,L,1],bright(vary(hc,.02,.08,.06),1.45));}st.ears++;}
function heliconia(x,y,z,lv,st){const h=rr(1.2,2.6),hc=vary(pick(PAL.aroid),.03,.1,.06);tuft('spike',x,y,z,h,h*.8,bright(hc,1.4));
 if(lv>=1){const col=C(pick(PAL.heliconia));for(let k=0,m=ri(1,3);k<m;k++){const a=rr(0,TAU),bx=x+Math.cos(a)*.3,bz=z+Math.sin(a)*.3,top=y+h*rr(.6,.95);
  if(lv===2)BIO.beam('rod',[bx,y,bz],[bx,top,bz],.025,.02,rodCol(0x4a6a3a));
  for(let j=0;j<ri(4,7);j++)BIO.put('bloom',[bx+rr(-.1,.1),top-j*.14,bz+rr(-.1,.1)],qEuler(rr(-.3,.3),rr(0,TAU),rr(.6,1.2)),rr(.22,.34),bright(vary(col,.02,.06,.05),1.1));}}st.helic++;}
function brom(x,y,z,st){const R=rr(.4,.9),c=rng()<.5?vary(pick(PAL.heliconia),.02,.1,.06):vary(pick(PAL.aroid),.03,.1,.06);
 BIO.put('brom',[x,y-.03,z],qEuler(rr(-.08,.08),rr(0,TAU),rr(-.08,.08)),[R,R*1.1,R],bright(c,1.1));st.brom++;}
function youngCane(x,y,z,lv,st){const S=SWLOW.SPECIES[4],n=ri(2,4);
 for(let k=0;k<n;k++){const px=x+rr(-.6,.6),pz=z+rr(-.6,.6),h=rr(1.2,3);BIO.beam('rod',[px,y-.1,pz],[px,y+h,pz],.05,.04,rodCol(pick(S.crownshaft)));
  frondCrown(px,y+h,pz,rr(1.2,2),ri(3,5),-.8,-.2,leafCol(S.leaf,1.4),'palmfrond');}st.canes++;}
function iris(x,y,z,lv,st){const h=rr(.7,1.2);tuft('spike',x,y,z,h,h*.6,leafCol(PAL.reed,1.35,.03));if(lv>=1)blooms(x,y+h*.75,z,.35,ri(2,4),PAL.iris,[.14,.24],.25);st.iris++;}
function reed(x,y,z,lv){const h=rr(1.4,2.8)*(lv===0?1.5:1),n=lv===2?ri(2,4):1;
 for(let k=0;k<n;k++){const a=rr(0,TAU),d=k?rr(.6,2):0;tuft('reed',x+Math.cos(a)*d,y,z+Math.sin(a)*d,h*rr(.75,1.1),h*rr(.7,1.1),leafCol(PAL.reed,1.35,.025));}}
function sedge(x,y,z,lv,set){const h=rr(.5,1.1)*(lv===0?1.5:1);tuft('grass',x,y,z,h,h*1.3,leafCol(set||PAL.grassGreen,1.35,.03));}
function grassTuft(x,y,z,lv,set,hk,k){const h=rr(.5,1.1)*(hk||1)*(lv===0?1.6:1),n=lv===2?(k||ri(2,4)):1;
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=i?rr(.5,1.8):0;tuft('grass',x+Math.cos(a)*d,y,z+Math.sin(a)*d,h*rr(.8,1.1),h*1.4,leafCol(set,1.3,.03));}}
function azalea(x,y,z,lv,st){const Rs=shrub(x,y,z,lv,PAL.shrub,.8);if(lv>=1)blooms(x,y+Rs*.6,z,Rs*.9,lv===2?ri(10,18):5,PAL.azalea,[.2,.34],Rs*.6);st.azaleas++;}
function yucca(x,y,z,lv,st){const h=rr(.8,1.4);tuft('spike',x,y,z,h,h*1.3,leafCol(PAL.agave,1.3,.02));
 if(lv>=1&&rng()<.5){const sh=rr(2.5,4.5),c=C(pick(PAL.cream));BIO.beam('rod',[x,y+h*.4,z],[x,y+sh,z],.05,.035,rodCol(0x7a6a4a));
  for(let j=0;j<(lv===2?ri(22,34):8);j++){const yy=y+sh*rr(.5,1),a=rr(0,TAU),d=(y+sh-yy)*.28+.12;BIO.put('bloom',[x+Math.cos(a)*d,yy,z+Math.sin(a)*d],qEuler(rr(-.4,.4),rr(0,TAU),rr(-.4,.4)),rr(.2,.32),bright(c,1.15));}}st.yuccas++;}
function mullein(x,y,z,lv,st){const h=rr(1.2,2.4),c=C(pick(PAL.mullein));BIO.put('rosette',[x,y,z],qEuler(0,rr(0,TAU),0),[.45,.3,.45],leafCol(PAL.sage,1.1));
 if(lv>=1){BIO.beam('rod',[x,y,z],[x,y+h,z],.04,.03,rodCol(0x8a9a78));for(let j=0;j<(lv===2?12:5);j++){const yy=y+h*rr(.35,1),a=rr(0,TAU);BIO.put('bloom',[x+Math.cos(a)*.08,yy,z+Math.sin(a)*.08],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),rr(.1,.16),bright(c,1.1));}}st.spikes++;}
function aloe(x,y,z,lv,st){const h=rr(.5,.9);tuft('spike',x,y,z,h,h*1.5,leafCol(PAL.agave,1.25,.02));
 if(lv>=1){for(let k=0,m=ri(1,3);k<m;k++){const px=x+rr(-.3,.3),pz=z+rr(-.3,.3),sh=rr(.9,1.6),c=C(pick(PAL.aloe));BIO.beam('rod',[px,y,pz],[px,y+sh,pz],.03,.02,rodCol(0x6a5a3a));
  for(let j=0;j<ri(4,7);j++)BIO.put('bloom',[px+rr(-.06,.06),y+sh-j*.09,pz+rr(-.06,.06)],qEuler(rr(-.3,.3),rr(0,TAU),rr(.8,1.2)),rr(.12,.18),bright(c,1.1));}}st.aloes++;}
function agave(x,y,z,lv,st){const R=rr(.5,1.2);BIO.put('rosette',[x,y-.02,z],qEuler(rr(-.05,.05),rr(0,TAU),rr(-.05,.05)),[R,R*.9,R],bright(vary(pick(PAL.agave),.02,.08,.05),1.05));st.agaves++;}
function pincushion(x,y,z,lv,st){const Rs=shrub(x,y,z,lv,PAL.chap,.6);if(lv>=1){const c=C(pick(PAL.pincushion));for(let k=0;k<(lv===2?ri(5,10):3);k++){const a=rr(0,TAU),d=Rs*rr(.2,.8);
 BIO.put('pompom',[x+Math.cos(a)*d,y+Rs*rr(.6,1.1),z+Math.sin(a)*d],qEuler(0,rr(0,TAU),0),rr(.13,.2),bright(c,.85));}}st.shrubs++;}
function chaparral(x,y,z,lv,st){const red=rng()<.22,set=red?PAL.chapRed:PAL.chap,Rs=rr(1,2.2);
 if(lv===2){
  for(let i=0;i<3;i++){const a=rr(0,TAU),d=i?Rs*rr(.3,.7):0;BIO.put('manz',[x+Math.cos(a)*d,y+Rs*rr(.4,.7),z+Math.sin(a)*d],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[Rs*1.5,Rs*1.1,Rs*1.5],bright(vary(pick(set),.03,.1,.06),1.4),{n:[0,1,0]});}}
 else BIO.put('manz',[x,y+Rs*.5,z],qEuler(0,rr(0,TAU),0),[Rs*1.9,Rs*1.3,Rs*1.9],bright(vary(pick(set),.03,.1,.06),1.35),{n:[0,1,0]});
 st.chap++;}
function boulder(x,y,z,lv,set,st){const n=lv===2?ri(1,3):1,Rb=rr(.8,2.6);
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=i?Rb*rr(.7,1.2):0,r=Rb*(i?rr(.35,.7):1),bx=x+Math.cos(a)*d,bz=z+Math.sin(a)*d,by=Y(bx,bz),h=r*rr(.5,.9);
  BIO.put('boulder',[bx,by+h*.3,bz],qEuler(rr(-.25,.25),rr(0,TAU),rr(-.25,.25)),[r*rr(.9,1.3),h*.8,r*rr(.9,1.3)],rockTint(set));st.boulders++;}}
function lily(x,z,lv,st,dense){const t=rng(),R=rr(.35,1.1);
 BIO.put('pad',[x,.04,z],qEuler(rr(-.03,.03),rr(0,TAU),rr(-.03,.03)),[R,1,R],bright(vary(pick(PAL.pad),.03,.1,.06),1.05));st.lilies++;
 if(lv===2&&rng()<.18)BIO.put('bloom',[x+rr(-.3,.3)*R,.2,z+rr(-.3,.3)*R],qEuler(rr(-.2,.2),rr(0,TAU),rr(-.2,.2)),rr(.22,.4),bright(rng()<.6?C(0xf6f0e0):C(0xf4c0d0),1.1));
 for(let k=0,m=dense?ri(2,5):(rng()<.3?1:0);k<m;k++){const R2=R*rr(.5,1),a=rr(0,TAU),d=R*rr(1.3,2.6);BIO.put('pad',[x+Math.cos(a)*d,.035,z+Math.sin(a)*d],qEuler(0,rr(0,TAU),0),[R2,1,R2],bright(vary(pick(PAL.pad),.03,.1,.06),1.05));st.lilies++;}}
function hyacinth(x,z,lv,st){for(let k=0,m=ri(2,5);k<m;k++){const px=x+rr(-.8,.8),pz=z+rr(-.8,.8),R=rr(.25,.45);BIO.put('pad',[px,.08,pz],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[R,1,R],bright(vary(pick(PAL.aroid),.03,.1,.06),1.15));}
 if(lv>=1)blooms(x,.1,z,.6,ri(3,7),PAL.hyacinth,[.14,.24],.45);st.lilies++;}
function duckweed(x,z,st){BIO.put('mossmat',[x,.03,z],qEuler(0,rr(0,TAU),0),[rr(1.5,4),1,rr(1.5,4)],leafCol(PAL.duckweed,1.1,.02));st.duckweed++;}
// a fallen tree: a silvered tube with moss, ferns and bromeliads along its back
function log(x,y,z,st,tropical){const a=rr(0,TAU),L=rr(14,40),r0=rr(.6,1.4),hx=Math.cos(a),hz=Math.sin(a),n=Math.ceil(L/7)+1,pts=[];
 for(let i=0;i<n;i++){const t=i/(n-1),px=x+hx*(t-.5)*L,pz=z+hz*(t-.5)*L;if(BIO.mask(px,pz)<=0||!okGround(px,pz,1.5))return false;
  pts.push({x:px,y:Y(px,pz)+r0*.35,z:pz,r:mix(r0,r0*.55,t),col:tint(pick(PAL.deadwood),means().wood,rr(.55,.85)).lerp(C(PAL.moss[i%3]),rng()<.35?.5:0)});}
 BIO.tube('wood',pts,pts[0].col,{seg:8,cap:true});st.logs++;
 for(let s=2;s<L-2;s+=rr(3,6)){const t=s/L,i=Math.min(n-2,Math.floor(t*(n-1))),f=t*(n-1)-i,A=pts[i],Bq=pts[i+1],px=mix(A.x,Bq.x,f),pz=mix(A.z,Bq.z,f),py=mix(A.y,Bq.y,f),r=mix(A.r,Bq.r,f);
  const k=rng();if(k<.45){BIO.put('mossmat',[px,py+r*.95,pz],qEuler(rr(-.1,.1),rr(0,TAU),rr(-.1,.1)),r*rr(.6,1),leafCol(PAL.moss,.95));st.moss++;}
  else if(k<.75)frondCrown(px+rr(-.3,.3),py+r*.9,pz+rr(-.3,.3),rr(.8,1.6),5,.05,.4,leafCol(PAL.fern,1.7));
  else if(tropical)brom(px,py+r*.9,pz,st);
  else BIO.put('fungus',[px,py+r*.3,pz],qEuler(0,rr(0,TAU),0),[rr(.3,.6),rr(.12,.2),rr(.3,.6)],C(pick(PAL.fungus)));}
 return true;}

// ---------------------------------------------------------------- the understorey (under the crowns)
// A SAPLING: the next generation in the shade -- a thin stem and a few leaf clumps
function sapling(x,y,z,lv,set,st){const h=rr(1.8,4.5),r=h*.012+.03;
 BIO.put('trunk2',[x,y-.1,z],qEuler(rr(-.08,.08),0,rr(-.08,.08)),[r/.4,h,r/.4],rodCol(0x6a5a48));
 for(let i=0,m=lv===2?ri(2,4):2;i<m;i++){const s=rr(1.2,2.2),a=rr(0,TAU),d=rr(0,.5);BIO.put('ucard',[x+Math.cos(a)*d,y+h*rr(.6,1),z+Math.sin(a)*d],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[s,s*.8,s],bright(vary(pick(set),.04,.1,.06),1.4));}
 st.saplings++;}
// a berry shrub for the dry woods (toyon-like): dark leaves, red berries
function toyon(x,y,z,lv,st){const Rs=shrub(x,y,z,lv,PAL.chap,.9);if(lv>=1)blooms(x,y+Rs*.7,z,Rs*.8,lv===2?ri(6,12):4,PAL.berry,[.1,.16],Rs*.5);st.shrubs++;}
// one understorey plant under a crown in zone Z: the shade layer, heavier than the open floor's mix
function underPlant(x,y,z,Z,lv,st){const t=rng();
 if(Z.rain>.4){if(t<.2)earCluster(x,y,z,lv,st);else if(t<.38){if(okGround(x,z,2))giantFern(x,y,z,lv);else fern(x,y,z,lv);st.ferns++;}
  else if(t<.5){fern(x,y,z,lv,PAL.fern,'forkfern');st.ferns++;}else if(t<.62)heliconia(x,y,z,lv,st);
  else if(t<.76){shrub(x,y,z,lv,PAL.aroid,1.2);st.shrubs++;}else if(t<.88)sapling(x,y,z,lv,PAL.aroid,st);else if(lv>=1)youngCane(x,y,z,lv,st);else fern(x,y,z,lv);return;}
 if(Z.swamp>.4){if(t<.35)palmetto(x,y,z,lv,st);else if(t<.62){fern(x,y,z,lv,PAL.fern,rng()<.3?'forkfern':'frond');st.ferns++;}
  else if(t<.78)iris(x,y,z,lv,st);else if(t<.9)sapling(x,y,z,lv,PAL.shrub,st);else{shrub(x,y,z,lv,PAL.shrub);st.shrubs++;}return;}
 if(Z.med>.5){if(t<.34)toyon(x,y,z,lv,st);else if(t<.52)chaparral(x,y,z,lv,st);else if(t<.66){BIO.put('lobe',[x,y-.2,z],qEuler(0,rr(0,TAU),0),rr(.6,1.2),shade(vary(pick(PAL.sage),.03,.08,.05),-.1));card(x,y+.6,z,1.6,1.1,leafCol(PAL.sage,1.25));st.shrubs++;}
  else if(t<.8)sapling(x,y,z,lv,PAL.cork,st);else if(t<.9){fern(x,y,z,lv);st.ferns++;}else yucca(x,y,z,lv,st);return;}
 // the plain
 if(t<.24){fern(x,y,z,lv,PAL.fern,rng()<.3?'forkfern':'frond');st.ferns++;}else if(t<.4)azalea(x,y,z,lv,st);
 else if(t<.56){shrub(x,y,z,lv,PAL.shrub,1.1);st.shrubs++;}else if(t<.7)sapling(x,y,z,lv,PAL.sycamore,st);
 else if(t<.82)palmetto(x,y,z,lv,st);else if(t<.9)earCluster(x,y,z,lv,st);else{groundMoss(x,y,z,rr(1.2,2.4));st.moss++;}}

// ---------------------------------------------------------------- the zone planters
// Each takes (x,y,z,Z,lv,st) and places one plant of the zone's mix.
function plantRain(x,y,z,Z,lv,st){const t=rng();
 if(t<.17){earCluster(x,y,z,lv,st);}
 else if(t<.29){if(lv>=1&&okGround(x,z,2.5))giantFern(x,y,z,lv);else fern(x,y,z,lv);st.ferns++;}
 else if(t<.40){fern(x,y,z,lv,PAL.fern,'forkfern');st.ferns++;}
 else if(t<.50){heliconia(x,y,z,lv,st);}
 else if(t<.57){brom(x,y,z,st);if(lv===2)fern(x+rr(-1,1),y,z+rr(-1,1),lv);}
 else if(t<.70){shrub(x,y,z,lv,PAL.aroid);st.shrubs++;}
 else if(t<.79){if(lv>=1){groundMoss(x,y,z,rr(1.2,2.6));st.moss++;}else{fern(x,y,z,lv);st.ferns++;}}
 else if(t<.86){if(lv>=1)youngCane(x,y,z,lv,st);else earCluster(x,y,z,lv,st);}
 else if(t<.93){blooms(x,y,z,rr(.8,1.8),ri(3,8),PAL.heliconia);st.blooms++;if(lv===2)fern(x,y,z,lv);}
 else palmetto(x,y,z,lv,st);}
function plantSwamp(x,y,z,Z,lv,st){const t=rng();
 if(t<.24)palmetto(x,y,z,lv,st);
 else if(t<.42){fern(x,y,z,lv,PAL.fern,rng()<.3?'forkfern':'frond');st.ferns++;}
 else if(t<.58)iris(x,y,z,lv,st);
 else if(t<.74){if(rng()<.5)reed(x,y,z,lv);else sedge(x,y,z,lv);st.tufts++;}
 else if(t<.86){if(lv>=1){groundMoss(x,y,z,rr(1.2,2.8));st.moss++;}else{sedge(x,y,z,lv);st.tufts++;}}
 else if(t<.93)earCluster(x,y,z,lv,st);
 else{blooms(x,y,z,rr(.6,1.4),ri(2,5),PAL.iris);st.blooms++;}}
function plantSub(x,y,z,Z,lv,st){const t=rng();
 if(Z.pineK>.5&&t<.55){palmetto(x,y,z,lv,st);if(lv===2&&rng()<.5)palmetto(x+rr(-2,2),y,z+rr(-2,2),1,st);return;}   // the flatwoods' palmetto carpet
 if(t<.30){grassTuft(x,y,z,lv,PAL.grassGreen,1,null);st.tufts++;}
 else if(t<.40)palmetto(x,y,z,lv,st);
 else if(t<.53){fern(x,y,z,lv,PAL.fern,rng()<.3?'forkfern':'frond');st.ferns++;}
 else if(t<.62)azalea(x,y,z,lv,st);
 else if(t<.72){groundMoss(x,y,z,rr(1.2,2.6),PAL.litter);st.litter++;}
 else if(t<.81){shrub(x,y,z,lv,PAL.shrub);st.shrubs++;}
 else if(t<.87){if(lv>=1&&dampK(x,z)>.5){groundMoss(x,y,z,rr(1,2.2));st.moss++;}else{grassTuft(x,y,z,lv,PAL.grassGreen);st.tufts++;}}
 else if(t<.94){blooms(x,y,z,rr(.6,1.5),ri(3,7),rng()<.5?PAL.azalea:PAL.lupin);st.blooms++;}
 else if(t<.97){earCluster(x,y,z,lv,st);}
 else boulder(x,y,z,lv,PAL.rock,st);}
function plantMed(x,y,z,Z,lv,st){const t=rng();
 if(rng()<Z.chapK*.9){   // the chaparral
  if(t<.62)chaparral(x,y,z,lv,st);
  else if(t<.74)yucca(x,y,z,lv,st);
  else if(t<.82){BIO.put('lobe',[x,y-.2,z],qEuler(0,rr(0,TAU),0),rr(.6,1.2),shade(vary(pick(PAL.sage),.03,.08,.05),-.1));card(x,y+.6,z,1.6,1.1,leafCol(PAL.sage,1.25));st.shrubs++;}
  else if(t<.9){grassTuft(x,y,z,lv,PAL.grassGold,1.1);st.tufts++;}
  else if(t<.95)pincushion(x,y,z,lv,st);
  else boulder(x,y,z,lv,rng()<.4?PAL.rockRed:PAL.rock,st);
  return;}
 const pk=poppyK(x,z),lk=lupinK(x,z);   // the golden grassland
 if(t<.40){grassTuft(x,y,z,lv,PAL.grassGold,1.1);st.tufts++;if(lv===2&&rng()<.5)grassTuft(x+rr(-1.5,1.5),y,z+rr(-1.5,1.5),lv,PAL.grassGold,1);}
 else if(t<.50){grassTuft(x,y,z,lv,PAL.stipa,.9,ri(3,5));st.tufts++;}             // feather-grass tussocks
 else if(t<.50+.14*pk+.02){blooms(x,y,z,rr(1,2.2),lv===2?ri(8,16):ri(3,6),PAL.poppy,[.12,.22],.25);st.blooms++;}
 else if(t<.66+.08*lk){const h=rr(.5,.9);tuft('lupin',x,y,z,h,h*.9,bright(vary(pick(rng()<.6?PAL.lupin:[0x8a4ab8,0x9a5ac8]),.03,.08,.06),1.25));st.spikes++;}
 else if(t<.74){BIO.put('lobe',[x,y-.2,z],qEuler(0,rr(0,TAU),0),rr(.5,1),shade(vary(pick(PAL.sage),.03,.08,.05),-.05));st.shrubs++;}
 else if(t<.79)mullein(x,y,z,lv,st);
 else if(t<.84)agave(x,y,z,lv,st);
 else if(t<.88)aloe(x,y,z,lv,st);
 else if(t<.91)pincushion(x,y,z,lv,st);
 else if(t<.95){grassTuft(x,y,z,lv,PAL.grassGold,.8);st.tufts++;}
 else boulder(x,y,z,lv,rng()<.35?PAL.rockRed:PAL.rock,st);}
function plantBeach(x,y,z,Z,lv,st){const t=rng();
 if(t<.45){grassTuft(x,y,z,lv,PAL.stipa,1.3,ri(2,4));st.tufts++;}
 else if(t<.62){sedge(x,y,z,lv,PAL.grassGreen);st.tufts++;}
 else if(t<.8){for(let k=0,m=ri(2,5);k<m;k++){const R=rr(.2,.4);BIO.put('pad',[x+rr(-1.5,1.5),y+.05,z+rr(-1.5,1.5)],qEuler(rr(-.2,.2),rr(0,TAU),rr(-.2,.2)),[R,1,R],leafCol(PAL.aroid,1.2));}
  if(lv>=1)blooms(x,y,z,1.5,ri(2,5),[0xc890e0,0xd8a0e8],[.12,.2],.1);st.vines++;}
 else if(t<.9)palmetto(x,y,z,lv,st);
 else boulder(x,y,z,lv,PAL.rock,st);}
function plantRip(x,y,z,Z,lv,st){const t=rng();
 if(t<.4){reed(x,y,z,lv);st.tufts++;}
 else if(t<.6){sedge(x,y,z,lv);st.tufts++;}
 else if(t<.75){fern(x,y,z,lv);st.ferns++;}
 else if(t<.85)iris(x,y,z,lv,st);
 else{shrub(x,y,z,lv,PAL.shrub,.8);st.shrubs++;}}

// ---------------------------------------------------------------- the pass
SWLOW.buildFloor=function(R,q){
 reseed(600021);q=q==null?1:q;R=R||2850;means();
 const st={saplings:0,understorey:0,ferns:0,shrubs:0,tufts:0,blooms:0,moss:0,boulders:0,lilies:0,duckweed:0,logs:0,palmettos:0,ears:0,helic:0,brom:0,canes:0,iris:0,azaleas:0,yuccas:0,spikes:0,aloes:0,agaves:0,chap:0,litter:0,vines:0};
 const planters=[plantRain,plantSwamp,plantSub,plantMed,plantBeach,plantRip];
 function plant(x,y,z,lv){if(!okGround(x,z,.7))return;const Z=zones(x,z);
  const w=[Z.rain*1.3,Z.swamp*1.2,Z.sub*.95,Z.med*1.1,Z.beach*.6,Z.rip*.5];let tot=0;for(const v of w)tot+=v;if(tot<=0)return;
  let r=rng()*Math.max(1,tot),k=0;for(;k<w.length;k++){if(r<w[k])break;r-=w[k];}if(k>=w.length)return;
  planters[k](x,y,z,Z,lv,st);}
 // three bands along the LOD spine (the spine runs NW-SE, so no box window: the disc is cheap to walk)
 const bands=[[10,560,0],[19,1400,560],[40,1e9,1400]];
 bands.forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;return .56*q*(lv===0?.42:1);},(x,y,z,d)=>plant(x,y,z,lv),{patch:.72,patchScale:.014,pad:.5});});
 // a second, cheap pass of grass: the ground cover of the hills and the glades (tufts are 6 triangles)
 [[5,480,0],[10,1200,480]].forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;return q*.7;},(x,y,z,d)=>{if(blocked(x,z,.4))return;const Z=zones(x,z);
    const w=(Z.med*(1-Z.chapK*.6)+Z.sub*.4*(1-Z.pineK)+Z.beach*.3)*.75;if(rng()>w)return;
    const set=Z.med>.5?(rng()<.15?PAL.stipa:PAL.grassGold):PAL.grassGreen;grassTuft(x,y,z,1,set,Z.med>.5?1.1:.8);st.tufts++;},{patch:.6,patchScale:.02,pad:.3});});
 // the water: lily pads carpeting still fresh water, hyacinth, duckweed; reeds in the shallows. The sea gets none.
 [[8,560,0],[16,1400,560]].forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;const h=Y(x,z);if(h>.3||h<-4)return 0;
    const Z=zones(x,z);if(Z.salt>.35)return 0;return q*(1-Z.flow*.85)*(.8*smooth(-4,-1,h)+.3*smooth(-.9,-.1,h));},
   (x,y,z,d)=>{if(!BIO.clearOf(x,z,1)||blocked(x,z,.5))return;const k=rng();
    if(y>-.5&&k<.35){reed(x,Math.max(y,-.4),z,lv);st.tufts++;}
    else if(k<.72)lily(x,z,lv,st,dampK(x,z)>.45);
    else if(k<.86)hyacinth(x,z,lv,st);else duckweed(x,z,st);},{patch:.8,patchScale:.02,noMask:true,pad:.4});});
 // THE UNDERSTOREY: under every near and mid crown, a shade layer scattered over the
 // ground the crown covers (clear of the bole), heavier than the open floor's mix. It
 // follows the trees, so it is thickest where the canopy is.
 for(const T of SWLOW.TREES){if(T.lv<1||T.crownR<5)continue;const Rc=Math.max(T.spread||T.crownR,T.crownR)*.85,area=Math.PI*Rc*Rc,n=Math.round(Math.min(T.lv===2?48:8,area*(T.lv===2?.011:.0018))*q);   // by the ground the crown covers
  for(let i=0;i<n;i++){const a=rr(0,TAU),d=T.rb*2+.8+(Math.max(T.spread||T.crownR,T.crownR)*.85-T.rb*2)*Math.sqrt(rng()),x=T.x+Math.cos(a)*d,z=T.z+Math.sin(a)*d;
   if(BIO.mask(x,z)<=0||!okGround(x,z,.7))continue;const y=Y(x,z);if(y<.3)continue;underPlant(x,y,z,zones(x,z),T.lv,st);st.understorey++;}}
 // fallen trees in the rainforest, the bayou and the plain
 BIO.grid(120,0,R,(x,z,d)=>{if(BIO.lodD(x,z)>1400)return 0;const Z=zones(x,z);return (Z.rain*.8+Z.swamp*.4+Z.sub*.35)*q;},
  (x,y,z,d)=>{const trop=zones(x,z).rain>.4;for(let t=0;t<4;t++)if(log(x+rr(-25,25),y,z+rr(-25,25),st,trop))break;},{patch:0,pad:3});
 return{under:st};};
})();

// ==================== 65-biome-swlowlands-dress.js
// ================================================================= SOUTHWESTERN LOWLANDS — growth on structures
// What the lowlands do to a building left in them (the hyperjungle kit's pass,
// in this biome's palette): moss on the ledges, Spanish moss hanging off every
// edge and soffit, strangler figs rooting in the joints and sending their
// roots down the walls, staghorn ferns and bromeliads perched on the ledges,
// azalea and heliconia colour. The host hands over its shells as
// BufferGeometry[] in world space; this pass samples their faces (BIO.upFaces
// / downFaces / sideFaces / ledgePoints) and grows on them. It never touches
// the geometry -- a plant is never part of a building.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const PAL=SWLOW.PAL;
const C=hex=>new BIO.host.THREE.Color(hex);
const vcol=()=>C(pick(PAL.vine)).offsetHSL(rr(-.03,.03),rr(-.08,.08),rr(-.05,.05));
const mcol=()=>C(pick(PAL.moss)).offsetHSL(rr(-.03,.03),rr(-.08,.08),rr(-.06,.04));
const bloomCol=()=>C(pick(rng()<.5?PAL.azalea:PAL.heliconia));
const beardCol=()=>C(pick(PAL.mossPale)).multiplyScalar(rr(1.1,1.35));

// a MOSS PATCH lying on a surface with normal n (up for a ledge, down for a soffit)
function moss(p,n,r){const q=qUp(n);const s=r*rr(.7,1.3);
 BIO.put('mossmat',[p[0]+n[0]*.06,p[1]+n[1]*.06,p[2]+n[2]*.06],q,[s,1,s],mcol());}
// a HANGING CURTAIN off a point: 2-4 ribbons side by side across w, facing (dx,dz),
// a trailing strand, and the odd flower
function curtain(p,dx,dz,len,w,opt){opt=opt||{};const m=Math.hypot(dx,dz);
 if(m<1e-6){const a=rng()*TAU;dx=Math.cos(a);dz=Math.sin(a);}else{dx/=m;dz/=m;}
 const q=qFacing([dx,0,dz]),tx=-dz,tz=dx,nrb=2+Math.floor(rng()*3),c=opt.col||vcol();
 for(let i=0;i<nrb;i++){const o=(i-(nrb-1)/2)*w/nrb+rr(-.1,.1)*w,L=len*rr(.5,1);
  BIO.put('ribbon',[p[0]+tx*o+dx*rr(.05,.35),p[1]+rr(-.15,.05),p[2]+tz*o+dz*rr(.05,.35)],q,[w/nrb*rr(1,1.8),L,1],c.clone().multiplyScalar(rr(.82,1.12)));}
 if(rng()<.75){const o=rr(-w/2,w/2);BIO.put('strand',[p[0]+tx*o+dx*.4,p[1]-rr(0,.2),p[2]+tz*o+dz*.4],q,[rr(.14,.34),len*rr(.9,1.5),1],c.clone().multiplyScalar(.85));}
 if(opt.flowers&&rng()<.55){const fc=bloomCol();for(let b=0,nb=2+Math.floor(rng()*5);b<nb;b++){const s=rr(.3,.62);
  BIO.put('bloom',[p[0]+tx*rr(-.5,.5)*w+dx*.45,p[1]-rr(.2,len*.75),p[2]+tz*rr(-.5,.5)*w+dz*.45],qEuler(0,rng()*TAU,0),[s,s,s],fc);}}}
// AERIAL ROOTS off a ceiling: thin, long, hanging straight down
function roots(p,len,w){const q=qEuler(0,rng()*TAU,0),c=vcol();
 for(let i=0,n=1+Math.floor(rng()*3);i<n;i++)BIO.put('strand',[p[0]+rr(-w,w),p[1],p[2]+rr(-w,w)],q,[rr(.1,.3),len*rr(.6,1.2),1],c.clone().multiplyScalar(rr(.8,1.1)));}
// BRACKET FUNGUS on the side of something
function bracket(p,n,s){for(let b=0,nb=2+Math.floor(rng()*3);b<nb;b++){const sb=s*rr(.4,1);
 BIO.put('fungus',[p[0]+n[0]*.2+rr(-.6,.6)*s*(1-Math.abs(n[0])),p[1]+rr(0,2.2)*s,p[2]+n[2]*.2+rr(-.6,.6)*s*(1-Math.abs(n[2]))],
  qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[sb,sb*.4,sb],C(pick(PAL.fungus)));}}
// a PLANT on a ledge: fern rosette, tuft or small bush
function plant(p,s){const k=rng();const y=p[1];
 if(k<.12){const c=C(pick(PAL.aroid));BIO.put('brom',[p[0],y,p[2]],qEuler(0,rng()*TAU,0),[s*.4,s*.45,s*.4],c.clone().multiplyScalar(rr(.8,1)));}
 else if(k<.45){const n=5+Math.floor(rng()*3),c=C(pick(PAL.fern));for(let i=0;i<n;i++){const a=i/n*TAU+rr(-.25,.25),L=s*rr(.85,1.4);
  BIO.put('frond',[p[0],y+s*.12,p[2]],qEuler(rr(.05,.30),-a,0),[L,L*rr(.7,1),L*rr(.7,1)],c.clone().multiplyScalar(rr(.82,1.2)));}}
 else if(k<.8){const c=C(pick(PAL.fern)).offsetHSL(rr(-.08,.08),0,rr(-.05,.08));
  BIO.put('ucard',[p[0],y+s*.35,p[2]],qEuler(rr(-.2,.2),rng()*TAU,rr(-.2,.2)),[s*1.2,s*.9,s*1.2],c);}
 else{const c=C(pick(PAL.fern)).offsetHSL(rr(-.1,.1),.05,.02);
  BIO.put('lobe',[p[0],y,p[2]],qEuler(0,rng()*TAU,0),[s,s*.7,s],c.clone().multiplyScalar(.82));
  for(let i=0;i<2;i++)BIO.put('ucard',[p[0]+rr(-.4,.4)*s,y+s*.5,p[2]+rr(-.4,.4)*s],qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[s*1.3,s,s*1.3],c.clone().multiplyScalar(rr(.9,1.2)));}}
// a SMALL TREE on a ledge: a tree fern, 4-12 m
function smallTree(p,h){const S=SWLOW.SPECIES[6],rb=h*.035+.2,rc=C(pick(S.bark)).multiplyScalar(.7);
 BIO.put('trunk2',[p[0],p[1],p[2]],qEuler(rr(-.08,.08),0,rr(-.08,.08)),[rb/.4,h,rb/.4],rc);
 for(let i=0,n=2+Math.floor(rng()*4);i<n;i++){const a=rng()*TAU,d=rr(.5,2.5);BIO.beam('rod',[p[0]+Math.cos(a)*d*.3,p[1]+h*rr(.4,.9),p[2]+Math.sin(a)*d*.3],[p[0]+Math.cos(a)*d,p[1]-.1,p[2]+Math.sin(a)*d],rr(.04,.1),null,rc);}
 const n=4+Math.floor(rng()*4),R=h*.35;
 for(let i=0;i<n;i++){const a=rng()*TAU,d=R*Math.sqrt(rng()),s=R*rr(.8,1.2);BIO.put('glossy',[p[0]+Math.cos(a)*d,p[1]+h*rr(.75,1.05),p[2]+Math.sin(a)*d],qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[s,s*.6,s],C(pick(S.leaf)).multiplyScalar(rr(1.1,1.4)),{n:[0,1,0]});}}
// LEDGES: moss on the flat, plants toward the outer edge, lips and curtains off the edge
SWLOW.dressLedges=function(geos,opt){opt=opt||{};
 const nM=opt.moss||400,nP=opt.plants||300,nE=opt.edges||140;
 BIO.upFaces(geos,nM,.6).forEach(f=>moss(f.p,f.n,rr(1.2,opt.mossR||3.5)));
 BIO.upFaces(geos,nP,.6).forEach(f=>{if(rng()<.12)smallTree(f.p,rr(4,opt.treeH||12));else plant(f.p,rr(1,opt.size||3));});
 BIO.ledgePoints(geos,nE,2.5).forEach(l=>{const p=[l.p[0]+l.n[0]*.3,l.p[1]-.1,l.p[2]+l.n[2]*.3];
  moss([l.p[0],l.p[1],l.p[2]],[0,1,0],rr(1,2.2));
  if(rng()<.7)curtain(p,l.n[0],l.n[2],rr(4,opt.hang||16),rr(2,5),{flowers:rng()<.4});
  if(rng()<.6)for(let b=0,nb=1+Math.floor(rng()*3);b<nb;b++)BIO.put('beard',[p[0]+rr(-1,1),p[1],p[2]+rr(-1,1)],qEuler(0,rng()*TAU,0),[rr(1,2.2),rr(2,6),1],beardCol());});};
// SOFFITS: moss rolled over to face the ground, roots and beards hanging out of
// it, brackets, curtains where the rim is. Density rises toward the rim: the
// middle of a big underside is in permanent dark and grows almost nothing.
SWLOW.dressSoffits=function(geos,opt){opt=opt||{};
 const S=BIO.downFaces(geos,opt.n||400,.6);if(!S.length)return;
 let cx=0,cz=0;S.forEach(f=>{cx+=f.p[0];cz+=f.p[2];});cx/=S.length;cz/=S.length;
 let rMax=1e-6;S.forEach(f=>{f.r=Math.hypot(f.p[0]-cx,f.p[2]-cz);if(f.r>rMax)rMax=f.r;});
 S.forEach(f=>{const u=f.r/rMax,lit=.15+.85*Math.pow(u,1.4);const R=(opt.mossR||5)*(.35+.65*lit);
  const dn=[0,-1,0];moss(f.p,dn,rr(R*.6,R));
  for(let q=0,nq=1+Math.floor(rng()*3);q<nq;q++)moss([f.p[0]+rr(-1,1)*R,f.p[1]-rr(0,.2),f.p[2]+rr(-1,1)*R],dn,rr(R*.25,R*.8));
  if(rng()<lit*.85)roots([f.p[0],f.p[1]-.15,f.p[2]],rr(4,opt.hang||16)*(.35+.65*lit),rr(.5,2.2));
  if(rng()<lit*.6)BIO.put('beard',[f.p[0]+rr(-1,1),f.p[1]-.1,f.p[2]+rr(-1,1)],qEuler(0,rng()*TAU,0),[rr(1.2,2.4),rr(2,7)*(.4+.6*lit),1],beardCol());
  if(rng()<lit*.40)curtain([f.p[0],f.p[1]-.2,f.p[2]],f.p[0]-cx,f.p[2]-cz,rr(5,opt.hang||16),rr(2,6),{flowers:rng()<.5});
  if(rng()<.14)bracket([f.p[0],f.p[1]-rr(.5,2),f.p[2]],[0,0,0],rr(1,2.6));});};
// WALLS: vines climbing, brackets, moss streaks under the drips
SWLOW.dressWalls=function(geos,opt){opt=opt||{};
 BIO.sideFaces(geos,opt.n||160).forEach(f=>{const k=rng();
  if(k<.2){const q=qFacing([f.n[0],0,f.n[2]]);for(let r=0,nr=2+Math.floor(rng()*3);r<nr;r++)BIO.put('strand',[f.p[0]+f.n[0]*.2+rr(-1,1)*(1-Math.abs(f.n[0])),f.p[1]+rr(0,3),f.p[2]+f.n[2]*.2+rr(-1,1)*(1-Math.abs(f.n[2]))],q,[rr(.15,.35),rr(4,opt.hang||12),1],C(0x8a8a78).multiplyScalar(rr(.6,.85)));}
  else if(k<.45)curtain([f.p[0]+f.n[0]*.3,f.p[1],f.p[2]+f.n[2]*.3],f.n[0],f.n[2],rr(3,opt.hang||12),rr(1.5,4),{});
  else if(k<.7)bracket([f.p[0],f.p[1],f.p[2]],f.n,rr(.8,2.2));
  else moss([f.p[0]+f.n[0]*.05,f.p[1],f.p[2]+f.n[2]*.05],f.n,rr(.8,2));});};
SWLOW.dressGeos=function(geos,opt){opt=opt||{};reseed(650001+(opt.seed||0));
 SWLOW.dressLedges(geos,opt.ledges||{});SWLOW.dressSoffits(geos,opt.soffits||{});SWLOW.dressWalls(geos,opt.walls||{});};
})();

// ==================== 70-biome-swlowlands.js
// ================================================================= SOUTHWESTERN LOWLANDS — build / dress / canopyH
// The biome's public surface (BIOME-API.md). The passes live in 55 (trees),
// 60 (floor) and 65 (dress); this file only orders them and reports.
SWLOW.build=function(opt){opt=opt||{};const R=opt.R||2850,q=opt.quality==null?1:opt.quality;
 const out={R,quality:q,trees:0,heroes:0,far:0};
 if(SWLOW.buildTrees){BIO.cur='lowlands/trees';Object.assign(out,SWLOW.buildTrees(R,q,opt));}
 if(SWLOW.buildFloor){BIO.cur='lowlands/floor';Object.assign(out,SWLOW.buildFloor(R,q));}
 BIO.cur=null;return out;};
SWLOW.dress=function(geos,opt){if(SWLOW.dressGeos){BIO.cur='lowlands/dress';SWLOW.dressGeos(geos,opt||{});BIO.cur=null;}};
SWLOW.canopyH=function(x,z){return SWLOW._canopyH?SWLOW._canopyH(x,z):10;};

// ==================== 82-host-sky.js
// ================================================================= HOST — Krator sky (from the Hexahedron)
// Baked equirectangular dome (haze column, sun, cumulus, the Inner and Outer
// Walls on the horizon, the inland sea's open horizon to the NW) and the gas
// giant as real geometry. Host-only: a biome never touches the sky.

// ---------------------------------------------------------------- the walls
// We are in Krator's SW quadrant, on the lowland floor between its two walls:
// the INNER WALL off to the NE, the OUTER WALL (the taller, nearer) to the SW.
// Both run NW-SE, parallel to the lowlands, so each stands highest square-on
// and sinks to the horizon toward the sea (NW) and toward the SE -- a straight
// wall of height h at distance d subtends atan(tan(e0)*cos(az-az0)). Far off,
// they are mostly haze: blue-grey faces, a lit crest, faint strata.
// u = ((270-az)/360) mod 1, as the dome maps it.
function paintWalls(g,w,h,HZ,DEG){const base=HZ+6;
 const WALLS=[{az0:45,e0:5.5,col:[104,116,128],name:'inner'},{az0:225,e0:8.5,col:[88,98,110],name:'outer'}];
 WALLS.forEach((W,wi)=>{
  const elev=u=>{const az=((270-u*360)%360+360)%360;let d=((az-W.az0+540)%360)-180;const c=Math.cos(d*Math.PI/180);if(c<=0)return 0;
   const e=Math.atan(Math.tan(W.e0*Math.PI/180)*c)*180/Math.PI;const n=fbm(u*31+wi*7,wi*3.3,81+wi,3)-.5,n2=fbm(u*170+wi,wi,83+wi,2)-.5;
   return Math.max(0,e*(1+n*.18)+n2*.25*Math.min(1,e));};
  const path=()=>{g.beginPath();g.moveTo(0,base+40);for(let x=0;x<=w;x+=2)g.lineTo(x,base-elev(x/w)*DEG);g.lineTo(w,base+40);g.closePath();};
  const c=W.col,grd=g.createLinearGradient(0,HZ-W.e0*DEG*1.2,0,base);
  grd.addColorStop(0,'rgba('+c.join(',')+',1)');grd.addColorStop(1,'rgba('+c.map(v=>v+40).join(',')+',1)');
  g.fillStyle=grd;path();g.fill();g.save();path();g.clip();
  // strata and gullies, stronger where the wall stands high
  for(let i=0;i<1400;i++){const u=rng(),e=elev(u);if(e<.4||rng()>e/W.e0)continue;const x=u*w,top=base-e*DEG,y=mix(top,base,rng());
   g.strokeStyle='rgba('+(rng()<.55?'70,80,90':'170,180,186')+','+(.08+rng()*.16).toFixed(2)+')';g.lineWidth=1+rng()*1.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+rr(-90,90),y+rr(-1.5,1.5));g.stroke();
   if(rng()<.08){g.strokeStyle='rgba(60,70,80,'+(.12+rng()*.15).toFixed(2)+')';g.lineWidth=rr(1.5,3);g.beginPath();g.moveTo(x,top+2);g.lineTo(x+rr(-3,3),mix(top,base,rr(.3,.8)));g.stroke();}}
  // the lit crest (the sun is in the WNW: the outer wall's crest catches it, the inner wall's face does)
  for(let x=0;x<=w;x+=2){const e=elev(x/w);if(e<.2)continue;const top=base-e*DEG;
   g.fillStyle='rgba(230,228,214,'+(wi?.30:.18).toFixed(2)+')';g.fillRect(x,top,2,2+e*.6);
   g.fillStyle='rgba(40,48,58,'+(.10*Math.min(1,e/3)).toFixed(2)+')';g.fillRect(x,top+3+e*.8,2,3+e);}
  // the air between: a heavy haze toward the foot
  const vv=g.createLinearGradient(0,HZ-W.e0*DEG,0,base);vv.addColorStop(0,'rgba(200,210,210,.04)');vv.addColorStop(1,'rgba(200,210,208,.45)');
  g.fillStyle=vv;g.fillRect(0,HZ-W.e0*DEG*1.3,w,base-HZ+W.e0*DEG*1.3);g.restore();});}
// the sea arc: from the lowlands the inland sea fills the horizon round the NW; no canopy line there
function landW(u){const az=((270-u*360)%360+360)%360,d=Math.abs(((az-318+540)%360)-180);return smooth(52,78,d);}
const skyTex=BIO.canvasTex(4096,2048,(g,w,h)=>{
 const HZ=h*.5,DEG=h/180;
 // --- the column: 1.9 atm, so a milky zenith and a thick haze band ---------
 const grd=g.createLinearGradient(0,0,0,h);
 grd.addColorStop(0.00,'#5d7ba2');grd.addColorStop(0.14,'#6f8aa9');
 grd.addColorStop(0.30,'#8fa4b7');grd.addColorStop(0.42,'#aebdc2');
 grd.addColorStop(0.478,'#ccd6c9');grd.addColorStop(0.497,'#dde3d2');
 grd.addColorStop(0.503,'#c9d3c0');grd.addColorStop(0.60,'#93a48c');
 grd.addColorStop(0.78,'#6d8068');grd.addColorStop(1.00,'#53664f');
 g.fillStyle=grd;g.fillRect(0,0,w,h);
 const wrapE=(x,y,rx,ry,f)=>{g.fillStyle=f;for(let k=-1;k<=1;k++){
  g.beginPath();g.ellipse(x+k*w,y,rx,ry,0,0,TAU);g.fill();}};
 // --- THE SUN, at the azimuth the directional light actually uses ----------
 // sun.position is (-1200,900,-600): azimuth 296.6, altitude 33.9. u follows
 // the dome's own mapping, u = ((270-az)/360) mod 1.
 const SUNU=((270-296.57)/360%1+1)%1, sx=w*SUNU, sy=HZ-33.85*DEG;
 {const gl=g.createRadialGradient(sx,sy,0,sx,sy,460);
  gl.addColorStop(0,'rgba(255,246,226,.95)');gl.addColorStop(.06,'rgba(255,238,200,.55)');
  gl.addColorStop(.22,'rgba(255,228,178,.20)');gl.addColorStop(1,'rgba(255,224,170,0)');
  g.fillStyle=gl;for(let k=-1;k<=1;k++)g.fillRect(sx-460+k*w,sy-460,920,920);
  wrapE(sx,sy,15,15,'rgba(255,252,240,1)');}
 // --- cumulus: flat-based heaps, crowded toward the horizon ----------------
 for(let ci=0;ci<150;ci++){
  const t=Math.pow(rng(),1.7);
  const cy=HZ-(4+t*58)*DEG, cx=rng()*w;
  const sc=.5+2.1*t+rr(0,.6), cw=rr(70,180)*sc, ch2=cw*rr(.15,.30);
  const ca=(.17+.30*rng())*(1-.32*t);
  wrapE(cx,cy+ch2*.12,cw*.92,ch2*.34,'rgba(146,160,166,'+(ca*.55).toFixed(3)+')');
  const nP=7+Math.floor(rng()*7);
  for(let p2=0;p2<nP;p2++){
   const px=cx+rr(-1,1)*cw*.78,k2=1-Math.abs(px-cx)/cw;
   const pr=ch2*(.45+.75*k2)*rr(.75,1.2);
   wrapE(px,cy-pr*.55,pr*1.5,pr,'rgba(250,250,244,'+(ca*rr(.55,1)).toFixed(3)+')');}}
 // --- humid veils -----------------------------------------------------------
 for(let i=0;i<46;i++)
  wrapE(rng()*w,HZ-rr(14,HZ*.72),rr(300,1100),rr(8,26),
   'rgba(240,246,238,'+(.025+.055*rng()).toFixed(3)+')');
 // --- two small moons, well off the giant ----------------------------------
 [[0.38,26,54,'rgba(226,222,214,'],[0.615,17,38,'rgba(214,198,192,']].forEach(M=>{
  const mx=w*M[0],my=HZ-M[1]*DEG;
  wrapE(mx,my,M[2],M[2],M[3]+'.55)');
  wrapE(mx-M[2]*.3,my-M[2]*.3,M[2]*.62,M[2]*.62,M[3]+'.28)');});
 // --- THE WALLS. At 5-8 degrees they stand well under the gas giant's lower
 // limb (25 - 15 = 10 degrees), so no overlay dome is needed in front of it.
 paintWalls(g,w,h,HZ,DEG);
 // --- horizon haze and the far canopy --------------------------------------
 const hz=g.createLinearGradient(0,HZ-80,0,HZ+40);
 hz.addColorStop(0,'rgba(200,210,204,0)');hz.addColorStop(.6,'rgba(200,210,204,.30)');
 hz.addColorStop(1,'rgba(200,210,204,.62)');
 g.fillStyle=hz;g.fillRect(0,HZ-80,w,120);
 const canopy=(col,h0,h1,R,off,bump,em)=>{g.fillStyle=col;g.beginPath();g.moveTo(0,HZ+20);
  for(let x=0;x<=w;x+=2){const an=(x%w)/w*TAU,cx2=Math.cos(an)*R,sz2=Math.sin(an)*R;
   const n=fbm(off+cx2,off+sz2,7,3),n2=fbm(off*3+cx2*6,off*3+sz2*6,11,2);
   let hh=(h0+(h1-h0)*n+bump*(n2-.5))*landW(x/w);
   if(em){const e=fbm(off*7+cx2*2.2,off*7+sz2*2.2,13,2);
    hh+=em*Math.max(0,(e-.74)/.26);}                 // emergents over the line
   g.lineTo(x,HZ-hh*DEG);}
  g.lineTo(w,HZ+20);g.closePath();g.fill();};
 canopy('rgba(128,146,132,.55)',.5,1.3,9,17.3,.3,.5);
 canopy('rgba(96,116,100,.7)',.3,.8,14,41.7,.3,.3);
 const gm=g.createLinearGradient(0,HZ-DEG*1.4,0,HZ+24);
 gm.addColorStop(0,'rgba(196,210,192,0)');gm.addColorStop(.3,'rgba(196,210,192,.32)');
 gm.addColorStop(1,'rgba(196,210,192,.95)');
 g.fillStyle=gm;g.fillRect(0,HZ-DEG*1.4,w,DEG*1.4+24);
});
skyTex.wrapS=THREE.RepeatWrapping;skyTex.wrapT=THREE.ClampToEdgeWrapping;
const sky=new THREE.Mesh(new THREE.SphereGeometry(9000,72,44),
 new THREE.MeshBasicMaterial({map:skyTex,side:THREE.BackSide,fog:false,depthWrite:false}));
sky.userData.probeSkip=true;sky.renderOrder=-10;scene.add(sky);
// the gas giant, low in the north-east (Krator canon: altitude 25°, azimuth 66°)
// THE GAS GIANT Krator orbits, ported from Girder's sky as real geometry
// rather than a painted sprite. Canon: 30 degrees across at azimuth 67,
// altitude 25 -- sixty full moons wide.
//
// The band coordinates are computed in the FRAGMENT shader from the world-space
// normal against a world-space spin axis, so the mesh needs no rotation of its
// own and there is no local/world convention to get wrong. The axis lies in the
// PLANE OF THE SKY, tilted 23 degrees from the sky's own up: that is the only
// reading that gives both a tilted planet AND rings seen as a hairline. An axis
// literally 23 degrees off world-up would sit far out of the ring plane and the
// rings would be wide open.
const GIANT_DIST=6000,GIANT_R=GIANT_DIST*Math.tan(15*Math.PI/180);
const giantDir=new THREE.Vector3(Math.sin(66*Math.PI/180)*Math.cos(25*Math.PI/180),Math.sin(25*Math.PI/180),-Math.cos(66*Math.PI/180)*Math.cos(25*Math.PI/180)).normalize();
const _gE1=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),giantDir).normalize();
const _gUp=new THREE.Vector3().crossVectors(giantDir,_gE1).normalize();
const GIANT_AXIS=_gUp.clone().multiplyScalar(Math.cos(23*Math.PI/180))
 .addScaledVector(_gE1,Math.sin(23*Math.PI/180)).normalize();
const GIANT_B1=new THREE.Vector3().crossVectors(GIANT_AXIS,giantDir).normalize();
const GIANT_B2=new THREE.Vector3().crossVectors(GIANT_AXIS,GIANT_B1).normalize();
const GU={
 uSunDir:{value:new THREE.Vector3().copy(sun.position).normalize()},
 uAxis:{value:GIANT_AXIS},uE1:{value:GIANT_B1},uE2:{value:GIANT_B2},
 uZone:{value:new THREE.Color(0x3c7e91)},uBelt:{value:new THREE.Color(0xd6c9a8)},
 uStormC:{value:new THREE.Color(0xb98a63)},uRimCol:{value:new THREE.Color(0x9fd4ea)},
 uNightC:{value:new THREE.Color(0x4b6f86)},uHazeC:{value:new THREE.Color(0xb7c4ae)},
 uSpin:{value:0},uRingLat:{value:.08},uHazeK:{value:.34}};
const giantMat=new THREE.ShaderMaterial({fog:false,depthWrite:false,uniforms:GU,
 vertexShader:[
  'varying vec3 vN; varying vec3 vV; varying vec3 vSky;',
  'void main(){vec4 wp=modelMatrix*vec4(position,1.0);',
  ' vN=normalize(mat3(modelMatrix)*normal);',
  ' vV=normalize(cameraPosition-wp.xyz);',
  ' vSky=normalize(wp.xyz-cameraPosition);',
  ' gl_Position=projectionMatrix*viewMatrix*wp;}'].join('\n'),
 fragmentShader:[
  'uniform vec3 uSunDir,uAxis,uE1,uE2,uZone,uBelt,uStormC,uRimCol,uNightC,uHazeC;',
  'uniform float uSpin,uRingLat,uHazeK;',
  'varying vec3 vN; varying vec3 vV; varying vec3 vSky;',
  'float oval(float lat,float lon,vec4 s){float dl=lat-s.x;',
  ' float dg=mod(lon-s.y+3.14159265,6.28318531)-3.14159265;',
  ' return (dg*dg)/(s.z*s.z)+(dl*dl)/(s.w*s.w);}',
  'void main(){vec3 N=normalize(vN),V=normalize(vV);',
  ' float sLat=clamp(dot(N,uAxis),-1.0,1.0), lat=asin(sLat);',
  ' float lon=atan(dot(N,uE2),dot(N,uE1))+uSpin;',
  ' float wav=0.42*sin(lon*3.0+lat*6.0)+0.24*sin(lon*7.0-2.1)+0.13*sin(lon*13.0+lat*3.0);',
  ' float b=sin(lat*10.0+wav);',
  ' vec3 col=mix(uZone,uBelt,smoothstep(-0.45,0.45,b));',
  ' col*=0.93+0.12*sin(lat*37.0+1.6*sin(lon*2.0+0.7));',
  ' col=mix(col,uZone*0.70,smoothstep(0.70,1.0,abs(sLat)));',
  ' col=mix(uStormC,col,smoothstep(0.45,1.0,oval(lat,lon,vec4(-0.36,1.10,0.40,0.13))));',
  ' col=mix(uStormC*1.12,col,smoothstep(0.45,1.0,oval(lat,lon,vec4(0.21,4.05,0.26,0.085))));',
  ' col*=1.0-0.34*(1.0-smoothstep(0.0,0.075,abs(lat-uRingLat)));',
  // clamp not max: two unit vectors can dot a hair over 1.0 and pow() of a
  // negative base is undefined in GLSL
  ' float ndv=clamp(dot(N,V),0.0,1.0);',
  ' float limb=pow(max(ndv,0.0015),0.35);',
  ' float ndl=dot(N,uSunDir);',
  ' float day=smoothstep(-0.17,0.17,ndl);',
  ' vec3 outc=col*limb*(0.92*day)+col*limb*uNightC*0.11;',
  ' float fres=pow(max(1.0-ndv,0.0),3.2);',
  ' outc+=uRimCol*fres*0.16*mix(smoothstep(-0.35,0.45,ndl),1.0,0.15);',
  // extinction: the disc is 30 deg wide, so its lower limb sits a good deal
  // deeper in the air than its upper one
  ' float up=max(vSky.y,0.0);',
  // a floor under the extinction: at this distance even the zenith is looking
// through a lot of 1.9-atm air, and without it the night side punched a
// black hole in a daylit sky
' outc=mix(outc,uHazeC,clamp(0.30+uHazeK*exp(-up/0.16),0.0,0.86));',
  ' gl_FragColor=vec4(outc,1.0);}'].join('\n')});
const giant=new THREE.Mesh(new THREE.SphereGeometry(GIANT_R,96,64),giantMat);
giant.renderOrder=-9;giant.userData.probeSkip=true;scene.add(giant);
// the rings, edge-on because the spin axis lies in the plane of the sky
const ringMat=new THREE.ShaderMaterial({fog:false,transparent:true,depthWrite:false,
 side:THREE.DoubleSide,uniforms:{uIn:{value:1.30},uOut:{value:2.12},
  uCol:{value:new THREE.Color(0xbcb09a)},uHazeC:GU.uHazeC,uHazeK:GU.uHazeK},
 vertexShader:['varying vec2 vUvR; varying vec3 vSky;',
  'void main(){vUvR=position.xy;vec4 wp=modelMatrix*vec4(position,1.0);',
  ' vSky=normalize(wp.xyz-cameraPosition);',
  ' gl_Position=projectionMatrix*viewMatrix*wp;}'].join('\n'),
 fragmentShader:['uniform float uIn,uOut,uHazeK;uniform vec3 uCol,uHazeC;',
  'varying vec2 vUvR; varying vec3 vSky;',
  'void main(){float r=length(vUvR);',
  ' float t=(r-uIn)/(uOut-uIn);',
  ' if(t<0.0||t>1.0)discard;',
  ' float a=0.62*(0.45+0.55*sin(t*34.0))*(1.0-smoothstep(0.86,1.0,t));',
  ' a*=smoothstep(0.0,0.06,t);',
  ' a*=1.0-0.55*smoothstep(0.40,0.46,t)*(1.0-smoothstep(0.46,0.52,t));',
  ' vec3 c=uCol*(0.8+0.3*sin(t*21.0));',
  ' float up=max(vSky.y,0.0);',
  ' c=mix(c,uHazeC,clamp(0.26+uHazeK*exp(-up/0.16),0.0,0.86));',
  ' gl_FragColor=vec4(c,a);}'].join('\n')});
const giantRing=new THREE.Mesh(new THREE.RingGeometry(GIANT_R*1.30,GIANT_R*2.12,256,1),ringMat);
giantRing.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),GIANT_AXIS);
giantRing.renderOrder=-9;giantRing.userData.probeSkip=true;scene.add(giantRing);
TICKS.push(function(dt){GU.uSpin.value+=dt*0.006;});

// ==================== 85-host-tower.js
// ================================================================= HOST — one Girder tower
// A single ruined tower of Girder's four (30 storeys of 5 m on a 48 m square,
// 4x4 cyclopean columns, 16 m floor plates in a 3x3 grid, spandrel girders,
// X-bracing, core walls, a ragged unfinished top), rebuilt here in plain
// three.js so the biome has soffits, ledges and walls to grow on. It is a TEST
// STRUCTURE for SWLOW.dress(): the host merges its shells per material
// and hands the geometries over; the biome samples their faces itself.
// Host-only. No plant is placed in this file.
function buildTestTower(){
 const TX=40,TZ=-470,HALF=24,N=30,FH=5,SLAB=1,COLS=[-HALF+1.6,-8,8,HALF-1.6];
 const y0=terrainH(TX,TZ);
 const conc=[],rust=[];
 const box=(list,x,y,z,w,h,d,rot)=>{const g=new THREE.BoxGeometry(w,h,d);if(rot){g.rotateX(rot[0]||0);g.rotateY(rot[1]||0);g.rotateZ(rot[2]||0);}g.translate(x,y+h/2,z);list.push(g);};
 const beam=(list,ax,ay,az,bx,by,bz,w,d)=>{const L=Math.hypot(bx-ax,by-ay,bz-az);const g=new THREE.BoxGeometry(w,L,d);
  const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(bx-ax,by-ay,bz-az).normalize());
  g.applyMatrix4(new THREE.Matrix4().makeRotationFromQuaternion(q));g.translate((ax+bx)/2,(ay+by)/2,(az+bz)/2);list.push(g);};
 // the ruin state: floors above 18 lose plates, the top is ragged
 const floors=[];for(let k=0;k<=N;k++){const missing=[];
  if(k>10)for(let bi=-1;bi<=1;bi++)for(let bj=-1;bj<=1;bj++){const p=k>22?.55:(k>16?.30:.10);if(rng()<p)missing.push(bi+','+bj);}
  floors.push({k,y:y0+3+k*FH,missing});}
 const top=y0+3+N*FH;
 // columns, some running on past the roof as broken stubs
 COLS.forEach((cx,i)=>COLS.forEach((cz,j)=>{const over=rng()<.55?rr(2,13):.4;box(rust,TX+cx,y0-3,TZ+cz,3.2,top-y0+3+over,3.2);}));
 floors.forEach(F=>{const yb=F.y-SLAB;
  for(let bi=-1;bi<=1;bi++)for(let bj=-1;bj<=1;bj++){if(F.missing.indexOf(bi+','+bj)>=0)continue;
   if(bi||bj)box(conc,TX+bi*16,yb,TZ+bj*16,16.02,SLAB,16.02);
   else if(F.k<N){box(conc,TX-6.2,yb,TZ,3.6,SLAB,16);box(conc,TX+1.8,yb,TZ-6.1,12.4,SLAB,3.8);box(conc,TX+1.8,yb,TZ+6.1,12.4,SLAB,3.8);}}
  [[0,-1],[0,1],[-1,0],[1,0]].forEach(f=>box(rust,TX+f[0]*(HALF-.35),yb-.9,TZ+f[1]*(HALF-.35),f[0]?.7:48,1.5,f[0]?48:.7));
  [-8,8].forEach(c=>{box(rust,TX+c,yb-.8,TZ,.9,.8,47);box(rust,TX,yb-.8,TZ+c,47,.8,.9);});
  if(F.k<N&&F.k<20){box(conc,TX,F.y,TZ-7.6,16,FH,.8);box(conc,TX,F.y,TZ+7.6,16,FH,.8);box(conc,TX+7.6,F.y,TZ,.8,FH,14.4);}
 });
 // X-bracing, two storeys at a time, gaps where it has fallen
 [[0,-1],[0,1],[-1,0],[1,0]].forEach(f=>{for(let k=0;k<N;k+=2){if(rng()<.22)continue;
  const ya=floors[k].y,yb2=floors[Math.min(N,k+2)].y-SLAB,px=TX+f[0]*(HALF-.4),pz=TZ+f[1]*(HALF-.4),ax=f[0]?0:-8,az=f[1]?0:-8;
  beam(rust,px+ax,ya,pz+az,px-ax,yb2,pz-az,.55,.55);beam(rust,px-ax,ya,pz-az,px+ax,yb2,pz+az,.55,.55);}});
 // rubble at the foot
 for(let i=0;i<40;i++){const a=rng()*TAU,r=rr(26,52);const x=TX+Math.cos(a)*r,z=TZ+Math.sin(a)*r;box(conc,x,terrainH(x,z)-.5,z,rr(2,7),rr(1,3),rr(2,6),[rr(-.3,.3),rng()*TAU,rr(-.3,.3)]);}
 // merge per material
 const TEXC=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=150+(fbm(x/18,y/18,2.2,3)-.5)*60+(fbm(x/3,y/3,8,1)-.5)*20;d[i]=v*.92;d[i+1]=v*.86;d[i+2]=v*.74;d[i+3]=255;}g.putImageData(id,0,0);});
 const TEXR=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=fbm(x/14,y/9,5.5,3),u=fbm(x/4,y/4,3,2);d[i]=96+v*46+u*16;d[i+1]=70+v*34+u*8;d[i+2]=52+v*22;d[i+3]=255;}g.putImageData(id,0,0);});
 const merge=(list,mat,label)=>{const pos=[],nor=[],uv=[];
  list.forEach(g=>{const ng=g.toNonIndexed();const p=ng.attributes.position.array,n=ng.attributes.normal.array;
   for(let i=0;i<p.length;i++){pos.push(p[i]);nor.push(n[i]);}
   for(let i=0;i<p.length;i+=3){uv.push((p[i]+p[i+2])/6,p[i+1]/6);}});   // triplanar-ish world uv
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  const m=new THREE.Mesh(geo,mat);m.userData.inspectLabel=label;m.userData.host=true;scene.add(m);return geo;};
 const gC=merge(conc,new THREE.MeshLambertMaterial({map:TEXC,color:0x8e8878}),'Girder tower — concrete');
 const gR=merge(rust,new THREE.MeshLambertMaterial({map:TEXR,color:0x6e4a36}),'Girder tower — iron');
 OBSTACLES.push({x:TX,z:TZ,r:HALF*1.5+6,y0:y0-5,y1:top+20});
 REGISTER({name:'Girder tower (test structure, ruined)',x:TX,z:TZ,y:y0,r:HALF*1.5,h:top-y0+16});
 return [gC,gR];}

// ==================== 88-host-build.js
// ================================================================= HOST — build
// The order a world follows: its own structures first (they fill OBSTACLES and
// hand their shells to dress()), then the biome, then one bake.
window._biome=null;
// ?q=0.5 (or window.KRATOR_Q) scales every count in the biome: the knob for a weaker machine
const BIOME_Q=(()=>{let q=+(window.KRATOR_Q||0);try{q=q||+(new URLSearchParams(location.search).get('q'));}catch(e){}return q>0?Math.min(q,1.5):1;})();
(function(){
 const t0=performance.now();
 let shells=[];
 if(typeof buildTestTower==='function'){try{shells=buildTestTower()||[];}catch(e){reportErr('tower: '+e.stack);}}
 try{window._biome=SWLOW.build({R:TERR.R-150,quality:BIOME_Q,avenues:[{path:ROAD,spacing:24,offset:13.5,species:'sprawloak'}],groves:[CORK_GROVE]});}catch(e){reportErr('biome: '+e.stack);}
 if(shells.length){try{SWLOW.dress(shells,{ledges:{moss:2200,plants:900,edges:520,hang:14},soffits:{n:1800,mossR:4,hang:14},walls:{n:520}});}catch(e){reportErr('dress: '+e.stack);}}
 const b=BIO.bake();
 window._instances=b.inst;window._bakeCalls=b.calls;window._buildMs=Math.round(performance.now()-t0);
 REGISTER({name:'The southwestern lowlands (ideal type)',x:0,z:0,r:TERR.R,h:420});
})();

// ==================== 90-host-camera.js
// ================================================================= HOST — camera, inspector, loop
const ctl={target:new THREE.Vector3(0,0,0),theta:0,phi:1.1,radius:600};
function setView(cx,cy,cz,tx,ty,tz){ctl.target.set(tx,ty,tz);const dx=cx-tx,dy=cy-ty,dz=cz-tz;ctl.radius=Math.sqrt(dx*dx+dy*dy+dz*dz);ctl.theta=Math.atan2(dx,dz);ctl.phi=Math.acos(clamp(dy/ctl.radius,-1,1));}
function applyCam(){const r=ctl.radius,sp=Math.sin(ctl.phi);camera.position.set(ctl.target.x+r*sp*Math.sin(ctl.theta),ctl.target.y+r*Math.cos(ctl.phi),ctl.target.z+r*sp*Math.cos(ctl.theta));
 const g=terrainH(camera.position.x,camera.position.z)+1.8;if(camera.position.y<g)camera.position.y=g;camera.lookAt(ctl.target);}
// Preset views. Most are FOUND, not typed: viewTree() looks up the nearest
// near-detail tree of a species to a point on the (s,t) axis and frames it from
// the sun side, so a view still lands on its subject when the placement moves.
const SUNH=(()=>{const l=Math.hypot(-1200,-600);return[-1200/l,-600/l];})();
function viewTree(key,s,t,dist,h,look,side){const sp=SWLOW.SPECIES.findIndex(S=>S.key===key),o=xzOf(s,t);let best=null,bd=1e9;
 for(const T of SWLOW.TREES){if(T.sp!==sp||T.lv!==2)continue;const d=Math.hypot(T.x-o[0],T.z-o[1]);if(d<bd){bd=d;best=T;}}
 if(!best)return[o[0]+80,terrainH(o[0],o[1])+30,o[1]+80,o[0],terrainH(o[0],o[1]),o[1]];
 const R=Math.max(best.spread||0,best.crownR),D=dist*R,a=Math.atan2(SUNH[1],SUNH[0])+(side||0),cx=best.x+Math.cos(a)*D,cz=best.z+Math.sin(a)*D;
 return[cx,terrainH(cx,cz)+h,cz,best.x,best.y0+best.H*look,best.z];}
function viewAxis(s0,t0,h0,s1,t1,h1){const a=xzOf(s0,t0),b=xzOf(s1,t1);return[a[0],terrainH(a[0],a[1])+h0,a[1],b[0],terrainH(b[0],b[1])+h1,b[1]];}
const VIEWS={
 'The oak avenue':(()=>{const a=xzOf(-985,ROAD_T(-985)),b=xzOf(-800,ROAD_T(-800));return[a[0],terrainH(a[0],a[1])+1.7,a[1],b[0],terrainH(b[0],b[1])+9,b[1]];})(),
 'Under the vault':(()=>{const a=xzOf(-720,ROAD_T(-720)),b=xzOf(-640,ROAD_T(-640));return[a[0],terrainH(a[0],a[1])+1.7,a[1],b[0],terrainH(b[0],b[1])+15,b[1]];})(),
 'A sprawl oak':viewTree('sprawloak',-300,0,1.75,4,.3,.4),
 'The plain from above':viewAxis(-900,-500,140,-200,300,0),
 'Pillar fig':viewTree('pillarfig',-900,0,1.0,3,.4,.3),
 'Parasol kapok':viewTree('kapok',-1500,0,1.1,4,.62,.2),
 'Mangrove shore':viewTree('mangrove',-1950,-150,2.2,4,.3,.5),
 'The bayou':viewTree('cypress',-1400,-100,2.2,3,.5,.3),
 'Cane palms and gums':viewTree('gum',-1350,0,1.4,3,.35,.5),
 'Veil willows':viewTree('willow',-200,-120,1.6,2,.35,.3),
 'Flatwoods':viewTree('pine',-400,300,5,2.5,.45,.2),
 'Crimson ghost':viewTree('crimson',300,0,2.2,6,.45,-.6),
 'The tower':[40-150,terrainH(-110,-560)+40,-470-90,40,110,-470],
 'Chaparral':viewTree('manzanita',1500,0,2.2,2.2,.3,.3),
 'Madrone and cork oak':viewTree('madrone',1300,0,1.6,3,.4,.4),
 'Skirt palms':viewTree('skirtpalm',1400,-150,3.2,2.5,.45,1.9),
 'The cork grove':(()=>{const c=CORK_GROVE.center,a=Math.atan2(SUNH[1],SUNH[0]),cx=c[0]+Math.cos(a)*105,cz=c[1]+Math.sin(a)*105;return[cx,terrainH(cx,cz)+5,cz,c[0],terrainH(c[0],c[1])+4,c[1]];})(),
 'Flame parasol':viewTree('flame',-900,0,1.5,4,.5,.3),
 'Violet jacaranda':viewTree('jacaranda',400,0,2.6,5,.55,.3),
 'Lantern magnolia':viewTree('magnolia',-400,0,2.4,6,.55,.3),
 'Sunburn tree':viewTree('sunburn',-800,0,1.6,3,.45,.3),
 'Star gum':viewTree('stargum',-300,0,1.6,3,.5,.3),
 'Bay laurel':viewTree('baylaurel',1200,0,1.7,3,.4,.3),
 'Tier cedars':viewTree('cedar',2000,0,1.4,6,.45,.3),
 'From the hills':viewAxis(2300,150,60,-1300,-200,0),
 'From afar':viewAxis(3000,-2200,380,-400,0,0),
 'Krator rising':viewAxis(-600,200,30,1200,1400,900),
};
const ui=document.getElementById('ui');const sel=document.createElement('select');sel.id='viewsel';for(const k in VIEWS){const o=document.createElement('option');o.textContent=k;sel.appendChild(o);}sel.onchange=()=>setView(...VIEWS[sel.value]);ui.appendChild(sel);
// hidden buttons, one per preset: verify.py drives the views through these
const _hb=document.createElement('div');_hb.style.display='none';ui.appendChild(_hb);for(const k in VIEWS){const b=document.createElement('button');b.textContent=k;b.onclick=()=>setView(...VIEWS[k]);_hb.appendChild(b);}
const insp=document.getElementById('insp');const ray=new THREE.Raycaster();
function inspectAt(cx,cy){const v=new THREE.Vector2(cx/innerWidth*2-1,-(cy/innerHeight)*2+1);ray.setFromCamera(v,camera);
 const hits=ray.intersectObjects(scene.children,true).filter(h=>!h.object.userData.probeSkip||h.object.userData.inspectLabel);
 if(!hits.length){insp.textContent='(nothing)';return;}const p=hits[0].point,o=hits[0].object;
 // the smallest registered volume round the point, ignoring the map-wide one
 let best=null;for(const r of REG){if(r.r>1500)continue;const dx=p.x-r.x,dz=p.z-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p.y>=(r.y||0)-2&&p.y<=(r.y||0)+r.h+5){if(!best||r.r<best.r)best=r;}}
 // a plant names itself (the item's label); a bole or a structure names its registered volume
 const lab=o.userData.inspectLabel||o.name||'mesh',isItem=o.isInstancedMesh&&o.userData.biome;
 let name=isItem?lab+(best?'  (under '+best.name+')':''):(best?best.name+'  ·  '+lab:lab);
 insp.textContent=name+'\n'+p.x.toFixed(0)+', '+p.y.toFixed(0)+', '+p.z.toFixed(0)+'  range '+camera.position.distanceTo(p).toFixed(0)+' m';}
setView(...VIEWS[Object.keys(VIEWS)[0]]);
const cv=renderer.domElement;let drag=null;const keys={};
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,b:e.button};cv.setPointerCapture(e.pointerId);});
cv.addEventListener('pointerup',e=>{if(drag&&drag.b===0&&Math.abs(e.clientX-drag.sx)<4&&Math.abs(e.clientY-drag.sy)<4)inspectAt(e.clientX,e.clientY);drag=null;});cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;
 if(drag.b===0){ctl.theta-=dx*.005;ctl.phi=clamp(ctl.phi-dy*.005,.05,Math.PI-.05);}
 else{const f=ctl.radius*.0015;const rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta));
  ctl.target.addScaledVector(rt,-dx*f).addScaledVector(fw,-dy*f);}});
cv.addEventListener('wheel',e=>{ctl.radius=clamp(ctl.radius*(e.deltaY>0?1.1:.9),3,6000);e.preventDefault();},{passive:false});
addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
const hud=document.getElementById('hud');let last=performance.now(),renderErr=false;
function frame(){const now=performance.now(),dt=Math.min(.1,(now-last)/1000);last=now;
 const sp=ctl.radius*.6*dt;const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta)),rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));
 if(keys.w)ctl.target.addScaledVector(fw,sp);if(keys.s)ctl.target.addScaledVector(fw,-sp);if(keys.d)ctl.target.addScaledVector(rt,sp);if(keys.a)ctl.target.addScaledVector(rt,-sp);
 if(keys.q)ctl.target.y-=sp;if(keys.e)ctl.target.y+=sp;
 for(let i=0;i<TICKS.length;i++){try{TICKS[i](dt,now/1000);}catch(e){if(!renderErr){renderErr=true;reportErr('tick: '+e.stack);}}}
 applyCam();if(typeof sky!=='undefined'){sky.position.copy(camera.position);if(typeof wallSky!=='undefined')wallSky.position.copy(camera.position);giant.position.copy(camera.position).addScaledVector(giantDir,GIANT_DIST);giantRing.position.copy(giant.position);}
 try{renderer.render(scene,camera);}catch(e){if(!renderErr){renderErr=true;reportErr('render: '+e.stack);}}
 hud.textContent=`cam ${camera.position.x|0},${camera.position.y|0},${camera.position.z|0}  tgt ${ctl.target.x|0},${ctl.target.y|0},${ctl.target.z|0}\ncalls ${renderer.info.render.calls}  tris ${(renderer.info.render.triangles/1e6).toFixed(2)}M  inst ${window._instances}`;
 requestAnimationFrame(frame);}
frame();window._ready=true;

// ==================== 91-host-probe.js
// ================================================================= HOST — probe (window._api)
// What verify.py --assert measures. Budgets per biome pass come from
// BIO.stats (charged by BIO.cur inside the biome).
const BUDGET={
 showcase:{tris:12000000,calls:120},   // raised for the lowlands (Sep 2026): the eastabyss ceilings were 7.6M / 5.6M
 cls:{pass:9000000,host:900000},
 type:{'lowlands/trees':'pass','lowlands/floor':'pass','lowlands/dress':'pass','host':'host'},
};
function _probePoints(){
 const pts=[],m=new THREE.Matrix4(),pos=new THREE.Vector3(),q=new THREE.Quaternion(),sc=new THREE.Vector3(),bb=new THREE.Box3();
 scene.traverse(o=>{if(o.userData&&o.userData.probeSkip)return;
  if(o.isInstancedMesh){for(let i=0;i<o.count;i++){o.getMatrixAt(i,m);m.decompose(pos,q,sc);pts.push([pos.x,pos.y,pos.z]);}return;}
  if(!o.isMesh)return;bb.setFromObject(o);if(!isFinite(bb.min.x)||!isFinite(bb.max.x))return;
  pts.push([(bb.min.x+bb.max.x)/2,(bb.min.y+bb.max.y)/2,(bb.min.z+bb.max.z)/2]);});
 return pts;}
function regOccupancy(){const n=new Array(REG.length).fill(0);const P=_probePoints();
 REG.forEach((r,i)=>{for(const p of P){const dx=p[0]-r.x,dz=p[2]-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p[1]>=(r.y||0)-2&&p[1]<=(r.y||0)+r.h+5)n[i]++;}});
 return REG.map((r,i)=>({name:r.name,type:r.type,n:n[i]}));}
function nanSweep(){const bad=[];let badInst=0;
 scene.traverse(o=>{if(!o.isMesh&&!o.isInstancedMesh)return;if(o.userData&&o.userData.probeSkip)return;
  const p=o.geometry&&o.geometry.attributes&&o.geometry.attributes.position;if(p){const a=p.array;for(let i=0;i<a.length;i++)if(!isFinite(a[i])){bad.push({geo:o.name||o.geometry.type,at:i});break;}}
  if(o.isInstancedMesh){const a=o.instanceMatrix.array;for(let i=0;i<a.length;i++)if(!isFinite(a[i])){badInst++;break;}}});
 return {meshes:bad.length,first:bad.slice(0,8),instances:badInst,firstInstances:[]};}
function typeStats(){const out={};for(const k in BIO.stats){const t=BIO.stats[k],cls=BUDGET.type[k]||'pass';out[k]={tris:t.tris,inst:t.inst,meshes:t.meshes,cls,limit:BUDGET.cls[cls],over:t.tris>BUDGET.cls[cls]};}return out;}
window._api={BUDGET,REG,
 get totals(){const t=BIO.totals();return {tris:t.tris,inst:t.inst,meshes:t.meshes,registered:REG.length,types:Object.keys(BIO.stats).length};},
 typeStats,regOccupancy,nanSweep,
 setView:(cx,cy,cz,tx,ty,tz)=>setView(cx,cy,cz,tx,ty,tz),views:()=>Object.keys(VIEWS),
 biome:()=>window._biome};
window._registered=REG.length;
