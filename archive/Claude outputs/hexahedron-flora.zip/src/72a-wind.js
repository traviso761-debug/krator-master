// ================================================================= WIND
// Ported from Girder's foliage sway (60-trees.js). Every leaf, frond, vine and
// trunk in the scene moves, and it costs nothing per frame but one uniform:
// the displacement is done in the vertex shader from a per-instance phase, so
// 30 000 plants animate without a single matrix being rewritten on the CPU.
//
// Three things this depends on, all verified in this kit before now:
//   - r128's project_vertex chunk is exactly the four lines replaced below;
//     the hook has to rebuild it rather than append, because the instance
//     matrix has to be applied BEFORE the displacement or every plant in a
//     cluster sways in lockstep.
//   - the phase comes from instanceMatrix[3].xyz -- the instance's own
//     translation -- so neighbours are out of step without any extra attribute.
//   - Material.clone() does NOT carry onBeforeCompile in r128, so these hooks
//     are applied to the shared materials themselves, not to copies.
//
// Amplitude scales with the instance's own scale (length of instanceMatrix[0]),
// or a 40 m canopy blob and a 3 m fern would move the same distance.
const WIND={t:{value:0}};
// `axis` picks which column of the instance matrix sets the amplitude. A crown
// clump is scaled evenly, so column 0 is its size; a hanging curtain is scaled
// thin in x and long in y, and reading its width would leave a 20 m vine
// trembling like a 1 m one. Hanging things pass 1.
function windHook(mat,swayW,swayA,name,axis){
 if(!mat)return;
 mat.onBeforeCompile=function(sh){
  sh.uniforms.uWindT=WIND.t;
  sh.vertexShader=sh.vertexShader
   .replace('#include <common>','#include <common>\nuniform float uWindT;')
   .replace('#include <project_vertex>',[
    'vec4 mvPosition = vec4( transformed, 1.0 );',
    'float _sc = 1.0; float _ph = 0.0;',
    '#ifdef USE_INSTANCING',
    '  mvPosition = instanceMatrix * mvPosition;',
    '  _ph = dot(instanceMatrix[3].xyz, vec3(0.131,0.073,0.117));',
    '  _sc = length(instanceMatrix['+(axis||0)+'].xyz);',
    '#endif',
    'float _wg = '+swayW+';',
    'mvPosition.xyz += _wg * _sc * vec3(',
    '   sin(uWindT*0.9+_ph) + 0.45*sin(uWindT*2.3+_ph*1.7+position.x*5.0),',
    '   0.40*sin(uWindT*1.6+_ph*0.6+position.z*5.0),',
    '   cos(uWindT*0.7+_ph*1.3) + 0.45*sin(uWindT*2.9+_ph+position.y*5.0) ) * '+swayA.toFixed(3)+';',
    'mvPosition = modelViewMatrix * mvPosition;',
    'gl_Position = projectionMatrix * mvPosition;'].join('\n'));
 };
 // different hooks on different materials need different cache keys, or three
 // will silently share one compiled program
 mat.customProgramCacheKey=function(){return 'wind_'+name;};
 mat.needsUpdate=true;
}
// MAT.vine backs both 'vine' (hangs from y=0 down to y=-1) and 'trunk' (stands
// from y=0 up to y=1). One weight of -position.y is correct for both: zero at
// the attached end, full at the free one.
windHook(MAT.vine,'(-position.y)',.085,'vine');
windHook(MAT.turf,'1.0',.050,'turf');
windHook(MAT.moss,'1.0',.022,'moss');
windHook(MAT.leaf,'1.0',.060,'leaf');
// FLORA's three foliage materials (71b-flora.js). Each carries a different
// weight because each is pinned at a different place: a curtain, a strand and
// an aerial root hang from y=0, a fern frond is clamped at its base and free
// at the tip, a flower is small and just trembles.
windHook(MAT.hang,'(-position.y)',.055,'hang',1);
windHook(MAT.frond,'(position.x)',.075,'frond');
windHook(MAT.bloom,'1.0',.050,'bloom');
tick(function(dt){WIND.t.value+=dt;});
