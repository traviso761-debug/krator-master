
// ==================== 10-core-head.js
// ================================================================= BIOME CORE — head
// The engine-independent kit every Krator biome fragment is written against.
// Nothing below names a world's kit. The host hands in what a biome needs
// through BIO.init(...) (see BIOME-API.md) and everything else lives here.
var BIO={host:null,stats:{},cur:null,version:'eastabyss-1'};
// EVERYTHING BELOW IS LOCAL. The core declares no generic global (rng, clamp,
// TAU...): a world that already has those would be clobbered. Biome fragments
// pull what they need from BIO.fn at the top of their own closure.
(function(){
const TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t, mix=lerp;
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};

// ---------------------------------------------------------------- PRNG
// The biome's OWN stream. A host that adds a biome must not see its rubble
// move, so the biome never draws from the host's generator.
let _bseed=1234567;
function reseed(s){_bseed=s>>>0;}
function rng(){_bseed|=0;_bseed=_bseed+0x6D2B79F5|0;let t=Math.imul(_bseed^_bseed>>>15,1|_bseed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}
function rr(a,b){return a+(b-a)*rng();}
function ri(a,b){return a+Math.floor(rng()*(b-a+1));}
function pick(arr){return arr[Math.floor(rng()*arr.length)%arr.length];}

// ---------------------------------------------------------------- noise
function h3(x,y,z){const s=Math.sin(x*12.9898+y*78.233+z*37.719)*43758.5453;return s-Math.floor(s);}
function vnoise(x,y,z){const xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),xf=x-xi,yf=y-yi,zf=z-zi;
 const sm=t=>t*t*(3-2*t);const u=sm(xf),v=sm(yf),w=sm(zf);const l=(a,b,t)=>a+(b-a)*t;
 return l(l(l(h3(xi,yi,zi),h3(xi+1,yi,zi),u),l(h3(xi,yi+1,zi),h3(xi+1,yi+1,zi),u),v),
          l(l(h3(xi,yi,zi+1),h3(xi+1,yi,zi+1),u),l(h3(xi,yi+1,zi+1),h3(xi+1,yi+1,zi+1),u),v),w);}
function fbm(x,y,z,o){o=o||3;let a=0,f=1,s=0;for(let i=0;i<o;i++){a+=vnoise(x*f,y*f,z*f)/f;s+=1/f;f*=2.03;}return a/s;}

// ---------------------------------------------------------------- host binding
// host = { THREE, scene, terrainH(x,z), mask(x,z), obstacles[], ticks(fn), seed,
//          origin[x,z], err(msg), stat(key,tris,inst) }
BIO.init=function(h){
 if(!h||!h.THREE)throw new Error('BIO.init: host needs THREE');
 // scene may arrive later (a world that creates its scene after its kit loads
 // calls BIO.setScene before build); it is only needed at bake
 BIO.host={
  THREE:h.THREE,scene:h.scene||null,
  terrainH:h.terrainH||((x,z)=>0),
  mask:h.mask||((x,z)=>1),
  obstacles:h.obstacles||[],
  ticks:h.ticks||(fn=>{}),
  seed:h.seed==null?1:h.seed,
  // origin: [x,z] or a LIST of [x,z] -- the LOD curve is measured from the
  // nearest one, so a long showcase (a lake shore, a river) can keep detail
  // along a spine instead of round one point. center: the disc the grids
  // cover (default: the first origin).
  origin:(h.origin&&typeof h.origin[0]==='number')?[h.origin]:(h.origin||[[0,0]]),
  center:h.center||null,
  // fields: optional climate fields a multi-zone biome asks for, each
  // (x,z)->0..1. Missing ones fall back to BIO.fieldDefault. wet: 0 arid ..
  // 1 saturated; salt: 0 .. 1 crust; upland: 0 basin floor .. 1 the high edge.
  fields:h.fields||{},
  err:h.err||(m=>console.error(m)),
  stat:h.stat||null};
 reseed(BIO.host.seed*7919+11);
 return BIO;};
BIO.setScene=function(s){BIO.host.scene=s;};
BIO.err=function(m){if(BIO.host)BIO.host.err(m);else console.error(m);};
BIO.terrainH=function(x,z){return BIO.host?BIO.host.terrainH(x,z):0;};
BIO.mask=function(x,z){return BIO.host?BIO.host.mask(x,z):1;};
// distance from the LOD origin, for the detail curve
BIO.lodD=function(x,z){const O=BIO.host?BIO.host.origin:[[0,0]];let m=1e9;for(let i=0;i<O.length;i++){const d=Math.hypot(x-O[i][0],z-O[i][1]);if(d<m)m=d;}return m;};
BIO.center=function(){const h=BIO.host;return h?(h.center||h.origin[0]):[0,0];};
BIO.fieldDefault={wet:(x,z)=>BIO.terrainH(x,z)<2?1:.6,salt:(x,z)=>0,upland:(x,z)=>0};
BIO.field=function(n,x,z){const f=BIO.host&&BIO.host.fields[n];return f?f(x,z):BIO.fieldDefault[n](x,z);};
// LOD is a CURVE, not two steps: full detail under ~700 m, a quarter by 3 km.
BIO.lod=function(x,z){return clamp(1.18-BIO.lodD(x,z)/2600,.22,1);};

// ---------------------------------------------------------------- accounting
// Every instance and merged triangle is charged to BIO.cur ('jungle/hyper',
// 'jungle/floor'...), so a probe can assert per-pass budgets.
BIO.tally=function(tris,inst,meshes){const k=BIO.cur||'biome';
 const t=BIO.stats[k]||(BIO.stats[k]={tris:0,inst:0,meshes:0});
 t.tris+=tris||0;t.inst+=inst||0;t.meshes+=meshes||0;
 if(BIO.host&&BIO.host.stat)BIO.host.stat(k,tris||0,inst||0);};
BIO.totals=function(){let tris=0,inst=0,meshes=0;for(const k in BIO.stats){tris+=BIO.stats[k].tris;inst+=BIO.stats[k].inst;meshes+=BIO.stats[k].meshes;}return{tris,inst,meshes};};

BIO.fn={TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm};
})();

// ==================== 20-core-kit.js
// ================================================================= BIOME CORE — kit
// Two ways to put geometry in the world, both cheap:
//   INSTANCED ITEMS   BIO.def(name,geo,mat) once, BIO.put(name,...) thousands of
//                     times, one InstancedMesh per item at bake. Per-instance
//                     colour, and optional per-instance extras (aN normal, aC2
//                     second colour) for the foliage shaders.
//   MERGED BUCKET     BIO.tri/quad/tube/lathe/surf write vertex-coloured
//                     triangles into a bucket per material family; one Mesh per
//                     family at bake. Boles, limbs, logs, boulders go here.
// Both are charged to BIO.cur by the accounting in 10-core-head.js.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm}=BIO.fn;
BIO.defs={};BIO.order=[];BIO.items={};
BIO.def=function(name,geo,mat,opt){opt=opt||{};
 if(BIO.defs[name])BIO.err('BIO.def: '+name+' defined twice');
 const g=geo.index?geo.toNonIndexed():geo;
 BIO.defs[name]={geo:g,mat,tris:g.attributes.position.count/3,attrs:opt.attrs||null,label:opt.label||name};
 BIO.items[name]={m:[],c:[],n:[],c2:[],count:0};BIO.order.push(name);};
const _bm=new (function(){return {}})();   // scratch holder, filled after THREE binds
BIO._scratch=function(){const T=BIO.host.THREE;if(!_bm.m){_bm.m=new T.Matrix4();_bm.q=new T.Quaternion();_bm.e=new T.Euler();_bm.p=new T.Vector3();_bm.s=new T.Vector3();_bm.c=new T.Color();_bm.up=new T.Vector3(0,1,0);_bm.v=new T.Vector3();}return _bm;};
// rotation helpers: qEuler(rx,ry,rz) or qFacing([nx,ny,nz]) (local +z toward n)
function qEuler(rx,ry,rz){const S=BIO._scratch();S.e.set(rx||0,ry||0,rz||0,'YXZ');return new BIO.host.THREE.Quaternion().setFromEuler(S.e);}
function qFacing(n){const T=BIO.host.THREE,v=new T.Vector3(n[0],n[1],n[2]).normalize();return new T.Quaternion().setFromUnitVectors(new T.Vector3(0,0,1),v);}
function qUp(n){const T=BIO.host.THREE,v=new T.Vector3(n[0],n[1],n[2]).normalize();return new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v);}
// put(name, [x,y,z], quat|null, [sx,sy,sz]|s, colour(hex|Color|null), extra{n:[..], c2:hex})
BIO.put=function(name,pos,q,sc,col,extra){
 const it=BIO.items[name];if(!it){BIO.err('BIO.put: no item '+name);return;}
 if(!(isFinite(pos[0])&&isFinite(pos[1])&&isFinite(pos[2]))){BIO.err('BIO.put: NaN position for '+name);return;}
 const S=BIO._scratch();
 S.p.set(pos[0],pos[1],pos[2]);
 if(typeof sc==='number')S.s.set(sc,sc,sc);else S.s.set(sc[0],sc[1],sc[2]);
 S.m.compose(S.p,q||S.q.set(0,0,0,1),S.s);
 const e=S.m.elements;for(let i=0;i<16;i++)it.m.push(e[i]);
 if(col==null)it.c.push(1,1,1);
 else{if(col.isColor)S.c.copy(col);else S.c.set(col);S.c.convertSRGBToLinear();it.c.push(S.c.r,S.c.g,S.c.b);}
 const def=BIO.defs[name];
 if(def.attrs){
  if(def.attrs.indexOf('aN')>=0){const n=(extra&&extra.n)||[0,1,0];it.n.push(n[0],n[1],n[2]);}
  if(def.attrs.indexOf('aC2')>=0){const c2=extra&&extra.c2;if(c2==null)it.c2.push(S.c.r,S.c.g,S.c.b);else{if(c2.isColor)S.c.copy(c2);else S.c.set(c2);S.c.convertSRGBToLinear();it.c2.push(S.c.r,S.c.g,S.c.b);}}}
 it.count++;BIO.tally(def.tris,1,0);};
// a beam of instanced item `name` (a unit cylinder along y, centred) from a to b
BIO.beam=function(name,a,b,r0,r1,col){const T=BIO.host.THREE,S=BIO._scratch();
 const dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],L=Math.hypot(dx,dy,dz);if(L<1e-4)return;
 S.v.set(dx/L,dy/L,dz/L);const q=new T.Quaternion().setFromUnitVectors(S.up,S.v);
 BIO.put(name,[(a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2],q,[r0*2,L,(r1==null?r0:r1)*2],col);};

// ---------------------------------------------------------------- merged buckets
BIO.buckets={};
BIO.bucket=function(fam,mat,opt){opt=opt||{};
 if(!BIO.buckets[fam])BIO.buckets[fam]={mat,pos:[],nor:[],uv:[],col:[],tris:0,label:opt.label||fam,uvScale:opt.uvScale||[3,3]};
 return BIO.buckets[fam];};
const _lc={r:1,g:1,b:1};
// COLOURS ARE sRGB IN, LINEAR OUT. r128 sends instance and vertex colours to
// the shader untouched, and the renderer encodes its output to sRGB, so a raw
// hex would render a stop too bright. Everything passed here is a designer's
// sRGB colour (hex, Color, or [r,g,b] already linear) and is converted once.
function _col3(c){const S=BIO._scratch();if(c==null)return[1,1,1];if(Array.isArray(c))return c;
 if(c.isColor)S.c.copy(c);else S.c.set(c);S.c.convertSRGBToLinear();return[S.c.r,S.c.g,S.c.b];}
// one triangle, flat normal unless `n` is given; a,b,c CCW from outside
BIO.tri=function(fam,a,b,c,col,n){const K=BIO.buckets[fam];if(!K){BIO.err('BIO.tri: no bucket '+fam);return;}
 let nx,ny,nz;if(n){nx=n[0];ny=n[1];nz=n[2];}else{const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  nx=uy*vz-uz*vy;ny=uz*vx-ux*vz;nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;}
 const cc=_col3(col);
 [a,b,c].forEach(p=>{K.pos.push(p[0],p[1],p[2]);K.nor.push(nx,ny,nz);K.uv.push(p[3]||0,p[4]||0);K.col.push(cc[0],cc[1],cc[2]);});
 K.tris++;BIO.tally(1,0,0);};
BIO.quad=function(fam,a,b,c,d,col){BIO.tri(fam,a,b,c,col);BIO.tri(fam,a,c,d,col);};
// TUBE along pts [{x,y,z,r,col?}], parallel-transport frames, constant texture
// repeat along the length (so a bole shows no shear bands where the radius
// changes). opt: seg, cap, rfn(i,ang,pt)->radius multiplier, vscale
BIO.tube=function(fam,pts,col,opt){opt=opt||{};const T=BIO.host.THREE,K=BIO.buckets[fam];if(!K){BIO.err('BIO.tube: no bucket '+fam);return 0;}
 const seg=opt.seg||8,sc=K.uvScale,n=pts.length;if(n<2)return 0;
 const Tn=[],N=[],Bn=[];
 for(let i=0;i<n;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(n-1,i+1)];Tn.push(new T.Vector3(b.x-a.x,b.y-a.y,b.z-a.z).normalize());}
 const ref=Math.abs(Tn[0].y)>.9?new T.Vector3(1,0,0):new T.Vector3(0,1,0);
 N[0]=new T.Vector3().crossVectors(Tn[0],ref).normalize();Bn[0]=new T.Vector3().crossVectors(Tn[0],N[0]).normalize();
 for(let j=1;j<n;j++){const nn=N[j-1].clone().sub(Tn[j].clone().multiplyScalar(N[j-1].dot(Tn[j]))).normalize();N[j]=nn;Bn[j]=new T.Vector3().crossVectors(Tn[j],nn).normalize();}
 const rt=pts[Math.min(n-1,Math.floor(n*.3))].r||1;   // one u-repeat count for the whole tube
 const rings=[];let vAcc=0;
 for(let q=0;q<n;q++){if(q>0)vAcc+=Math.hypot(pts[q].x-pts[q-1].x,pts[q].y-pts[q-1].y,pts[q].z-pts[q-1].z);
  const ring=[];const urep=Math.max(1,Math.round(TAU*rt/sc[0]));
  for(let s=0;s<=seg;s++){const ang=s/seg*TAU,rad=pts[q].r*(opt.rfn?opt.rfn(q,ang,pts[q]):1);
   const cx=Math.cos(ang),sx=Math.sin(ang);const nx=N[q].x*cx+Bn[q].x*sx,ny=N[q].y*cx+Bn[q].y*sx,nz=N[q].z*cx+Bn[q].z*sx;
   ring.push({p:[pts[q].x+nx*rad,pts[q].y+ny*rad,pts[q].z+nz*rad],n:[nx,ny,nz],uv:[s/seg*urep,vAcc/(opt.vscale||sc[1])]});}
  rings.push(ring);}
 const pv=(v,c)=>{K.pos.push(v.p[0],v.p[1],v.p[2]);K.nor.push(v.n[0],v.n[1],v.n[2]);K.uv.push(v.uv[0],v.uv[1]);K.col.push(c[0],c[1],c[2]);};
 const cc=_col3(col);let tris=0;
 for(let r2=0;r2<n-1;r2++){const c0=pts[r2].col!=null?_col3(pts[r2].col):cc,c1=pts[r2+1].col!=null?_col3(pts[r2+1].col):cc;
  for(let s2=0;s2<seg;s2++){const a0=rings[r2][s2],a1=rings[r2][s2+1],b0=rings[r2+1][s2],b1=rings[r2+1][s2+1];
   pv(a0,c0);pv(b1,c1);pv(b0,c1);pv(a0,c0);pv(a1,c0);pv(b1,c1);tris+=2;}}
 if(opt.cap){[[0,-1],[n-1,1]].forEach(e=>{const ri2=rings[e[0]],ctr=[pts[e[0]].x,pts[e[0]].y,pts[e[0]].z];
  for(let s3=0;s3<seg;s3++){if(e[1]>0)BIO.tri(fam,ctr,ri2[s3].p,ri2[s3+1].p,opt.capCol!=null?opt.capCol:col);else BIO.tri(fam,ctr,ri2[s3+1].p,ri2[s3].p,opt.capCol!=null?opt.capCol:col);}});}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};
// LATHE from rings [{x,y,z,yy,col}], radius rad(ring,ang), ambient-occlusion aof(ring,ang);
// true surface normals so fluting and buttress fins shade
BIO.lathe=function(fam,rings,seg,rep,vs,rad,aof){const K=BIO.buckets[fam];if(!K){BIO.err('BIO.lathe: no bucket '+fam);return 0;}
 const n=rings.length,P=[];
 for(let i=0;i<n;i++){const row=[];for(let s=0;s<seg;s++){const a=s/seg*TAU,r=rad(rings[i],a);row.push([rings[i].x+Math.cos(a)*r,rings[i].y,rings[i].z+Math.sin(a)*r]);}P.push(row);}
 const V=[];
 for(let i=0;i<n;i++){const vr=[],lc=_col3(rings[i].col);
  for(let s=0;s<=seg;s++){const s0=s%seg,pa=P[i][(s0+1)%seg],pb=P[i][(s0+seg-1)%seg],pu=P[Math.min(n-1,i+1)][s0],pd=P[Math.max(0,i-1)][s0];
   const ax=pa[0]-pb[0],ay=pa[1]-pb[1],az=pa[2]-pb[2],ux=pu[0]-pd[0],uy=pu[1]-pd[1],uz=pu[2]-pd[2];
   let nx=uy*az-uz*ay,ny=uz*ax-ux*az,nz=ux*ay-uy*ax;const nl=Math.hypot(nx,ny,nz)||1;const ao=aof?aof(rings[i],s0/seg*TAU):1;
   vr.push({p:P[i][s0],n:[nx/nl,ny/nl,nz/nl],u:s/seg*rep,v:rings[i].yy/vs,c:[lc[0]*ao,lc[1]*ao,lc[2]*ao]});}
  V.push(vr);}
 const pv=q=>{K.pos.push(q.p[0],q.p[1],q.p[2]);K.nor.push(q.n[0],q.n[1],q.n[2]);K.uv.push(q.u,q.v);K.col.push(q.c[0],q.c[1],q.c[2]);};
 let tris=0;
 for(let i=0;i<n-1;i++)for(let s=0;s<seg;s++){const a0=V[i][s],a1=V[i][s+1],b0=V[i+1][s],b1=V[i+1][s+1];pv(a0);pv(b1);pv(a1);pv(a0);pv(b0);pv(b1);tris+=2;}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};
// a parametric SURFACE fn(u,v)->[x,y,z] over nu x nv cells, smooth normals, uv scaled
BIO.surf=function(fam,fn,nu,nv,col,opt){opt=opt||{};const K=BIO.buckets[fam];if(!K){BIO.err('BIO.surf: no bucket '+fam);return 0;}
 const P=[];for(let i=0;i<=nu;i++){const row=[];for(let j=0;j<=nv;j++)row.push(fn(i/nu,j/nv));P.push(row);}
 const nrm=(i,j)=>{const a=P[Math.min(nu,i+1)][j],b=P[Math.max(0,i-1)][j],c=P[i][Math.min(nv,j+1)],d=P[i][Math.max(0,j-1)];
  const ux=a[0]-b[0],uy=a[1]-b[1],uz=a[2]-b[2],vx=c[0]-d[0],vy=c[1]-d[1],vz=c[2]-d[2];
  let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;return[nx/l,ny/l,nz/l];};
 const cc=_col3(col),uS=opt.uS||1,vS=opt.vS||1;let tris=0;
 const pv=(i,j)=>{const p=P[i][j],n=nrm(i,j);const c=opt.colFn?_col3(opt.colFn(i/nu,j/nv,p)):cc;
  K.pos.push(p[0],p[1],p[2]);K.nor.push(n[0],n[1],n[2]);K.uv.push(i/nu*uS,j/nv*vS);K.col.push(c[0],c[1],c[2]);};
 for(let i=0;i<nu;i++)for(let j=0;j<nv;j++){if(opt.hole&&opt.hole((i+.5)/nu,(j+.5)/nv))continue;
  pv(i,j);pv(i+1,j+1);pv(i+1,j);pv(i,j);pv(i,j+1);pv(i+1,j+1);tris+=2;}
 K.tris+=tris;BIO.tally(tris,0,0);return tris;};

// ---------------------------------------------------------------- bake
// Turns the stores into meshes. Call once per host after every biome has
// built; a second call only emits what arrived since the first.
BIO.baked=[];
BIO.bake=function(){const T=BIO.host.THREE,scene=BIO.host.scene;if(!scene)throw new Error('BIO.bake: no scene (BIO.init({scene}) or BIO.setScene first)');let calls=0,inst=0;
 for(const name of BIO.order){const it=BIO.items[name];if(!it.count)continue;const def=BIO.defs[name];
  const geo=def.geo.clone();
  if(def.attrs&&it.n.length)geo.setAttribute('aN',new T.InstancedBufferAttribute(new Float32Array(it.n),3));
  if(def.attrs&&it.c2.length)geo.setAttribute('aC2',new T.InstancedBufferAttribute(new Float32Array(it.c2),3));
  const im=new T.InstancedMesh(geo,def.mat,it.count);
  im.instanceMatrix.array.set(it.m);im.instanceMatrix.needsUpdate=true;
  im.instanceColor=new T.InstancedBufferAttribute(new Float32Array(it.c),3);
  im.frustumCulled=false;im.userData.biome=true;im.userData.inspectLabel=def.label;im.name='biome:'+name;
  scene.add(im);BIO.baked.push(im);calls++;inst+=it.count;
  BIO.items[name]={m:[],c:[],n:[],c2:[],count:0};}
 for(const fam in BIO.buckets){const K=BIO.buckets[fam];if(!K.pos.length)continue;
  const g=new T.BufferGeometry();
  g.setAttribute('position',new T.Float32BufferAttribute(K.pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(K.nor,3));
  g.setAttribute('uv',new T.Float32BufferAttribute(K.uv,2));g.setAttribute('color',new T.Float32BufferAttribute(K.col,3));
  g.computeBoundingSphere();
  const m=new T.Mesh(g,K.mat);m.frustumCulled=false;m.userData.biome=true;m.userData.inspectLabel=K.label;m.name='biome:'+fam;
  scene.add(m);BIO.baked.push(m);calls++;
  K.pos=[];K.nor=[];K.uv=[];K.col=[];}
 BIO.lastBake={calls,inst};return BIO.lastBake;};

Object.assign(BIO.fn,{qEuler,qFacing,qUp});
})();

// ==================== 30-core-foliage.js
// ================================================================= BIOME CORE — foliage
// What makes a card read as leaves. Ported from Girder's 60-trees.js and the
// Hexahedron's 71b-flora.js, with the three lessons those cost:
//   - LAMBERT, never Standard: a Standard card keeps a 4% specular at any
//     roughness and goes white at grazing angles, i.e. from under the canopy.
//   - two-sided light MIX, not a flip: a leaf seen from below is a lit,
//     translucent leaf, not the ground-hemisphere shadow a flipped normal gives.
//   - low-alpha texels carry the species' MID colour, or mipmapping bleeds a
//     black fringe round every leaf at distance; and alpha is boosted with
//     distance, or the far canopy thins to lace.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
BIO.WIND={t:{value:0}};
BIO.SUN={value:null};                 // set by BIO.setSun([x,y,z]); defaults at first use
BIO.setSun=function(v){const T=BIO.host.THREE;if(!BIO.SUN.value)BIO.SUN.value=new T.Vector3();BIO.SUN.value.set(v[0],v[1],v[2]).normalize();};
BIO._windTicked=false;
BIO._tickWind=function(){if(BIO._windTicked)return;BIO._windTicked=true;BIO.host.ticks(dt=>{BIO.WIND.t.value+=dt;});};

// ---------------------------------------------------------------- alpha textures
// draw(g,S) paints GREYSCALE leaves on a transparent canvas; the material's
// per-instance colour tints them. fillRGB fills the transparent texels.
BIO.alphaTex=function(S,draw,fillRGB){const T=BIO.host.THREE;
 const c=document.createElement('canvas');c.width=c.height=S;const g=c.getContext('2d');g.clearRect(0,0,S,S);draw(g,S);
 const d=g.getImageData(0,0,S,S).data,out=new Uint8Array(S*S*4);
 for(let o=0;o<out.length;o+=4){const a=d[o+3];
  if(a<48){out[o]=fillRGB[0];out[o+1]=fillRGB[1];out[o+2]=fillRGB[2];}else{out[o]=d[o];out[o+1]=d[o+1];out[o+2]=d[o+2];}
  out[o+3]=a;}
 const t=new T.DataTexture(out,S,S,T.RGBAFormat);
 t.encoding=T.sRGBEncoding;t.generateMipmaps=true;t.minFilter=T.LinearMipmapLinearFilter;t.magFilter=T.LinearFilter;
 t.anisotropy=4;t.needsUpdate=true;t.wrapS=t.wrapT=T.RepeatWrapping;return t;};
// a COLOUR canvas texture (bark, ground), repeat-wrapped
BIO.canvasTex=function(w,h,fn,rep){const T=BIO.host.THREE;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');fn(g,w,h);
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=8;t.encoding=T.sRGBEncoding;if(rep)t.repeat.set(rep,rep);return t;};
// drawing helpers for leaf textures
BIO.tex={
 grey(l){l=clamp(Math.round(l),0,255);return'rgb('+l+','+l+','+l+')';},
 leaf(g,x,y,len,wid,ang,lum,rib){g.save();g.translate(x,y);g.rotate(ang);
  g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.45,wid,len,0);g.quadraticCurveTo(len*.45,-wid,0,0);g.fill();
  if(rib){g.strokeStyle=BIO.tex.grey(lum*.72);g.lineWidth=1;g.beginPath();g.moveTo(0,0);g.lineTo(len*.92,0);g.stroke();}
  g.restore();},
 cl:[],
 clusters(S,n,k){BIO.tex.cl=[];for(let i=0;i<n;i++){const a=i/n*TAU+rr(-.3,.3),r=S*.5*k*(i%3===0?rr(0,.35):rr(.55,1));BIO.tex.cl.push([S/2+Math.cos(a)*r,S/2+Math.sin(a)*r]);}},
 clPt(S,sd,lim){const c=pick(BIO.tex.cl),a=rr(0,TAU),r=sd*S*Math.sqrt(-2*Math.log(1-rng()*.98))*.6;
  let x=c[0]+Math.cos(a)*r,y=c[1]+Math.sin(a)*r;const d=Math.hypot(x-S/2,y-S/2),m=S*.5*lim;if(d>m){x=S/2+(x-S/2)*m/d;y=S/2+(y-S/2)*m/d;}
  return[x,y,Math.atan2(y-c[1],x-c[0])];},
 discPt(S,k){const a=rr(0,TAU),r=S*.5*k*Math.sqrt(rng());return[S/2+Math.cos(a)*r,S/2+Math.sin(a)*r,a];}
};

// ---------------------------------------------------------------- card geometries
BIO.geo={};
// leaf clump: a tripod of three tilted unit quads
BIO.geo.clump=function(){const T=BIO.host.THREE,pos=[],uv=[],nor=[];
 for(let k=0;k<3;k++){const az=k/3*TAU+.3,tilt=.92,ca=Math.cos(az),sa=Math.sin(az);
  const n=[Math.sin(tilt)*ca,Math.cos(tilt),Math.sin(tilt)*sa],u=[-sa,0,ca],v=[-Math.cos(tilt)*ca,Math.sin(tilt),-Math.cos(tilt)*sa];
  const c=[n[0]*.10,n[1]*.10-.04,n[2]*.10];
  const P=[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]].map(q=>[c[0]+u[0]*q[0]+v[0]*q[1],c[1]+u[1]*q[0]+v[1]*q[1],c[2]+u[2]*q[0]+v[2]*q[1],q[0]+.5,q[1]+.5]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(n[0],n[1],n[2]);});}
 return BIO.geo._make(pos,nor,uv);};
BIO.geo._make=function(pos,nor,uv,col){const T=BIO.host.THREE,g=new T.BufferGeometry();
 g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('normal',new T.Float32BufferAttribute(nor,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
 if(col)g.setAttribute('color',new T.Float32BufferAttribute(col,3));return g;};
// hanging raceme / strand: two crossed quads, local y 0 (hung) .. -1
BIO.geo.hang=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<2;k++){const ca=Math.cos(k*Math.PI/2+.4),sa=Math.sin(k*Math.PI/2+.4);
  const P=[[-.5,0],[.5,0],[.5,-1],[-.5,-1]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,-q[1]]);
  [0,2,1,0,3,2].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a hanging RIBBON: origin at the top, running down to y=-1 in nseg tapering
// quads, drifting in z so a curtain of them is not a plank; texture repeats
// once per segment so a long one reads as a chain of leaves
BIO.geo.ribbon=function(nseg,taper,drift){const pos=[],uv=[],nor=[];nseg=nseg||4;taper=taper==null?.55:taper;drift=drift==null?.18:drift;
 const P=[];for(let i=0;i<=nseg;i++){const t=i/nseg,w=.5*lerp(1,taper,t),z=Math.sin(t*3.1)*drift;P.push([-w,-t,z],[w,-t,z]);}
 for(let i=0;i<nseg;i++){const a=P[2*i],b=P[2*i+1],c=P[2*i+2],d=P[2*i+3];
  [[a,0,0],[c,0,1],[b,1,0],[b,1,0],[c,0,1],[d,1,1]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,0,1);});}
 return BIO.geo._make(pos,nor,uv);};
// an arching FROND: pinned at the origin, arching along +x to x=1 and down
BIO.geo.frond=function(nseg){const pos=[],uv=[],nor=[];nseg=nseg||3;
 const P=[];for(let i=0;i<=nseg;i++){const t=i/nseg,w=.16*Math.sin(t*Math.PI)*.9+.02,y=.32*Math.sin(t*2.2)-.22*t*t;P.push([t,y,-w],[t,y,w]);}
 for(let i=0;i<nseg;i++){const a=P[2*i],b=P[2*i+1],c=P[2*i+2],d=P[2*i+3];
  [[a,0,0],[b,1,0],[c,0,1],[b,1,0],[d,1,1],[c,0,1]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a MOSS MAT: a fan of quads in the xz plane, front face UP (winding matters:
// the Hexahedron lost 18k of these to a reversed fan). Flip pi about x for a soffit.
BIO.geo.mat=function(){const pos=[],uv=[],nor=[];const N=7;
 for(let s=0;s<N;s++){const a0=s/N*TAU,a1=(s+1)/N*TAU,r0=rr(.7,1),r1=rr(.7,1);
  const A=[0,0,0],B=[Math.cos(a0)*r0,rr(0,.08),Math.sin(a0)*r0],C=[Math.cos(a1)*r1,rr(0,.08),Math.sin(a1)*r1];
  [[A,.5,.5],[C,.5+C[0]*.5,.5+C[2]*.5],[B,.5+B[0]*.5,.5+B[2]*.5]].forEach(q=>{pos.push(q[0][0],q[0][1],q[0][2]);uv.push(q[1],q[2]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a BUSH LOBE: a squat 6-sided dome, origin at the ground
BIO.geo.lobe=function(){const T=BIO.host.THREE;const g=new T.SphereGeometry(1,7,4,0,TAU,0,Math.PI*.55);g.scale(1,.8,1);return g;};
// a BLOOM: a diamond of two quads, origin at the centre
BIO.geo.bloom=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<2;k++){const ca=Math.cos(k*Math.PI/2),sa=Math.sin(k*Math.PI/2);
  const P=[[-.5,0],[0,.5],[.5,0],[0,-.5]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,q[1]+.5]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a POD on its stalk: local y 0 (hung) .. -1, vertex-coloured (stalk dark, pod white)
BIO.geo.pod=function(){const T=BIO.host.THREE;
 const parts=[[new T.CylinderGeometry(.012,.012,.5,3,1,true).translate(0,-.25,0),.16],[new T.SphereGeometry(.15,6,4).scale(1,1.75,1).translate(0,-.735,0),1]];
 const pos=[],nor=[],col=[],uv=[];
 parts.forEach(p=>{const g=p[0].toNonIndexed(),a=g.attributes.position.array,b=g.attributes.normal.array,u=g.attributes.uv.array;
  for(let i=0;i<a.length;i+=3){pos.push(a[i],a[i+1],a[i+2]);nor.push(b[i],b[i+1],b[i+2]);
   const sh=p[1]===1?(.78+.22*Math.sin(Math.atan2(a[i+2],a[i])*5))*lerp(.72,1,clamp((a[i+1]+1)/.5,0,1)):p[1];col.push(sh,sh,sh);}
  for(let j=0;j<u.length;j++)uv.push(u[j]);});
 return BIO.geo._make(pos,nor,uv,col);};
// a unit cylinder along y, centred (for BIO.beam)
BIO.geo.rod=function(n){const T=BIO.host.THREE;return new T.CylinderGeometry(.5,.5,1,n||7);};
// a tapering trunk from y=0 up to y=1
BIO.geo.trunk=function(n){const T=BIO.host.THREE;return new T.CylinderGeometry(.16,.4,1,n||8).translate(0,.5,0);};

// ---------------------------------------------------------------- the foliage hook
// o: { aN:bool, irid:bool, swayW:'glsl expr', swayA:0.2, axis:0|1, dist:bool }
//   swayW  weight of the displacement per vertex: '1.0' for a clump, '(-position.y)'
//          for something hung from y=0, '(position.x)' for a frond pinned at x=0
//   axis   which instanceMatrix column sets the amplitude (1 for a long thin hang)
BIO.foliageHook=function(o){o=o||{};
 return function(sh){
  sh.uniforms.uWindT=BIO.WIND.t;
  if(!BIO.SUN.value)BIO.setSun([.45,.72,-.52]);
  sh.uniforms.uSunDir=BIO.SUN;
  sh.vertexShader=sh.vertexShader
   .replace('#include <common>','#include <common>\nuniform float uWindT;\nvarying vec3 vFlWP;\nvarying float vFlD;\n'+
    (o.aN?'attribute vec3 aN;\nvarying vec3 vFlN;\n':'')+(o.irid?'attribute vec3 aC2;\nvarying vec3 vFlC2;\n':''))
   .replace('#include <project_vertex>',[
    'vec4 mvPosition = vec4( transformed, 1.0 );',
    'float _sc = 1.0; float _ph = 0.0;',
    '#ifdef USE_INSTANCING',
    '  mvPosition = instanceMatrix * mvPosition;',
    '  _ph = dot(instanceMatrix[3].xyz, vec3(0.131,0.073,0.117));',
    '  _sc = length(instanceMatrix['+(o.axis||0)+'].xyz);',
    '#endif',
    'float _wg = '+(o.swayW||'1.0')+';',
    'mvPosition.xyz += _wg * _sc * vec3(',
    '   sin(uWindT*0.9+_ph) + 0.45*sin(uWindT*2.3+_ph*1.7+position.x*5.0),',
    '   0.40*sin(uWindT*1.6+_ph*0.6+position.z*5.0),',
    '   cos(uWindT*0.7+_ph*1.3) + 0.45*sin(uWindT*2.9+_ph+position.y*5.0) ) * '+(o.swayA==null?.06:o.swayA).toFixed(3)+';',
    'vFlWP = (modelMatrix * mvPosition).xyz;',
    o.aN?'vFlN = aN;':'',o.irid?'vFlC2 = aC2;':'',
    'mvPosition = modelViewMatrix * mvPosition;',
    'vFlD = -mvPosition.z;',
    'gl_Position = projectionMatrix * mvPosition;'].join('\n'));
  // the lighting normal: the clump's own (aN, world space, so it shades as a
  // lit mass), or the card normal bent toward world-up for anything without one
  if(o.aN)sh.vertexShader=sh.vertexShader.replace('#include <defaultnormal_vertex>','vec3 transformedNormal = normalize(normalMatrix * aN);');
  else sh.vertexShader=sh.vertexShader.replace('#include <defaultnormal_vertex>','#include <defaultnormal_vertex>\n'+
   '{vec3 _up=normalize(normalMatrix*vec3(0.0,1.0,0.0)); transformedNormal=normalize(mix(normalize(transformedNormal),_up,0.45));}');
  sh.fragmentShader=sh.fragmentShader
   .replace('#include <common>','#include <common>\nuniform float uWindT;\nuniform vec3 uSunDir;\nvarying vec3 vFlWP;\nvarying float vFlD;\n'+
    (o.aN?'varying vec3 vFlN;\n':'')+(o.irid?'varying vec3 vFlC2;\n':''))
   .replace('#include <map_fragment>','#include <map_fragment>\n diffuseColor.a *= 1.0 + clamp(vFlD/650.0, 0.0, 1.1);')
   .replace('reflectedLight.indirectDiffuse += ( gl_FrontFacing ) ? vIndirectFront : vIndirectBack;','reflectedLight.indirectDiffuse += 0.72*vIndirectFront + 0.28*vIndirectBack;')
   .replace('reflectedLight.directDiffuse = ( gl_FrontFacing ) ? vLightFront : vLightBack;','reflectedLight.directDiffuse = vLightFront + 0.30*vLightBack;');
  // IRIDESCENCE (prism gum): green facing the sun, the second colour away from
  // it and at grazing view angles, shimmering slowly in the wind
  if(o.irid)sh.fragmentShader=sh.fragmentShader.replace('#include <color_fragment>',[
   '#include <color_fragment>',
   '{ vec3 _V = normalize(cameraPosition - vFlWP); vec3 _N = normalize('+(o.aN?'vFlN':'vec3(0.0,1.0,0.0)')+');',
   '  float _fr = 1.0 - abs(dot(_N,_V));',
   '  float _sf = dot(_N, uSunDir)*0.5 + 0.5;',
   '  float _sh = 0.16*sin(uWindT*0.8 + dot(vFlWP, vec3(0.045,0.083,0.037))) + 0.08*sin(uWindT*1.9 + dot(vFlWP, vec3(-0.21,0.13,0.17)));',
   '  float _k = smoothstep(0.22, 0.78, _sf*1.15 - _fr*0.80 + 0.30 + _sh);',
   '  diffuseColor.rgb *= mix(vFlC2, vColor, _k) / max(vColor, vec3(0.004)); }'].join('\n'));
 };};
// a foliage MATERIAL: Lambert, alpha-tested, double-sided, hooked. Each key
// compiles its own program (different hooks on different materials need
// different cache keys or three silently shares one).
BIO.leafMat=function(tex,key,o){const T=BIO.host.THREE;o=o||{};
 const m=new T.MeshLambertMaterial({color:0xffffff,map:tex||null,alphaTest:o.alphaTest==null?.42:o.alphaTest,side:T.DoubleSide,vertexColors:!!o.vertexColors});
 m.onBeforeCompile=BIO.foliageHook(o);m.customProgramCacheKey=function(){return'biofol|'+key;};
 BIO._tickWind();return m;};
// a BARK / WOOD material for merged buckets: Lambert, vertex-coloured, textured
BIO.barkMat=function(tex,col){const T=BIO.host.THREE;return new T.MeshLambertMaterial({color:col==null?0xffffff:col,map:tex||null,vertexColors:true,side:T.DoubleSide});};
// a plain material for instanced solids (rods, lobes, boulders)
BIO.solidMat=function(tex,col){const T=BIO.host.THREE;return new T.MeshLambertMaterial({color:col==null?0xffffff:col,map:tex||null,side:T.DoubleSide});};

})();

// ==================== 40-core-place.js
// ================================================================= BIOME CORE — placement
// Where things go. Ported from the Hexahedron's forest rebuild (the forest is
// PLACEMENT, not plants) and Girder's keep-clear tests.

// SPECIES COME IN STANDS. A per-tree random draw mixes species so evenly the
// eye integrates them back into one colour; an fbm patch field a few hundred
// metres across picks a dominant species with a fraction off-pattern.
// fbm is bell-shaped (mean .5, sd ~.11): splitting its raw value n ways gave
// 1/27/53/20 % for four species. The value is stretched through the middle of
// the bell first so the n bands come out roughly even.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
BIO.standAt=function(x,z,n,scale,seed){scale=scale||.0017;const f=fbm(x*scale+31,z*scale-19,seed||9483,2);
 const u=smooth(.30,.70,f);return clamp(Math.floor(u*n),0,n-1);};
BIO.stand=function(x,z,n,off,scale,seed){return rng()<(off==null?.26:off)?Math.floor(rng()*n):BIO.standAt(x,z,n,scale,seed);};

// A JITTERED GRID over a disc [rIn,rOut] round the origin: one candidate per
// cell, jittered, tested against the host mask, an fbm patch mask (the floor
// is patchy) and `accept(x,z,d)->0..1`. Even coverage with no clumps of
// rejection-sampling luck, and the count is predictable from the cell size.
BIO.grid=function(cell,rIn,rOut,accept,fn,opt){opt=opt||{};const o=opt.center||BIO.center(),N=Math.ceil(rOut*2/cell);let n=0;
 const pk=opt.patch==null?.85:opt.patch,ps=opt.patchScale||.016;
 const B=opt.box;   // optional [x0,z0,x1,z1] window (a zone strip); cells outside it cost nothing
 let ix0=0,ix1=N-1,iz0=0,iz1=N-1;
 if(B){ix0=Math.max(0,Math.floor((B[0]-(o[0]-rOut))/cell));ix1=Math.min(N-1,Math.ceil((B[2]-(o[0]-rOut))/cell));iz0=Math.max(0,Math.floor((B[1]-(o[1]-rOut))/cell));iz1=Math.min(N-1,Math.ceil((B[3]-(o[1]-rOut))/cell));}
 for(let iz=iz0;iz<=iz1;iz++)for(let ix=ix0;ix<=ix1;ix++){
  const x=o[0]-rOut+(ix+rng())*cell,z=o[1]-rOut+(iz+rng())*cell,u=rng();
  if(B&&(x<B[0]||z<B[1]||x>B[2]||z>B[3]))continue;
  const d=Math.hypot(x-o[0],z-o[1]);if(d<rIn||d>rOut)continue;
  const m=opt.noMask?1:BIO.mask(x,z);if(m<=0)continue;
  const patch=pk>0?(1-pk*.5)+pk*fbm(x*ps+7,z*ps-3,9484,2):1;
  const a=accept?accept(x,z,d):1;
  if(u>a*m*clamp(patch,0,1.15))continue;
  if(!BIO.clearOf(x,z,opt.pad||0))continue;
  fn(x,BIO.terrainH(x,z),z,d);n++;}
 return n;};
// POISSON-ish scatter of n points with a minimum spacing, area-uniform in the
// annulus, biased outward by `pow` (>1 pushes the crowd out)
BIO.scatter=function(n,rIn,rOut,minD,fn,opt){opt=opt||{};const o=opt.center||BIO.center(),P=[];let tries=0;
 while(P.length<n&&tries++<n*40){const a=rng()*TAU,u=Math.pow(rng(),opt.pow||1);
  const r=Math.sqrt(lerp(rIn*rIn,rOut*rOut,u)),x=o[0]+Math.cos(a)*r,z=o[1]+Math.sin(a)*r;
  if(rng()>BIO.mask(x,z))continue;if(!BIO.clearOf(x,z,opt.pad||0))continue;
  let ok=true;for(const q of P)if(Math.hypot(x-q[0],z-q[1])<minD){ok=false;break;}
  if(!ok)continue;P.push([x,z]);fn(x,BIO.terrainH(x,z),z,r);}
 return P;};
// keep-clear: outside every host obstacle cylinder (plus pad), on the ground
BIO.clearOf=function(x,z,pad){const O=BIO.host.obstacles;pad=pad||0;
 for(let i=0;i<O.length;i++){const q=O[i];if(Math.hypot(x-q.x,z-q.z)<q.r+pad)return false;}return true;};
// keep-clear in 3D: a blob of horizontal radius rad, half-height vr at (x,y,z)
BIO.clearOf3=function(x,y,z,rad,vr){const O=BIO.host.obstacles;
 for(let i=0;i<O.length;i++){const q=O[i];if(q.y0!=null&&(y+vr<q.y0||y-vr>q.y1))continue;
  if(Math.hypot(x-q.x,z-q.z)<q.r+rad)return false;}return true;};

// ---------------------------------------------------------------- surface sampling
// For growing on a structure the host hands over as BufferGeometry[] in world
// space. Samples by triangle area, then filters by facing:
//   upFaces    normal.y > minUp   (ledges, treads, roofs)      -> moss, plants
//   downFaces  normal.y < -minDown (soffits, ceilings)          -> mats, curtains
//   sideFaces  |normal.y| < .35                                 -> vines, brackets
// Each sample: {p:[x,y,z], n:[nx,ny,nz], a:area}
BIO.faceSamples=function(geos,n,filt){const out=[];const F=[];let tot=0;
 for(const g of geos){const p=g.attributes.position;if(!p)continue;const idx=g.index?g.index.array:null;const cnt=idx?idx.length:p.count;
  for(let i=0;i<cnt;i+=3){const a=idx?idx[i]:i,b=idx?idx[i+1]:i+1,c=idx?idx[i+2]:i+2;
   const ax=p.getX(a),ay=p.getY(a),az=p.getZ(a),bx=p.getX(b),by=p.getY(b),bz=p.getZ(b),cx=p.getX(c),cy=p.getY(c),cz=p.getZ(c);
   const ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az;
   let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz);if(l<1e-9)continue;nx/=l;ny/=l;nz/=l;
   if(filt&&!filt(nx,ny,nz))continue;
   const ar=l*.5;tot+=ar;F.push([ax,ay,az,bx,by,bz,cx,cy,cz,nx,ny,nz,ar,tot]);}}
 if(!F.length)return out;
 for(let k=0;k<n;k++){const r=rng()*tot;let lo=0,hi=F.length-1;while(lo<hi){const m=(lo+hi)>>1;if(F[m][13]<r)lo=m+1;else hi=m;}
  const f=F[lo];let u=rng(),v=rng();if(u+v>1){u=1-u;v=1-v;}const w=1-u-v;
  out.push({p:[f[0]*w+f[3]*u+f[6]*v,f[1]*w+f[4]*u+f[7]*v,f[2]*w+f[5]*u+f[8]*v],n:[f[9],f[10],f[11]],a:f[12]});}
 return out;};
BIO.upFaces=function(geos,n,minUp){return BIO.faceSamples(geos,n,(nx,ny,nz)=>ny>(minUp==null?.62:minUp));};
BIO.downFaces=function(geos,n,minDown){return BIO.faceSamples(geos,n,(nx,ny,nz)=>ny<-(minDown==null?.62:minDown));};
BIO.sideFaces=function(geos,n){return BIO.faceSamples(geos,n,(nx,ny,nz)=>Math.abs(ny)<.35);};
// LEDGE POINTS: the outer edges of up-facing faces -- where a vine roots and
// hangs off. Found as up-face samples that have empty air just outboard of them
// (no up-face within `gap` metres in the direction away from the surface's centroid).
BIO.ledgePoints=function(geos,n,gap){gap=gap||2.5;const S=BIO.upFaces(geos,n*4,.62);if(!S.length)return[];
 let cx=0,cz=0;S.forEach(s=>{cx+=s.p[0];cz+=s.p[2];});cx/=S.length;cz/=S.length;
 const cell=gap,H={};const key=(x,y,z)=>(Math.floor(x/cell))+','+(Math.floor(y/(cell*2)))+','+(Math.floor(z/cell));
 S.forEach(s=>{H[key(s.p[0],s.p[1],s.p[2])]=1;});
 const out=[];
 for(const s of S){if(out.length>=n)break;const dx=s.p[0]-cx,dz=s.p[2]-cz,l=Math.hypot(dx,dz)||1;const ox=dx/l,oz=dz/l;
  if(!H[key(s.p[0]+ox*gap,s.p[1],s.p[2]+oz*gap)])out.push({p:s.p,n:[ox,0,oz]});}
 return out;};

})();

// ==================== 45-host-stage.js
// ================================================================= HOST — stage
// The ideal-type host for the NORTHWESTERN LOWLANDS: renderer, lights, fog, the terrain
// with terrainH(), the climate fields the biome asks for, the water (one plane at y=0
// for the lake, the lowland river and the ponds, a ribbon where the river comes down out
// of the foothills), the painted ground, the road, the tick list, the error panel. A real
// world replaces this whole section; the biome reads it only through BIO.host.
//
// THE MAP (x east, z south, origin mid-lowland, R 3000). One axis does the work: s runs
// NW -> SE (s=(x+z)/sqrt2), t across it toward the NE. We are in Krator's NW quadrant:
// the great LAKE lies to the NW with the Outer Wall far beyond it; the Inner Wall's
// mountains rise to the SE; the country is OPEN to the NE and SW.
//   s < ~-1900        the LAKE (jade over sand; coves; a river mouth)
//   -1900 .. -1250    a brief strip of RAINFOREST at the shore, paperbark swamps, lotus ponds
//   -1250 .. +900     the long HUMID SUBTROPICAL tract: gums, kauri, birch and cedar
//                     stands, bamboo groves by the water
//   +900 .. +3000     MEDITERRANEAN foothills climbing toward the Inner Wall (to ~350 m)
const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,fbm,qEuler,qFacing,qUp}=BIO.fn;
const ERRS=document.getElementById('errs');
function reportErr(m){ERRS.style.display='block';ERRS.textContent+=m+'\n';}
window.onerror=(m,s,l,c,e)=>reportErr((e&&e.stack)||(m+' @'+l+':'+c));
window.addEventListener('unhandledrejection',e=>reportErr('promise: '+(e.reason&&e.reason.stack||e.reason)));
const TICKS=[];
function tick(fn){TICKS.push(fn);}
const REG=[];function REGISTER(o){REG.push(o);}

const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.04;document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();const HAZE=new THREE.Color(0xc6ccc0);scene.fog=new THREE.FogExp2(HAZE.getHex(),.00020);
const camera=new THREE.PerspectiveCamera(50,innerWidth/innerHeight,1,14000);
scene.add(new THREE.HemisphereLight(0xc8d4d0,0x4a4030,.62));
const sun=new THREE.DirectionalLight(0xfff0d2,1.45);sun.position.set(-1200,900,-600);scene.add(sun);   // WNW, over the sea
const fill=new THREE.DirectionalLight(0xb4cec4,.30);fill.position.set(800,400,900);scene.add(fill);

// ---------------------------------------------------------------- the axis, the sea, the river
const TERR={R:3000};
const RT2=Math.SQRT1_2;
const sOf=(x,z)=>(x+z)*RT2, tOf=(x,z)=>(x-z)*RT2;
const xzOf=(s,t)=>[(s+t)*RT2,(s-t)*RT2];
// the zone coordinate: s, wobbled along t so no boundary is a ruled line
function sw(x,z){const t=tOf(x,z);return sOf(x,z)+110*Math.sin(t*.0012+.4)+45*Math.sin(t*.0041);}
// the shore: s of the waterline as a function of t (coves and a delta bulge)
function shoreS(t){return -1900+170*(fbm(t*.0011+3,1.7,41,3)-.5)*2+40*Math.sin(t*.006)+90*smooth(420,60,Math.abs(t-RIVER_T(-1900)));}
// signed distance-ish to the shore in metres, negative out in the sea
function seaIn(x,z){const t=tOf(x,z);return sOf(x,z)-shoreS(t);}
// the river: t as a function of s, meandering down from the SE hills to the delta
function RIVER_T(s){return -120+260*Math.sin(s*.00115+.6)+90*Math.sin(s*.0043+1.3)+30*Math.sin(s*.011);}
function riverD(x,z){const s=sOf(x,z),t=tOf(x,z);if(s>TERR.R*1.2)return 1e9;
 let d=Math.abs(t-RIVER_T(s));
 // the delta: two distributaries fan out over the last 500 m
 const sh=shoreS(RIVER_T(s)),f=smooth(sh+520,sh+40,s);
 if(f>0){d=Math.min(d,Math.abs(t-(RIVER_T(s)+f*210)),Math.abs(t-(RIVER_T(s)-f*170)));}
 return d;}
// the river's width grows toward the sea
function riverW(x,z){const s=sOf(x,z);return mix(9,26,smooth(1800,-1500,s));}
// a bayou: sloughs and pools in the coastal lowland, oxbow ponds up the valley
function swampK(x,z){const s=sw(x,z),sh=shoreS(tOf(x,z));return smooth(-1050,-1350,s)*smooth(sh+10,sh+90,sOf(x,z));}
// THE GHOST-GUM AVENUE: a pale road across the plain toward the tower, t as a function of s.
// The host owns the road; the biome plants its two rows (NWLOW.build({avenues})).
const ROAD_S=[-1000,-420];
function ROAD_T(s){return 300+22*Math.sin(s*.006);}
function roadD(x,z){const s=sOf(x,z),t=tOf(x,z);if(s<ROAD_S[0]-60||s>ROAD_S[1]+60||Math.abs(t-300)>90)return 1e9;
 const sc=clamp(s,ROAD_S[0],ROAD_S[1]),slope=22*.006*Math.cos(sc*.006);return Math.hypot(s-sc,(t-ROAD_T(sc))/Math.sqrt(1+slope*slope));}
const ROAD=[];for(let s=ROAD_S[0];s<=ROAD_S[1]+.1;s+=20)ROAD.push(xzOf(s,ROAD_T(s)));
// ---------------------------------------------------------------- terrain
function baseH(x,z){const s=sw(x,z);
 // the lowland shelf, the long subtropical rise, then the foothills of the Inner Wall range
 return 1.25+2.8*smooth(-1500,-300,s)+9*smooth(-400,900,s)+90*smooth(800,2200,s)+220*smooth(1900,3600,s);}
function hillH(x,z){const s=sw(x,z),k=smooth(300,1300,s);
 return k*(mix(46,110,smooth(1500,3000,s))*(fbm(x*.0016+2,z*.0016-4,63,3)-.5)+18*(fbm(x*.006-1,z*.006+7,64,2)-.5))+(1-k)*(1.6*(fbm(x*.004,z*.004,65,2)-.5));}
function terrainH(x,z){
 let h=baseH(x,z)+hillH(x,z);const h0=h;
 const s=sOf(x,z),rd=riverD(x,z),W=riverW(x,z);
 // bayou pools and sloughs: standing water a few tens of metres across
 const sk=swampK(x,z);if(sk>0){const pool=fbm(x*.0068+11,z*.0068-7,313,2);h-=sk*3.6*smooth(.43,.29,pool);}
 // oxbow ponds up the subtropical valley, near the river only
 const ox=smooth(-1100,-700,sw(x,z))*smooth(600,300,sw(x,z))*smooth(420,120,rd);if(ox>0){const p=fbm(x*.011-3,z*.011+5,317,2);h-=ox*4.2*smooth(.70,.665,p);}
 // the valley the river cut (wider in the hills), and the channel itself
 const vk=smooth(W*9+120,W*1.2,rd)*smooth(200,900,sw(x,z));h-=vk*Math.max(0,h-baseH(x,z)*.8)*.55;
 const bank=smooth(W+10,W*.6,rd);
 // in the lowland the bed drops under the water plane; up in the hills it is a 2.8 m trench the ribbon runs in
 if(bank>0){const lowland=smooth(250,-150,sw(x,z));h=mix(h,Math.min(h-.2,mix(h-2.8,-2.2,lowland)),bank);}
 // the sea: a sandy shelf then the deep
 const si=seaIn(x,z);if(si<30){const bed=-.4-1.6*smooth(0,-160,si)-9*smooth(-160,-700,si)+.8*(fbm(x*.004,z*.004,71,2)-.5)*smooth(-20,-150,si);
  h=mix(h,Math.min(bed,-.25),smooth(30,-12,si));}
 // the road: a level bed, a hand's depth under the verge, no ponds on it
 const rdd=roadD(x,z);if(rdd<16)h=mix(h,h0-.12,smooth(16,5,rdd));
 return h;}
// ---------------------------------------------------------------- the climate fields
// wet 0..1 (annual moisture), tropic 0..1 (frost-free and hot: 1 in the
// rainforest), dry 0..1 (summer drought: 1 in the Mediterranean hills), salt
// (brackish ground at the sea), flow (river banks), upland (0 lowland .. 1 hilltops)
const FIELD={
 tropic:(x,z)=>smooth(-600,-1650,sw(x,z)),   // the rainforest proper is where this passes ~.75 (s < ~-1150)
 dry:(x,z)=>smooth(700,1400,sw(x,z)),
 wet:(x,z)=>{const s=sw(x,z),rd=riverD(x,z),h=terrainH(x,z);
  let w=mix(.96,.80,smooth(-1400,-600,s));w=mix(w,.34,smooth(450,1300,s));w=mix(w,.22,smooth(1800,2900,s));
  // the north-facing draws hold water in the hills: madrone and sycamore country
  w+=.14*smooth(600,1400,s)*(fbm(x*.0021-6,z*.0021+2,66,2)-.5)*2;
  w=Math.max(w,.97*smooth(W_R(x,z)*4+60,W_R(x,z),rd),.95*smooth(1.2,-.4,h)*smooth(-600,-1000,s));return clamp(w,0,1);},
 salt:(x,z)=>0,   // a freshwater lake
 flow:(x,z)=>clamp(smooth(W_R(x,z)*5+90,W_R(x,z)+4,riverD(x,z)),0,1),
 upland:(x,z)=>clamp((terrainH(x,z)-10)/240,0,1)};
function W_R(x,z){return riverW(x,z);}
// ---------------------------------------------------------------- the host binding
const OBSTACLES=[];
BIO.init({THREE:THREE,scene:scene,terrainH:terrainH,
 mask:(x,z)=>{if(roadD(x,z)<11.5)return 0;const h=terrainH(x,z);return h<.12?0:h<.6?(h-.12)/.48:1;},   // nothing on the road or its mown verges   // nothing rooted under water (the mangrove pass asks past the mask itself)
 obstacles:OBSTACLES,ticks:tick,seed:23,
 // the LOD spine: a row of origins down the NW -> SE axis, sea to hills
 origin:[-2300,-1650,-1000,-350,300,950,1600,2250].map(s=>xzOf(s,0)),center:[0,0],
 fields:FIELD,err:reportErr});
BIO.setSun([-1200,900,-600]);
// ---------------------------------------------------------------- the ground
// One mesh, painted from a coarse cache of the fields (each costs fbm calls),
// with a tiled grain texture multiplied in. The red soils of the hills are
// the same family of colours as the bark.
const FC=(function(){const N=320,S=TERR.R*2.2,a={wet:new Float32Array(N*N),dry:new Float32Array(N*N),tr:new Float32Array(N*N),rd:new Float32Array(N*N),si:new Float32Array(N*N),up:new Float32Array(N*N),sk:new Float32Array(N*N)};
 for(let j=0;j<N;j++)for(let i=0;i<N;i++){const x=(i/(N-1)-.5)*S,z=(j/(N-1)-.5)*S,k=j*N+i;
  a.wet[k]=FIELD.wet(x,z);a.dry[k]=FIELD.dry(x,z);a.tr[k]=FIELD.tropic(x,z);a.rd[k]=riverD(x,z);a.si[k]=seaIn(x,z);a.up[k]=FIELD.upland(x,z);a.sk[k]=swampK(x,z);}
 const at=(arr,x,z)=>{const u=clamp((x/S+.5)*(N-1),0,N-1.001),v=clamp((z/S+.5)*(N-1),0,N-1.001),i=Math.floor(u),j=Math.floor(v),fu=u-i,fv=v-j;
  return arr[j*N+i]*(1-fu)*(1-fv)+arr[j*N+i+1]*fu*(1-fv)+arr[(j+1)*N+i]*(1-fu)*fv+arr[(j+1)*N+i+1]*fu*fv;};
 return{N,S,a,at};})();
const TEX_GROUND=BIO.canvasTex(1536,1536,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;const S=TERR.R*2.2;
 const c=new THREE.Color(),t=new THREE.Color();
 const MUD=new THREE.Color(0x2c3428),LIT=new THREE.Color(0x2a3424),LITG=new THREE.Color(0x344a2c),
  SUB=new THREE.Color(0x3e5a2e),SUBG=new THREE.Color(0x5a7a36),
  GOLD=new THREE.Color(0xa89a64),GOLD2=new THREE.Color(0x8e8a5a),OCHRE=new THREE.Color(0x9a7a56),REDSOIL=new THREE.Color(0x9a5a3e),SCRUB=new THREE.Color(0x56664a),
  SAND=new THREE.Color(0xd6c6a0),WETSAND=new THREE.Color(0x8e7c5c),SILT=new THREE.Color(0x7a6a50),BED=new THREE.Color(0x9a8a62);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const wx=(x/w-.5)*S,wz=(y/h-.5)*S;
  const n=fbm(x/26,y/26,.3,2)-.5,n2=(BIO.fn.h3(x,y,3)-.5),n3=fbm(x/90,y/90,1.7,2)-.5;
  const tr=FC.at(FC.a.tr,wx,wz),dry=FC.at(FC.a.dry,wx,wz),wet=FC.at(FC.a.wet,wx,wz),rd=FC.at(FC.a.rd,wx,wz),si=FC.at(FC.a.si,wx,wz),sk=FC.at(FC.a.sk,wx,wz);
  // subtropical: leaf litter under the trees, grass in the glades
  c.copy(SUB).lerp(SUBG,clamp(.5+n3*2.4+n*.8,0,1));
  // the rainforest: dark red litter
  t.copy(LIT).lerp(LITG,clamp(.45+n*1.8,0,1));c.lerp(t,tr);
  // the bayou: mud
  c.lerp(MUD,sk*.7);
  // the Mediterranean: golden grass, ochre and red soil where it is bare, scrub where it is wetter
  t.copy(GOLD).lerp(GOLD2,clamp(.5+n*1.8,0,1)).lerp(OCHRE,clamp(n3*2.2,0,.6)).lerp(REDSOIL,smooth(.16,.3,n3)*.8).lerp(SCRUB,smooth(.3,.5,wet)*.55);c.lerp(t,dry);
  // river banks: silt; the beach: sand, darker where the sea wets it
  c.lerp(SILT,smooth(60,14,rd)*.7);
  c.lerp(SAND,smooth(150,40,si)*(1-sk)*(1-smooth(80,20,rd)));c.lerp(WETSAND,smooth(25,0,si)*.8);
  c.lerp(BED,smooth(0,-40,si));
  const k=1+n*.10+n2*.05;
  d[i]=clamp(c.r*255*k,0,255);d[i+1]=clamp(c.g*255*k,0,255);d[i+2]=clamp(c.b*255*k,0,255);d[i+3]=255;}
 g.putImageData(id,0,0);});
const TEX_DETAIL=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=232+(fbm(x/9,y/9,5,2)-.5)*36+(BIO.fn.h3(x,y,9)-.5)*20;d[i]=d[i+1]=d[i+2]=clamp(v,0,255);d[i+3]=255;}
 g.putImageData(id,0,0);});
const MAT_GROUND=new THREE.MeshLambertMaterial({map:TEX_GROUND,color:0x9a9890});
MAT_GROUND.onBeforeCompile=sh=>{sh.uniforms.uDetail={value:TEX_DETAIL};
 sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vGWP;').replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvGWP=(modelMatrix*vec4(transformed,1.0)).xyz;');
 sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D uDetail;varying vec3 vGWP;')
  .replace('#include <map_fragment>','#include <map_fragment>\n{vec3 dt=texture2D(uDetail,vGWP.xz*0.165).rgb;vec3 dt2=texture2D(uDetail,vGWP.xz*0.021+0.37).rgb;diffuseColor.rgb*=mix(vec3(1.0),dt*dt2*1.12,0.85);}');};
(function(){const N=400,S=TERR.R*2.2,g=new THREE.PlaneGeometry(S,S,N,N);g.rotateX(-Math.PI/2);
 const p=g.attributes.position;for(let i=0;i<p.count;i++)p.setY(i,terrainH(p.getX(i),p.getZ(i)));
 g.computeVertexNormals();const m=new THREE.Mesh(g,MAT_GROUND);m.userData.probeSkip=true;m.userData.inspectLabel='The lowland floor';scene.add(m);})();

// ---------------------------------------------------------------- the water
// One plane at y=0 carries the inland sea, the bayou and the river's lowland
// reach; its vertex colour is the water's own: a clear green-blue sea over
// sand, tea-dark in the bayou, silty in the river. Where the river runs down
// through the hills it is a ribbon in the same material.
const SEA_SHALLOW=new THREE.Color(0x5aa8a8),SEA_MID=new THREE.Color(0x2a7a90),SEA_DEEP=new THREE.Color(0x163e6a),SEA_PALE=new THREE.Color(0xa8d8cc);   // the lake: jade to blue
const BAYOU_COL=new THREE.Color(0x2e4a44),RIVER_COL=new THREE.Color(0x3e6a64);
const MAT_WATER=new THREE.ShaderMaterial({fog:true,vertexColors:true,
 uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{uT:{value:0},uSun:{value:new THREE.Vector3(-1200,900,-600).normalize()},uSky:{value:new THREE.Color(0xd8e2dc)}}]),
 vertexShader:['#include <fog_pars_vertex>','varying vec3 vWP;varying vec3 vCol;',
  'void main(){vCol=color;vec4 wp=modelMatrix*vec4(position,1.0);vWP=wp.xyz;vec4 mvPosition=viewMatrix*wp;gl_Position=projectionMatrix*mvPosition;','#include <fog_vertex>','}'].join('\n'),
 fragmentShader:['#include <fog_pars_fragment>','uniform float uT;uniform vec3 uSun,uSky;varying vec3 vWP;varying vec3 vCol;',
  'void main(){',
  ' float dcam=length(cameraPosition-vWP);float rk=1.0-smoothstep(120.0,420.0,dcam);',   // ripples fade with range or they alias into a moire
  ' vec3 n=normalize(vec3(rk*(0.035*sin(vWP.x*0.31+uT*1.1)+0.02*sin(vWP.z*0.53-uT*0.7+vWP.x*0.11)),1.0,rk*(0.035*cos(vWP.z*0.27+uT*0.9)+0.02*sin(vWP.x*0.47+uT*1.3))));',
  ' vec3 V=normalize(cameraPosition-vWP);float fr=pow(1.0-max(dot(n,V),0.0),3.0);',
  ' vec3 col=mix(vCol,uSky,0.08+fr*0.62);',
  ' vec3 H=normalize(uSun+V);col+=pow(max(dot(n,H),0.0),140.0)*0.75*vec3(1.0,0.96,0.86);',
  ' gl_FragColor=vec4(col,1.0);','#include <fog_fragment>','}'].join('\n')});
MAT_WATER.uniforms.fogColor.value=scene.fog.color;MAT_WATER.uniforms.fogDensity.value=scene.fog.density;
TICKS.push(dt=>{MAT_WATER.uniforms.uT.value+=dt;});
function waterColorAt(x,z,out){const h=terrainH(x,z),d=Math.max(0,-h),si=seaIn(x,z),rd=riverD(x,z);
 const shoal=fbm(x*.0031+2,z*.0031-4,505,2);
 out.copy(SEA_SHALLOW).lerp(SEA_PALE,Math.max(smooth(.5,.68,shoal)*smooth(2.2,.3,d),smooth(.5,.08,d)*.6)).lerp(SEA_MID,smooth(1.4,4,d)).lerp(SEA_DEEP,smooth(4.5,10,d));
 out.lerp(BAYOU_COL,smooth(-30,60,si)*.9);                                   // everything inland of the shore is fresh and dark
 out.lerp(RIVER_COL,smooth(60,15,rd)*smooth(-200,20,si)*.85);return out;}
(function(){const N=300,S=TERR.R*2.2,g=new THREE.PlaneGeometry(S,S,N,N);g.rotateX(-Math.PI/2);
 const p=g.attributes.position,col=new Float32Array(p.count*3),c=new THREE.Color();
 for(let i=0;i<p.count;i++){waterColorAt(p.getX(i),p.getZ(i),c);c.convertSRGBToLinear();col[i*3]=c.r;col[i*3+1]=c.g;col[i*3+2]=c.b;}
 g.setAttribute('color',new THREE.BufferAttribute(col,3));
 const m=new THREE.Mesh(g,MAT_WATER);m.userData.probeSkip=true;m.userData.inspectLabel='The lake';m.renderOrder=1;scene.add(m);
 // the river down through the hills: a ribbon at bed+0.6 wherever the bed is above the plane
 const pos=[],cc=[],rc=RIVER_COL.clone().convertSRGBToLinear(),ds=24;
 for(let s=-300;s<TERR.R*1.25;s+=ds){const t0=RIVER_T(s),t1=RIVER_T(s+ds);
  const a=xzOf(s,t0),b=xzOf(s+ds,t1),w=riverW(a[0],a[1])*.8;
  const ya=terrainH(a[0],a[1])+.6,yb=terrainH(b[0],b[1])+.6;if(ya<.05&&yb<.05)continue;
  // the across-stream offset is along t, i.e. (RT2,-RT2) in x,z
  const ox=RT2*w,oz=-RT2*w;
  pos.push(a[0]-ox,ya,a[1]-oz, b[0]-ox,yb,b[1]-oz, b[0]+ox,yb,b[1]+oz,  a[0]-ox,ya,a[1]-oz, b[0]+ox,yb,b[1]+oz, a[0]+ox,ya,a[1]+oz);for(let k=0;k<6;k++)cc.push(rc.r,rc.g,rc.b);}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(cc,3));geo.computeVertexNormals();
 const rm=new THREE.Mesh(geo,MAT_WATER);rm.userData.probeSkip=true;rm.userData.inspectLabel='The river';scene.add(rm);})();
// ---------------------------------------------------------------- the road
// A ribbon a few cm over the ground in its own dirt texture: two wheel ruts, a grassy
// crown, leaf litter, pale sand. (The ground canvas is ~4 m a pixel; a road needs its own.)
// the height of the RENDERED ground (400 cells of ~16 m, split on the same diagonal as PlaneGeometry):
// between its vertices it rides above or below terrainH, and a road laid on terrainH sinks into it
function meshH(x,z){const N=400,S=TERR.R*2.2,c=S/N,u=(x+S/2)/c,v=(z+S/2)/c,i=Math.floor(u),j=Math.floor(v),fu=u-i,fv=v-j,X=k=>-S/2+k*c;
 const h00=terrainH(X(i),X(j)),h10=terrainH(X(i+1),X(j)),h01=terrainH(X(i),X(j+1)),h11=terrainH(X(i+1),X(j+1));
 return fu+fv<=1?h00+(h10-h00)*fu+(h01-h00)*fv:h11+(h01-h11)*(1-fu)+(h10-h11)*(1-fv);}
(function(){const TEX=BIO.canvasTex(256,512,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,u=x/w,q=(u-.5)/.4+.5,rut=Math.max(smooth(.12,0,Math.abs(q-.28)),smooth(.12,0,Math.abs(q-.72))),crown=smooth(.1,0,Math.abs(q-.5)),verge=smooth(.19,.22,Math.abs(u-.5));
   const n=(fbm(x/14,y/14,2.1,3)-.5)*40+(BIO.fn.h3(x,y,5)-.5)*22;let r=206+n-rut*26,g2=190+n-rut*24,b=152+n-rut*20;   // the road in the middle 40%, mown grass verges either side
   r=mix(r,120,crown*.45);g2=mix(g2,132,crown*.45);b=mix(b,70,crown*.45);
   const gn=(fbm(x/8,y/8,4.4,2)-.5)*50;r=mix(r,96+gn*.6,verge);g2=mix(g2,118+gn,verge);b=mix(b,62+gn*.4,verge);
   if(fbm(x/6,y/6,7.7,2)>.62){r*=.72;g2*=.64;b*=.52;}   // fallen leaves
   d[i]=clamp(r,0,255);d[i+1]=clamp(g2,0,255);d[i+2]=clamp(b,0,255);d[i+3]=255;}
  g.putImageData(id,0,0);});
 const pos=[],uv=[],W=11;let v=0;
 for(let s=ROAD_S[0];s<ROAD_S[1];s+=4){const a=xzOf(s,ROAD_T(s)),b=xzOf(s+4,ROAD_T(s+4)),dx=b[0]-a[0],dz=b[1]-a[1],L=Math.hypot(dx,dz),nx=-dz/L*W,nz=dx/L*W;
  const P=[[a[0]-nx,a[1]-nz,0,v],[a[0]+nx,a[1]+nz,1,v],[b[0]+nx,b[1]+nz,1,v+L/44],[b[0]-nx,b[1]-nz,0,v+L/44]];   // one tile per 44 m along, ~22 m across: texels square
  [0,2,1,0,3,2].forEach(k=>{const p=P[k];pos.push(p[0],Math.max(terrainH(p[0],p[1]),meshH(p[0],p[1]))+.08,p[1]);uv.push(p[2],p[3]);});v+=L/44;}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();
 const m=new THREE.Mesh(g,new THREE.MeshLambertMaterial({map:TEX,color:0xaaa498,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
 m.userData.probeSkip=true;m.userData.inspectLabel='The ghost-gum avenue';scene.add(m);})();

// ==================== 50-biome-nwlowlands-species.js
// ================================================================= NORTHWESTERN LOWLANDS — species (data + kit items)
// Krator's northwestern lowlands: the shore of the great lake (the Outer Wall far
// beyond it to the NW), a brief strip of rainforest, a long humid-subtropical tract,
// and Mediterranean foothills climbing toward the Inner Wall mountains in the SE.
// Asian and Australian in inspiration -- gums, paperbarks, kauri, cryptomeria,
// ginkgo, birch, casuarina, banksia, grass trees, bamboo -- and the not-Earth in it is:
//   VERTICALITY.  Trees ~50% taller than their Earth kin, and thin: clean boles, few
//                 low branches, crowns high up. The eye is led upward. (The glow-willow
//                 is the one exception.) BAMBOO grows in groves of its own -- a
//                 sub-biome with a hard edge, not a scatter through the forest.
//   PALE BARK.    White, blue-grey, green-grey and blue-green, with brown only in the
//                 fissures.
//   SEA PENS.     The shrub layer is upright feathers and clubs, Ediacaran in look.
//   GLOW-WILLOW.  Hanging lantern blossoms that light themselves.
// Everything here is DATA and kit definitions; no placement. Tags follow the project
// rule and are honoured by the passes.
var NWLOW={};
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
NWLOW.TAGS={climate:'tropic..temperate',aridity:'semiarid..humid',abyssal:false,riparian:'both'};
// the climate beyond the core's wet / salt / upland (additive; see BIOME-API.md)
const FD=BIO.fieldDefault;
if(!FD.tropic)FD.tropic=(x,z)=>0;
if(!FD.dry)FD.dry=(x,z)=>0;
if(!FD.flow)FD.flow=(x,z)=>0;

// ---------------------------------------------------------------- palettes
const PAL=NWLOW.PAL={
 // foliage
 glossy:[0x2a5230,0x336038,0x24482a,0x3c6a40],
 gum:[0x5a7a6e,0x6a8a78,0x4e6e64,0x7a9486],          // glaucous blue-green
 birch:[0x6a9a3a,0x7aaa44,0x5a8a34,0x8ab850],
 needle:[0x2c4a44,0x345650,0x284038,0x3c5e54],       // blue-green conifer
 cypress:[0x4a6a6a,0x567878,0x3e5e60,0x628480],      // blue cypress
 pine:[0x2e4a3a,0x365644,0x2a4234],
 ginkgo:[0x9ab040,0xaabc48,0x8aa038,0xb8c850],
 poplar:[0x5a8a44,0x6a9a4c,0x4e7a3c],
 kauri:[0x2e4a34,0x36563a,0x283e2c],
 willow:[0xa8b8a0,0x9eaab4,0xb4acc8,0x98b090],       // lavender-grey-green
 sheoak:[0x5a6e5a,0x667a64,0x4e6250],
 palm:[0x3a6a44,0x467a4c,0x325e3c],
 fern:[0x3a7a5a,0x468a64,0x326a50,0x2e6a6a],
 wattle:[0x5a7a6a,0x6a8a74,0x4e6e60],
 banksia:[0x3e5a3a,0x4a6642,0x364e32],
 bamboo:[0x5a8a3a,0x6a9a44,0x4e7a34,0x7aa84c],
 // bamboo culms: blue-green, grey-blue, pale green
 culm:[0x4a7a6e,0x5a8a7a,0x6a9a84,0x4a6a7a,0x5a7a8a,0x7aa08a,0x8aa870],
 belly:[0x8aa850,0x9ab858,0x7a9848,0xa8c060],
 // flowers and lights
 lantern:[0xc890ff,0xb070f0,0xe0a8ff,0xa060e0,0xf0b8ff],
 wattleGold:[0xf0c830,0xf4d440,0xe8bc28],
 banksiaCandle:[0xe88a24,0xf0a030,0xd87020,0xf0c048],
 grassSpike:[0xe8e0c0,0xf0e8cc],
 rhodo:[0xc860b8,0xd878c8,0xb050a8,0xe8a0d8,0xf0f0f8],
 bluebell:[0x6a58d8,0x7a68e0,0x5a48c8,0x8a78e8],
 lily:[0xf0c830,0xe8601c,0xf4e0a0,0xd83a2a],
 ginger:[0xd83040,0xe84a50,0xc82838],
 lotus:[0xf4b0c8,0xf8c8d8,0xf0f0f0],
 kpaw:[0xd84030,0x40a040,0xe8c040],
 // the sea pens: pale, pinkish, lilac, white
 pen:[0xe8e0d8,0xf0e4e0,0xd8d0e8,0xe8d8e4,0xf4f0ec,0xd0dce0],
 penDeep:[0xb8a8c8,0xc8b0c0,0xa8b8c0],
 // ground
 moss:[0x4f6a3c,0x5a7a44,0x3f5a34,0x6a8a4a],
 mossPale:[0x9aa89a,0xa8b4a8,0x8a9a8c],
 shrub:[0x2a4a34,0x345a3c,0x2e503a,0x3e6044],
 aroid:[0x2a6a6a,0x347a74,0x225e60,0x3a8a80],        // teal (pic: the blue-green aroids)
 grassGreen:[0x5a8a3a,0x6a9a44,0x4e7a34],
 grassDry:[0xb8aa78,0xc4b684,0xa89a6a,0xd0c090],
 saltbush:[0x8a9a94,0x98a8a0,0x7a8a86],
 reed:[0x5a7a44,0x6a8a4a,0x4e6e3c],
 litter:[0xb0a070,0xa89468,0xc0b080,0x9a8a60],       // bamboo leaf litter
 pad:[0x3a6a4a,0x4a7a54,0x2e5a40],
 rock:[0x9a8e80,0x8a7e70,0xa89e90],
 rockRed:[0xa86a48,0x9a5e40,0xb87a54],
 deadwood:[0xa8aaa4,0x9a9c96,0xb4b6ae],
 vine:[0x3d5a3a,0x2f4a30,0x4a6a44],
 fungus:[0xd8d0c0,0xc8bcb0,0xe8e0d0],
};

// ---------------------------------------------------------------- the species
// H height band (~1.5x the Earth kin), rb bole radius, crownR, bk the bark bucket, bark
// the colours as they should LOOK, leaf the foliage set, habit the builder family.
NWLOW.SPECIES=[
 /*0*/{key:'meranti',name:'Sky meranti',habit:'column',H:[70,90],rb:[1.8,2.6],crownR:[14,22],bk:'bk_smooth',bark:[0xb8bcb4,0xaab0a8,0xc4c6bc],leaf:PAL.glossy,item:'glossy',
  crotch:[.7,.78],limbs:[5,7],buttress:1.8,tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'no'}},
 /*1*/{key:'mistpalm',name:'Mist palm',habit:'palm',H:[25,38],rb:[.16,.26],crownR:[4,6],bk:'bk_ring',bark:[0xb8c0bc,0xa8b2ae,0xc8ccc4],leaf:PAL.palm,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*2*/{key:'treefern',name:'Spire tree fern',habit:'fern',H:[10,18],rb:[.2,.34],crownR:[3.5,5.5],bk:'bk_fern',bark:[0x3a4a4a,0x344444,0x425252],leaf:PAL.fern,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*3*/{key:'pandan',name:'Stilt pandan',habit:'pandan',H:[8,14],rb:[.2,.32],crownR:[3,5],bk:'bk_ring',bark:[0x9aa8a4,0x8a9894,0xa8b4ae],leaf:PAL.gum,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*4*/{key:'ghostgum',name:'Ghost gum',habit:'column',H:[40,55],rb:[.7,1.1],crownR:[8,13],bk:'bk_ghost',bark:[0xeeeee6,0xe6e8e0,0xf4f2ea],leaf:PAL.gum,item:'lance',
  crotch:[.55,.68],limbs:[3,5],tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*5*/{key:'bluegum',name:'Ribbon blue gum',habit:'column',H:[50,66],rb:[1.0,1.5],crownR:[10,15],bk:'bk_bluegum',bark:[0x7a8c9a,0x8494a2,0x6e808e],leaf:PAL.gum,item:'lance',
  crotch:[.6,.7],limbs:[3,5],ribbons:true,tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 /*6*/{key:'birch',name:'Candle birch',habit:'column',H:[26,36],rb:[.22,.36],crownR:[4,6.5],bk:'bk_birch',bark:[0xf0f0ec,0xe8eae6,0xf6f4f0],leaf:PAL.birch,item:'broad',
  crotch:[.45,.6],limbs:[4,6],stems:[2,5],tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'both'}},
 /*7*/{key:'spire',name:'Spire cedar',habit:'spire',H:[45,62],rb:[1.0,1.6],crownR:[5,8],bk:'bk_fibre',bark:[0x7a8894,0x6e7c88,0x8694a0],leaf:PAL.needle,item:'needle',
  tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'no'}},
 /*8*/{key:'glowwillow',name:'Glow-willow',habit:'willow',H:[16,24],rb:[1.0,1.5],crownR:[10,15],bk:'bk_silver',bark:[0xd8dcdc,0xccd2d4,0xe2e4e2],leaf:PAL.willow,
  tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*9*/{key:'ginkgo',name:'Column ginkgo',habit:'fastigiate',H:[30,42],rb:[.6,1.0],crownR:[5,8],bk:'bk_smooth',bark:[0x8a948a,0x7e887e,0x96a094],leaf:PAL.ginkgo,item:'ginkgo',
  tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 /*10*/{key:'paperbark',name:'Pale paperbark',habit:'column',H:[20,30],rb:[.4,.7],crownR:[5,8],bk:'bk_paper',bark:[0xe4e0d0,0xdcd8c8,0xece8da],leaf:PAL.gum,item:'lance',
  crotch:[.45,.6],limbs:[3,5],tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'yes'}},
 /*11*/{key:'poplar',name:'Spindle poplar',habit:'fastigiate',H:[35,48],rb:[.6,.9],crownR:[3.5,5.5],bk:'bk_smooth',bark:[0xa8b2a6,0x9ca69a,0xb4bcb0],leaf:PAL.poplar,item:'broad',
  tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'yes'}},
 /*12*/{key:'kauri',name:'Column kauri',habit:'column',H:[50,70],rb:[2.0,3.0],crownR:[12,18],bk:'bk_plate',bark:[0x8a989e,0x7e8c94,0x96a2a8],leaf:PAL.kauri,item:'glossy',
  crotch:[.66,.74],limbs:[4,6],tags:{climate:'temperate',aridity:'humid',abyssal:false,riparian:'no'}},
 /*13*/{key:'towerash',name:'Tower ash',habit:'column',H:[80,105],rb:[2.0,3.0],crownR:[12,18],bk:'bk_ghost',bark:[0xd4d8d0,0xcacec6,0xdedfd6],leaf:PAL.gum,item:'lance',
  crotch:[.72,.8],limbs:[4,6],ribbons:true,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'both'}},
 /*14*/{key:'needlecypress',name:'Needle cypress',habit:'spire',H:[24,36],rb:[.5,.8],crownR:[2.2,3.4],bk:'bk_fibre',bark:[0x8a949a,0x7e8890,0x96a0a6],leaf:PAL.cypress,item:'needle',
  columnar:true,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*15*/{key:'sheoak',name:'Drape she-oak',habit:'column',H:[24,34],rb:[.4,.7],crownR:[5,8],bk:'bk_fibre',bark:[0x6e7c78,0x627070,0x7a8884],leaf:PAL.sheoak,item:'drape',
  crotch:[.4,.55],limbs:[4,6],tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'both'}},
 /*16*/{key:'cragpine',name:'Crag pine',habit:'spire',H:[30,42],rb:[.5,.8],crownR:[6,10],bk:'bk_plate',bark:[0x5a8a88,0x4e7e7c,0x669694],leaf:PAL.pine,item:'needle',
  flatTop:true,tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*17*/{key:'grasstree',name:'Grass tree',habit:'grasstree',H:[3,6],rb:[.25,.4],crownR:[1.5,2.4],bk:'bk_char',bark:[0x2e3238,0x383c42,0x26292e],leaf:PAL.gum,
  tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*18*/{key:'banksia',name:'Candle banksia',habit:'banksia',H:[6,12],rb:[.25,.4],crownR:[3,5],bk:'bk_smooth',bark:[0x8a9090,0x7e8484,0x969c9a],leaf:PAL.banksia,
  tags:{climate:'temperate',aridity:'semiarid',abyssal:false,riparian:'no'}},
 /*19*/{key:'wattle',name:'Tall wattle',habit:'column',H:[16,24],rb:[.35,.55],crownR:[5,8],bk:'bk_smooth',bark:[0x7a8a94,0x6e7e88,0x8694a0],leaf:PAL.wattle,item:'feather',
  crotch:[.35,.5],limbs:[4,6],flower:PAL.wattleGold,tags:{climate:'temperate',aridity:'subhumid',abyssal:false,riparian:'no'}},
 // the bamboos: placed by the GROVE pass (their own sub-biome), not the tree passes
 /*20*/{key:'skybamboo',name:'Sky bamboo',habit:'bamboo',H:[26,36],rb:[.08,.14],crownR:[2,3],bark:PAL.culm,leaf:PAL.bamboo,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*21*/{key:'bellybamboo',name:'Buddha-belly bamboo',habit:'bamboo',H:[8,13],rb:[.05,.09],crownR:[1.5,2.5],bark:PAL.belly,leaf:PAL.bamboo,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'both'}},
 /*22*/{key:'coilcane',name:'Coil cane',habit:'bamboo',H:[6,11],rb:[.06,.1],crownR:[1.5,2.2],bark:PAL.culm,leaf:PAL.bamboo,
  tags:{climate:'tropic',aridity:'humid',abyssal:false,riparian:'yes'}},
];

// ---------------------------------------------------------------- leaf textures
// Greyscale on transparent canvases (BIO.alphaTex); the per-instance colour tints them.
reseed(510011);
const TX={};
/* dense small elliptic leaves -- the oaks */
TX.oakleaf=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,12,.68);   // small leaves: a live oak's are a few cm, and a clump is 8 m across
 for(let i=0;i<1500;i++){const c=BIO.tex.clPt(S,.12,.94),lum=lerp(95,240,i/1500)+rr(-20,12);
  g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.ellipse(c[0],c[1],rr(4.5,7),rr(2.5,4),rr(0,TAU),0,TAU);g.fill();}},[150,150,150]);
/* broad glossy ovate leaves in clusters -- figs, mangroves, madrones */
TX.glossy=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,8,.60);
 for(let i=0;i<60;i++){const c=BIO.tex.clPt(S,.10,.74),lum=lerp(105,242,i/60)+rr(-15,12),n=ri(3,5),a0=rr(0,TAU);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(40,58),rr(15,20),a0+(k-(n-1)/2)*.8,lum*rr(.9,1.05),true);}},[160,160,160]);
/* broad lobed leaves -- kapok, sycamore, ringbark */
TX.broad=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,8,.60);
 for(let i=0;i<54;i++){const c=BIO.tex.clPt(S,.10,.72),lum=lerp(110,238,i/54)+rr(-15,12),n=ri(3,5),a0=rr(0,TAU);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(44,66),rr(16,22),a0+(k-(n-1)/2)*.75,lum*rr(.9,1.05),true);}},[165,165,165]);
/* feathery sprays -- the cypress */
TX.feather=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.62);
 for(let i=0;i<78;i++){const p=BIO.tex.clPt(S,.09,.62),a=p[2]+rr(-.7,.7),L=rr(50,86),lum=lerp(110,235,i/78)+rr(-18,18);
  g.strokeStyle=BIO.tex.grey(lum*.55);g.lineWidth=2.2;g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[0]+Math.cos(a)*L,p[1]+Math.sin(a)*L);g.stroke();
  for(let s=4;s<L;s+=3.4){const t=s/L,nl=lerp(14,5,t),bx=p[0]+Math.cos(a)*s,by=p[1]+Math.sin(a)*s;g.strokeStyle=BIO.tex.grey(lum*rr(.85,1.08));g.lineWidth=1.8;
   for(let sd=-1;sd<=1;sd+=2){const na=a+sd*1.15;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(na)*nl,by+Math.sin(na)*nl);g.stroke();}}}},[130,130,130]);
/* hanging sickle leaves in loose bunches -- the flayed gum */
TX.lance=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.62);
 for(let i=0;i<70;i++){const c=BIO.tex.clPt(S,.10,.74),lum=lerp(110,238,i/70)+rr(-15,12),n=ri(4,7);
  for(let k=0;k<n;k++){const a=Math.PI/2+rr(-.6,.6),L=rr(50,80),x=c[0]+rr(-8,8),y=c[1];g.fillStyle=BIO.tex.grey(lum*rr(.9,1.05));
   g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+Math.cos(a)*L*.5+9,y+Math.sin(a)*L*.5,x+Math.cos(a)*L+rr(-6,6),y+Math.sin(a)*L);g.quadraticCurveTo(x+Math.cos(a)*L*.5-4,y+Math.sin(a)*L*.5,x,y);g.fill();}}},[150,150,150]);
/* small leathery leaves on crooked twigs -- manzanita */
TX.manz=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.64);
 for(let i=0;i<110;i++){const c=BIO.tex.clPt(S,.12,.8),a=c[2]+rr(-.8,.8),L=rr(40,80),lum=lerp(110,238,i/110);
  g.strokeStyle=BIO.tex.grey(70);g.lineWidth=2.4;g.beginPath();g.moveTo(c[0],c[1]);const ex=c[0]+Math.cos(a)*L,ey=c[1]+Math.sin(a)*L;g.lineTo(ex,ey);g.stroke();
  for(let s=6;s<L;s+=7){const bx=c[0]+Math.cos(a)*s,by=c[1]+Math.sin(a)*s;for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lum*rr(.88,1.06));
   g.beginPath();g.ellipse(bx+Math.cos(a+sd*1.2)*6,by+Math.sin(a+sd*1.2)*6,8.5,5.5,a+sd*1.2,0,TAU);g.fill();}}}},[150,150,150]);
/* weeping willow: fine strands of narrow leaves, tileable top to bottom (v=0 at the top of a ribbon) */
TX.willow=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';   // a few strands with air between them: a veil, not a plank
 for(let k=0;k<8;k++){const x0=12+(k+rr(-.25,.25))*(S-24)/7,lum=lerp(115,238,rng());
  for(let off=-S;off<=S;off+=S){let x=x0,y=off;g.strokeStyle=BIO.tex.grey(lum*.7);g.lineWidth=1.3;g.beginPath();g.moveTo(x,y);
   const pts=[];while(y<off+S){const nx=x+rr(-3,3),ny=y+rr(8,14);g.lineTo(nx,ny);pts.push([nx,ny]);x=nx;y=ny;}g.stroke();
   pts.forEach(p=>{for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lum*rr(.88,1.08));g.beginPath();g.ellipse(p[0]+sd*3.5,p[1]+4,1.8,8,sd*.4,0,TAU);g.fill();}});}}},[150,150,150]);
/* cherry blossom: small five-petalled flowers in dense clusters */
TX.blossom=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,9,.64);
 for(let i=0;i<260;i++){const c=BIO.tex.clPt(S,.10,.9),lum=lerp(170,250,rng()),r=rr(6,10);
  for(let p=0;p<5;p++){const a=p/5*TAU+c[2];g.fillStyle=BIO.tex.grey(lum*rr(.92,1.02));g.beginPath();g.ellipse(c[0]+Math.cos(a)*r*.6,c[1]+Math.sin(a)*r*.6,r*.55,r*.38,a,0,TAU);g.fill();}
  g.fillStyle=BIO.tex.grey(lum*.72);g.beginPath();g.arc(c[0],c[1],r*.2,0,TAU);g.fill();}},[210,210,210]);
/* a pinnate palm frond along +x */
TX.palmfrond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.19+.31*f);g.strokeStyle=BIO.tex.grey(95);g.lineWidth=3;g.beginPath();g.moveTo(3,y);g.lineTo(S-3,y+rr(-3,3));g.stroke();
  for(let x=6;x<S-4;x+=5){const t=x/S,L=lerp(30,10,Math.pow(t,1.2))*rr(.9,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(120,232,rng()));g.lineWidth=3.2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+L*.35,y+sd*L*.55,x+L*.55,y+sd*L);g.stroke();}}}},[140,140,140]);
/* a fan: a half-disc of radial ribs, base at the bottom centre (skirt palm, palmetto) */
TX.fan=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';const bx=S/2,by=S*.96,n=34;
 for(let k=0;k<n;k++){const a=-Math.PI*.5+(k/(n-1)-.5)*Math.PI*.96+rr(-.02,.02),L=S*.88*(.8+.2*Math.sin(k/(n-1)*Math.PI));
  g.strokeStyle=BIO.tex.grey(lerp(120,235,rng()));g.lineWidth=rr(3.5,6);g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(a)*L,by+Math.sin(a)*L);g.stroke();
  if(rng()<.5){g.lineWidth=1;g.strokeStyle=BIO.tex.grey(200);g.beginPath();g.moveTo(bx+Math.cos(a)*L,by+Math.sin(a)*L);g.lineTo(bx+Math.cos(a)*L*1.06+rr(-4,4),by+Math.sin(a)*L*1.06+10);g.stroke();}}   // the filaments at the tips
 g.strokeStyle=BIO.tex.grey(90);g.lineWidth=4;g.beginPath();g.moveTo(bx,by);g.lineTo(bx,by-S*.32);g.stroke();},[150,150,150]);
/* an elephant-ear: one big heart-shaped leaf, base at the bottom centre */
TX.heart=BIO.alphaTex(256,(g,S)=>{const cx=S/2;g.fillStyle=BIO.tex.grey(170);
 g.beginPath();g.moveTo(cx,S*.98);g.bezierCurveTo(S*1.02,S*.72,S*.9,S*.02,cx,S*.2);g.bezierCurveTo(S*.1,S*.02,-S*.02,S*.72,cx,S*.98);g.fill();
 g.strokeStyle=BIO.tex.grey(215);g.lineWidth=3;g.beginPath();g.moveTo(cx,S*.95);g.lineTo(cx,S*.24);g.stroke();
 g.lineWidth=1.6;for(let k=0;k<7;k++){const y=lerp(S*.85,S*.3,k/6);for(let sd=-1;sd<=1;sd+=2){g.beginPath();g.moveTo(cx,y);g.quadraticCurveTo(cx+sd*S*.18,y-S*.03,cx+sd*S*.34*Math.sin((k+1)/8*Math.PI),y-S*.1);g.stroke();}}},[160,160,160]);
/* stiff blades from the base: yucca, agave, iris, sawgrass (vertical tuft card) */
TX.spike=BIO.alphaTex(256,(g,S)=>{for(let k=0;k<20;k++){const a=-Math.PI/2+rr(-.75,.75),L=S*rr(.55,.95),w=rr(5,9),lum=lerp(110,235,rng()),x0=S/2+rr(-6,6);
 g.fillStyle=BIO.tex.grey(lum);g.beginPath();g.moveTo(x0-w/2,S);g.lineTo(x0+Math.cos(a)*L,S+Math.sin(a)*L);g.lineTo(x0+w/2,S);g.fill();}},[150,150,150]);
/* lupin: a spike of pea-flowers over a few palmate leaves (vertical tuft card) */
TX.lupin=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<5;k++){const x0=S/2+rr(-40,40),top=S*rr(.08,.3);g.strokeStyle=BIO.tex.grey(90);g.lineWidth=3;g.beginPath();g.moveTo(x0,S);g.lineTo(x0,top);g.stroke();
  for(let y=top;y<S*.62;y+=7){const w=lerp(4,13,(y-top)/(S*.62-top));for(let sd=-1;sd<=1;sd+=2){g.fillStyle=BIO.tex.grey(lerp(170,240,rng()));g.beginPath();g.ellipse(x0+sd*w*.6,y,w*.55,4,0,0,TAU);g.fill();}}}},[150,150,150]);
/* reeds, grass, fern, generic understorey, bloom, moss, beard: the kit's common set */
TX.reed=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<26;k++){const x0=S/2+rr(-16,16),a=-Math.PI/2+rr(-.28,.28),L=S*rr(.72,.98),lum=lerp(105,235,rng());
  g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(2.4,4.2);g.beginPath();g.moveTo(x0,S);g.quadraticCurveTo(x0+Math.cos(a)*L*.5,S+Math.sin(a)*L*.55,x0+Math.cos(a)*L+rr(-10,10)*Math.sign(Math.cos(a)||1),S+Math.sin(a)*L);g.stroke();
  if(rng()<.35){g.fillStyle=BIO.tex.grey(lum*.75);g.beginPath();g.ellipse(x0+Math.cos(a)*L,S+Math.sin(a)*L,3.2,12,a+Math.PI/2,0,TAU);g.fill();}}},[140,140,140]);
TX.grass=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<44;k++){const x0=S/2+rr(-20,20),a=-Math.PI/2+rr(-.5,.5),L=S*rr(.5,.95),lum=lerp(120,240,rng());
  g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(1.4,2.6);g.beginPath();g.moveTo(x0,S);g.quadraticCurveTo(x0+Math.cos(a)*L*.5,S+Math.sin(a)*L*.6,x0+Math.cos(a)*L*1.1,S+Math.sin(a)*L);g.stroke();}},[150,150,150]);
TX.frond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.2+.3*f);g.strokeStyle=BIO.tex.grey(90);g.lineWidth=3;g.beginPath();g.moveTo(4,y);g.lineTo(S-4,y+rr(-6,6));g.stroke();
  for(let x=8;x<S-6;x+=7){const t=x/S,L=lerp(28,6,Math.pow(t,1.4))*rr(.8,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(120,230,rng()));g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+L*.35,y+sd*L);g.stroke();}}}},[140,140,140]);
TX.bigfrond=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let f=0;f<3;f++){const y=S*(.19+.31*f);g.strokeStyle=BIO.tex.grey(85);g.lineWidth=3.2;g.beginPath();g.moveTo(3,y);g.lineTo(S-3,y+rr(-4,4));g.stroke();
  for(let x=6;x<S-4;x+=5.2){const t=x/S,L=lerp(34,7,Math.pow(t,1.3))*rr(.85,1.1);for(let sd=-1;sd<=1;sd+=2){
   g.strokeStyle=BIO.tex.grey(lerp(115,225,rng()));g.lineWidth=3.4;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+L*.25,y+sd*L*.6,x+L*.45,y+sd*L);g.stroke();}}}},[140,140,140]);
TX.under=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,7,.62);
 for(let i=0;i<64;i++){const c=BIO.tex.clPt(S,.11,.70),base=c[2]+rr(-1,1),lum=lerp(100,235,i/64),n=ri(4,7);
  for(let k=0;k<n;k++)BIO.tex.leaf(g,c[0],c[1],rr(40,70),rr(10,16),base+(k-(n-1)/2)*.55,lum+rr(-20,15),true);}},[150,150,150]);
TX.bloom=BIO.alphaTex(128,(g,S)=>{const cx=S/2,cy=S/2;
 for(let p=0;p<5;p++){const a=p/5*TAU;g.fillStyle=BIO.tex.grey(lerp(170,235,rng()));g.beginPath();g.ellipse(cx+Math.cos(a)*S*.22,cy+Math.sin(a)*S*.22,S*.2,S*.13,a,0,TAU);g.fill();}
 g.fillStyle=BIO.tex.grey(120);g.beginPath();g.arc(cx,cy,S*.09,0,TAU);g.fill();g.fillStyle=BIO.tex.grey(250);g.beginPath();g.arc(cx,cy,S*.05,0,TAU);g.fill();},[200,200,200]);
TX.moss=BIO.alphaTex(128,(g,S)=>{for(let i=0;i<260;i++){const x=S/2+(rng()-.5)*S*.96,y=S/2+(rng()-.5)*S*.96;if(Math.hypot(x-S/2,y-S/2)>S*.47)continue;
 g.fillStyle=BIO.tex.grey(lerp(110,220,rng()));g.beginPath();g.arc(x,y,rr(6,14),0,TAU);g.fill();}},[150,150,150]);
/* Spanish moss: stringy strands hanging (v=0 at the top) */
TX.beard=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 for(let k=0;k<34;k++){const x0=rr(10,S-10),lum=lerp(120,225,rng());g.strokeStyle=BIO.tex.grey(lum);g.lineWidth=rr(1.2,2.4);
  g.beginPath();g.moveTo(x0,0);let x=x0,y=0;while(y<S*rr(.6,1)){const nx=x+rr(-9,9),ny=y+rr(10,22);g.lineTo(nx,ny);x=nx;y=ny;}g.stroke();
  for(let j=0;j<6;j++){const yy=rr(0,S*.9);g.beginPath();g.moveTo(x0+rr(-8,8),yy);g.lineTo(x0+rr(-16,16),yy+rr(6,18));g.stroke();}}},[150,150,150]);
/* needles in flat sprays -- cedar and pine pads */
TX.needle=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,10,.66);
 for(let i=0;i<140;i++){const c=BIO.tex.clPt(S,.10,.8),lum=lerp(105,235,i/140),a0=rr(0,TAU);g.strokeStyle=BIO.tex.grey(lum*rr(.88,1.05));g.lineWidth=1.6;
  for(let k=0;k<14;k++){const a=a0+rr(-1.2,1.2),L=rr(14,26);g.beginPath();g.moveTo(c[0],c[1]);g.lineTo(c[0]+Math.cos(a)*L,c[1]+Math.sin(a)*L);g.stroke();}}},[140,140,140]);
/* a forking fern (Dicranopteris): a frond that branches in pairs, along +x */
TX.forkfern=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';
 const arm=(x,y,a,L,dep)=>{const ex=x+Math.cos(a)*L,ey=y+Math.sin(a)*L;g.strokeStyle=BIO.tex.grey(90);g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();
  if(dep>0){for(let s=4;s<L;s+=4){const bx=x+Math.cos(a)*s,by=y+Math.sin(a)*s;for(let sd=-1;sd<=1;sd+=2){g.strokeStyle=BIO.tex.grey(lerp(140,235,rng()));g.lineWidth=2.2;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(a+sd*1.3)*9,by+Math.sin(a+sd*1.3)*9);g.stroke();}}}
  if(dep<2){arm(ex,ey,a-.6,L*.8,dep+1);arm(ex,ey,a+.6,L*.8,dep+1);}};
 arm(4,S/2,0,S*.22,0);},[150,150,150]);
/* a staghorn fern: antler-forked lobes from a round shield at the bottom centre */
TX.staghorn=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';g.lineJoin='round';
 const lobe=(x,y,a,L,w,dep)=>{const ex=x+Math.cos(a)*L,ey=y+Math.sin(a)*L;g.strokeStyle=BIO.tex.grey(lerp(150,220,rng()));g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.lineTo(ex,ey);g.stroke();
  if(dep<3){lobe(ex,ey,a-rr(.35,.6),L*.72,w*.72,dep+1);lobe(ex,ey,a+rr(.35,.6),L*.72,w*.72,dep+1);}};
 for(let k=0;k<5;k++)lobe(S/2,S*.8,-Math.PI/2+(k-2)*.5,S*.2,16,0);
 g.fillStyle=BIO.tex.grey(185);g.beginPath();g.ellipse(S/2,S*.82,S*.2,S*.14,0,0,TAU);g.fill();},[160,160,160]);
NWLOW.TEX=TX;

/* bamboo: a spray of narrow drooping leaves on fine twigs */
TX.bleaf=BIO.alphaTex(512,(g,S)=>{g.lineCap='round';BIO.tex.clusters(S,9,.64);
 for(let i=0;i<60;i++){const c=BIO.tex.clPt(S,.11,.72),a0=c[2]+rr(-.6,.6),lum=lerp(105,238,i/60);
  g.strokeStyle=BIO.tex.grey(80);g.lineWidth=1.4;const L=rr(30,60),ex=c[0]+Math.cos(a0)*L,ey=c[1]+Math.sin(a0)*L;g.beginPath();g.moveTo(c[0],c[1]);g.lineTo(ex,ey);g.stroke();
  for(let k=0,n=ri(4,7);k<n;k++){const a=a0+Math.PI*.5+rr(-.9,.9),Ll=rr(28,46),bx=mix(c[0],ex,rng()),by=mix(c[1],ey,rng());g.fillStyle=BIO.tex.grey(lum*rr(.88,1.06));
   g.beginPath();g.moveTo(bx,by);g.quadraticCurveTo(bx+Math.cos(a)*Ll*.5+4,by+Math.sin(a)*Ll*.5+6,bx+Math.cos(a)*Ll,by+Math.sin(a)*Ll+Ll*.25);g.quadraticCurveTo(bx+Math.cos(a)*Ll*.5-3,by+Math.sin(a)*Ll*.5+2,bx,by);g.fill();}}},[140,140,140]);
/* ginkgo: little fans in clusters */
TX.ginkgo=BIO.alphaTex(512,(g,S)=>{BIO.tex.clusters(S,10,.66);
 for(let i=0;i<380;i++){const c=BIO.tex.clPt(S,.11,.9),lum=lerp(110,245,i/380),a=rr(0,TAU),r=rr(8,12);g.fillStyle=BIO.tex.grey(lum);
  g.beginPath();g.moveTo(c[0],c[1]);g.arc(c[0],c[1],r,a-.9,a+.9);g.closePath();g.fill();}},[170,170,170]);
/* a SEA PEN: a stalk up the middle and pinnae narrowing to the top, base at the bottom (tuft card) */
TX.pen=BIO.alphaTex(256,(g,S)=>{g.lineCap='round';const cx=S/2;
 g.strokeStyle=BIO.tex.grey(200);g.lineWidth=5;g.beginPath();g.moveTo(cx,S);g.lineTo(cx,S*.05);g.stroke();
 for(let y=S*.9;y>S*.06;y-=5){const t=(S*.9-y)/(S*.84),w=S*.36*Math.sin(Math.PI*Math.min(1,t*1.15+.05))*(1-t*.35);
  for(let sd=-1;sd<=1;sd+=2){g.strokeStyle=BIO.tex.grey(lerp(170,250,rng()));g.lineWidth=3.2;g.beginPath();g.moveTo(cx,y);g.quadraticCurveTo(cx+sd*w*.6,y-4,cx+sd*w,y-12);g.stroke();}}},[210,210,210]);
/* a CLUB PEN: a stalk and a ribbed bulb */
TX.clubpen=BIO.alphaTex(256,(g,S)=>{const cx=S/2;g.fillStyle=BIO.tex.grey(190);g.fillRect(cx-4,S*.5,8,S*.5);
 g.fillStyle=BIO.tex.grey(225);g.beginPath();g.ellipse(cx,S*.32,S*.2,S*.28,0,0,TAU);g.fill();
 g.strokeStyle=BIO.tex.grey(160);g.lineWidth=2;for(let k=-3;k<=3;k++){g.beginPath();g.ellipse(cx,S*.32,Math.abs(k)*S*.028+1,S*.27,0,0,TAU);g.stroke();}},[200,200,200]);
/* a soft round glow (for the lanterns' halos) */
TX.glow=(function(){const Sz=64,c=document.createElement('canvas');c.width=c.height=Sz;const g=c.getContext('2d'),gr=g.createRadialGradient(Sz/2,Sz/2,0,Sz/2,Sz/2,Sz/2);
 gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.25,'rgba(255,255,255,.45)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,Sz,Sz);
 const t=new T3.CanvasTexture(c);return t;})();
NWLOW.TEX=TX;
// ---------------------------------------------------------------- TWO-TONE BARK
// A bark canvas here carries TWO things: R = the relief (grey, normalised by
// its own mean in the shader so the vertex colour is the albedo), G = a MASK
// that swaps the vertex colour for the bucket's second colour. That is how a
// madrone is red with green-white flayed patches, a manzanita red with char
// streaks, a ringbark copper with pale lenticels, a cypress cinnamon with grey
// weathered strands -- one draw call per look, species colours per vertex.
// uGain folds in the light rig: sun + hemisphere render an albedo about twice
// as bright as it is written, so a designer's colour is multiplied down here
// and the palettes above stay what the bark should look like. uGloss adds a
// sun highlight (manzanita, lacquered mangrove, the ringbark's sheen).
function wrap9(W,H,fn){for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++)fn(i*W,j*H);}
function blob(g,x,y,w,h,wob,sl){g.beginPath();const n=14,sd=w*1.7+h*.31;for(let k=0;k<=n;k++){const a=k/n*TAU,r=1+wob*(h3(sd,k%n,7)-.5)*2;   // shape from its size only: every wrapped copy is identical
 const px=Math.cos(a)*w*r,py=Math.sin(a)*h*r;const X=x+px+py*sl,Y=y+py;k?g.lineTo(X,Y):g.moveTo(X,Y);}g.closePath();g.fill();}
const PAINT={
 ember(L,M,W,H){   // smooth, twisting sheen; char streaks
  for(let i=0;i<8;i++){const x=rng()*W;L.fillStyle='rgba(190,190,190,.10)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,oy,rr(10,40),H));}
  for(let i=0;i<260;i++){const x=rng()*W,y=rng()*H,l=rng()<.5?'70,70,70':'200,200,200';L.strokeStyle='rgba('+l+','+rr(.08,.25).toFixed(2)+')';L.lineWidth=rr(.8,2);
   const len=rr(40,200),dx=rr(-10,10);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.quadraticCurveTo(x+ox+dx,y+oy+len*.5,x+ox+dx*.4,y+oy+len);L.stroke();});}
  M.fillStyle='#fff';for(let i=0;i<16;i++){const x=rng()*W,y=rng()*H,w=rr(5,26),h=rr(50,220),sl=rr(-.12,.12);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.45,sl));}
  M.strokeStyle='#fff';for(let i=0;i<30;i++){const x=rng()*W,y=rng()*H;M.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{M.beginPath();M.moveTo(x+ox,y+oy);M.lineTo(x+ox+rr(-6,6),y+oy+rr(20,70));M.stroke();});}},
 lacquer(L,M,W,H){   // smooth, faint ripples and lenticels; a little pale lichen
  for(let i=0;i<30;i++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'120,120,120':'165,165,165')+',.25)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(3,14)));}
  for(let i=0;i<90;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,.45)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(5,16),rr(1.5,3)));}
  M.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<10;i++){const x=rng()*W,y=rng()*H,r=rr(4,12);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.2,.5,0));}},
 flay(L,M,W,H){   // flame-shaped flakes peeling off red to a pale underbark (red dominant: the pale shows in flakes)
  for(let i=0;i<140;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba(110,110,110,.25)';L.lineWidth=1;wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-4,4),y+oy+rr(20,60));L.stroke();});}
  for(let i=0;i<17;i++){const x=rng()*W,y=rng()*H,w=rr(8,24),h=rr(30,100),sl=rr(-.35,.35),l=Math.round(rr(120,170));
   wrap9(W,H,(ox,oy)=>{M.fillStyle='#fff';blob(M,x+ox,y+oy,w,h,.35,sl);L.fillStyle='rgba('+l+','+l+','+l+',.6)';blob(L,x+ox,y+oy,w,h,.35,sl);
    L.strokeStyle='rgba(50,50,50,.55)';L.lineWidth=1.4;L.stroke();});}},
 mottle(L,M,W,H){   // sycamore jigsaw: rounder, more of the pale showing
  for(let i=0;i<46;i++){const x=rng()*W,y=rng()*H,w=rr(14,40),h=rr(18,60),l=Math.round(rr(115,175));
   const mf=rng()<.8?'#fff':'#888',sl=rr(-.2,.2);wrap9(W,H,(ox,oy)=>{M.fillStyle=mf;blob(M,x+ox,y+oy,w,h,.5,sl);L.fillStyle='rgba('+l+','+l+','+l+',.55)';blob(L,x+ox,y+oy,w,h,.5,sl);});}},
 ring(L,M,W,H){   // copper sheen banded with pale lenticels; peeling curls
  for(let i=0;i<20;i++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'125,125,125':'175,175,175')+',.3)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(4,18)));}
  for(let i=0;i<150;i++){const x=rng()*W,y=rng()*H,w=rr(10,46),h=rr(2,4);
   wrap9(W,H,(ox,oy)=>{L.fillStyle='rgba(70,70,70,.6)';L.fillRect(x+ox,y+oy+h*.6,w,h*.6);M.fillStyle='#fff';M.fillRect(x+ox,y+oy,w,h);});}
  for(let i=0;i<7;i++){const x=rng()*W,y=rng()*H,w=rr(20,60),h=rr(8,20);wrap9(W,H,(ox,oy)=>{M.fillStyle='rgba(255,255,255,.85)';blob(M,x+ox,y+oy,w,h,.6,0);L.fillStyle='rgba(60,60,60,.5)';L.fillRect(x+ox-w*.8,y+oy+h,w*1.6,2.5);});}},
 furrow(L,M,W,H){   // deep furrows, blocky ridges; grey-green lichen
  for(let i=0;i<34;i++){const x=rng()*W;L.strokeStyle='rgba(40,40,40,.75)';L.lineWidth=rr(3,7);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+rr(-14,14),oy+H*.33,x+ox+rr(-14,14),oy+H*.66,x+ox+rr(-6,6),oy+H+10);L.stroke();});}
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(45,45,45,.6)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(8,22),rr(2,4)));}
  for(let i=0;i<40;i++){const x=rng()*W;L.strokeStyle='rgba(185,185,185,.35)';L.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.lineTo(x+ox+rr(-8,8),oy+H);L.stroke();});}
  M.fillStyle='rgba(255,255,255,.35)';for(let i=0;i<8;i++){const x=rng()*W,y=rng()*H,r=rr(14,34);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.5,.6,0));}},   // lichen: a soft stain, not spots
 stringy(L,M,W,H){   // cypress: long fibres, weathered grey strands over cinnamon
  for(let i=0;i<300;i++){const x=rng()*W,d=rng();L.strokeStyle='rgba('+(d<.5?'55,55,55':'170,170,170')+','+(.3+rng()*.5).toFixed(2)+')';L.lineWidth=d<.5?rr(2,5):rr(1,2);
   wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+rr(-10,10),oy+H*.33,x+ox+rr(-10,10),oy+H*.66,x+ox+rr(-8,8),oy+H+10);L.stroke();});}
  M.fillStyle='#fff';for(let i=0;i<50;i++){const x=rng()*W,y=rng()*H,w=rr(2,7),h=rr(60,300);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.3,rr(-.03,.03)));}},
 pale(L,M,W,H){   // smooth pale, horizontal lenticels, a bloom of green algae
  L.fillStyle='#9c9c9c';L.fillRect(0,0,W,H);
  for(let k=0;k<22;k++){const y=rng()*H;L.fillStyle='rgba('+(rng()<.5?'130,130,130':'175,175,175')+',.35)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(4,22)));}
  for(let i=0;i<120;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,'+(.3+rng()*.4).toFixed(2)+')';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(6,24),rr(1.5,3.5)));}
  M.fillStyle='rgba(255,255,255,.3)';for(let i=0;i<9;i++){const x=rng()*W,y=rng()*H,r=rr(14,40);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.8,.6,0));}},   // algae: a faint wash, not camouflage
 cork(L,M,W,H){   // thick spongy cork: a network of deep fissures with red-brown in their floors
  L.fillStyle='#9a9a9a';L.fillRect(0,0,W,H);
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H,r=rr(12,30),l=Math.round(rr(130,185));L.fillStyle='rgba('+l+','+l+','+l+',.5)';wrap9(W,H,(ox,oy)=>blob(L,x+ox,y+oy,r,r*1.4,.4,0));}
  const P=[];for(let i=0;i<34;i++)P.push([rng()*W,rng()*H]);
  for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const a=P[i],b=P[j];if(Math.hypot(a[0]-b[0],a[1]-b[1])>90||rng()<.4)continue;const lw=rr(4,9);
   wrap9(W,H,(ox,oy)=>{L.strokeStyle='rgba(35,35,35,.85)';L.lineWidth=lw;L.beginPath();L.moveTo(a[0]+ox,a[1]+oy);L.quadraticCurveTo((a[0]+b[0])/2+ox+rr(-10,10),(a[1]+b[1])/2+oy+rr(-10,10),b[0]+ox,b[1]+oy);L.stroke();
    M.strokeStyle='#fff';M.lineWidth=lw*.55;M.beginPath();M.moveTo(a[0]+ox,a[1]+oy);M.lineTo(b[0]+ox,b[1]+oy);M.stroke();});}},
 strip(L,M,W,H){   // ribbon gum: long vertical flames of red over white, some slanted
  for(let i=0;i<120;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba(110,110,110,.2)';L.lineWidth=1;wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-2,2),y+oy+rr(30,90));L.stroke();});}
  for(let i=0;i<22;i++){const x=rng()*W,y=rng()*H,w=rr(6,20),h=rr(120,300),sl=rr(-.12,.12),l=Math.round(rr(150,185));
   wrap9(W,H,(ox,oy)=>{M.fillStyle='#fff';blob(M,x+ox,y+oy,w,h,.3,sl);L.fillStyle='rgba('+l+','+l+','+l+',.6)';blob(L,x+ox,y+oy,w,h,.3,sl);L.strokeStyle='rgba(60,60,60,.35)';L.lineWidth=1;L.stroke();});}},
 ocelli(L,M,W,H){   // the eyed beech: smooth tan, dark ringed eyes and chevrons
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(70,70,70,.3)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(6,18),rr(1.5,3)));}
  const dx=42,dy=46;for(let j=-1;j<=H/dy+1;j++)for(let i=-1;i<=W/dx+1;i++){const x=i*dx+(j%2?dx/2:0)+rr(-5,5),y=j*dy+rr(-5,5),r=rr(9,15);if(rng()<.15)continue;
   M.fillStyle='#fff';M.beginPath();M.ellipse(x,y,r,r*1.15,0,0,TAU);M.fill();M.fillStyle='#000';M.beginPath();M.ellipse(x,y,r*.62,r*.72,0,0,TAU);M.fill();
   M.fillStyle='#fff';M.beginPath();M.ellipse(x,y,r*.28,r*.32,0,0,TAU);M.fill();L.fillStyle='rgba(90,90,90,.35)';L.beginPath();L.ellipse(x,y+2,r*1.05,r*1.2,0,0,TAU);L.fill();}},
 crack(L,M,W,H){   // the crimson ghost: cream bark split in a gold-orange network
  L.fillStyle='#9e9e9e';L.fillRect(0,0,W,H);
  const P=[];for(let i=0;i<40;i++)P.push([rng()*W,rng()*H]);
  for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const a=P[i],b=P[j],dd=Math.hypot(a[0]-b[0],(a[1]-b[1])*.5);if(dd>70||rng()<.35)continue;const lw=rr(2.5,6),mx=rr(-8,8),my=rr(-8,8);
   wrap9(W,H,(ox,oy)=>{M.strokeStyle='#fff';M.lineWidth=lw;M.beginPath();M.moveTo(a[0]+ox,a[1]+oy);M.quadraticCurveTo((a[0]+b[0])/2+ox+mx,(a[1]+b[1])/2+oy+my,b[0]+ox,b[1]+oy);M.stroke();
    L.strokeStyle='rgba(70,70,70,.5)';L.lineWidth=lw*.35;L.stroke();});}},
 plate(L,M,W,H){   // flatwood pine: red plates, dark fissures, pale flaking edges
  L.fillStyle='#909090';L.fillRect(0,0,W,H);
  for(let j=0;j<16;j++)for(let i=0;i<5;i++){const x=i*W/5+rr(-8,8)+(j%2?W/10:0),y=j*H/16+rr(-5,5),w=W/5*rr(.8,.98),h=H/16*rr(.9,1.6),l=Math.round(rr(125,175));
   wrap9(W,H,(ox,oy)=>{L.fillStyle='rgba('+l+','+l+','+l+',.85)';blob(L,x+ox,y+oy,w*.5,h*.5,.25,0);M.fillStyle='rgba(255,255,255,.55)';M.fillRect(x+ox-w*.45,y+oy-h*.5,w*.9,2.5);});}
  for(let i=0;i<30;i++){const x=rng()*W;L.strokeStyle='rgba(30,30,30,.7)';L.lineWidth=rr(2,4);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.lineTo(x+ox+rr(-12,12),oy+H);L.stroke();});}},
 cane(L,M,W,H){   // a cane: fine vertical striations, two nodes per tile
  for(let i=0;i<90;i++){const x=rng()*W;L.strokeStyle='rgba('+(rng()<.5?'110,110,110':'170,170,170')+',.35)';L.lineWidth=rr(1,2.5);L.beginPath();L.moveTo(x,0);L.lineTo(x,H);L.stroke();}
  [0,H/2].forEach(y=>{L.fillStyle='rgba(50,50,50,.8)';L.fillRect(0,y,W,5);L.fillRect(0,y+H-1,W,1);L.fillStyle='rgba(200,200,200,.7)';L.fillRect(0,y+5,W,4);M.fillStyle='#fff';M.fillRect(0,y-3,W,10);});M.fillRect(0,H-3,W,3);},
 fibre(L,M,W,H){   // palm trunk: leaf-base scars in a lattice, fibres between
  for(let i=0;i<300;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba('+(rng()<.5?'60,60,60':'170,170,170')+','+(.3+rng()*.4).toFixed(2)+')';L.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-6,6),y+oy+rr(14,50));L.stroke();});}
  const dx=64,dy=64;for(let j=-1;j<=H/dy+1;j++)for(let i=-1;i<=W/dx+1;i++){const x=i*dx+(j%2?dx/2:0),y=j*dy;L.strokeStyle='rgba(40,40,40,.55)';L.lineWidth=3;L.beginPath();L.moveTo(x-dx*.45,y);L.quadraticCurveTo(x,y+dy*.25,x+dx*.45,y);L.stroke();}},
};
Object.assign(PAINT,{
 ghost(L,M,W,H){   // powder-white, faint blotches of grey where the bark is shedding
  L.fillStyle='#a0a0a0';L.fillRect(0,0,W,H);
  for(let i=0;i<60;i++){const x=rng()*W,y=rng()*H;L.fillStyle='rgba(120,120,120,.18)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(4,14),rr(1,2.5)));}
  M.fillStyle='rgba(255,255,255,.55)';for(let i=0;i<14;i++){const x=rng()*W,y=rng()*H,w=rr(10,30),h=rr(20,70);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.5,rr(-.1,.1)));}},
 bluegum(L,M,W,H){   // blue-grey, long ribbons of cream bark peeling down
  for(let i=0;i<120;i++){const x=rng()*W;L.strokeStyle='rgba('+(rng()<.5?'120,120,120':'170,170,170')+',.25)';L.lineWidth=rr(1,3);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.lineTo(x+ox+rr(-6,6),oy+H);L.stroke();});}
  for(let i=0;i<14;i++){const x=rng()*W,y=rng()*H,w=rr(5,14),h=rr(120,320),sl=rr(-.05,.05);wrap9(W,H,(ox,oy)=>{M.fillStyle='#fff';blob(M,x+ox,y+oy,w,h,.25,sl);L.fillStyle='rgba(60,60,60,.3)';L.fillRect(x+ox+w,y+oy-h*.8,2,h*1.6);});}},
 birch(L,M,W,H){   // white; black horizontal lenticels and chevron scars
  L.fillStyle='#a8a8a8';L.fillRect(0,0,W,H);
  M.fillStyle='#fff';for(let i=0;i<70;i++){const x=rng()*W,y=rng()*H,w=rr(10,40),h=rr(2,5);wrap9(W,H,(ox,oy)=>M.fillRect(x+ox,y+oy,w,h));}
  for(let i=0;i<9;i++){const x=rng()*W,y=rng()*H,w=rr(20,50);wrap9(W,H,(ox,oy)=>{M.beginPath();M.moveTo(x+ox-w,y+oy);M.lineTo(x+ox,y+oy+w*.5);M.lineTo(x+ox+w,y+oy);M.lineTo(x+ox+w,y+oy+8);M.lineTo(x+ox,y+oy+w*.5+10);M.lineTo(x+ox-w,y+oy+8);M.closePath();M.fill();});}},
 paper(L,M,W,H){   // paperbark: soft layered sheets, torn edges showing tan beneath
  for(let k=0;k<40;k++){const y=rng()*H,l=Math.round(rr(130,180));L.fillStyle='rgba('+l+','+l+','+l+',.5)';wrap9(W,H,(ox,oy)=>L.fillRect(0,y+oy,W,rr(6,30)));}
  M.fillStyle='rgba(255,255,255,.8)';for(let i=0;i<24;i++){const x=rng()*W,y=rng()*H,w=rr(20,60),h=rr(6,18);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.6,0));}},
 fern(L,M,W,H){   // tree fern: frond-base scars in a lattice on a dark fibrous trunk
  for(let i=0;i<260;i++){const x=rng()*W,y=rng()*H;L.strokeStyle='rgba('+(rng()<.5?'60,60,60':'160,160,160')+',.4)';L.lineWidth=rr(1,2.5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,y+oy);L.lineTo(x+ox+rr(-5,5),y+oy+rr(10,40));L.stroke();});}
  const dx=36,dy=40;for(let j=-1;j<=H/dy+1;j++)for(let i=-1;i<=W/dx+1;i++){const x=i*dx+(j%2?dx/2:0),y=j*dy;M.fillStyle='#fff';M.beginPath();M.ellipse(x,y,dx*.28,dy*.2,0,0,TAU);M.fill();L.fillStyle='rgba(40,40,40,.5)';L.beginPath();L.ellipse(x,y+3,dx*.2,dy*.12,0,0,TAU);L.fill();}},
 silver(L,M,W,H){   // the glow-willow: silver, softly twisted furrows
  for(let i=0;i<26;i++){const x=rng()*W;L.strokeStyle='rgba(80,80,80,.5)';L.lineWidth=rr(2,5);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+30,oy+H*.33,x+ox-20,oy+H*.66,x+ox+15,oy+H+10);L.stroke();});}
  for(let i=0;i<40;i++){const x=rng()*W;L.strokeStyle='rgba(200,200,200,.35)';L.lineWidth=rr(1,3);wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy);L.bezierCurveTo(x+ox+25,oy+H*.4,x+ox-15,oy+H*.7,x+ox+10,oy+H);L.stroke();});}
  M.fillStyle='rgba(255,255,255,.4)';for(let i=0;i<8;i++){const x=rng()*W,y=rng()*H,r=rr(10,26);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,r,r*1.6,.5,.2));}},
 char(L,M,W,H){   // grass tree: charred leaf bases, black with grey ash in the cracks
  for(let i=0;i<500;i++){const x=rng()*W,y=rng()*H,l=Math.round(rr(50,150));L.fillStyle='rgba('+l+','+l+','+l+',.6)';wrap9(W,H,(ox,oy)=>L.fillRect(x+ox,y+oy,rr(4,10),rr(2,5)));}
  M.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<160;i++){const x=rng()*W,y=rng()*H;wrap9(W,H,(ox,oy)=>M.fillRect(x+ox,y+oy,rr(2,6),1.5));}},
 smooth(L,M,W,H){PAINT.pale(L,M,W,H);},
 fibrenw(L,M,W,H){   // blue-grey fibres; the weathered (alt) strands few, so brown stays in the grooves
  for(let i=0;i<300;i++){const x=rng()*W,d=rng();L.strokeStyle='rgba('+(d<.5?'60,60,60':'170,170,170')+','+(.3+rng()*.5).toFixed(2)+')';L.lineWidth=d<.5?rr(2,5):rr(1,2);
   wrap9(W,H,(ox,oy)=>{L.beginPath();L.moveTo(x+ox,oy-10);L.bezierCurveTo(x+ox+rr(-10,10),oy+H*.33,x+ox+rr(-10,10),oy+H*.66,x+ox+rr(-8,8),oy+H+10);L.stroke();});}
  M.fillStyle='#fff';for(let i=0;i<14;i++){const x=rng()*W,y=rng()*H,w=rr(1.5,3.5),h=rr(60,220);wrap9(W,H,(ox,oy)=>blob(M,x+ox,y+oy,w,h,.3,0));}},
});
function barkTex2(kind){const W=256,H=512,cl=document.createElement('canvas'),cm=document.createElement('canvas');cl.width=cm.width=W;cl.height=cm.height=H;
 const L=cl.getContext('2d'),M=cm.getContext('2d');L.fillStyle='#8c8c8c';L.fillRect(0,0,W,H);M.fillStyle='#000';M.fillRect(0,0,W,H);
 PAINT[kind](L,M,W,H);
 const Ld=L.getImageData(0,0,W,H).data,Md=M.getImageData(0,0,W,H).data,out=L.createImageData(W,H),o=out.data;let s=0;
 for(let i=0;i<o.length;i+=4){o[i]=Ld[i];o[i+1]=Md[i];o[i+2]=Ld[i];o[i+3]=255;s+=Ld[i];}
 const c=document.createElement('canvas');c.width=W;c.height=H;c.getContext('2d').putImageData(out,0,0);
 const t=new T3.CanvasTexture(c);t.wrapS=t.wrapT=T3.RepeatWrapping;t.anisotropy=8;t.encoding=T3.LinearEncoding;t.biomeMean=s/(W*H)/255;return t;}   // r128 textures have no userData
NWLOW.barkMat2=function(tex,key,o){o=o||{};
 const m=new T3.MeshLambertMaterial({color:0xffffff,map:tex,vertexColors:true,side:T3.DoubleSide});
 const alt=C(o.alt==null?0x808080:o.alt).convertSRGBToLinear();
 m.onBeforeCompile=sh=>{
  sh.uniforms.uAlt={value:alt};sh.uniforms.uMean={value:tex.biomeMean||.55};sh.uniforms.uGain={value:o.gain==null?.52:o.gain};sh.uniforms.uGloss={value:o.gloss||0};
  if(!BIO.SUN.value)BIO.setSun([.45,.72,-.52]);sh.uniforms.uSunDir=BIO.SUN;
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vBWP;varying vec3 vBWN;')
   .replace('#include <worldpos_vertex>','#include <worldpos_vertex>\nvBWP=(modelMatrix*vec4(transformed,1.0)).xyz;vBWN=normalize(mat3(modelMatrix)*objectNormal);');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform vec3 uAlt,uSunDir;uniform float uMean,uGain,uGloss;varying vec3 vBWP;varying vec3 vBWN;')
   .replace('#include <map_fragment>','vec4 _bt=texture2D(map,vUv);float _bl=_bt.r/uMean;float _bm=_bt.g;')
   .replace('#include <color_fragment>','diffuseColor.rgb*=mix(vColor,uAlt,_bm)*_bl*uGain;')
   .replace('#include <envmap_fragment>','{vec3 _V=normalize(cameraPosition-vBWP);vec3 _N=normalize(vBWN);if(dot(_N,_V)<0.0)_N=-_N;vec3 _H=normalize(uSunDir+_V);'+
    'float _sp=pow(max(dot(_N,_H),0.0),26.0)*step(0.0,dot(_N,uSunDir));outgoingLight+=uGloss*_sp*vec3(1.0,0.93,0.8)*(1.0-_bm*0.8)*_bl;}\n#include <envmap_fragment>');};
 m.customProgramCacheKey=function(){return'nwlbark|'+key;};return m;};
const BK={};['smooth','ring','fern','ghost','bluegum','birch','fibre','silver','paper','plate','char'].forEach(k=>BK[k]=barkTex2(k==='ring'?'cane':k==='fibre'?'fibrenw':k));
NWLOW.BARKTEX=BK;
// greyscale canvases for the instanced small trunks and the logs/rocks (the kit's usual tint() path)
NWLOW.FIBRETEX=BIO.canvasTex(256,512,(g,w,h)=>{g.fillStyle='#8c8c8c';g.fillRect(0,0,w,h);
 for(let i=0;i<420;i++){const x=rng()*w,y=rng()*h;g.strokeStyle='rgba('+(rng()<.5?'50,50,50':'170,170,170')+','+(.3+rng()*.5).toFixed(2)+')';g.lineWidth=rr(1,3);g.beginPath();g.moveTo(x,y);g.lineTo(x+rr(-6,6),y+rr(14,60));g.stroke();}
 for(let i=0;i<60;i++){g.fillStyle='rgba(40,40,40,.5)';g.beginPath();g.ellipse(rng()*w,rng()*h,rr(5,12),rr(3,6),0,0,TAU);g.fill();}});
NWLOW.SMOOTHTEX=BIO.canvasTex(256,512,(g,w,h)=>{g.fillStyle='#8c8c8c';g.fillRect(0,0,w,h);
 for(let k=0;k<26;k++){const y=rng()*h;g.fillStyle='rgba('+(rng()<.5?'120,120,120':'165,165,165')+',.35)';g.fillRect(0,y,w,rr(4,26));}
 for(let i=0;i<110;i++){const x=rng()*w,y=rng()*h;g.fillStyle='rgba(60,60,60,'+(.4+rng()*.4).toFixed(2)+')';g.fillRect(x,y,rr(6,26),rr(1.5,3.5));}});
NWLOW.WOODTEX=BIO.canvasTex(256,256,(g,w,h)=>{g.fillStyle='#8a8074';g.fillRect(0,0,w,h);
 for(let i=0;i<220;i++){const y=rng()*h;g.strokeStyle='rgba('+(rng()<.5?'60,52,44':'170,160,150')+','+(.2+rng()*.4).toFixed(2)+')';g.lineWidth=1+rng()*2;
  g.beginPath();g.moveTo(-4,y);g.lineTo(w+4,y+rr(-5,5));g.stroke();}});
NWLOW.ROCKTEX=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=120+(fbm(x/22,y/22,3.3,3)-.5)*70+(fbm(x/4,y/4,9,1)-.5)*24+8*Math.sin(y*.35+fbm(x/40,y/40,5,2)*8);d[i]=v;d[i+1]=v*.97;d[i+2]=v*.92;d[i+3]=255;}
 g.putImageData(id,0,0);});

// the bamboo culm: a greyscale canvas (nodes with a pale waxy ring under each), tinted per instance
NWLOW.CULMTEX=BIO.canvasTex(64,256,(g,w,h)=>{g.fillStyle='#8c8c8c';g.fillRect(0,0,w,h);
 for(let i=0;i<30;i++){const x=rng()*w;g.strokeStyle='rgba('+(rng()<.5?'110,110,110':'170,170,170')+',.35)';g.lineWidth=rr(1,2);g.beginPath();g.moveTo(x,0);g.lineTo(x,h);g.stroke();}
 [0,h/2].forEach(y=>{g.fillStyle='rgba(50,50,50,.8)';g.fillRect(0,y,w,4);g.fillStyle='rgba(220,220,220,.7)';g.fillRect(0,y+4,w,7);});});
NWLOW.CULMTEX.repeat.set(1,9);
// ---------------------------------------------------------------- geometries local to this biome
const G={};
// a TUFT: three crossed vertical quads, origin at the base, up to y=1
G.tuft=function(){const pos=[],uv=[],nor=[];
 for(let k=0;k<3;k++){const a=k/3*Math.PI+.2,ca=Math.cos(a),sa=Math.sin(a);
  const P=[[-.5,0],[.5,0],[.5,1],[-.5,1]].map(q=>[ca*q[0],q[1],sa*q[0],q[0]+.5,1-q[1]]);
  [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(-sa,0,ca);});}
 return BIO.geo._make(pos,nor,uv);};
// a FAN: one vertical quad, base at the origin, up to y=1, local +z its face
G.fan=function(){const pos=[],uv=[],nor=[];const P=[[-.5,0],[.5,0],[.5,1],[-.5,1]].map(q=>[q[0],q[1],0,q[0]+.5,1-q[1]]);
 [0,1,2,0,2,3].forEach(i=>{pos.push(P[i][0],P[i][1],P[i][2]);uv.push(P[i][3],P[i][4]);nor.push(0,0,1);});return BIO.geo._make(pos,nor,uv);};
// a DROOPING FAN: the fan card bent in three bands so it arches out and hangs (the skirt palm's wide hanging leaves)
G.droop=function(){const pos=[],uv=[],nor=[];const R=[[0,0,0],[0,.22,.30],[0,.16,.62],[0,-.22,.84]];   // (x unused, y, z) of each row's spine: out, over, and down
 const rows=R.map((r,i)=>{const t=i/(R.length-1),w=.5*Math.min(1,.35+t*1.1);return[[-w,r[1],r[2],.5-w,1-t*1],[w,r[1],r[2],.5+w,1-t]];});
 for(let i=0;i<rows.length-1;i++){const a=rows[i][0],b=rows[i][1],c=rows[i+1][1],d=rows[i+1][0];
  [a,b,c,a,c,d].forEach(p=>{pos.push(p[0],p[1],p[2]);uv.push(p[3],p[4]);nor.push(0,1,0);});}
 return BIO.geo._make(pos,nor,uv);};
// a ROSETTE: three tiers of fleshy bent leaves, vertex-coloured pale at the base (agave, bromeliad)
G.rosette=function(tiers){const pos=[],nor=[],uv=[],col=[];
 tiers=tiers||[[10,1.0,.30,.55],[8,.70,.55,.40],[6,.42,.85,.28]];
 tiers.forEach((tr,ti)=>{const n=tr[0],R=tr[1],el=tr[2],wd=tr[3];const a0=ti*.31;
  for(let k=0;k<n;k++){const a=a0+k/n*TAU,ca=Math.cos(a),sa=Math.sin(a),px=-sa,pz=ca;
   const tip=[ca*R,Math.sin(el)*R*.9+.05,sa*R],mid=[ca*R*.5,Math.sin(el)*R*.35+.04,sa*R*.5],base=[ca*.08,.02,sa*.08];
   const W=wd*R;
   const q=[[base[0]-px*W*.25,base[1],base[2]-pz*W*.25],[base[0]+px*W*.25,base[1],base[2]+pz*W*.25],[mid[0]+px*W*.5,mid[1],mid[2]+pz*W*.5],[mid[0]-px*W*.5,mid[1],mid[2]-pz*W*.5],tip];
   const nrm=[-Math.sin(el)*ca,Math.cos(el),-Math.sin(el)*sa];
   const push=(p,c)=>{pos.push(p[0],p[1],p[2]);nor.push(nrm[0],nrm[1],nrm[2]);uv.push(0,0);col.push(c,c,c);};
   push(q[0],.55);push(q[1],.55);push(q[2],.85);push(q[0],.55);push(q[2],.85);push(q[3],.85);
   push(q[3],.85);push(q[2],.85);push(q[4],1.0);}});
 return BIO.geo._make(pos,nor,uv,col);};
// a LILY PAD: a flat disc with a notch, unit radius, vertex-coloured (lighter centre)
G.pad=function(){const pos=[],nor=[],uv=[],col=[];const n=11;
 for(let k=0;k<n;k++){const a0=(k/n)*TAU*.92+.25,a1=((k+1)/n)*TAU*.92+.25;
  const r0=1+.06*Math.sin(k*3.1),r1=1+.06*Math.sin((k+1)*3.1);
  [[0,0,0,1.12],[Math.cos(a1)*r1,0,Math.sin(a1)*r1,.92],[Math.cos(a0)*r0,0,Math.sin(a0)*r0,.92]].forEach(p=>{pos.push(p[0],p[1],p[2]);nor.push(0,1,0);uv.push(0,0);col.push(p[3],p[3],p[3]);});}
 return BIO.geo._make(pos,nor,uv,col);};
// a CONE: origin at the base (cypress knees, kapok spines, mangrove pneumatophores)
G.cone=function(){const g=new T3.ConeGeometry(.5,1,6,1);g.translate(0,.5,0);return g;};
NWLOW.G=G;

// a CULM: an open unit cylinder from y=0 to 1 (the bamboo stem, instanced)
G.culm=function(n){const g=new T3.CylinderGeometry(.5,.5,1,n||6,1,true);g.translate(0,.5,0);return g;};
// a BELLY CULM: short swollen internodes (Buddha-belly bamboo), a lathe, y 0..1
G.belly=function(){const P=[];const N=9;for(let i=0;i<=N*6;i++){const t=i/(N*6),k=(i%6)/6;P.push(new T3.Vector2(.5*(0.72+.32*Math.sin(k*Math.PI)),t));}return new T3.LatheGeometry(P,6);};
// a COIL: a culm wound in a helix (coil cane), y 0..1
G.coil=function(){const pts=[];for(let i=0;i<=40;i++){const t=i/40,a=t*TAU*3.2;pts.push(new T3.Vector3(Math.cos(a)*.035,t,Math.sin(a)*.035));}
 return new T3.TubeGeometry(new T3.CatmullRomCurve3(pts),40,.012,5,false);};
// a LANTERN: a five-lobed papery calyx, origin at its top (it hangs), y 0 .. -1
G.lantern=function(){const P=[];for(let i=0;i<=5;i++){const t=i/5;P.push(new T3.Vector2(.5*Math.sin(Math.PI*Math.pow(t,.8))*(1-.15*t),-t));}
 const g=new T3.LatheGeometry(P,7),p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),a=Math.atan2(z,x),k=1+.12*Math.cos(a*5);p.setX(i,x*k);p.setZ(i,z*k);}g.computeVertexNormals();return g;};
NWLOW.G=G;

// ---------------------------------------------------------------- materials
const M=NWLOW.MAT={
 bk:{
  smooth:NWLOW.barkMat2(BK.smooth,'smooth',{alt:0x6a8a70,gloss:.06}),
  ring:NWLOW.barkMat2(BK.ring,'ring',{alt:0x5a6660,gloss:.2}),
  fern:NWLOW.barkMat2(BK.fern,'fern',{alt:0x5a4a3a,gloss:0}),
  ghost:NWLOW.barkMat2(BK.ghost,'ghost',{alt:0xb8bab4,gloss:.08}),
  bluegum:NWLOW.barkMat2(BK.bluegum,'bluegum',{alt:0xe0dcc8,gloss:.05}),
  birch:NWLOW.barkMat2(BK.birch,'birch',{alt:0x1e2022,gloss:.05}),
  fibre:NWLOW.barkMat2(BK.fibre,'fibre',{alt:0x6a5a4e,gloss:0}),
  silver:NWLOW.barkMat2(BK.silver,'silver',{alt:0xa8b0b4,gloss:.25}),
  paper:NWLOW.barkMat2(BK.paper,'paper',{alt:0xb4a484,gloss:0}),
  plate:NWLOW.barkMat2(BK.plate,'plate',{alt:0x6a4a38,gloss:0}),
  char:NWLOW.barkMat2(BK.char,'char',{alt:0x8a8a86,gloss:0})},
 wood:BIO.barkMat(NWLOW.WOODTEX),
 rock:BIO.barkMat(NWLOW.ROCKTEX),
 oakleaf:BIO.leafMat(TX.oakleaf,'nwl-oakleaf',{aN:true,swayW:'1.0',swayA:.10}),
 glossy:BIO.leafMat(TX.glossy,'nwl-glossy',{aN:true,swayW:'1.0',swayA:.12}),
 broad:BIO.leafMat(TX.broad,'nwl-broad',{aN:true,swayW:'1.0',swayA:.14}),
 lance:BIO.leafMat(TX.lance,'nwl-lance',{aN:true,swayW:'1.0',swayA:.16}),
 needle:BIO.leafMat(TX.needle,'nwl-needle',{aN:true,swayW:'1.0',swayA:.08}),
 feather:BIO.leafMat(TX.feather,'nwl-feather',{aN:true,swayW:'1.0',swayA:.12}),
 ginkgo:BIO.leafMat(TX.ginkgo,'nwl-ginkgo',{aN:true,swayW:'1.0',swayA:.12}),
 bleaf:BIO.leafMat(TX.bleaf,'nwl-bleaf',{aN:true,swayW:'1.0',swayA:.18}),
 blossom:BIO.leafMat(TX.blossom,'nwl-blossom',{aN:true,swayW:'1.0',swayA:.10}),
 veil:BIO.leafMat(TX.willow,'nwl-veil',{swayW:'(-position.y)',swayA:.10,axis:1,alphaTest:.36}),
 drape:BIO.leafMat(TX.willow,'nwl-drape',{swayW:'(-position.y)',swayA:.08,axis:1,alphaTest:.36}),
 palmfrond:BIO.leafMat(TX.palmfrond,'nwl-palmfrond',{swayW:'(position.x)',swayA:.10}),
 bigfrond:BIO.leafMat(TX.bigfrond,'nwl-bigfrond',{swayW:'(position.x)',swayA:.09}),
 frond:BIO.leafMat(TX.frond,'nwl-frond',{swayW:'(position.x)',swayA:.07}),
 forkfern:BIO.leafMat(TX.forkfern,'nwl-forkfern',{swayW:'(position.x)',swayA:.06}),
 heart:BIO.leafMat(TX.heart,'nwl-heart',{swayW:'(position.y)',swayA:.07,alphaTest:.45}),
 spike:BIO.leafMat(TX.spike,'nwl-spike',{swayW:'(position.y)',swayA:.04,alphaTest:.42}),
 lupin:BIO.leafMat(TX.lupin,'nwl-lupin',{swayW:'(position.y)',swayA:.08,alphaTest:.42}),
 pen:BIO.leafMat(TX.pen,'nwl-pen',{swayW:'(position.y)',swayA:.05,alphaTest:.42}),
 clubpen:BIO.leafMat(TX.clubpen,'nwl-clubpen',{swayW:'(position.y)',swayA:.03,alphaTest:.42}),
 reed:BIO.leafMat(TX.reed,'nwl-reed',{swayW:'(position.y)',swayA:.11,alphaTest:.4}),
 grass:BIO.leafMat(TX.grass,'nwl-grass',{swayW:'(position.y)',swayA:.12,alphaTest:.4}),
 under:BIO.leafMat(TX.under,'nwl-under',{swayW:'1.0',swayA:.06}),
 beard:BIO.leafMat(TX.beard,'nwl-beard',{swayW:'(-position.y)',swayA:.12,axis:1,alphaTest:.35}),
 hang:BIO.leafMat(TX.under,'nwl-hang',{swayW:'(-position.y)',swayA:.055,axis:1}),
 moss:BIO.leafMat(TX.moss,'nwl-moss',{swayW:'1.0',swayA:.012,alphaTest:.3}),
 bloom:BIO.leafMat(TX.bloom,'nwl-bloom',{swayW:'1.0',swayA:.05,alphaTest:.4}),
 staghorn:BIO.leafMat(TX.staghorn,'nwl-staghorn',{swayW:'(position.y)',swayA:.03,alphaTest:.45}),
 rosette:BIO.leafMat(null,'nwl-rosette',{swayW:'0.0',swayA:0,alphaTest:0,vertexColors:true}),
 pad:BIO.leafMat(null,'nwl-pad',{swayW:'1.0',swayA:.02,alphaTest:0,vertexColors:true}),
 culm:BIO.solidMat(NWLOW.CULMTEX),
 // the lanterns light themselves: unlit, so their colour is their own at any hour; a soft additive halo round each
 lantern:new T3.MeshBasicMaterial({color:0xffffff,side:T3.DoubleSide}),
 halo:new T3.MeshBasicMaterial({map:TX.glow,color:0xffffff,transparent:true,blending:T3.AdditiveBlending,depthWrite:false,side:T3.DoubleSide,fog:false}),
 solid:BIO.solidMat(null,0xffffff),
};
[['smooth','Smooth bark (meranti, ginkgo, poplar, wattle, banksia)',[3,5]],['ring','Ringed stems (mist palm, pandan)',[1,1.6]],['fern','Tree-fern trunks',[1.2,1.6]],
 ['ghost','Ghost bark (ghost gum, tower ash)',[3,5]],['bluegum','Ribbon bark (blue gum)',[2.4,6]],['birch','Birch bark',[1.2,2.2]],['fibre','Fibrous bark (spire cedar, cypress, she-oak)',[2.4,5]],
 ['silver','Silver bark (glow-willow)',[2.4,4]],['paper','Paperbark',[2,2.4]],['plate','Plated bark (kauri, crag pine)',[2,3.4]],['char','Grass-tree trunks',[1,1.4]]]
 .forEach(b=>BIO.bucket('bk_'+b[0],M.bk[b[0]],{label:b[1],uvScale:b[2]}));
BIO.bucket('wood',M.wood,{label:'Dead wood',uvScale:[3,4]});
BIO.bucket('rock',M.rock,{label:'Boulders',uvScale:[6,6]});
BIO.bucket('far',BIO.barkMat(null),{label:'Far trees (impostors)'});

// ---------------------------------------------------------------- instanced items
[['glossy','Glossy foliage'],['broad','Broadleaf foliage'],['lance','Gum foliage'],['needle','Needle pads'],['feather','Feathery foliage (wattle)'],['ginkgo','Ginkgo foliage'],
 ['bleaf','Bamboo leaves'],['blossom','Blossom']].forEach(d=>BIO.def(d[0],BIO.geo.clump(),M[d[0]],{attrs:['aN'],label:d[1]}));
BIO.def('veil',BIO.geo.ribbon(6,.45,.10),M.veil,{label:'Glow-willow veils'});
BIO.def('drape',BIO.geo.ribbon(3,.5,.06),M.drape,{label:'She-oak drapes'});
BIO.def('palmfrond',BIO.geo.frond(4),M.palmfrond,{label:'Palm fronds'});
BIO.def('bigfrond',BIO.geo.frond(4),M.bigfrond,{label:'Tree-fern fronds'});
BIO.def('frond',BIO.geo.frond(3),M.frond,{label:'Fern fronds'});
BIO.def('forkfern',BIO.geo.frond(3),M.forkfern,{label:'Forking ferns'});
BIO.def('heart',G.fan(),M.heart,{label:'Teal aroids'});
BIO.def('spike',G.tuft(),M.spike,{label:'Blade leaves'});
BIO.def('lupin',G.tuft(),M.lupin,{label:'Flower spikes'});
BIO.def('pen',G.tuft(),M.pen,{label:'Sea pens'});
BIO.def('clubpen',G.tuft(),M.clubpen,{label:'Club pens'});
BIO.def('reed',G.tuft(),M.reed,{label:'Reeds'});
BIO.def('grass',G.tuft(),M.grass,{label:'Grass'});
BIO.def('ucard',BIO.geo.clump(),M.under,{label:'Understorey foliage'});
BIO.def('beard',BIO.geo.ribbon(4,.6,.12),M.beard,{label:'Hanging moss'});
BIO.def('ribbon',BIO.geo.ribbon(4,.55,.18),M.hang,{label:'Hanging growth'});
BIO.def('strand',BIO.geo.ribbon(2,.4,.05),M.hang,{label:'Strands and bark ribbons'});
BIO.def('mossmat',BIO.geo.mat(),M.moss,{label:'Moss and litter'});
BIO.def('lobe',BIO.geo.lobe(),M.solid,{label:'Shrub lobes'});
BIO.def('bloom',BIO.geo.bloom(),M.bloom,{label:'Flowers'});
BIO.def('staghorn',G.fan(),M.staghorn,{label:'Staghorn ferns'});
BIO.def('rosette',G.rosette(),M.rosette,{label:'Rosettes'});
BIO.def('pad',G.pad(),M.pad,{label:'Lotus and lily pads'});
BIO.def('cone',G.cone(),M.solid,{label:'Shoots and cones'});
BIO.def('rod',BIO.geo.rod(6),M.solid,{label:'Stems and stalks'});
BIO.def('trunk',BIO.geo.trunk(8),BIO.solidMat(NWLOW.FIBRETEX),{label:'Small trunks (fibrous)'});
BIO.def('trunk2',BIO.geo.trunk(8),BIO.solidMat(NWLOW.SMOOTHTEX),{label:'Small trunks (smooth)'});
BIO.def('culm',G.culm(6),M.culm,{label:'Sky bamboo'});
BIO.def('belly',G.belly(),M.culm,{label:'Buddha-belly bamboo'});
BIO.def('coil',G.coil(),M.solid,{label:'Coil cane'});
BIO.def('lantern',G.lantern(),M.lantern,{label:'Glow-willow lanterns'});
BIO.def('halo',BIO.geo.bloom(),M.halo,{label:'Lantern glow'});
BIO.def('pompom',new T3.IcosahedronGeometry(1,1),M.solid,{label:'Flower heads'});
BIO.def('fungus',new T3.SphereGeometry(1,9,5,0,TAU,0,Math.PI*.5),M.solid,{label:'Bracket fungus'});
BIO.def('boulder',new T3.IcosahedronGeometry(1,1),BIO.solidMat(NWLOW.ROCKTEX),{label:'Boulders'});
})();

// ==================== 55-biome-nwlowlands-trees.js
// ================================================================= NORTHWESTERN LOWLANDS — trees
// Twenty tree species and three bamboos, placed by zone from the host's climate
// fields (wet / tropic / dry / flow / upland) and terrainH. The biome's rule is
// VERTICALITY: trees ~50% taller than their Earth kin, clean boles, few low limbs,
// crowns carried high on steeply ascending limbs, spires and spindles -- the eye goes
// up. (The glow-willow is the exception, and hangs its lanterns.) BAMBOO grows in
// GROVES: patches with a hard edge where the tree passes do not plant, culms taller
// in the interior than at the rim, clumping kinds fringing it -- a sub-biome, not a
// scatter. Beyond the LOD spine the trees become blob impostors and the groves blob
// canopies.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const SP=NWLOW.SPECIES,PAL=NWLOW.PAL,GOLD=2.399963;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
NWLOW.TREES=[];

// ---------------------------------------------------------------- zones from the fields
const Y=(x,z)=>BIO.terrainH(x,z);
function zones(x,z){const wet=BIO.field('wet',x,z),tropic=BIO.field('tropic',x,z),dry=BIO.field('dry',x,z),flow=BIO.field('flow',x,z),up=BIO.field('upland',x,z),h=Y(x,z);
 const trop=smooth(.68,.86,tropic),rain=trop*smooth(.72,.86,wet),sub=(1-trop)*(1-dry)*smooth(.45,.65,wet);
 // bamboo groves: patches of their own in the wet country, likelier by water; a hard-ish edge
 const bk=fbm(x*.0026+5,z*.0026-9,5501,2)+flow*.08+(wet-.8)*.2,bamboo=smooth(.61,.65,bk)*(rain+sub)*(1-dry*.9);
 return{wet,tropic,dry,flow,up,h,rain,sub,bamboo,
  med:dry,
  shore:smooth(3.2,.9,h)*smooth(.82,.95,wet)*(1-dry),
  gully:dry*smooth(.34,.5,wet),
  rip:flow,
  // stands: birch and spire cedar grow in stands of their own
  birchK:smooth(.55,.63,fbm(x*.0021-7,z*.0021+3,5502,2)),spireK:smooth(.56,.64,fbm(x*.0019+11,z*.0019-5,5503,2))};}
NWLOW.zones=zones;

// ---------------------------------------------------------------- colour
function shade(hex,f){const c=hex.isColor?hex.clone():C(hex);if(f>=0)c.lerp(C(0xffffff),f);else c.lerp(C(0x120f0a),-f);return c;}
function bright(col,k){const c=col.isColor?col.clone():C(col);c.convertSRGBToLinear();c.r=Math.min(1,c.r*k);c.g=Math.min(1,c.g*k);c.b=Math.min(1,c.b*k);return c.convertLinearToSRGB();}
const _hsl={h:0,s:0,l:0};
function vary(hex,dh,ds,dl){const c=hex.isColor?hex.clone():C(hex);c.getHSL(_hsl);c.setHSL(((_hsl.h+rr(-dh,dh))%1+1)%1,clamp(_hsl.s+rr(-ds,ds),0,1),clamp(_hsl.l+rr(-dl,dl),.03,.97));return c;}
function texMean(tex){const im=tex&&tex.image;if(!im||!im.getContext)return[.25,.25,.25];
 const d=im.getContext('2d').getImageData(0,0,im.width,im.height).data;let r=0,g=0,b=0,n=0;
 for(let i=0;i<d.length;i+=4*13){r+=d[i];g+=d[i+1];b+=d[i+2];n++;}
 const c=C(0).setRGB(r/n/255,g/n/255,b/n/255).convertSRGBToLinear();return[c.r,c.g,c.b];}
// the sRGB tint that renders `hex` on a greyscale texture of linear mean m (the instanced small trunks, logs, rocks)
function tint(hex,m,k){const c=hex.isColor?hex.clone():C(hex);c.convertSRGBToLinear();k=k==null?1:k;
 c.setRGB(Math.min(1,c.r*k/Math.max(.02,m[0])),Math.min(1,c.g*k/Math.max(.02,m[1])),Math.min(1,c.b*k/Math.max(.02,m[2])));return c.convertLinearToSRGB();}
let MEAN=null;
function means(){if(MEAN)return MEAN;MEAN={fibre:texMean(NWLOW.FIBRETEX),smooth:texMean(NWLOW.SMOOTHTEX),wood:texMean(NWLOW.WOODTEX),rock:texMean(NWLOW.ROCKTEX)};return MEAN;}
Object.assign(NWLOW,{means,tint,bright,shade,vary});
// the two-tone bark buckets take the designer's colour as it should look (their material does the light arithmetic)
const barkC=(S,k)=>vary(C(S.bark[(k==null?ri(0,99):k)%S.bark.length]),.01,.05,.04);
// an untextured rod in a species' bark colour, a shade down for the rig
const rodCol=(hex)=>shade(vary(hex,.01,.05,.04),-.3);
const leafCol=(set,k)=>bright(vary(pick(set),.025,.10,.06),k==null?1.3:k);

// ---------------------------------------------------------------- keep-clear between trees
const HC=120,HASH={};
function hkey(x,z){return Math.floor(x/HC)+','+Math.floor(z/HC);}
function hadd(o){const R=o.r+40;for(let z=Math.floor((o.z-R)/HC);z<=Math.floor((o.z+R)/HC);z++)for(let x=Math.floor((o.x-R)/HC);x<=Math.floor((o.x+R)/HC);x++){const k=x+','+z;(HASH[k]||(HASH[k]=[])).push(o);}}
function blocked(x,z,pad){const L=HASH[hkey(x,z)];if(!L)return false;for(let i=0;i<L.length;i++){const o=L[i];if(Math.hypot(x-o.x,z-o.z)<o.r+pad)return true;}return false;}
// the floor asks only about the bole (rt); the trees ask about each other's ground (r)
function blockedTrunk(x,z,pad){const L=HASH[hkey(x,z)];if(!L)return false;for(let i=0;i<L.length;i++){const o=L[i];if(Math.hypot(x-o.x,z-o.z)<(o.rt||o.r)+pad)return true;}return false;}
NWLOW.blocked=blockedTrunk;NWLOW.blockedGround=blocked;
const clear3=(x,y,z,rad,vr)=>BIO.clearOf3(x,y,z,rad,vr);
const okPts=pts=>{for(let i=1;i<pts.length;i++)if(!clear3(pts[i].x,pts[i].y,pts[i].z,pts[i].r+1.5,pts[i].r+1.5))return false;return true;};

// ---------------------------------------------------------------- the LIMB
// A sinuous limb from o toward azimuth a at elevation el, len metres long,
// radius r0 -> r1 over n segments. sag bends it down with distance (a live
// oak's limbs run out level and droop); rise lifts the last part again; wig
// wanders it sideways. A limb that meets the ground RESTS on it -- the
// sprawl oak's limbs lie along the ground for metres and climb again.
function limbPts(o,a,el,len,r0,r1,n,sag,wig,rise){const ca=Math.cos(a),sa=Math.sin(a),ce=Math.cos(el),se=Math.sin(el),sx=-sa,sz=ca;
 const w1=rr(-1,1)*wig,w2=rr(-1,1)*wig,v1=rr(-1,1)*wig*.6,pts=[];let rested=0;
 for(let k=0;k<=n;k++){const t=k/n,hd=len*ce*t,lat=(w1*Math.sin(t*Math.PI)+w2*Math.sin(t*TAU))*len;
  let y=o.y+len*(se*t+sag*t*t)+(rise||0)*len*Math.pow(smooth(.5,1,t),2)+v1*len*Math.sin(t*TAU)*.5;
  const x=o.x+ca*hd+sx*lat,z=o.z+sa*hd+sz*lat,r=mix(r0,r1,Math.pow(t,.8));
  const gy=Y(x,z)+r*.75;if(k>0&&y<gy){y=gy;rested++;}
  pts.push({x,y,z,r});}
 pts.rested=rested;return pts;}
// a limb's direction at point i (for secondaries)
function limbDir(pts,i){const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)],dx=b.x-a.x,dz=b.z-a.z;return Math.atan2(dz,dx);}

// ---------------------------------------------------------------- foliage and epiphytes
function clumpAt(item,x,y,z,size,flat,col,cx,cy,cz,ex,ey){
 const dx=(x-cx)/ex,dy=(y-cy)/ey,dz=(z-cz)/ex,qq=Math.hypot(dx,dy,dz);
 const ao=mix(.5,1,smooth(.3,.95,qq))*mix(.8,1,smooth(-.6,.35,dy))*rr(.88,1.1);
 const nx=dx*.9+rr(-.3,.3),ny=dy*.7+.75+rr(-.15,.2),nz=dz*.9+rr(-.3,.3),nn=Math.hypot(nx,ny,nz)||1;
 BIO.put(item,[x,y,z],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[size,size*flat,size],bright(col,ao*1.3),{n:[nx/nn,ny/nn,nz/nn]});}
function frondAt(item,x,y,z,a,L,pitch,col,wid){BIO.put(item,[x,y,z],qEuler(rr(-.1,.1),-a,pitch),[L,L*rr(.85,1.05),L*(wid||rr(1.1,1.4))],col);}
// the foliage colour of a clump: the species' set, with the odd flush of bronze new growth
function crownCol(S,flush){return C(rng()<(flush||0)?pick(PAL.flush):pick(S.leaf));}
// Spanish moss off a limb point: how much depends on the species and how wet the ground is
function mossAt(p,k,wet,st,Lmax){const n=Math.round(rr(0,2.2)*k*smooth(.45,.9,wet));
 for(let i=0;i<n;i++){const L=rr(1.5,Lmax||7);BIO.put('beard',[p.x+rr(-.7,.7),p.y-(p.r||.3)*.6,p.z+rr(-.7,.7)],qEuler(0,rr(0,TAU),0),[rr(1,2.2),L,1],bright(vary(pick(PAL.mossPale),.02,.08,.06),1.02));st.moss++;}}
// a staghorn fern on a bole: a shield and antlers, facing out
function staghorn(x,y,z,a,R,s,st){const nx=Math.cos(a),nz=Math.sin(a);
 BIO.put('staghorn',[x+nx*(R+.05),y-s*.3,z+nz*(R+.05)],qFacing([nx,rr(-.1,.25),nz]),[s,s,1],leafCol(PAL.aroid,1.35));
 BIO.put('staghorn',[x+nx*(R+.1),y-s*.2,z+nz*(R+.1)],qFacing([nx,-.6,nz]),[s*.9,s*1.2,1],leafCol(PAL.aroid,1.3));st.epi++;}
// a bromeliad perched on a bough
// grey-green tank bromeliads and air plants only: a red rosette on a bough reads as a flower
// growing out of the bark, which is not how these trees flower
function brom(p,st){const R=rr(.35,.8),c=rng()<.5?vary(pick(PAL.mossPale),.02,.06,.05):vary(pick(PAL.aroid),.03,.1,.06);
 BIO.put('brom',[p.x,p.y+p.r*.8,p.z],qEuler(rr(-.2,.2),rr(0,TAU),rr(-.2,.2)),[R,R*1.1,R],bright(c,1.1));st.epi++;}
// ---------------------------------------------------------------- the crown, ON its branches
// A clump's centre sits within a third of its own size of a real branch point,
// a little above it: no foliage hangs in the air. twigs() sprouts short
// three-sided tips off a branch point where a crown needs more to carry.
function twigs(fam,S,p,a0,n,len,elLo,elHi,st,out){for(let k=0;k<n;k++){const a=a0+rr(-1.4,1.4),el=rr(elLo,elHi),L=len*rr(.7,1.2),r=Math.max(.05,(p.r||.2)*.5);
  const tip={x:p.x+Math.cos(a)*Math.cos(el)*L,y:p.y+Math.sin(el)*L,z:p.z+Math.sin(a)*Math.cos(el)*L,r:.04};
  if(!clear3(tip.x,tip.y,tip.z,1,1))continue;st.limb+=BIO.tube(fam,[{x:p.x,y:p.y,z:p.z,r},tip],barkC(S),{seg:3});out.push(tip);}}
function crownOn(item,spots,sz0,flat,colFn,T,cy,ex,ey,dens,st){let n=0;
 for(const p of spots){const m=Math.floor(dens)+(rng()<dens%1?1:0);
  for(let c=0;c<m;c++){const sz=sz0*rr(.85,1.2),a=rr(0,TAU),d=sz*.3*Math.sqrt(rng()),x=p.x+Math.cos(a)*d,z=p.z+Math.sin(a)*d,y=p.y+sz*flat*rr(.1,.35);
   if(!clear3(x,y,z,sz*.5,sz*flat*.5))continue;clumpAt(item,x,y,z,sz,flat,colFn(),T.x,cy,T.z,ex,ey);st.clumps++;n++;}}
 return n;}
// a LEADER: an upright limb from the bole to the crown's top, so the top of a crown is carried
function leader(fam,S,T,from,top,r0,st,all){const el=Math.PI/2-rr(.1,.32),len=(top-from.y)/Math.sin(el);if(len<1.5)return null;
 const pts=limbPts({x:from.x,y:from.y,z:from.z},rr(0,TAU),el,len,r0,.1,4,-.02,.05,0);if(!okPts(pts))return null;
 st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});if(all)all.push(...pts);return pts;}
// an ARCH: a vault limb, parametrised by what it does -- out to `reach`, up to `peak` metres
// over its origin at fraction pT of the way, and down to `end` metres over the origin at the tip
function archPts(o,a,reach,peak,pT,end,r0,r1,n,wig){const ca=Math.cos(a),sa=Math.sin(a),sx=-sa,sz=ca,w1=rr(-1,1)*wig,w2=rr(-1,1)*wig,pts=[];
 for(let k=0;k<=n;k++){const t=k/n,lat=(w1*Math.sin(t*Math.PI)+w2*Math.sin(t*TAU))*reach;
  const f=t<=pT?1-Math.pow(1-t/pT,2):1-(1-end/peak)*Math.pow((t-pT)/(1-pT),2);
  const x=o.x+ca*reach*t+sx*lat,z=o.z+sa*reach*t+sz*lat,r=mix(r0,r1,Math.pow(t,.8));let y=o.y+peak*f+Math.sin(t*9+w1*7)*reach*.012;
  const gy=Y(x,z)+r*.75;if(k>0&&y<gy)y=gy;pts.push({x,y,z,r});}
 return pts;}
function spread(T,pts){let s=T.crownR*.5;for(const p of pts){const d=Math.hypot(p.x-T.x,p.z-T.z);if(d>s)s=d;}return s;}
function reg(T,S){if(typeof REGISTER==='function')REGISTER({name:S.name,kind:'tree',label:S.name,x:T.x,z:T.z,y:T.y0,r:Math.max(T.spread||0,T.crownR*.6),h:T.H});}
// the bole: a lathe with a flared, lobed foot; closed at the top with a dome ring (never an open pipe)
function bole(fam,T,S,top,rb,flare,fh,lobes,seg,vs,lean){const nl=lobes||0,L=[],ti=T.seed%3;for(let k=0;k<nl;k++)L.push({a:k/nl*TAU+rr(-.3,.3),amp:rr(.5,1.1)});
 const lobeSum=ang=>{let s=0;for(const q of L){const c=Math.cos(ang-q.a);if(c>0)s+=q.amp*Math.pow(c,5);}return s;};
 const la=rr(0,TAU),lx=Math.cos(la)*(lean||0),lz=Math.sin(la)*(lean||0);
 const rAt=u=>rb*(1-.35*u)*(1+flare*Math.exp(-u*top/fh)),rings=[],step=Math.max(.8,Math.min(vs*.5,top/7));
 for(let yy=0;yy<top;yy+=(yy<fh*1.5?Math.min(step,fh*.5):step))rings.push({x:T.x+lx*yy,y:T.y0+yy,z:T.z+lz*yy,r:rAt(yy/top),yy:yy,col:barkC(S,Math.floor(yy/9)+ti)});
 const r1=rAt(1);rings.push({x:T.x+lx*top,y:T.y0+top,z:T.z+lz*top,r:r1,yy:top,col:barkC(S,1)},{x:T.x+lx*top,y:T.y0+top+r1*.8,z:T.z+lz*top,r:.05,yy:top+1,col:barkC(S,1)});
 const tris=BIO.lathe(fam,rings,seg,Math.max(1,Math.round(TAU*rb/3)),vs,(R,ang)=>R.r*(1+(nl?flare*.9*Math.exp(-R.yy/fh)*lobeSum(ang):0)+.03*Math.sin(5*ang+R.yy*.2)),
  nl?(R,ang)=>mix(1,.6+.4*clamp(lobeSum(ang),0,1),Math.exp(-R.yy/fh)):null);
 return{tris,top:{x:T.x+lx*top,y:T.y0+top,z:T.z+lz*top},rAt,lx,lz};}


// ---------------------------------------------------------------- the builders
// Each: (T, st, lv) where T={x,z,y0,sp,H,rb,crownR,seed,wet} and lv 2 near / 1 mid
const B={};
// COLUMN: a clean bole to a high crotch, a few STEEP limbs and a leader, the crown up
// there on their secondaries. Birch comes in several stems from one foot; the gums and
// the tower ash hang ribbons of shed bark; the she-oak drapes; the wattle flowers gold.
B.column=function(T,st,lv){const S=SP[T.sp],fam=S.bk,rb0=T.rb,nS=S.stems?(lv===2?ri(S.stems[0],Math.min(4,S.stems[1])):1):1,all=[],spots=[];
 for(let si=0;si<nS;si++){const off=si?rr(.4,1.3):0,sa=rr(0,TAU),H=T.H*(si?rr(.72,.95):1),rb=rb0*(si?rr(.7,.95):1);
  const Ts=Object.assign({},T,{x:T.x+Math.cos(sa)*off,z:T.z+Math.sin(sa)*off});
  const hc=H*rr(S.crotch[0],S.crotch[1]),bt=S.buttress||0;
  const bo=bole(fam,Ts,S,hc,rb,bt?bt:.3,bt?4:1.2,bt?ri(4,6):0,lv===2?(rb>1?12:8):6,4,S.stems?rr(.01,.05):rr(0,.025));st.trunk+=bo.tris;
  const nL=lv===2?ri(S.limbs[0],S.limbs[1]):Math.max(2,S.limbs[0]-1),a0=rr(0,TAU);
  for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.3,.3),u=rr(.82,1),o={x:bo.top.x-bo.lx*(1-u)*hc+Math.cos(a)*rb*.3,y:T.y0+hc*u,z:bo.top.z-bo.lz*(1-u)*hc+Math.sin(a)*rb*.3};
   const el=rr(.95,1.3),len=(T.y0+H-o.y)*rr(.75,1.02)/Math.sin(el),pts=limbPts(o,a,el,len,rb*rr(.35,.5),.08,5,-.06,.07,0);if(!okPts(pts))continue;
   st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?6:4,cap:true});all.push(...pts);st.limbs++;
   for(let i=2;i<pts.length;i+=(lv===2&&nS===1)?1:2){const p=pts[i],len2=T.crownR*rr(.3,.5),sp=limbPts(p,a+rr(-1.2,1.2),rr(.25,.8),len2,Math.max(.06,p.r*.5),.04,3,-.12,.1,0);
    if(!okPts(sp))continue;st.limb+=BIO.tube(fam,sp,barkC(S),{seg:3});spots.push(sp[2],sp[3]);if(lv===2)twigs(fam,S,sp[3],a,1,len2*.4,.1,.8,st,spots);}}
  const L=leader(fam,S,Ts,bo.top,T.y0+H,rb*.4,st,all);if(L){spots.push(L[3],L[4]);twigs(fam,S,L[4],rr(0,TAU),3,T.crownR*.3,0,.6,st,spots);}
  if(S.ribbons&&lv===2)for(let j=0,m=ri(3,7);j<m;j++){const u=rr(.1,.9),a=rr(0,TAU),R=bo.rAt(u);BIO.put('strand',[Ts.x+bo.lx*hc*u+Math.cos(a)*(R+.05),T.y0+hc*u,Ts.z+bo.lz*hc*u+Math.sin(a)*(R+.05)],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(.25,.6),rr(2,7),1],C(0xd8d2bc));}   // ribbons of shed bark
  if(bt&&lv===2&&rng()<.7)staghorn(Ts.x,T.y0+hc*rr(.2,.5),Ts.z,rr(0,TAU),bo.rAt(.3),rr(1.2,2),st);}
 const cy=T.y0+T.H*.85,ex=T.crownR,ey=T.H*.15,sz0=T.sp===0||T.sp===12?rr(8,11):S.item==='lance'?rr(5,7):rr(4,6);
 if(S.item==='drape'){crownOn('needle',spots.filter(()=>rng()<.4),sz0*.7,.6,()=>C(pick(S.leaf)),T,cy,ex,ey,1,st);
  spots.forEach(p=>{for(let j=0,m=lv===2?ri(1,2):1;j<m;j++)BIO.put('drape',[p.x+rr(-.8,.8),p.y+rr(0,.8),p.z+rr(-.8,.8)],qEuler(0,rr(0,TAU),0),[rr(.8,1.5),rr(2,4.5),1],leafCol(S.leaf,1.25));});}
 else{const fl=S.flower?spots.filter(()=>rng()<.3):[],lf=S.flower?spots.filter(p=>fl.indexOf(p)<0):spots;
  crownOn(S.item,lf,sz0,S.item==='lance'?.8:.62,()=>C(pick(S.leaf)),T,cy,ex,ey,lv===2?1.4:.9,st);
  if(fl.length)crownOn('blossom',fl,sz0*.8,.6,()=>vary(C(pick(S.flower)),.01,.05,.04),T,cy,ex,ey,lv===2?1.4:.9,st);}
 T.spread=spread(T,all);reg(T,S);};
// FASTIGIATE: a leader to the top and many short limbs hugging it all the way up --
// a green spindle (column ginkgo, spindle poplar)
B.fastigiate=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const bo=bole(fam,T,S,H*.22,rb,.3,1.2,0,lv===2?9:6,4,rr(0,.02));st.trunk+=bo.tris;const all=[],spots=[];
 const L=leader(fam,S,T,bo.top,T.y0+H,rb*.6,st,all);if(L)spots.push(L[2],L[3],L[4]);
 const nL=lv===2?ri(10,15):6;
 for(let k=0;k<nL;k++){const u=mix(.2,.86,(k+rr(0,1))/nL),y=T.y0+H*u,a=k*GOLD+rr(-.3,.3),env=Math.sin(Math.PI*mix(.1,1,u)),len=T.crownR*mix(.7,1.2,env)*rr(.9,1.1);
  const pts=limbPts({x:T.x+Math.cos(a)*rb*.3,y,z:T.z+Math.sin(a)*rb*.3},a,rr(1.15,1.38),len/Math.cos(1.2)*.35,rb*.28,.05,3,-.02,.05,0);if(!okPts(pts))continue;
  st.limb+=BIO.tube(fam,pts,barkC(S),{seg:lv===2?4:3,cap:true});all.push(...pts);spots.push(pts[1],pts[2],pts[3]);}
 crownOn(S.item,spots,rr(3.5,4.8),1.05,()=>C(pick(S.leaf)),T,T.y0+H*.55,T.crownR,H*.45,lv===2?1.3:.8,st);
 T.spread=spread(T,all);reg(T,S);};
// SPIRE: a straight tapering column to the very top and whorls of short limbs (spire
// cedar: conical from a third of the way up; needle cypress: a narrow flame; crag pine:
// a bare pole to 70% and a few flat layered pads at the top)
B.spire=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const bo=bole(fam,T,S,H*.97,rb,S.flatTop?.25:.45,1.5,0,lv===2?9:6,4,rr(0,.02));st.trunk+=bo.tris;const all=[];
 const at=y=>({x:T.x+bo.lx*(y-T.y0),z:T.z+bo.lz*(y-T.y0)});
 if(S.flatTop){const spots=[],n=lv===2?ri(5,7):4,a0=rr(0,TAU);
  for(let k=0;k<n;k++){const y=T.y0+H*mix(.72,.95,k/n),c=at(y),a=a0+k*GOLD,pts=limbPts({x:c.x,y,z:c.z},a,rr(.05,.35),T.crownR*rr(.6,1),rb*.3,.06,4,-.05,.1,.12);
   if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:4,cap:true});all.push(...pts);spots.push(pts[2],pts[3],pts[4]);}
  crownOn('needle',spots,rr(4,5.5),.26,()=>C(pick(S.leaf)),T,T.y0+H*.85,T.crownR,H*.1,lv===2?1.6:1,st);
  for(let k=0;k<(lv===2?ri(2,4):0);k++){const y=T.y0+H*rr(.2,.6),c=at(y),a=rr(0,TAU);BIO.beam('rod',[c.x,y,c.z],[c.x+Math.cos(a)*rr(1,2),y+rr(-.3,.3),c.z+Math.sin(a)*rr(1,2)],.06,.03,C(0x4a5250));}}
 else{const col=!!S.columnar,y0=T.y0+H*(col?.06:.3),nW=lv===2?(col?16:13):8,spots=[];
  for(let k=0;k<nW;k++){const u=k/(nW-1),y=mix(y0,T.y0+H*.96,u),c=at(y),R=col?T.crownR*(.55+.45*Math.sin(Math.PI*mix(.15,1,u)))*(1-.5*u):T.crownR*Math.pow(1-u,.85)+.6,m=lv===2?(col?3:4):3,a0=rr(0,TAU);
   for(let j=0;j<m;j++){const a=a0+j/m*TAU+rr(-.3,.3),el=col?rr(.9,1.2):rr(-.12,.25),len=R/Math.max(.35,Math.cos(el));
    if(lv===2&&!col){const pts=limbPts({x:c.x,y,z:c.z},a,el,len,Math.max(.06,rb*.16*(1-u)),.04,2,-.1,.05,0);st.limb+=BIO.tube(fam,pts,barkC(S),{seg:3});all.push(...pts);spots.push(pts[1],pts[2]);}
    else spots.push({x:c.x+Math.cos(a)*R*.6,y:y+(col?R*.5:0),z:c.z+Math.sin(a)*R*.6,r:.1});}}
  crownOn('needle',spots,col?rr(2.4,3.2):rr(3,4.2),col?1.1:.55,()=>C(pick(S.leaf)),T,T.y0+H*.6,T.crownR,H*.45,lv===2?1.1:.8,st);}
 T.spread=Math.max(T.crownR,spread(T,all));reg(T,S);};
// PALM (mist palm): a pale ringed stem, tall and thin, a green crownshaft, an arching
// crown of feather fronds and lilac flower strings hanging below the shaft
B.palm=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,la=rr(0,TAU),lk=rr(.01,.06),pts=[];
 for(let i=0;i<=6;i++){const u=i/6;pts.push({x:T.x+Math.cos(la)*lk*H*u*u,y:T.y0-.2+H*u,z:T.z+Math.sin(la)*lk*H*u*u,r:rb*(1+.35*Math.exp(-u*10))*(1-.15*u),col:u>.9?C(0x6a8a5a):barkC(S)});}
 st.trunk+=BIO.tube('bk_ring',pts,barkC(S),{seg:lv===2?7:5,cap:true});const e=pts[6];
 const nf=lv===2?ri(9,13):6,a0=rr(0,TAU),hc=vary(C(pick(S.leaf)),.02,.08,.05);
 for(let f=0;f<nf;f++)frondAt('palmfrond',e.x,e.y+.3,e.z,a0+f/nf*TAU+rr(-.2,.2),T.crownR*rr(.85,1.1),rr(-.7,.35),bright(hc,1.4),1.05);
 if(lv===2)for(let j=0,m=ri(2,4);j<m;j++){const a=rr(0,TAU);BIO.put('strand',[pts[5].x+Math.cos(a)*rb*1.2,pts[5].y,pts[5].z+Math.sin(a)*rb*1.2],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(.3,.5),rr(1,2),1],C(pick(PAL.lantern)).lerp(C(0xffffff),.3));}
 st.fronds+=nf;if(lv===2&&rng()<.4){T.spread=T.crownR;reg(T,S);}};
// FERN (spire tree fern): a slim dark trunk, a crown of long fronds, the old ones hanging grey
B.fern=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,la=rr(0,TAU),lk=rr(0,.1),pts=[];
 for(let i=0;i<=4;i++){const u=i/4;pts.push({x:T.x+Math.cos(la)*lk*H*u*u,y:T.y0-.2+H*u,z:T.z+Math.sin(la)*lk*H*u*u,r:rb*(1+.5*Math.exp(-u*6))});}
 st.trunk+=BIO.tube('bk_fern',pts,barkC(S),{seg:lv===2?7:5,cap:true});const e=pts[4],nf=lv===2?ri(11,16):7,a0=rr(0,TAU),hc=vary(C(pick(S.leaf)),.03,.1,.05);
 for(let f=0;f<nf;f++)frondAt('bigfrond',e.x,e.y,e.z,a0+f/nf*TAU+rr(-.2,.2),T.crownR*rr(.85,1.1),rr(-.25,.3),bright(hc,1.45),1.2);
 if(lv===2){for(let f=0;f<4;f++)frondAt('bigfrond',e.x,e.y+.2,e.z,a0+f*1.6,T.crownR*.5,rr(.7,1.1),bright(shade(hc,.1),1.45),1);
  for(let k=0,m=ri(3,6);k<m;k++){const a=rr(0,TAU);BIO.put('ribbon',[e.x+Math.cos(a)*rb,e.y-.4,e.z+Math.sin(a)*rb],qFacing([Math.cos(a),0,Math.sin(a)]),[rr(.8,1.4),rr(1.5,3),1],C(0x8a8e84));}}
 st.fronds+=nf;};
// PANDAN (stilt pandan): a short trunk on a cone of stilt roots, branching arms each
// ending in a tall spiral tuft of blade leaves -- upright even at the lake's edge
B.pandan=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,base=T.y0+rr(1,2),all=[];
 for(let k=0,m=lv===2?ri(6,9):4;k<m;k++){const a=k/m*TAU+rr(-.2,.2),R=rr(1,2.2),gx=T.x+Math.cos(a)*R,gz=T.z+Math.sin(a)*R;
  st.limb+=BIO.tube('bk_ring',[{x:T.x+Math.cos(a)*rb*.6,y:base+rr(.3,1),z:T.z+Math.sin(a)*rb*.6,r:rb*.4},{x:gx,y:Y(gx,gz)-.3,z:gz,r:rb*.3}],barkC(S),{seg:4});}
 const trunk=[{x:T.x,y:base,z:T.z,r:rb},{x:T.x,y:T.y0+H*.45,z:T.z,r:rb*.8}];st.trunk+=BIO.tube('bk_ring',trunk,barkC(S),{seg:6});
 for(let k=0,m=ri(2,4);k<m;k++){const a=rr(0,TAU),pts=limbPts(trunk[1],a,rr(.9,1.25),H*rr(.4,.55),rb*.6,rb*.4,3,-.05,.08,.1);st.limb+=BIO.tube('bk_ring',pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  const e=pts[3],hc=vary(C(pick(S.leaf)),.02,.06,.05);for(let t=0;t<3;t++)BIO.put('spike',[e.x,e.y-.3,e.z],qEuler(rr(-.2,.2),t*1.1+rr(0,1),rr(-.2,.2)),[T.crownR*.9,T.crownR*1.1,T.crownR*.9],bright(hc,1.3));
  if(lv===2&&rng()<.3)BIO.put('pompom',[e.x+rr(-.3,.3),e.y-.5,e.z+rr(-.3,.3)],qEuler(0,rr(0,TAU),0),[.35,.45,.35],C(0xd87a2a));}
 T.spread=spread(T,all);};
// the GLOW-WILLOW: a silver twisting bole, limbs arching over, veils to the ground in
// lavender-grey-green, and hanging from the limbs on fine strings its LANTERN BLOSSOMS:
// papery calyxes that light themselves, violet to amethyst, each in a soft glow
B.willow=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;
 const hc=H*rr(.28,.38),bo=bole(fam,T,S,hc,rb,.6,1.2,ri(3,5),lv===2?10:7,3,rr(.12,.28));st.trunk+=bo.tris;
 const nL=lv===2?ri(5,7):4,a0=rr(0,TAU),all=[];
 for(let k=0;k<nL;k++){const a=a0+k*GOLD+rr(-.25,.25),len=T.crownR*rr(.8,1.15),pts=limbPts(bo.top,a,rr(.8,1.15),len,rb*.45,.08,6,-rr(.6,.9),.12,0);
  if(!okPts(pts))continue;st.limb+=BIO.tube(fam,pts,barkC(S),{seg:5,cap:true});all.push(...pts);
  const nv=lv===2?ri(14,20):6;
  for(let v=0;v<nv;v++){const i=ri(2,pts.length-1),p=pts[i],px=p.x+rr(-1.8,1.8),pz=p.z+rr(-1.8,1.8),gy=Y(px,pz),Lv=Math.max(1.5,(p.y-gy)*rr(.55,.95));
   BIO.put('veil',[px,p.y+rr(0,1),pz],qEuler(0,rr(0,TAU),0),[rr(.45,.85),Lv*rr(.7,1),1],leafCol(S.leaf,1.2));st.veils++;}
  // the lanterns: on strings from the limb, at various lengths, the lowest near head height
  const nl=lv===2?ri(7,12):3;
  for(let j=0;j<nl;j++){const i=ri(2,pts.length-1),p=pts[i],px=p.x+rr(-1.5,1.5),pz=p.z+rr(-1.5,1.5),gy=Y(px,pz),drop=Math.min(p.y-gy-1.2,rr(1.5,7));if(drop<.5)continue;
   const ly=p.y-drop,s=rr(.28,.45),col=bright(vary(C(pick(PAL.lantern)),.02,.05,.05),1.1);
   if(lv===2)BIO.beam('rod',[px,p.y,pz],[px,ly,pz],.012,null,C(0x8a9290));
   BIO.put('lantern',[px,ly,pz],qEuler(rr(-.1,.1),rr(0,TAU),rr(-.1,.1)),[s,s*1.25,s],col);
   BIO.put('halo',[px,ly-s*.6,pz],qEuler(0,rr(0,TAU),0),s*rr(1.9,2.5),col.clone().multiplyScalar(.3));st.lanterns++;}}
 T.spread=spread(T,all);reg(T,S);};
// the GRASS TREE: a short charred trunk (sometimes two heads), a fountain of fine blades,
// a grey skirt of dead ones, and a spear of a flower spike far above it all
B.grasstree=function(T,st,lv){const S=SP[T.sp],H=T.H,rb=T.rb,heads=rng()<.25?2:1;
 for(let h=0;h<heads;h++){const a=rr(0,TAU),hh=H*(h?rr(.6,.85):1),top={x:T.x+(h?Math.cos(a)*.9:0),y:T.y0+hh,z:T.z+(h?Math.sin(a)*.9:0)};
  st.trunk+=BIO.tube('bk_char',[{x:T.x,y:T.y0-.2,z:T.z,r:rb*1.15},{x:mix(T.x,top.x,.5),y:T.y0+hh*.5,z:mix(T.z,top.z,.5),r:rb},{x:top.x,y:top.y,z:top.z,r:rb*.9}],barkC(S),{seg:6,cap:true});
  const R=T.crownR,hc=C(pick(PAL.gum));for(let t=0;t<(lv===2?5:3);t++)BIO.put('spike',[top.x,top.y-R*.35,top.z],qEuler(rr(-.25,.25),t*1.3,rr(-.25,.25)),[R*2,R*1.3,R*2],bright(vary(hc,.02,.06,.05),1.3));
  if(lv===2)for(let k=0;k<ri(5,9);k++){const a2=rr(0,TAU);BIO.put('strand',[top.x+Math.cos(a2)*rb,top.y-.2,top.z+Math.sin(a2)*rb],qFacing([Math.cos(a2),0,Math.sin(a2)]),[rr(.5,.9),rr(.8,1.6),1],C(0x9a9888));}
  if(rng()<.55){const sh=rr(2.5,4.5);BIO.beam('rod',[top.x,top.y,top.z],[top.x,top.y+sh,top.z],.06,.045,C(0x5a5a4e));
   const col=C(pick(PAL.grassSpike));for(let j=0;j<(lv===2?16:6);j++){const yy=top.y+sh*rr(.35,1),aa=rr(0,TAU);BIO.put('bloom',[top.x+Math.cos(aa)*.08,yy,top.z+Math.sin(aa)*.08],qEuler(rr(-.3,.3),aa,rr(-.3,.3)),rr(.1,.16),col);}}}};
// the CANDLE BANKSIA: a small grey tree of ascending branches, leathery leaves, and at
// the tips its flowers standing straight up like candles, orange to gold
B.banksia=function(T,st,lv){const S=SP[T.sp],fam=S.bk,H=T.H,rb=T.rb;const bo=bole(fam,T,S,H*.3,rb,.3,1,0,lv===2?7:5,3,rr(0,.08));st.trunk+=bo.tris;const spots=[],all=[];
 for(let k=0,n=lv===2?ri(4,6):3;k<n;k++){const a=k*GOLD+rr(-.3,.3),pts=limbPts(bo.top,a,rr(.8,1.2),H*rr(.55,.75),rb*.5,.06,4,-.08,.1,0);st.limb+=BIO.tube(fam,pts,barkC(S),{seg:4,cap:true});all.push(...pts);spots.push(pts[2],pts[3],pts[4]);}
 crownOn('glossy',spots,rr(2.5,3.4),.7,()=>C(pick(S.leaf)),T,T.y0+H*.7,T.crownR,H*.3,lv===2?1.3:.9,st);
 if(lv>=1)spots.forEach(p=>{if(rng()>.55)return;const hgt=rr(.35,.6);BIO.put('pompom',[p.x+rr(-.4,.4),p.y+hgt+.4,p.z+rr(-.4,.4)],qEuler(rr(-.1,.1),0,rr(-.1,.1)),[.12,hgt,.12],bright(C(pick(PAL.banksiaCandle)),.9));st.blooms++;});
 T.spread=spread(T,all);};

// ---------------------------------------------------------------- impostors (the far canopy)
// Blobs in the 'far' bucket. The wide species get flattened, overlapping blobs out
// to their real width, so the silhouette from the hills reads WIDE too.
let ICO=null;
function buildFar(T,fi,st){const K=BIO.bucket('far');if(!ICO)ICO=new T3.IcosahedronGeometry(1,1).attributes.position.array;const ip=ICO;
 const S=SP[T.sp],cheap=BIO.lodD(T.x,T.z)>2200;let tris=0;
 function vtx(x,y,z,nx,ny,nz,r,g,b){K.pos.push(x,y,z);K.nor.push(nx,ny,nz);K.uv.push(0,0);K.col.push(r,g,b);}
 function blob(x,y,z,rx,ry,colA,colB,sd){const ca=C(colA).convertSRGBToLinear(),cb=C(colB).convertSRGBToLinear(),k1=sd*7.3,k2=sd*3.1;
  for(let i=0;i<ip.length;i+=3){const dx=ip[i],dy=ip[i+1],dz=ip[i+2];
   const m=1+.20*Math.sin(dx*4.1+k1)*Math.cos(dz*3.7+k2)+.14*Math.sin(dy*6.3+k2+dx*2);
   const sh=(.50+.50*smooth(-.7,.8,dy))*(.9+.2*Math.sin(dx*9+dz*7+k1)),t=smooth(-.2,.7,dy+.3*Math.sin(dx*5+k2));
   const ny=dy*.7+.45,nl=Math.hypot(dx,ny,dz)||1;
   vtx(x+dx*rx*m,y+dy*ry*m,z+dz*rx*m,dx/nl,ny/nl,dz/nl,mix(cb.r,ca.r,t)*sh,mix(cb.g,ca.g,t)*sh,mix(cb.b,ca.b,t)*sh);}
  tris+=ip.length/9;}
 const bc=C(S.bark[fi%S.bark.length]).convertSRGBToLinear(),seg=cheap?4:6,shape=({column:'column',fastigiate:'spindle',spire:(S.flatTop?'pine':'spindle'),willow:'weep'})[S.habit]||'round';
 const top=T.y0+T.H*(shape==='column'?(S.crotch?S.crotch[0]:.6):shape==='spindle'?.85:shape==='pine'?.9:.6),rings=[];
 [0,.06,.5,1].forEach(u=>{const y=T.y0+(top-T.y0)*u,r=Math.max(.4,T.rb*(1-.5*u)*(u<.08?1.5:1)),ring=[];for(let s=0;s<=seg;s++){const a=s/seg*TAU;ring.push([T.x+Math.cos(a)*r,y,T.z+Math.sin(a)*r,Math.cos(a),Math.sin(a)]);}rings.push(ring);});
 for(let r2=0;r2<rings.length-1;r2++)for(let s2=0;s2<seg;s2++){const A=rings[r2][s2],Bq=rings[r2][s2+1],D=rings[r2+1][s2],E=rings[r2+1][s2+1],sh=.45*(.7+.3*(r2/rings.length));
  [A,D,E,A,E,Bq].forEach(p=>vtx(p[0],p[1],p[2],p[3],.05,p[4],bc.r*sh,bc.g*sh,bc.b*sh));tris+=2;}
 const L=S.leaf.map(h=>bright(h,.85)),R=T.crownR,H=T.H,a0=(T.seed%628)/100,n=L.length;
 if(shape==='wide'){const m=cheap?3:5;blob(T.x,T.y0+H*.75,T.z,R*.55,H*.22,L[fi%n],L[(fi+2)%n],fi);
  for(let k=0;k<m;k++){const a=a0+k/m*TAU;blob(T.x+Math.cos(a)*R*.58,T.y0+H*mix(.5,.68,(k*7%5)/5),T.z+Math.sin(a)*R*.58,R*.42,H*.18,L[(k+fi)%n],L[(k+1)%n],fi+k);}}
 else if(shape==='parasol'){blob(T.x,T.y0+H*.85,T.z,R*.85,H*.09,L[fi%n],L[(fi+1)%n],fi);if(!cheap)blob(T.x,T.y0+H*.72,T.z,R*.55,H*.07,L[1%n],L[2%n],fi+3);}
 else if(shape==='tier'){for(let k=0;k<(cheap?2:3);k++)blob(T.x,T.y0+H*mix(.4,.88,k/2),T.z,R*mix(.9,.4,k/2),H*.06,L[(k+fi)%n],L[(k+1)%n],fi+k);}
 else if(shape==='pine'){blob(T.x,T.y0+H*.92,T.z,R*.8,H*.1,L[fi%n],L[(fi+1)%n],fi);}
 else if(shape==='flat'){blob(T.x,T.y0+H*.86,T.z,R*.9,H*.12,L[fi%n],L[(fi+1)%n],fi);}
 else if(shape==='column'){const c0=S.crotch?S.crotch[0]:.6;blob(T.x,T.y0+H*mix(c0,1,.6),T.z,R*.75,H*(1-c0)*.42,L[fi%n],L[(fi+1)%n],fi);if(!cheap)blob(T.x+Math.cos(a0)*R*.3,T.y0+H*.93,T.z+Math.sin(a0)*R*.3,R*.45,H*.08,L[(fi+2)%n],L[1%n],fi+3);}
 else if(shape==='spindle'){blob(T.x,T.y0+H*.58,T.z,R*.95,H*.4,L[fi%n],L[(fi+1)%n],fi);}
 else if(shape==='weep'){blob(T.x,T.y0+H*.55,T.z,R*.85,H*.42,L[fi%n],L[(fi+1)%n],fi);}
 else{blob(T.x,T.y0+H*.72,T.z,R*.85,H*.25,L[fi%n],L[(fi+2)%n],fi);}
 K.tris+=tris;BIO.tally(tris,0,0);st.far+=tris;}


// ---------------------------------------------------------------- the BAMBOO GROVES
// A grove is a patch of the `bamboo` zone weight with a hard edge (zones()). Inside it
// the tree passes do not plant. Sky bamboo fills the interior, its culms tallest in the
// middle and lower toward the rim so a grove reads as one mass; Buddha-belly bamboo and
// coil cane fringe it where it is wet. Near the spine every culm has leaf sprays up its
// top half; mid-range a couple of big sprays; far, the grove is a blob canopy.
function groves(R,q,st){const skyS=SP[20],bellyS=SP[21],coilS=SP[22],m=means();
 const culmTint=hex=>tint(vary(C(hex),.015,.06,.05),m.culm,1);
 const bands=[[6,420,0,2],[13,1250,420,1],[22,1e9,1250,0]];
 bands.forEach(b=>{const lv=b[3];
  BIO.grid(b[0],0,R,(x,z)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;const Z=zones(x,z);return smooth(.04,.3,Z.bamboo)*q;},(x,y,z)=>{
   if(y<.35||blocked(x,z,.6))return;const Z=zones(x,z),e=smooth(.05,.7,Z.bamboo),fine=fbm(x*.05,z*.05,5504,2);
   // the rim: clumping kinds where it is wet, else a shorter sky bamboo
   const rim=e<.3&&rng()<.55,kind=rim?(Z.flow>.25||Z.wet>.92?'coil':'belly'):'sky',S=kind==='sky'?skyS:kind==='belly'?bellyS:coilS;
   if(lv===0){if(kind!=='sky')return;const H=rr(S.H[0],S.H[1])*mix(.6,1,e);farGrove(x,y,z,H,st);return;}
   const H=rr(S.H[0],S.H[1])*(kind==='sky'?mix(.55,1,e)*mix(.85,1.1,fine):1),r=rr(S.rb[0],S.rb[1]),lean=[rr(-.04,.04),1,rr(-.04,.04)];
   // culms come in tight clumps (a running bamboo's culms rise close together from one rhizome run)
   const n=kind==='sky'?(lv===2?ri(3,5):2):ri(3,5),spreadC=kind==='sky'?1.3:.8;
   for(let c=0;c<n;c++){const cx=x+(c?rr(-spreadC,spreadC):0),cz=z+(c?rr(-spreadC,spreadC):0),h=H*(c?rr(.75,1):1),col=culmTint(pick(S.bark));
    if(kind==='sky')BIO.put('culm',[cx,y-.2,cz],qUp(lean),[r*2,h,r*2],col);
    else if(kind==='belly')BIO.put('belly',[cx,y-.2,cz],qUp([rr(-.08,.08),1,rr(-.08,.08)]),[r*2.4,h,r*2.4],col);
    else BIO.put('coil',[cx,y-.2,cz],qEuler(0,rr(0,TAU),0),[r/.012*.5,h,r/.012*.5],bright(col,.9));
    st.culms++;}
   // the clump's leaf mass: branches leaf out from a third of the way up (as a culm does), heaviest in the upper half
   const nl=lv===2?(kind==='sky'?ri(5,8):2):(kind==='sky'?2:1);
   for(let k=0;k<nl;k++){const u=lv===2?rr(.32,1)*rr(.85,1.05):rr(.55,1),a=rr(0,TAU),d=rr(.4,2.6)*(kind==='sky'?1:.6),s=(lv===2?rr(4.4,6.4):rr(6,8))*(kind==='sky'?1:.65);
    clumpAt('bleaf',x+lean[0]*H*u+Math.cos(a)*d,y+H*u,z+lean[2]*H*u+Math.sin(a)*d,s,.75,C(pick(S.leaf)),x,y+H*.85,z,4,H*.3);st.clumps++;}},
  {patch:0,pad:.3});});
 // shoots at the grove floor are the floor pass's (60)
}
function farGrove(x,y,z,H,st){const K=BIO.bucket('far');if(!ICO)ICO=new T3.IcosahedronGeometry(1,1).attributes.position.array;const ip=ICO;
 const ca=C(pick(PAL.bamboo)).convertSRGBToLinear(),cb=C(PAL.bamboo[0]).multiplyScalar(.6).convertSRGBToLinear();let tris=0;
 for(let i=0;i<ip.length;i+=3){const dx=ip[i],dy=ip[i+1],dz=ip[i+2],t=smooth(-.4,.7,dy),sh=.55+.45*smooth(-.7,.8,dy);
  K.pos.push(x+dx*10,y+H*.72+dy*H*.3,z+dz*10);const ny=dy*.7+.45,nl=Math.hypot(dx,ny,dz)||1;K.nor.push(dx/nl,ny/nl,dz/nl);K.uv.push(0,0);K.col.push(mix(cb.r,ca.r,t)*sh,mix(cb.g,ca.g,t)*sh,mix(cb.b,ca.b,t)*sh);}
 tris=ip.length/9;K.tris+=tris;BIO.tally(tris,0,0);st.far+=tris;}

// the SMALL species far off: one 20-triangle blob in the leaf colour, so the chaparral
// and the palm groves still read at range instead of stopping at the band edge
let ICO0=null;
function buildFarSmall(T,st){const K=BIO.bucket('far');if(!ICO0)ICO0=new T3.IcosahedronGeometry(1,0).attributes.position.array;const S=SP[T.sp],ip=ICO0;
 const ca=bright(C(pick(S.leaf)),.85).convertSRGBToLinear(),cb=ca.clone().multiplyScalar(.55),R=T.crownR*.85,H=T.H,cy=T.y0+H*.62;
 for(let i=0;i<ip.length;i+=3){const dx=ip[i],dy=ip[i+1],dz=ip[i+2],t=smooth(-.5,.7,dy),ny=dy*.7+.45,nl=Math.hypot(dx,ny,dz)||1;
  K.pos.push(T.x+dx*R,cy+dy*Math.max(R*.6,H*.38),T.z+dz*R);K.nor.push(dx/nl,ny/nl,dz/nl);K.uv.push(0,0);K.col.push(mix(cb.r,ca.r,t),mix(cb.g,ca.g,t),mix(cb.b,ca.b,t));}
 const tris=ip.length/9;K.tris+=tris;BIO.tally(tris,0,0);st.far+=tris;}

// ---------------------------------------------------------------- the pass
NWLOW.buildTrees=function(R,q,opt){opt=opt||{};
 reseed(560031);q=q==null?1:q;R=R||2850;const m=means();if(!m.culm)m.culm=texMean(NWLOW.CULMTEX);
 const st={trunk:0,limb:0,far:0,limbs:0,clumps:0,blooms:0,moss:0,fronds:0,veils:0,lanterns:0,epi:0,culms:0,heroes:0,fars:0,byS:SP.map(()=>0)};
 const TREES=NWLOW.TREES;TREES.length=0;for(const k in HASH)delete HASH[k];
 const mk=(x,y,z,sp)=>{const S=SP[sp];return{x:x,z:z,y0:y-.4,sp:sp,H:rr(S.H[0],S.H[1]),rb:rr(S.rb[0],S.rb[1]),crownR:rr(S.crownR[0],S.crownR[1]),seed:ri(0,999999),wet:BIO.field('wet',x,z)};};
 const DENS=.4;   // the showcase's stocking at q=1, measured against the budget (KNOWN_ISSUES)
 function pass(sp,cell,accept,opt){opt=opt||{};let n=0;const pad=opt.pad==null?3:opt.pad;
  BIO.grid(cell,0,R,(x,z,d)=>{const Z=zones(x,z);const a=accept(Z,x,z)*(1-smooth(.02,.2,Z.bamboo));if(a<=0)return 0;   // never inside a bamboo grove
    return a*(opt.lodK?lerp(1,BIO.lod(x,z),opt.lodK):1)*q*(opt.dens==null?DENS:opt.dens);},
   (x,y,z,d)=>{if(!opt.inWater&&y<.3)return;if(opt.inWater&&(y<opt.inWater[0]||y>opt.inWater[1]))return;
    if(blocked(x,z,pad))return;if(!BIO.clearOf(x,z,pad+2))return;
    const T=mk(x,y,z,sp),ld=BIO.lodD(x,z);T.lv=ld<opt.hero?2:(ld<opt.mid?1:0);if(T.lv===0&&!opt.far)return;
    TREES.push(T);hadd({x:x,z:z,r:(opt.own==null?T.rb*1.5+1:T.crownR*opt.own),rt:T.rb*1.6+.8});n++;},{patch:opt.patch==null?.5:opt.patch,patchScale:opt.patchScale||.01,noMask:!!opt.inWater,pad:1});
  return n;}
 // AVENUES: rows along a host path (see BIOME-API.md), e.g. ghost gums down a road
 (opt.avenues||[]).forEach(av=>{const P=av.path,sp=SP.findIndex(S=>S.key===av.species),gap=av.spacing||18,off=av.offset||9;let carry=gap*.5;
  for(let i=0;i<P.length-1;i++){const a=P[i],b=P[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]),ux=(b[0]-a[0])/L,uz=(b[1]-a[1])/L;let d=carry;
   for(;d<L;d+=gap*rr(.95,1.05))[-1,1].forEach(side=>{const o=off+rr(-.4,.8),x=a[0]+ux*d-uz*side*o,z=a[1]+uz*d+ux*side*o,y=Y(x,z);
    if(y<.3||!BIO.clearOf(x,z,4)||blocked(x,z,2))return;const T=mk(x,y,z,sp),ld=BIO.lodD(x,z);T.lv=ld<1100?2:ld<1700?1:0;TREES.push(T);hadd({x,z,r:gap*.4,rt:T.rb*1.6+.8});st.avenue=(st.avenue||0)+1;});
   carry=d-L;}});
 // the emergents and the giants first
 pass(0,120,Z=>Z.rain*.7,{hero:1100,mid:1800,far:true,pad:10,own:.5,patch:.25});                                  // sky meranti
 pass(12,120,Z=>Z.sub*.35*smooth(.7,.85,Z.wet)+Z.rain*.12,{hero:1100,mid:1800,far:true,pad:8,own:.45,patch:.35});   // column kauri
 pass(13,110,Z=>Z.gully*.6+Z.sub*.08*smooth(.2,.6,Z.up),{hero:1100,mid:1900,far:true,pad:8,own:.45,patch:.35});   // tower ash
 pass(5,70,Z=>Z.sub*.3+Z.gully*.25,{hero:1000,mid:1700,far:true,pad:5,patch:.4});                                  // ribbon blue gum
 pass(4,55,Z=>Z.sub*.22+Z.med*.25*(1-Z.up*.5),{hero:1000,mid:1700,far:true,pad:4,patch:.45});                      // ghost gum
 pass(7,34,Z=>Z.sub*Z.spireK*.7,{hero:950,mid:1600,far:true,pad:3,patch:.3});                                     // spire cedar, in stands
 pass(6,32,Z=>Z.sub*Z.birchK*.65*(1-Z.spireK),{hero:850,mid:1500,far:true,pad:1.5,patch:.3});                      // candle birch, in stands
 pass(9,60,Z=>Z.sub*.12+Z.med*.06,{hero:950,mid:1600,far:true,pad:4,patch:.5});                                    // column ginkgo
 pass(11,26,Z=>Z.rip*(Z.sub+Z.med*.5)*.7,{hero:950,mid:1600,far:true,pad:3});                                     // spindle poplar
 pass(8,55,Z=>(Z.rip*.5+Z.shore*.5)*(1-Z.med*.6),{hero:950,mid:1500,far:true,pad:4,own:.35});                     // glow-willow
 pass(10,32,Z=>Z.shore*.6+Z.rain*smooth(.9,.97,Z.wet)*.25,{hero:900,mid:1500,far:true,pad:2.5});                 // pale paperbark
 pass(3,22,Z=>Z.shore*Z.rain*.5+Z.shore*.15,{hero:800,mid:1300,far:true,pad:2,lodK:.5});                       // stilt pandan
 pass(1,20,Z=>Z.rain*.45,{hero:850,mid:1400,far:true,pad:1.5,lodK:.5});                                         // mist palm
 pass(2,18,Z=>Z.rain*.5+Z.sub*smooth(.88,.96,Z.wet)*.2,{hero:800,mid:1300,far:true,pad:1.5,lodK:.5});          // spire tree fern
 pass(19,40,Z=>Z.sub*.08+Z.med*.12,{hero:900,mid:1500,far:true,pad:3,patch:.5});                                  // tall wattle
 pass(15,44,Z=>Z.med*.2+Z.rip*Z.med*.3,{hero:900,mid:1500,far:true,pad:3,patch:.5});                             // drape she-oak
 pass(14,34,Z=>Z.med*.28*(1-Z.gully),{hero:900,mid:1600,far:true,pad:2,patch:.45});                             // needle cypress
 pass(16,60,Z=>Z.med*smooth(.25,.55,Z.up)*.5,{hero:1000,mid:1700,far:true,pad:4,patch:.4});                     // crag pine
 pass(18,32,Z=>Z.med*.22,{hero:800,mid:1300,far:true,pad:1.5,lodK:.5,patch:.5});                               // candle banksia
 pass(17,22,Z=>Z.med*.3*(1-Z.gully),{hero:700,mid:1200,far:true,pad:1,lodK:.5,patch:.5});                       // grass tree
 // build
 const trisS=SP.map(()=>0),cur=()=>{const t=BIO.stats[BIO.cur||'biome'];return t?t.tris:0;};
 const SMALL={1:1,2:1,3:1,17:1,18:1};
 TREES.forEach((T,i)=>{const t0=cur(),S=SP[T.sp];if(T.lv===0){if(SMALL[T.sp])buildFarSmall(T,st);else buildFar(T,i,st);st.fars++;}else{B[S.habit](T,st,T.lv);st.heroes++;}st.byS[T.sp]++;trisS[T.sp]+=cur()-t0;});
 // the groves last: they fill the patches the trees left
 const g0=cur();groves(R,q,st);trisS[20]+=cur()-g0;
 return{trees:TREES.length,avenue:st.avenue||0,heroes:st.heroes,far:st.fars,culms:st.culms,lanterns:st.lanterns,bySpecies:SP.map((S,i)=>S.key+':'+st.byS[i]).join(' '),
  trisBySpecies:SP.map((S,i)=>S.key+':'+Math.round(trisS[i]/1000)+'k').join(' '),limbs:st.limbs,clumps:st.clumps,tris:{trunk:st.trunk,limbs:st.limb,far:st.far}};};
NWLOW._canopyH=function(x,z){let h=0;for(const T of NWLOW.TREES){if(Math.hypot(x-T.x,z-T.z)<Math.max(30,T.crownR))h=Math.max(h,T.y0+T.H);}return h||12;};
})();

// ==================== 60-biome-nwlowlands-floor.js
// ================================================================= NORTHWESTERN LOWLANDS — floor
// Everything under the trees, by zone (NWLOW.zones). The shrub layer here is SEA PENS:
// upright feathers, clubs and whips in white, pale pink and lilac, the region's most
// alien note, and vertical like everything else in it.
//   the SHORE       reeds, sedge, iris, sea pens at the water; lotus and lilies on it
//   the RAINFOREST  teal aroids, torch ginger, ferns and forking ferns, tall feather pens, moss
//   the GROVES      bamboo leaf litter, shoots, a little moss and fern: a bare floor, so a
//                   grove reads as a grove
//   the PLAIN       bluebell carpets, ferns, rhododendrons, lilies, sea pens, green grass
//   the HILLS       tussock and dry grass, kangaroo paw, saltbush, club pens, rocks
// Three LOD bands along the spine, a grass carpet, the water, fallen trees, and an
// understorey pass under the crowns.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const PAL=NWLOW.PAL,zones=NWLOW.zones,blocked=NWLOW.blocked;
const T3=BIO.host.THREE,C=h=>new T3.Color(h);
const {bright,shade,vary,tint,means}=NWLOW;
const Y=(x,z)=>BIO.terrainH(x,z);
const leafCol=(set,k,dh)=>bright(vary(pick(set),dh==null?.05:dh,.14,.07),k==null?1.3:k);
const rockTint=(set,k)=>tint(vary(pick(set||PAL.rock),.02,.06,.06),means().rock,k==null?rr(.35,.6):k);
const rodCol=(hex)=>shade(vary(hex,.02,.08,.06),rr(-.45,-.2));
const okGround=(x,z,pad)=>!blocked(x,z,pad)&&BIO.clearOf(x,z,pad);
const bellK=(x,z)=>smooth(.5,.62,fbm(x*.0048-5,z*.0048+2,4131,2));     // the bluebell carpets
const dampK=(x,z)=>fbm(x*.0062+21,z*.0062+13,777,2);

// ---------------------------------------------------------------- small plants
function card(x,y,z,s,sy,col,tilt){BIO.put('ucard',[x,y,z],qEuler(rr(-(tilt||.2),tilt||.2),rr(0,TAU),rr(-(tilt||.2),tilt||.2)),[s,sy==null?s:sy,s],col);}
function tuft(item,x,y,z,h,w,col){BIO.put(item,[x,y-.05,z],qEuler(rr(-.06,.06),rr(0,TAU),rr(-.06,.06)),[w||h*.8,h,w||h*.8],col);}
function groundMoss(x,y,z,r,set){BIO.put('mossmat',[x,y+.06,z],qEuler(rr(-.06,.06),rr(0,TAU),rr(-.06,.06)),r,leafCol(set||PAL.moss,.95,.03));}
function blooms(x,y,z,r,n,set,sz,h){const c=bright(vary(pick(set),.03,.1,.08),1.15);
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=r*Math.sqrt(rng()),s=sz?rr(sz[0],sz[1]):rr(.16,.34);BIO.put('bloom',[x+Math.cos(a)*d,y+rr(.05,h==null?.4:h),z+Math.sin(a)*d],qEuler(rr(-.4,.4),rr(0,TAU),rr(-.4,.4)),s,c);}}
function frondCrown(x,y,z,Rf,n,p0,p1,col,item){const a0=rr(0,TAU);
 for(let k=0;k<n;k++){const a=a0+k/n*TAU+rr(-.25,.25),L=Rf*rr(.8,1.1);BIO.put(item||'frond',[x,y,z],qEuler(rr(-.18,.18),-a,rr(p0,p1)),[L,L*rr(.85,1.05),L*rr(1.1,1.5)],bright(col,rr(.86,1.1)));}}
function fern(x,y,z,lv,item){const hc=vary(pick(PAL.fern),.06,.14,.07);frondCrown(x,y-.1,z,rr(1.6,3.2)*(item==='forkfern'?1.3:1),lv===2?ri(5,7):lv===1?4:3,.1,.55,bright(hc,1.7),item);}
function giantFern(x,y,z,lv){const hc=vary(pick(PAL.fern),.05,.14,.07);frondCrown(x,y-.1,z,rr(3,5),lv===2?ri(6,8):4,.1,.6,bright(hc,1.6),'bigfrond');}
function shrub(x,y,z,lv,set,k){const hc=vary(pick(set||PAL.shrub),.07,.14,.07),Rs=rr(1.1,2.4)*(k||1);
 if(lv===2){BIO.put('lobe',[x,y-.3,z],qEuler(0,rr(0,TAU),0),[Rs*.8,Rs*rr(.8,1.1),Rs*.8],shade(vary(hc,.03,.1,.05),-.2));
  for(let i=0;i<2;i++){const a=rr(0,TAU),d=i?Rs*rr(.3,.6):0;card(x+Math.cos(a)*d,y+Rs*rr(.6,.9),z+Math.sin(a)*d,Rs*rr(1.3,1.7),Rs*rr(1.3,1.7),bright(vary(hc,.04,.1,.06),1.45),.2);}}
 else card(x,y+Rs*.7,z,Rs*1.6,Rs*1.5,bright(hc,1.4));
 return Rs;}
// a SEA PEN: one to five upright fronds -- feather pens, club pens, the odd whip pen
function seaPen(x,y,z,lv,st,big){const t=rng(),n=lv===2?ri(2,6):ri(1,3),set=rng()<.8?PAL.pen:PAL.penDeep,base=rr(1,2.6)*(big||1);
 for(let k=0;k<n;k++){const a=rr(0,TAU),d=k?rr(.2,.9):0,px=x+Math.cos(a)*d,pz=z+Math.sin(a)*d,h=base*rr(.6,1.35)*(lv===0?1.4:1),col=bright(vary(pick(set),.02,.06,.05),1.15);
  if(t<.62)BIO.put('pen',[px,y-.05,pz],qEuler(rr(-.08,.08),rr(0,TAU),rr(-.08,.08)),[h*.42,h,h*.42],col);          // feather
  else if(t<.86)BIO.put('clubpen',[px,y-.05,pz],qEuler(rr(-.06,.06),rr(0,TAU),rr(-.06,.06)),[h*.34,h*.8,h*.34],col); // club
  else BIO.put('pen',[px,y-.05,pz],qEuler(rr(-.1,.1),rr(0,TAU),rr(-.1,.1)),[h*.16,h*1.8,h*.16],col);}              // whip
 st.pens++;}
function aroid(x,y,z,lv,st){const n=lv===2?ri(3,6):2,hc=vary(pick(PAL.aroid),.03,.1,.06);
 for(let k=0;k<n;k++){const a=rr(0,TAU),L=rr(1,2.4),stem=rr(.5,1.6),px=x+Math.cos(a)*.3,pz=z+Math.sin(a)*.3;
  if(lv===2)BIO.beam('rod',[px,y,pz],[px+Math.cos(a)*.3,y+stem,pz+Math.sin(a)*.3],.03,.02,rodCol(0x3a6a5a));
  BIO.put('heart',[px+Math.cos(a)*.3,y+stem,pz+Math.sin(a)*.3],qEuler(rr(.4,.9),Math.atan2(Math.cos(a),Math.sin(a)),rr(-.2,.2)),[L*.8,L,1],bright(vary(hc,.02,.08,.06),1.45));}st.aroids++;}
function ginger(x,y,z,lv,st){const h=rr(1.4,2.8);tuft('spike',x,y,z,h,h*.7,leafCol(PAL.fern,1.35));
 if(lv>=1){const col=C(pick(PAL.ginger)),sh=rr(.8,1.4);BIO.beam('rod',[x+.2,y,z],[x+.2,y+sh,z],.02,.015,rodCol(0x4a6a3a));BIO.put('pompom',[x+.2,y+sh+.1,z],qEuler(0,rr(0,TAU),0),[.14,.22,.14],bright(col,.85));}st.ginger++;}
function rhodo(x,y,z,lv,st){const Rs=shrub(x,y,z,lv,PAL.shrub,1.1);if(lv>=1)blooms(x,y+Rs*.9,z,Rs*.8,lv===2?ri(10,18):5,PAL.rhodo,[.22,.36],Rs*.6);st.rhodo++;}
function lilies(x,y,z,lv,st){const n=lv===2?ri(3,7):2,col=C(pick(PAL.lily));
 for(let k=0;k<n;k++){const px=x+rr(-.8,.8),pz=z+rr(-.8,.8),h=rr(.6,1.2);tuft('spike',px,y,pz,h*.8,h*.4,leafCol(PAL.grassGreen,1.3));BIO.put('bloom',[px,y+h,pz],qEuler(rr(.8,1.2),rr(0,TAU),0),rr(.18,.28),bright(col,1.1));}st.lilies++;}
function bluebells(x,y,z,lv,st){blooms(x,y,z,rr(1.2,2.4),lv===2?ri(14,26):ri(6,10),PAL.bluebell,[.07,.13],.35);st.bells++;}
function reed(x,y,z,lv){const h=rr(1.4,2.8)*(lv===0?1.5:1);for(let k=0,n=lv===2?ri(2,4):1;k<n;k++){const a=rr(0,TAU),d=k?rr(.6,2):0;tuft('reed',x+Math.cos(a)*d,y,z+Math.sin(a)*d,h*rr(.75,1.1),h*rr(.7,1.1),leafCol(PAL.reed,1.35,.025));}}
function grassTuft(x,y,z,lv,set,hk,k){const h=rr(.5,1.1)*(hk||1)*(lv===0?1.6:1),n=lv===2?(k||ri(2,4)):1;
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=i?rr(.5,1.8):0;tuft('grass',x+Math.cos(a)*d,y,z+Math.sin(a)*d,h*rr(.8,1.1),h*1.4,leafCol(set,1.3,.03));}}
function kpaw(x,y,z,lv,st){tuft('spike',x,y,z,rr(.6,.9),.8,leafCol(PAL.grassGreen,1.2));if(lv>=1)tuft('lupin',x,y,z,rr(1,1.6),.7,bright(C(pick(PAL.kpaw)),1.1));st.kpaw++;}
function saltbush(x,y,z,lv,st){const Rs=rr(.7,1.3);BIO.put('lobe',[x,y-.2,z],qEuler(0,rr(0,TAU),0),[Rs,Rs*.8,Rs],shade(vary(pick(PAL.saltbush),.02,.06,.05),-.05));if(lv===2)card(x,y+Rs*.6,z,Rs*1.8,Rs*1.3,leafCol(PAL.saltbush,1.2));st.shrubs++;}
function boulder(x,y,z,lv,set,st){const n=lv===2?ri(1,3):1,Rb=rr(.8,2.6);
 for(let i=0;i<n;i++){const a=rr(0,TAU),d=i?Rb*rr(.7,1.2):0,r=Rb*(i?rr(.35,.7):1),bx=x+Math.cos(a)*d,bz=z+Math.sin(a)*d,by=Y(bx,bz),h=r*rr(.5,.9);
  BIO.put('boulder',[bx,by+h*.3,bz],qEuler(rr(-.25,.25),rr(0,TAU),rr(-.25,.25)),[r*rr(.9,1.3),h*.8,r*rr(.9,1.3)],rockTint(set));st.boulders++;}}
function lotus(x,z,lv,st){const R=rr(.5,1.1);BIO.put('pad',[x,.12,z],qEuler(rr(-.1,.1),rr(0,TAU),rr(-.1,.1)),[R,1,R],bright(vary(pick(PAL.pad),.03,.1,.06),1.1));
 if(lv===2&&rng()<.35){const h=rr(.5,1.2);BIO.beam('rod',[x+.2,0,z],[x+.2,h,z],.02,.015,C(0x4a6a4a));BIO.put('bloom',[x+.2,h,z],qEuler(rr(1.1,1.4),rr(0,TAU),0),rr(.28,.4),bright(C(pick(PAL.lotus)),1.1));}
 for(let k=0,m=rng()<.5?ri(1,3):0;k<m;k++){const a=rr(0,TAU),d=R*rr(1.3,2.4),R2=R*rr(.5,.9);BIO.put('pad',[x+Math.cos(a)*d,.05,z+Math.sin(a)*d],qEuler(0,rr(0,TAU),0),[R2,1,R2],bright(vary(pick(PAL.pad),.03,.1,.06),1.05));}st.lotus++;}
// the bamboo grove floor: pale leaf litter, shoots coming up, a little moss
function groveFloor(x,y,z,lv,st){const t=rng();
 if(t<.62){BIO.put('mossmat',[x,y+.05,z],qEuler(rr(-.05,.05),rr(0,TAU),rr(-.05,.05)),[rr(1.5,3),1,rr(1.5,3)],leafCol(PAL.litter,.95,.02));st.litter++;}
 else if(t<.84){const h=rr(.4,1.6);BIO.put('cone',[x,y-.05,z],qEuler(rr(-.08,.08),rr(0,TAU),rr(-.08,.08)),[h*.28,h,h*.28],shade(vary(C(0x7a6a44),.03,.1,.08),-.1));st.shoots++;}
 else if(t<.94){groundMoss(x,y,z,rr(.8,1.8));st.moss++;}
 else{fern(x,y,z,lv);st.ferns++;}}
// a fallen trunk, silvered, with moss and ferns along its back
function log(x,y,z,st){const a=rr(0,TAU),L=rr(14,40),r0=rr(.6,1.4),hx=Math.cos(a),hz=Math.sin(a),n=Math.ceil(L/7)+1,pts=[];
 for(let i=0;i<n;i++){const t=i/(n-1),px=x+hx*(t-.5)*L,pz=z+hz*(t-.5)*L;if(BIO.mask(px,pz)<=0||!okGround(px,pz,1.5))return false;
  pts.push({x:px,y:Y(px,pz)+r0*.35,z:pz,r:mix(r0,r0*.55,t),col:tint(pick(PAL.deadwood),means().wood,rr(.55,.85)).lerp(C(PAL.moss[i%3]),rng()<.35?.5:0)});}
 BIO.tube('wood',pts,pts[0].col,{seg:8,cap:true});st.logs++;
 for(let s=2;s<L-2;s+=rr(3,6)){const t=s/L,i=Math.min(n-2,Math.floor(t*(n-1))),f=t*(n-1)-i,A=pts[i],Bq=pts[i+1],px=mix(A.x,Bq.x,f),pz=mix(A.z,Bq.z,f),py=mix(A.y,Bq.y,f),r=mix(A.r,Bq.r,f);
  const k=rng();if(k<.45){BIO.put('mossmat',[px,py+r*.95,pz],qEuler(rr(-.1,.1),rr(0,TAU),rr(-.1,.1)),r*rr(.6,1),leafCol(PAL.moss,.95));st.moss++;}
  else if(k<.75)frondCrown(px+rr(-.3,.3),py+r*.9,pz+rr(-.3,.3),rr(.8,1.6),5,.05,.4,leafCol(PAL.fern,1.7));
  else BIO.put('fungus',[px,py+r*.3,pz],qEuler(0,rr(0,TAU),0),[rr(.3,.6),rr(.12,.2),rr(.3,.6)],C(pick(PAL.fungus)));}
 return true;}

// ---------------------------------------------------------------- the zone planters
function plantRain(x,y,z,Z,lv,st){const t=rng();
 if(t<.18)aroid(x,y,z,lv,st);
 else if(t<.32){if(lv>=1&&okGround(x,z,2.5))giantFern(x,y,z,lv);else fern(x,y,z,lv);st.ferns++;}
 else if(t<.42){fern(x,y,z,lv,'forkfern');st.ferns++;}
 else if(t<.52)ginger(x,y,z,lv,st);
 else if(t<.66)seaPen(x,y,z,lv,st,1.6);
 else if(t<.78){shrub(x,y,z,lv,PAL.aroid);st.shrubs++;}
 else if(t<.9){if(lv>=1){groundMoss(x,y,z,rr(1.2,2.6));st.moss++;}else{fern(x,y,z,lv);st.ferns++;}}
 else blooms(x,y,z,rr(.8,1.6),ri(3,7),PAL.ginger);}
function plantShore(x,y,z,Z,lv,st){const t=rng();
 if(t<.4){reed(x,y,z,lv);st.tufts++;}
 else if(t<.6){grassTuft(x,y,z,lv,PAL.reed,.9);st.tufts++;}
 else if(t<.75){tuft('spike',x,y,z,rr(.7,1.1),.6,leafCol(PAL.reed,1.3));if(lv>=1)blooms(x,y+.8,z,.3,ri(2,4),PAL.bluebell,[.14,.22],.2);st.iris++;}
 else if(t<.9)seaPen(x,y,z,lv,st,1.1);
 else aroid(x,y,z,lv,st);}
function plantSub(x,y,z,Z,lv,st){const t=rng(),bk=bellK(x,z);
 if(t<.3*bk){bluebells(x,y,z,lv,st);if(lv===2&&rng()<.5)bluebells(x+rr(-2,2),y,z+rr(-2,2),lv,st);return;}
 if(t<.22){grassTuft(x,y,z,lv,PAL.grassGreen,1);st.tufts++;}
 else if(t<.38){fern(x,y,z,lv,rng()<.3?'forkfern':'frond');st.ferns++;}
 else if(t<.6)seaPen(x,y,z,lv,st,1.3);
 else if(t<.68)rhodo(x,y,z,lv,st);
 else if(t<.72)lilies(x,y,z,lv,st);
 else if(t<.8){shrub(x,y,z,lv,PAL.shrub);st.shrubs++;}
 else if(t<.88){if(lv>=1&&dampK(x,z)>.5){groundMoss(x,y,z,rr(1,2.2));st.moss++;}else{grassTuft(x,y,z,lv,PAL.grassGreen);st.tufts++;}}
 else if(t<.95)bluebells(x,y,z,lv,st);
 else boulder(x,y,z,lv,PAL.rock,st);}
function plantMed(x,y,z,Z,lv,st){const t=rng();
 if(t<.36){grassTuft(x,y,z,lv,PAL.grassDry,1.1);st.tufts++;if(lv===2&&rng()<.5)grassTuft(x+rr(-1.5,1.5),y,z+rr(-1.5,1.5),lv,PAL.grassDry,.9);}
 else if(t<.5)seaPen(x,y,z,lv,st,.9);
 else if(t<.6)kpaw(x,y,z,lv,st);
 else if(t<.72)saltbush(x,y,z,lv,st);
 else if(t<.8){fern(x,y,z,lv);st.ferns++;}
 else if(t<.88){BIO.put('rosette',[x,y-.02,z],qEuler(rr(-.05,.05),rr(0,TAU),rr(-.05,.05)),[rr(.5,1),rr(.4,.8),rr(.5,1)],bright(vary(pick(PAL.saltbush),.02,.08,.05),1.05));st.shrubs++;}
 else if(t<.93)blooms(x,y,z,rr(.8,1.8),ri(3,8),PAL.wattleGold,[.1,.18]);
 else boulder(x,y,z,lv,rng()<.4?PAL.rockRed:PAL.rock,st);}
function plantRip(x,y,z,Z,lv,st){const t=rng();
 if(t<.4){reed(x,y,z,lv);st.tufts++;}else if(t<.6){fern(x,y,z,lv);st.ferns++;}else if(t<.8)seaPen(x,y,z,lv,st,1.2);else{shrub(x,y,z,lv,PAL.shrub,.8);st.shrubs++;}}

// ---------------------------------------------------------------- the understorey (under the crowns)
function sapling(x,y,z,lv,set,st,col){const h=rr(2.5,6),r=h*.01+.03;
 BIO.put('trunk2',[x,y-.1,z],qEuler(rr(-.05,.05),0,rr(-.05,.05)),[r/.4,h,r/.4],col||rodCol(0x9aa4a0));
 for(let i=0,m=lv===2?ri(2,3):1;i<m;i++){const s=rr(1,1.8);BIO.put('ucard',[x+rr(-.3,.3),y+h*rr(.7,1),z+rr(-.3,.3)],qEuler(rr(-.3,.3),rr(0,TAU),rr(-.3,.3)),[s,s*1.2,s],bright(vary(pick(set),.04,.1,.06),1.4));}
 st.saplings++;}
function underPlant(x,y,z,Z,lv,st){const t=rng();
 if(Z.rain>.4){if(t<.2)aroid(x,y,z,lv,st);else if(t<.4){if(okGround(x,z,2))giantFern(x,y,z,lv);else fern(x,y,z,lv);st.ferns++;}else if(t<.6)seaPen(x,y,z,lv,st,1.8);
  else if(t<.72)ginger(x,y,z,lv,st);else if(t<.86)sapling(x,y,z,lv,PAL.glossy,st);else{fern(x,y,z,lv,'forkfern');st.ferns++;}return;}
 if(Z.med>.5){if(t<.3)seaPen(x,y,z,lv,st,1.1);else if(t<.5)saltbush(x,y,z,lv,st);else if(t<.66)kpaw(x,y,z,lv,st);else if(t<.82)sapling(x,y,z,lv,PAL.gum,st,rodCol(0xd8d8d0));else{grassTuft(x,y,z,lv,PAL.grassDry,1);st.tufts++;}return;}
 if(t<.28)seaPen(x,y,z,lv,st,1.5);else if(t<.46){fern(x,y,z,lv,rng()<.3?'forkfern':'frond');st.ferns++;}else if(t<.58)rhodo(x,y,z,lv,st);
 else if(t<.72)sapling(x,y,z,lv,PAL.birch,st,rodCol(0xe8e8e0));else if(t<.86)bluebells(x,y,z,lv,st);else{groundMoss(x,y,z,rr(1.2,2.4));st.moss++;}}

// ---------------------------------------------------------------- the pass
NWLOW.buildFloor=function(R,q){
 reseed(610021);q=q==null?1:q;R=R||2850;means();
 const st={pens:0,aroids:0,ginger:0,rhodo:0,lilies:0,bells:0,kpaw:0,ferns:0,shrubs:0,tufts:0,moss:0,boulders:0,lotus:0,litter:0,shoots:0,logs:0,iris:0,saplings:0,understorey:0};
 const planters=[plantRain,plantShore,plantSub,plantMed,plantRip];
 function plant(x,y,z,lv){if(!okGround(x,z,.7))return;const Z=zones(x,z);
  if(Z.bamboo>.08){if(rng()<smooth(.08,.4,Z.bamboo)){groveFloor(x,y,z,lv,st);return;}}
  const w=[Z.rain*1.3,Z.shore*.9,Z.sub*1.0,Z.med*1.1,Z.rip*.5];let tot=0;for(const v of w)tot+=v;if(tot<=0)return;
  let r=rng()*Math.max(1,tot),k=0;for(;k<w.length;k++){if(r<w[k])break;r-=w[k];}if(k>=w.length)return;
  planters[k](x,y,z,Z,lv,st);}
 [[10,560,0],[19,1400,560],[40,1e9,1400]].forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;return .5*q*(lv===0?.45:1);},(x,y,z,d)=>plant(x,y,z,lv),{patch:.72,patchScale:.014,pad:.5});});
 // a cheap second pass of grass: the ground cover of the plain and the hills
 [[5,480,0],[10,1200,480]].forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;return q*.7;},(x,y,z,d)=>{if(blocked(x,z,.4))return;const Z=zones(x,z);
    const w=(Z.med*.9+Z.sub*.4)*(1-Z.bamboo)*.75;if(rng()>w)return;grassTuft(x,y,z,1,Z.med>.5?PAL.grassDry:PAL.grassGreen,Z.med>.5?1.1:.8);st.tufts++;},{patch:.6,patchScale:.02,pad:.3});});
 // the water: lotus and lilies on still fresh water, reeds in the shallows
 [[7,560,0],[14,1400,560]].forEach((b,bi)=>{const lv=2-bi;
  BIO.grid(b[0],0,R,(x,z,d)=>{const ld=BIO.lodD(x,z);if(ld>=b[1]||ld<b[2])return 0;const h=Y(x,z);if(h>.3||h<-3.5)return 0;
    const Z=zones(x,z);return q*(1-Z.flow*.85)*(.7*smooth(-3.5,-1,h)+.3*smooth(-.9,-.1,h));},
   (x,y,z,d)=>{if(!BIO.clearOf(x,z,1)||blocked(x,z,.5))return;if(y>-.5&&rng()<.35){reed(x,Math.max(y,-.4),z,lv);st.tufts++;}else lotus(x,z,lv,st);},{patch:.8,patchScale:.02,noMask:true,pad:.4});});
 // fallen trees
 BIO.grid(130,0,R,(x,z,d)=>{if(BIO.lodD(x,z)>1400)return 0;const Z=zones(x,z);return (Z.rain*.8+Z.sub*.35)*(1-Z.bamboo)*q;},(x,y,z,d)=>{for(let t=0;t<4;t++)if(log(x+rr(-25,25),y,z+rr(-25,25),st))break;},{patch:0,pad:3});
 // THE UNDERSTOREY under the near and mid crowns, scaled by the ground each crown covers
 for(const T of NWLOW.TREES){if(T.lv<1||T.crownR<3.5)continue;const Rc=Math.max(T.spread||T.crownR,T.crownR)*.9,area=Math.PI*Rc*Rc,n=Math.round(Math.min(T.lv===2?30:6,area*(T.lv===2?.02:.004))*q);
  for(let i=0;i<n;i++){const a=rr(0,TAU),d=T.rb*2+.8+(Rc-T.rb*2)*Math.sqrt(rng()),x=T.x+Math.cos(a)*d,z=T.z+Math.sin(a)*d;
   if(BIO.mask(x,z)<=0||!okGround(x,z,.7))continue;const y=Y(x,z);if(y<.3)continue;const Z=zones(x,z);if(Z.bamboo>.2)continue;underPlant(x,y,z,Z,T.lv,st);st.understorey++;}}
 return{under:st};};
})();

// ==================== 65-biome-nwlowlands-dress.js
// ================================================================= NORTHWESTERN LOWLANDS — growth on structures
// What the lowlands do to a building left in them: moss on the ledges, hanging moss off
// the edges and soffits, fig-like roots down the walls, and on the ledges this region's
// own things -- sea pens standing up in the joints, young birches, ferns. The host hands
// over its shells as BufferGeometry[] in world space; this pass samples their faces and
// grows on them. It never touches the geometry -- a plant is never part of a building.
(function(){const {TAU,clamp,lerp,mix,smooth,reseed,rng,rr,ri,pick,h3,vnoise,fbm,qEuler,qFacing,qUp}=BIO.fn;
const PAL=NWLOW.PAL;
const C=hex=>new BIO.host.THREE.Color(hex);
const vcol=()=>C(pick(PAL.vine)).offsetHSL(rr(-.03,.03),rr(-.08,.08),rr(-.05,.05));
const mcol=()=>C(pick(PAL.moss)).offsetHSL(rr(-.03,.03),rr(-.08,.08),rr(-.06,.04));
const bloomCol=()=>C(pick(rng()<.5?PAL.rhodo:PAL.lantern));
const beardCol=()=>C(pick(PAL.mossPale)).multiplyScalar(rr(1.1,1.35));

// a MOSS PATCH lying on a surface with normal n (up for a ledge, down for a soffit)
function moss(p,n,r){const q=qUp(n);const s=r*rr(.7,1.3);
 BIO.put('mossmat',[p[0]+n[0]*.06,p[1]+n[1]*.06,p[2]+n[2]*.06],q,[s,1,s],mcol());}
// a HANGING CURTAIN off a point: 2-4 ribbons side by side across w, facing (dx,dz),
// a trailing strand, and the odd flower
function curtain(p,dx,dz,len,w,opt){opt=opt||{};const m=Math.hypot(dx,dz);
 if(m<1e-6){const a=rng()*TAU;dx=Math.cos(a);dz=Math.sin(a);}else{dx/=m;dz/=m;}
 const q=qFacing([dx,0,dz]),tx=-dz,tz=dx,nrb=2+Math.floor(rng()*3),c=opt.col||vcol();
 for(let i=0;i<nrb;i++){const o=(i-(nrb-1)/2)*w/nrb+rr(-.1,.1)*w,L=len*rr(.5,1);
  BIO.put('ribbon',[p[0]+tx*o+dx*rr(.05,.35),p[1]+rr(-.15,.05),p[2]+tz*o+dz*rr(.05,.35)],q,[w/nrb*rr(1,1.8),L,1],c.clone().multiplyScalar(rr(.82,1.12)));}
 if(rng()<.75){const o=rr(-w/2,w/2);BIO.put('strand',[p[0]+tx*o+dx*.4,p[1]-rr(0,.2),p[2]+tz*o+dz*.4],q,[rr(.14,.34),len*rr(.9,1.5),1],c.clone().multiplyScalar(.85));}
 if(opt.flowers&&rng()<.55){const fc=bloomCol();for(let b=0,nb=2+Math.floor(rng()*5);b<nb;b++){const s=rr(.3,.62);
  BIO.put('bloom',[p[0]+tx*rr(-.5,.5)*w+dx*.45,p[1]-rr(.2,len*.75),p[2]+tz*rr(-.5,.5)*w+dz*.45],qEuler(0,rng()*TAU,0),[s,s,s],fc);}}}
// AERIAL ROOTS off a ceiling: thin, long, hanging straight down
function roots(p,len,w){const q=qEuler(0,rng()*TAU,0),c=vcol();
 for(let i=0,n=1+Math.floor(rng()*3);i<n;i++)BIO.put('strand',[p[0]+rr(-w,w),p[1],p[2]+rr(-w,w)],q,[rr(.1,.3),len*rr(.6,1.2),1],c.clone().multiplyScalar(rr(.8,1.1)));}
// BRACKET FUNGUS on the side of something
function bracket(p,n,s){for(let b=0,nb=2+Math.floor(rng()*3);b<nb;b++){const sb=s*rr(.4,1);
 BIO.put('fungus',[p[0]+n[0]*.2+rr(-.6,.6)*s*(1-Math.abs(n[0])),p[1]+rr(0,2.2)*s,p[2]+n[2]*.2+rr(-.6,.6)*s*(1-Math.abs(n[2]))],
  qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[sb,sb*.4,sb],C(pick(PAL.fungus)));}}
// a PLANT on a ledge: fern rosette, tuft or small bush
function plant(p,s){const k=rng();const y=p[1];
 if(k<.16){const c=C(pick(PAL.pen)),h=s*rr(.8,1.6);BIO.put('pen',[p[0],y,p[2]],qEuler(rr(-.08,.08),rng()*TAU,rr(-.08,.08)),[h*.42,h,h*.42],c);}   // a sea pen in the joint
 else if(k<.45){const n=5+Math.floor(rng()*3),c=C(pick(PAL.fern));for(let i=0;i<n;i++){const a=i/n*TAU+rr(-.25,.25),L=s*rr(.85,1.4);
  BIO.put('frond',[p[0],y+s*.12,p[2]],qEuler(rr(.05,.30),-a,0),[L,L*rr(.7,1),L*rr(.7,1)],c.clone().multiplyScalar(rr(.82,1.2)));}}
 else if(k<.8){const c=C(pick(PAL.fern)).offsetHSL(rr(-.08,.08),0,rr(-.05,.08));
  BIO.put('ucard',[p[0],y+s*.35,p[2]],qEuler(rr(-.2,.2),rng()*TAU,rr(-.2,.2)),[s*1.2,s*.9,s*1.2],c);}
 else{const c=C(pick(PAL.fern)).offsetHSL(rr(-.1,.1),.05,.02);
  BIO.put('lobe',[p[0],y,p[2]],qEuler(0,rng()*TAU,0),[s,s*.7,s],c.clone().multiplyScalar(.82));
  for(let i=0;i<2;i++)BIO.put('ucard',[p[0]+rr(-.4,.4)*s,y+s*.5,p[2]+rr(-.4,.4)*s],qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[s*1.3,s,s*1.3],c.clone().multiplyScalar(rr(.9,1.2)));}}
// a SMALL TREE on a ledge: a tree fern, 4-12 m
function smallTree(p,h){const S=NWLOW.SPECIES[6],rb=h*.035+.2,rc=C(pick(S.bark)).multiplyScalar(.7);
 BIO.put('trunk2',[p[0],p[1],p[2]],qEuler(rr(-.08,.08),0,rr(-.08,.08)),[rb/.4,h,rb/.4],rc);
 for(let i=0,n=2+Math.floor(rng()*4);i<n;i++){const a=rng()*TAU,d=rr(.5,2.5);BIO.beam('rod',[p[0]+Math.cos(a)*d*.3,p[1]+h*rr(.4,.9),p[2]+Math.sin(a)*d*.3],[p[0]+Math.cos(a)*d,p[1]-.1,p[2]+Math.sin(a)*d],rr(.04,.1),null,rc);}
 const n=4+Math.floor(rng()*4),R=h*.35;
 for(let i=0;i<n;i++){const a=rng()*TAU,d=R*Math.sqrt(rng()),s=R*rr(.8,1.2);BIO.put('glossy',[p[0]+Math.cos(a)*d,p[1]+h*rr(.75,1.05),p[2]+Math.sin(a)*d],qEuler(rr(-.3,.3),rng()*TAU,rr(-.3,.3)),[s,s*.6,s],C(pick(S.leaf)).multiplyScalar(rr(1.1,1.4)),{n:[0,1,0]});}}
// LEDGES: moss on the flat, plants toward the outer edge, lips and curtains off the edge
NWLOW.dressLedges=function(geos,opt){opt=opt||{};
 const nM=opt.moss||400,nP=opt.plants||300,nE=opt.edges||140;
 BIO.upFaces(geos,nM,.6).forEach(f=>moss(f.p,f.n,rr(1.2,opt.mossR||3.5)));
 BIO.upFaces(geos,nP,.6).forEach(f=>{if(rng()<.12)smallTree(f.p,rr(4,opt.treeH||12));else plant(f.p,rr(1,opt.size||3));});
 BIO.ledgePoints(geos,nE,2.5).forEach(l=>{const p=[l.p[0]+l.n[0]*.3,l.p[1]-.1,l.p[2]+l.n[2]*.3];
  moss([l.p[0],l.p[1],l.p[2]],[0,1,0],rr(1,2.2));
  if(rng()<.7)curtain(p,l.n[0],l.n[2],rr(4,opt.hang||16),rr(2,5),{flowers:rng()<.4});
  if(rng()<.6)for(let b=0,nb=1+Math.floor(rng()*3);b<nb;b++)BIO.put('beard',[p[0]+rr(-1,1),p[1],p[2]+rr(-1,1)],qEuler(0,rng()*TAU,0),[rr(1,2.2),rr(2,6),1],beardCol());});};
// SOFFITS: moss rolled over to face the ground, roots and beards hanging out of
// it, brackets, curtains where the rim is. Density rises toward the rim: the
// middle of a big underside is in permanent dark and grows almost nothing.
NWLOW.dressSoffits=function(geos,opt){opt=opt||{};
 const S=BIO.downFaces(geos,opt.n||400,.6);if(!S.length)return;
 let cx=0,cz=0;S.forEach(f=>{cx+=f.p[0];cz+=f.p[2];});cx/=S.length;cz/=S.length;
 let rMax=1e-6;S.forEach(f=>{f.r=Math.hypot(f.p[0]-cx,f.p[2]-cz);if(f.r>rMax)rMax=f.r;});
 S.forEach(f=>{const u=f.r/rMax,lit=.15+.85*Math.pow(u,1.4);const R=(opt.mossR||5)*(.35+.65*lit);
  const dn=[0,-1,0];moss(f.p,dn,rr(R*.6,R));
  for(let q=0,nq=1+Math.floor(rng()*3);q<nq;q++)moss([f.p[0]+rr(-1,1)*R,f.p[1]-rr(0,.2),f.p[2]+rr(-1,1)*R],dn,rr(R*.25,R*.8));
  if(rng()<lit*.85)roots([f.p[0],f.p[1]-.15,f.p[2]],rr(4,opt.hang||16)*(.35+.65*lit),rr(.5,2.2));
  if(rng()<lit*.6)BIO.put('beard',[f.p[0]+rr(-1,1),f.p[1]-.1,f.p[2]+rr(-1,1)],qEuler(0,rng()*TAU,0),[rr(1.2,2.4),rr(2,7)*(.4+.6*lit),1],beardCol());
  if(rng()<lit*.40)curtain([f.p[0],f.p[1]-.2,f.p[2]],f.p[0]-cx,f.p[2]-cz,rr(5,opt.hang||16),rr(2,6),{flowers:rng()<.5});
  if(rng()<.14)bracket([f.p[0],f.p[1]-rr(.5,2),f.p[2]],[0,0,0],rr(1,2.6));});};
// WALLS: vines climbing, brackets, moss streaks under the drips
NWLOW.dressWalls=function(geos,opt){opt=opt||{};
 BIO.sideFaces(geos,opt.n||160).forEach(f=>{const k=rng();
  if(k<.2){const q=qFacing([f.n[0],0,f.n[2]]);for(let r=0,nr=2+Math.floor(rng()*3);r<nr;r++)BIO.put('strand',[f.p[0]+f.n[0]*.2+rr(-1,1)*(1-Math.abs(f.n[0])),f.p[1]+rr(0,3),f.p[2]+f.n[2]*.2+rr(-1,1)*(1-Math.abs(f.n[2]))],q,[rr(.15,.35),rr(4,opt.hang||12),1],C(0x8a8a78).multiplyScalar(rr(.6,.85)));}
  else if(k<.45)curtain([f.p[0]+f.n[0]*.3,f.p[1],f.p[2]+f.n[2]*.3],f.n[0],f.n[2],rr(3,opt.hang||12),rr(1.5,4),{});
  else if(k<.7)bracket([f.p[0],f.p[1],f.p[2]],f.n,rr(.8,2.2));
  else moss([f.p[0]+f.n[0]*.05,f.p[1],f.p[2]+f.n[2]*.05],f.n,rr(.8,2));});};
NWLOW.dressGeos=function(geos,opt){opt=opt||{};reseed(650001+(opt.seed||0));
 NWLOW.dressLedges(geos,opt.ledges||{});NWLOW.dressSoffits(geos,opt.soffits||{});NWLOW.dressWalls(geos,opt.walls||{});};
})();

// ==================== 70-biome-nwlowlands.js
// ================================================================= NORTHWESTERN LOWLANDS — build / dress / canopyH
// The biome's public surface (BIOME-API.md). The passes live in 55 (trees),
// 60 (floor) and 65 (dress); this file only orders them and reports.
NWLOW.build=function(opt){opt=opt||{};const R=opt.R||2850,q=opt.quality==null?1:opt.quality;
 const out={R,quality:q,trees:0,heroes:0,far:0};
 if(NWLOW.buildTrees){BIO.cur='nwlow/trees';Object.assign(out,NWLOW.buildTrees(R,q,opt));}
 if(NWLOW.buildFloor){BIO.cur='nwlow/floor';Object.assign(out,NWLOW.buildFloor(R,q));}
 BIO.cur=null;return out;};
NWLOW.dress=function(geos,opt){if(NWLOW.dressGeos){BIO.cur='nwlow/dress';NWLOW.dressGeos(geos,opt||{});BIO.cur=null;}};
NWLOW.canopyH=function(x,z){return NWLOW._canopyH?NWLOW._canopyH(x,z):10;};

// ==================== 82-host-sky.js
// ================================================================= HOST — Krator sky (from the Hexahedron)
// Baked equirectangular dome (haze column, sun, cumulus, the Inner and Outer
// Walls on the horizon, the inland sea's open horizon to the NW) and the gas
// giant as real geometry. Host-only: a biome never touches the sky.

// ---------------------------------------------------------------- the walls
// We are in Krator's NW quadrant. The OUTER WALL stands far across the lake to the NW,
// low and hazed; the INNER WALL rises as mountains to the SE, near and jagged. Both run
// NE-SW, across the lowlands, so each sinks to the horizon toward the NE and the SW,
// where the country lies open -- a straight wall of height h at distance d subtends
// atan(tan(e0)*cos(az-az0)).
// u = ((270-az)/360) mod 1, as the dome maps it.
function paintWalls(g,w,h,HZ,DEG){const base=HZ+6;
 // NW: the Outer Wall, far across the lake, low and hazed; SE: the Inner Wall's MOUNTAINS, near, high and jagged
 const WALLS=[{az0:315,e0:3.2,col:[128,142,152],jag:.2,name:'outer'},{az0:135,e0:16,col:[78,90,106],jag:1,name:'inner'}];
 WALLS.forEach((W,wi)=>{
  const elev=u=>{const az=((270-u*360)%360+360)%360;let d=((az-W.az0+540)%360)-180;const c=Math.cos(d*Math.PI/180);if(c<=0)return 0;
   const e=Math.atan(Math.tan(W.e0*Math.PI/180)*c)*180/Math.PI;const n=fbm(u*31+wi*7,wi*3.3,81+wi,3)-.5,n2=fbm(u*170+wi,wi,83+wi,2)-.5,pk=Math.pow(Math.max(0,fbm(u*60+wi*5,wi*2,85+wi,2)-.45)/.55,2);
   return Math.max(0,e*(1+n*W.jag*1.4+pk*W.jag*.9)+n2*.25*Math.min(1,e));};   // jag: ridgelines and peaks (the mountains are jagged, the far wall is not)
  const path=()=>{g.beginPath();g.moveTo(0,base+40);for(let x=0;x<=w;x+=2)g.lineTo(x,base-elev(x/w)*DEG);g.lineTo(w,base+40);g.closePath();};
  const c=W.col,grd=g.createLinearGradient(0,HZ-W.e0*DEG*1.2,0,base);
  grd.addColorStop(0,'rgba('+c.join(',')+',1)');grd.addColorStop(1,'rgba('+c.map(v=>v+40).join(',')+',1)');
  g.fillStyle=grd;path();g.fill();g.save();path();g.clip();
  // strata and gullies, stronger where the wall stands high
  for(let i=0;i<1400;i++){const u=rng(),e=elev(u);if(e<.4||rng()>e/W.e0)continue;const x=u*w,top=base-e*DEG,y=mix(top,base,rng());
   g.strokeStyle='rgba('+(rng()<.55?'70,80,90':'170,180,186')+','+(.08+rng()*.16).toFixed(2)+')';g.lineWidth=1+rng()*1.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+rr(-90,90),y+rr(-1.5,1.5));g.stroke();
   if(rng()<.08){g.strokeStyle='rgba(60,70,80,'+(.12+rng()*.15).toFixed(2)+')';g.lineWidth=rr(1.5,3);g.beginPath();g.moveTo(x,top+2);g.lineTo(x+rr(-3,3),mix(top,base,rr(.3,.8)));g.stroke();}}
  // the lit crest (the sun is in the WNW: the outer wall's crest catches it, the inner wall's face does)
  for(let x=0;x<=w;x+=2){const e=elev(x/w);if(e<.2)continue;const top=base-e*DEG;
   g.fillStyle='rgba(230,228,214,'+(wi?.30:.18).toFixed(2)+')';g.fillRect(x,top,2,2+e*.6);
   g.fillStyle='rgba(40,48,58,'+(.10*Math.min(1,e/3)).toFixed(2)+')';g.fillRect(x,top+3+e*.8,2,3+e);}
  // the air between: a heavy haze toward the foot
  const vv=g.createLinearGradient(0,HZ-W.e0*DEG,0,base);vv.addColorStop(0,'rgba(200,210,210,.04)');vv.addColorStop(1,'rgba(200,210,208,.45)');
  g.fillStyle=vv;g.fillRect(0,HZ-W.e0*DEG*1.3,w,base-HZ+W.e0*DEG*1.3);g.restore();});}
// the sea arc: from the lowlands the inland sea fills the horizon round the NW; no canopy line there
function landW(u){const az=((270-u*360)%360+360)%360,d=Math.abs(((az-318+540)%360)-180);return smooth(52,78,d);}
const skyTex=BIO.canvasTex(4096,2048,(g,w,h)=>{
 const HZ=h*.5,DEG=h/180;
 // --- the column: 1.9 atm, so a milky zenith and a thick haze band ---------
 const grd=g.createLinearGradient(0,0,0,h);
 grd.addColorStop(0.00,'#5d7ba2');grd.addColorStop(0.14,'#6f8aa9');
 grd.addColorStop(0.30,'#8fa4b7');grd.addColorStop(0.42,'#aebdc2');
 grd.addColorStop(0.478,'#ccd6c9');grd.addColorStop(0.497,'#dde3d2');
 grd.addColorStop(0.503,'#c9d3c0');grd.addColorStop(0.60,'#93a48c');
 grd.addColorStop(0.78,'#6d8068');grd.addColorStop(1.00,'#53664f');
 g.fillStyle=grd;g.fillRect(0,0,w,h);
 const wrapE=(x,y,rx,ry,f)=>{g.fillStyle=f;for(let k=-1;k<=1;k++){
  g.beginPath();g.ellipse(x+k*w,y,rx,ry,0,0,TAU);g.fill();}};
 // --- THE SUN, at the azimuth the directional light actually uses ----------
 // sun.position is (-1200,900,-600): azimuth 296.6, altitude 33.9. u follows
 // the dome's own mapping, u = ((270-az)/360) mod 1.
 const SUNU=((270-296.57)/360%1+1)%1, sx=w*SUNU, sy=HZ-33.85*DEG;
 {const gl=g.createRadialGradient(sx,sy,0,sx,sy,460);
  gl.addColorStop(0,'rgba(255,246,226,.95)');gl.addColorStop(.06,'rgba(255,238,200,.55)');
  gl.addColorStop(.22,'rgba(255,228,178,.20)');gl.addColorStop(1,'rgba(255,224,170,0)');
  g.fillStyle=gl;for(let k=-1;k<=1;k++)g.fillRect(sx-460+k*w,sy-460,920,920);
  wrapE(sx,sy,15,15,'rgba(255,252,240,1)');}
 // --- cumulus: flat-based heaps, crowded toward the horizon ----------------
 for(let ci=0;ci<150;ci++){
  const t=Math.pow(rng(),1.7);
  const cy=HZ-(4+t*58)*DEG, cx=rng()*w;
  const sc=.5+2.1*t+rr(0,.6), cw=rr(70,180)*sc, ch2=cw*rr(.15,.30);
  const ca=(.17+.30*rng())*(1-.32*t);
  wrapE(cx,cy+ch2*.12,cw*.92,ch2*.34,'rgba(146,160,166,'+(ca*.55).toFixed(3)+')');
  const nP=7+Math.floor(rng()*7);
  for(let p2=0;p2<nP;p2++){
   const px=cx+rr(-1,1)*cw*.78,k2=1-Math.abs(px-cx)/cw;
   const pr=ch2*(.45+.75*k2)*rr(.75,1.2);
   wrapE(px,cy-pr*.55,pr*1.5,pr,'rgba(250,250,244,'+(ca*rr(.55,1)).toFixed(3)+')');}}
 // --- humid veils -----------------------------------------------------------
 for(let i=0;i<46;i++)
  wrapE(rng()*w,HZ-rr(14,HZ*.72),rr(300,1100),rr(8,26),
   'rgba(240,246,238,'+(.025+.055*rng()).toFixed(3)+')');
 // --- two small moons, well off the giant ----------------------------------
 [[0.38,26,54,'rgba(226,222,214,'],[0.615,17,38,'rgba(214,198,192,']].forEach(M=>{
  const mx=w*M[0],my=HZ-M[1]*DEG;
  wrapE(mx,my,M[2],M[2],M[3]+'.55)');
  wrapE(mx-M[2]*.3,my-M[2]*.3,M[2]*.62,M[2]*.62,M[3]+'.28)');});
 // --- THE WALLS. At 5-8 degrees they stand well under the gas giant's lower
 // limb (25 - 15 = 10 degrees), so no overlay dome is needed in front of it.
 paintWalls(g,w,h,HZ,DEG);
 // --- horizon haze and the far canopy --------------------------------------
 const hz=g.createLinearGradient(0,HZ-80,0,HZ+40);
 hz.addColorStop(0,'rgba(200,210,204,0)');hz.addColorStop(.6,'rgba(200,210,204,.30)');
 hz.addColorStop(1,'rgba(200,210,204,.62)');
 g.fillStyle=hz;g.fillRect(0,HZ-80,w,120);
 const canopy=(col,h0,h1,R,off,bump,em)=>{g.fillStyle=col;g.beginPath();g.moveTo(0,HZ+20);
  for(let x=0;x<=w;x+=2){const an=(x%w)/w*TAU,cx2=Math.cos(an)*R,sz2=Math.sin(an)*R;
   const n=fbm(off+cx2,off+sz2,7,3),n2=fbm(off*3+cx2*6,off*3+sz2*6,11,2);
   let hh=(h0+(h1-h0)*n+bump*(n2-.5))*landW(x/w);
   if(em){const e=fbm(off*7+cx2*2.2,off*7+sz2*2.2,13,2);
    hh+=em*Math.max(0,(e-.74)/.26);}                 // emergents over the line
   g.lineTo(x,HZ-hh*DEG);}
  g.lineTo(w,HZ+20);g.closePath();g.fill();};
 canopy('rgba(128,146,132,.55)',.5,1.3,9,17.3,.3,.5);
 canopy('rgba(96,116,100,.7)',.3,.8,14,41.7,.3,.3);
 const gm=g.createLinearGradient(0,HZ-DEG*1.4,0,HZ+24);
 gm.addColorStop(0,'rgba(196,210,192,0)');gm.addColorStop(.3,'rgba(196,210,192,.32)');
 gm.addColorStop(1,'rgba(196,210,192,.95)');
 g.fillStyle=gm;g.fillRect(0,HZ-DEG*1.4,w,DEG*1.4+24);
});
skyTex.wrapS=THREE.RepeatWrapping;skyTex.wrapT=THREE.ClampToEdgeWrapping;
const sky=new THREE.Mesh(new THREE.SphereGeometry(9000,72,44),
 new THREE.MeshBasicMaterial({map:skyTex,side:THREE.BackSide,fog:false,depthWrite:false}));
sky.userData.probeSkip=true;sky.renderOrder=-10;scene.add(sky);
// the gas giant, low in the north-east (Krator canon: altitude 25°, azimuth 66°)
// THE GAS GIANT Krator orbits, ported from Girder's sky as real geometry
// rather than a painted sprite. Canon: 30 degrees across at azimuth 67,
// altitude 25 -- sixty full moons wide.
//
// The band coordinates are computed in the FRAGMENT shader from the world-space
// normal against a world-space spin axis, so the mesh needs no rotation of its
// own and there is no local/world convention to get wrong. The axis lies in the
// PLANE OF THE SKY, tilted 23 degrees from the sky's own up: that is the only
// reading that gives both a tilted planet AND rings seen as a hairline. An axis
// literally 23 degrees off world-up would sit far out of the ring plane and the
// rings would be wide open.
const GIANT_DIST=6000,GIANT_R=GIANT_DIST*Math.tan(15*Math.PI/180);
const giantDir=new THREE.Vector3(Math.sin(66*Math.PI/180)*Math.cos(25*Math.PI/180),Math.sin(25*Math.PI/180),-Math.cos(66*Math.PI/180)*Math.cos(25*Math.PI/180)).normalize();
const _gE1=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),giantDir).normalize();
const _gUp=new THREE.Vector3().crossVectors(giantDir,_gE1).normalize();
const GIANT_AXIS=_gUp.clone().multiplyScalar(Math.cos(23*Math.PI/180))
 .addScaledVector(_gE1,Math.sin(23*Math.PI/180)).normalize();
const GIANT_B1=new THREE.Vector3().crossVectors(GIANT_AXIS,giantDir).normalize();
const GIANT_B2=new THREE.Vector3().crossVectors(GIANT_AXIS,GIANT_B1).normalize();
const GU={
 uSunDir:{value:new THREE.Vector3().copy(sun.position).normalize()},
 uAxis:{value:GIANT_AXIS},uE1:{value:GIANT_B1},uE2:{value:GIANT_B2},
 uZone:{value:new THREE.Color(0x3c7e91)},uBelt:{value:new THREE.Color(0xd6c9a8)},
 uStormC:{value:new THREE.Color(0xb98a63)},uRimCol:{value:new THREE.Color(0x9fd4ea)},
 uNightC:{value:new THREE.Color(0x4b6f86)},uHazeC:{value:new THREE.Color(0xb7c4ae)},
 uSpin:{value:0},uRingLat:{value:.08},uHazeK:{value:.34}};
const giantMat=new THREE.ShaderMaterial({fog:false,depthWrite:false,uniforms:GU,
 vertexShader:[
  'varying vec3 vN; varying vec3 vV; varying vec3 vSky;',
  'void main(){vec4 wp=modelMatrix*vec4(position,1.0);',
  ' vN=normalize(mat3(modelMatrix)*normal);',
  ' vV=normalize(cameraPosition-wp.xyz);',
  ' vSky=normalize(wp.xyz-cameraPosition);',
  ' gl_Position=projectionMatrix*viewMatrix*wp;}'].join('\n'),
 fragmentShader:[
  'uniform vec3 uSunDir,uAxis,uE1,uE2,uZone,uBelt,uStormC,uRimCol,uNightC,uHazeC;',
  'uniform float uSpin,uRingLat,uHazeK;',
  'varying vec3 vN; varying vec3 vV; varying vec3 vSky;',
  'float oval(float lat,float lon,vec4 s){float dl=lat-s.x;',
  ' float dg=mod(lon-s.y+3.14159265,6.28318531)-3.14159265;',
  ' return (dg*dg)/(s.z*s.z)+(dl*dl)/(s.w*s.w);}',
  'void main(){vec3 N=normalize(vN),V=normalize(vV);',
  ' float sLat=clamp(dot(N,uAxis),-1.0,1.0), lat=asin(sLat);',
  ' float lon=atan(dot(N,uE2),dot(N,uE1))+uSpin;',
  ' float wav=0.42*sin(lon*3.0+lat*6.0)+0.24*sin(lon*7.0-2.1)+0.13*sin(lon*13.0+lat*3.0);',
  ' float b=sin(lat*10.0+wav);',
  ' vec3 col=mix(uZone,uBelt,smoothstep(-0.45,0.45,b));',
  ' col*=0.93+0.12*sin(lat*37.0+1.6*sin(lon*2.0+0.7));',
  ' col=mix(col,uZone*0.70,smoothstep(0.70,1.0,abs(sLat)));',
  ' col=mix(uStormC,col,smoothstep(0.45,1.0,oval(lat,lon,vec4(-0.36,1.10,0.40,0.13))));',
  ' col=mix(uStormC*1.12,col,smoothstep(0.45,1.0,oval(lat,lon,vec4(0.21,4.05,0.26,0.085))));',
  ' col*=1.0-0.34*(1.0-smoothstep(0.0,0.075,abs(lat-uRingLat)));',
  // clamp not max: two unit vectors can dot a hair over 1.0 and pow() of a
  // negative base is undefined in GLSL
  ' float ndv=clamp(dot(N,V),0.0,1.0);',
  ' float limb=pow(max(ndv,0.0015),0.35);',
  ' float ndl=dot(N,uSunDir);',
  ' float day=smoothstep(-0.17,0.17,ndl);',
  ' vec3 outc=col*limb*(0.92*day)+col*limb*uNightC*0.11;',
  ' float fres=pow(max(1.0-ndv,0.0),3.2);',
  ' outc+=uRimCol*fres*0.16*mix(smoothstep(-0.35,0.45,ndl),1.0,0.15);',
  // extinction: the disc is 30 deg wide, so its lower limb sits a good deal
  // deeper in the air than its upper one
  ' float up=max(vSky.y,0.0);',
  // a floor under the extinction: at this distance even the zenith is looking
// through a lot of 1.9-atm air, and without it the night side punched a
// black hole in a daylit sky
' outc=mix(outc,uHazeC,clamp(0.30+uHazeK*exp(-up/0.16),0.0,0.86));',
  ' gl_FragColor=vec4(outc,1.0);}'].join('\n')});
const giant=new THREE.Mesh(new THREE.SphereGeometry(GIANT_R,96,64),giantMat);
giant.renderOrder=-9;giant.userData.probeSkip=true;scene.add(giant);
// the rings, edge-on because the spin axis lies in the plane of the sky
const ringMat=new THREE.ShaderMaterial({fog:false,transparent:true,depthWrite:false,
 side:THREE.DoubleSide,uniforms:{uIn:{value:1.30},uOut:{value:2.12},
  uCol:{value:new THREE.Color(0xbcb09a)},uHazeC:GU.uHazeC,uHazeK:GU.uHazeK},
 vertexShader:['varying vec2 vUvR; varying vec3 vSky;',
  'void main(){vUvR=position.xy;vec4 wp=modelMatrix*vec4(position,1.0);',
  ' vSky=normalize(wp.xyz-cameraPosition);',
  ' gl_Position=projectionMatrix*viewMatrix*wp;}'].join('\n'),
 fragmentShader:['uniform float uIn,uOut,uHazeK;uniform vec3 uCol,uHazeC;',
  'varying vec2 vUvR; varying vec3 vSky;',
  'void main(){float r=length(vUvR);',
  ' float t=(r-uIn)/(uOut-uIn);',
  ' if(t<0.0||t>1.0)discard;',
  ' float a=0.62*(0.45+0.55*sin(t*34.0))*(1.0-smoothstep(0.86,1.0,t));',
  ' a*=smoothstep(0.0,0.06,t);',
  ' a*=1.0-0.55*smoothstep(0.40,0.46,t)*(1.0-smoothstep(0.46,0.52,t));',
  ' vec3 c=uCol*(0.8+0.3*sin(t*21.0));',
  ' float up=max(vSky.y,0.0);',
  ' c=mix(c,uHazeC,clamp(0.26+uHazeK*exp(-up/0.16),0.0,0.86));',
  ' gl_FragColor=vec4(c,a);}'].join('\n')});
const giantRing=new THREE.Mesh(new THREE.RingGeometry(GIANT_R*1.30,GIANT_R*2.12,256,1),ringMat);
giantRing.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),GIANT_AXIS);
giantRing.renderOrder=-9;giantRing.userData.probeSkip=true;scene.add(giantRing);
TICKS.push(function(dt){GU.uSpin.value+=dt*0.006;});

// ==================== 85-host-tower.js
// ================================================================= HOST — one Girder tower
// A single ruined tower of Girder's four (30 storeys of 5 m on a 48 m square,
// 4x4 cyclopean columns, 16 m floor plates in a 3x3 grid, spandrel girders,
// X-bracing, core walls, a ragged unfinished top), rebuilt here in plain
// three.js so the biome has soffits, ledges and walls to grow on. It is a TEST
// STRUCTURE for NWLOW.dress(): the host merges its shells per material
// and hands the geometries over; the biome samples their faces itself.
// Host-only. No plant is placed in this file.
function buildTestTower(){
 const TX=40,TZ=-470,HALF=24,N=30,FH=5,SLAB=1,COLS=[-HALF+1.6,-8,8,HALF-1.6];
 const y0=terrainH(TX,TZ);
 const conc=[],rust=[];
 const box=(list,x,y,z,w,h,d,rot)=>{const g=new THREE.BoxGeometry(w,h,d);if(rot){g.rotateX(rot[0]||0);g.rotateY(rot[1]||0);g.rotateZ(rot[2]||0);}g.translate(x,y+h/2,z);list.push(g);};
 const beam=(list,ax,ay,az,bx,by,bz,w,d)=>{const L=Math.hypot(bx-ax,by-ay,bz-az);const g=new THREE.BoxGeometry(w,L,d);
  const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(bx-ax,by-ay,bz-az).normalize());
  g.applyMatrix4(new THREE.Matrix4().makeRotationFromQuaternion(q));g.translate((ax+bx)/2,(ay+by)/2,(az+bz)/2);list.push(g);};
 // the ruin state: floors above 18 lose plates, the top is ragged
 const floors=[];for(let k=0;k<=N;k++){const missing=[];
  if(k>10)for(let bi=-1;bi<=1;bi++)for(let bj=-1;bj<=1;bj++){const p=k>22?.55:(k>16?.30:.10);if(rng()<p)missing.push(bi+','+bj);}
  floors.push({k,y:y0+3+k*FH,missing});}
 const top=y0+3+N*FH;
 // columns, some running on past the roof as broken stubs
 COLS.forEach((cx,i)=>COLS.forEach((cz,j)=>{const over=rng()<.55?rr(2,13):.4;box(rust,TX+cx,y0-3,TZ+cz,3.2,top-y0+3+over,3.2);}));
 floors.forEach(F=>{const yb=F.y-SLAB;
  for(let bi=-1;bi<=1;bi++)for(let bj=-1;bj<=1;bj++){if(F.missing.indexOf(bi+','+bj)>=0)continue;
   if(bi||bj)box(conc,TX+bi*16,yb,TZ+bj*16,16.02,SLAB,16.02);
   else if(F.k<N){box(conc,TX-6.2,yb,TZ,3.6,SLAB,16);box(conc,TX+1.8,yb,TZ-6.1,12.4,SLAB,3.8);box(conc,TX+1.8,yb,TZ+6.1,12.4,SLAB,3.8);}}
  [[0,-1],[0,1],[-1,0],[1,0]].forEach(f=>box(rust,TX+f[0]*(HALF-.35),yb-.9,TZ+f[1]*(HALF-.35),f[0]?.7:48,1.5,f[0]?48:.7));
  [-8,8].forEach(c=>{box(rust,TX+c,yb-.8,TZ,.9,.8,47);box(rust,TX,yb-.8,TZ+c,47,.8,.9);});
  if(F.k<N&&F.k<20){box(conc,TX,F.y,TZ-7.6,16,FH,.8);box(conc,TX,F.y,TZ+7.6,16,FH,.8);box(conc,TX+7.6,F.y,TZ,.8,FH,14.4);}
 });
 // X-bracing, two storeys at a time, gaps where it has fallen
 [[0,-1],[0,1],[-1,0],[1,0]].forEach(f=>{for(let k=0;k<N;k+=2){if(rng()<.22)continue;
  const ya=floors[k].y,yb2=floors[Math.min(N,k+2)].y-SLAB,px=TX+f[0]*(HALF-.4),pz=TZ+f[1]*(HALF-.4),ax=f[0]?0:-8,az=f[1]?0:-8;
  beam(rust,px+ax,ya,pz+az,px-ax,yb2,pz-az,.55,.55);beam(rust,px-ax,ya,pz-az,px+ax,yb2,pz+az,.55,.55);}});
 // rubble at the foot
 for(let i=0;i<40;i++){const a=rng()*TAU,r=rr(26,52);const x=TX+Math.cos(a)*r,z=TZ+Math.sin(a)*r;box(conc,x,terrainH(x,z)-.5,z,rr(2,7),rr(1,3),rr(2,6),[rr(-.3,.3),rng()*TAU,rr(-.3,.3)]);}
 // merge per material
 const TEXC=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=150+(fbm(x/18,y/18,2.2,3)-.5)*60+(fbm(x/3,y/3,8,1)-.5)*20;d[i]=v*.92;d[i+1]=v*.86;d[i+2]=v*.74;d[i+3]=255;}g.putImageData(id,0,0);});
 const TEXR=BIO.canvasTex(256,256,(g,w,h)=>{const id=g.createImageData(w,h),d=id.data;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,v=fbm(x/14,y/9,5.5,3),u=fbm(x/4,y/4,3,2);d[i]=96+v*46+u*16;d[i+1]=70+v*34+u*8;d[i+2]=52+v*22;d[i+3]=255;}g.putImageData(id,0,0);});
 const merge=(list,mat,label)=>{const pos=[],nor=[],uv=[];
  list.forEach(g=>{const ng=g.toNonIndexed();const p=ng.attributes.position.array,n=ng.attributes.normal.array;
   for(let i=0;i<p.length;i++){pos.push(p[i]);nor.push(n[i]);}
   for(let i=0;i<p.length;i+=3){uv.push((p[i]+p[i+2])/6,p[i+1]/6);}});   // triplanar-ish world uv
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  const m=new THREE.Mesh(geo,mat);m.userData.inspectLabel=label;m.userData.host=true;scene.add(m);return geo;};
 const gC=merge(conc,new THREE.MeshLambertMaterial({map:TEXC,color:0x8e8878}),'Girder tower — concrete');
 const gR=merge(rust,new THREE.MeshLambertMaterial({map:TEXR,color:0x6e4a36}),'Girder tower — iron');
 OBSTACLES.push({x:TX,z:TZ,r:HALF*1.5+6,y0:y0-5,y1:top+20});
 REGISTER({name:'Girder tower (test structure, ruined)',x:TX,z:TZ,y:y0,r:HALF*1.5,h:top-y0+16});
 return [gC,gR];}

// ==================== 88-host-build.js
// ================================================================= HOST — build
// The order a world follows: its own structures first (they fill OBSTACLES and
// hand their shells to dress()), then the biome, then one bake.
window._biome=null;
// ?q=0.5 (or window.KRATOR_Q) scales every count in the biome: the knob for a weaker machine
const BIOME_Q=(()=>{let q=+(window.KRATOR_Q||0);try{q=q||+(new URLSearchParams(location.search).get('q'));}catch(e){}return q>0?Math.min(q,1.5):1;})();
(function(){
 const t0=performance.now();
 let shells=[];
 if(typeof buildTestTower==='function'){try{shells=buildTestTower()||[];}catch(e){reportErr('tower: '+e.stack);}}
 try{window._biome=NWLOW.build({R:TERR.R-150,quality:BIOME_Q,avenues:[{path:ROAD,spacing:16,offset:9,species:'ghostgum'}]});}catch(e){reportErr('biome: '+e.stack);}
 if(shells.length){try{NWLOW.dress(shells,{ledges:{moss:2200,plants:900,edges:520,hang:14},soffits:{n:1800,mossR:4,hang:14},walls:{n:520}});}catch(e){reportErr('dress: '+e.stack);}}
 const b=BIO.bake();
 window._instances=b.inst;window._bakeCalls=b.calls;window._buildMs=Math.round(performance.now()-t0);
 REGISTER({name:'The northwestern lowlands (ideal type)',x:0,z:0,r:TERR.R,h:420});
})();

// ==================== 90-host-camera.js
// ================================================================= HOST — camera, inspector, loop
const ctl={target:new THREE.Vector3(0,0,0),theta:0,phi:1.1,radius:600};
function setView(cx,cy,cz,tx,ty,tz){ctl.target.set(tx,ty,tz);const dx=cx-tx,dy=cy-ty,dz=cz-tz;ctl.radius=Math.sqrt(dx*dx+dy*dy+dz*dz);ctl.theta=Math.atan2(dx,dz);ctl.phi=Math.acos(clamp(dy/ctl.radius,-1,1));}
function applyCam(){const r=ctl.radius,sp=Math.sin(ctl.phi);camera.position.set(ctl.target.x+r*sp*Math.sin(ctl.theta),ctl.target.y+r*Math.cos(ctl.phi),ctl.target.z+r*sp*Math.cos(ctl.theta));
 const g=terrainH(camera.position.x,camera.position.z)+1.8;if(camera.position.y<g)camera.position.y=g;camera.lookAt(ctl.target);}
// Preset views. Most are FOUND, not typed: viewTree() looks up the nearest
// near-detail tree of a species to a point on the (s,t) axis and frames it from
// the sun side, so a view still lands on its subject when the placement moves.
const SUNH=(()=>{const l=Math.hypot(-1200,-600);return[-1200/l,-600/l];})();
function viewTree(key,s,t,dist,h,look,side){const sp=NWLOW.SPECIES.findIndex(S=>S.key===key),o=xzOf(s,t);let best=null,bd=1e9;
 for(const T of NWLOW.TREES){if(T.sp!==sp||T.lv!==2)continue;const d=Math.hypot(T.x-o[0],T.z-o[1]);if(d<bd){bd=d;best=T;}}
 if(!best)return[o[0]+80,terrainH(o[0],o[1])+30,o[1]+80,o[0],terrainH(o[0],o[1]),o[1]];
 const R=Math.max(best.spread||0,best.crownR),D=dist*R,a=Math.atan2(SUNH[1],SUNH[0])+(side||0),cx=best.x+Math.cos(a)*D,cz=best.z+Math.sin(a)*D;
 return[cx,terrainH(cx,cz)+h,cz,best.x,best.y0+best.H*look,best.z];}
function viewAxis(s0,t0,h0,s1,t1,h1){const a=xzOf(s0,t0),b=xzOf(s1,t1);return[a[0],terrainH(a[0],a[1])+h0,a[1],b[0],terrainH(b[0],b[1])+h1,b[1]];}
// a bamboo grove near (s,t): the point of highest grove weight within ~700 m.
// inside: stand in it looking along; edge: stand outside it looking in
function viewGrove(s0,t0,inside){let best=null,bw=.35;
 for(let ds=-700;ds<=700;ds+=25)for(let dt=-700;dt<=700;dt+=25){const p=xzOf(s0+ds,t0+dt),w=NWLOW.zones(p[0],p[1]).bamboo-Math.hypot(ds,dt)*.00015;if(w>bw&&terrainH(p[0],p[1])>.5){bw=w;best=p;}}
 if(!best){const o=xzOf(s0,t0);return[o[0]+80,terrainH(o[0],o[1])+30,o[1]+80,o[0],terrainH(o[0],o[1]),o[1]];}
 if(inside){const b2=[best[0]+25,best[1]+10];return[best[0],terrainH(best[0],best[1])+1.7,best[1],b2[0],terrainH(b2[0],b2[1])+19,b2[1]];}
 // walk out from the interior along the sun direction until the grove weight falls away, then back off
 let x=best[0],z=best[1];for(let k=0;k<60;k++){x+=SUNH[0]*8;z+=SUNH[1]*8;if(NWLOW.zones(x,z).bamboo<.02)break;}x+=SUNH[0]*75;z+=SUNH[1]*75;
 return[x,terrainH(x,z)+3,z,best[0],terrainH(best[0],best[1])+20,best[1]];}
const VIEWS={
 'The ghost-gum avenue':(()=>{const a=xzOf(-985,ROAD_T(-985)),b=xzOf(-800,ROAD_T(-800));return[a[0],terrainH(a[0],a[1])+1.7,a[1],b[0],terrainH(b[0],b[1])+22,b[1]];})(),
 'Glow-willow':viewTree('glowwillow',-500,0,1.9,3,.4,.3),
 'Among the lanterns':viewTree('glowwillow',-300,100,.45,1.7,.3,.9),
 'In a bamboo grove':viewGrove(-700,0,true),
 'A bamboo grove':viewGrove(-700,0,false),
 'Sky meranti':viewTree('meranti',-1500,0,.9,2,.7,.3),
 'The lake shore':viewTree('paperbark',-1850,-100,3.5,2.5,.35,.6),
 'Candle birches':viewTree('birch',-300,-200,2.5,1.8,.55,.3),
 'Spire cedars':viewTree('spire',-200,200,2.4,2,.6,.3),
 'Column kauri':viewTree('kauri',-900,-300,1.1,2,.65,.3),
 'Sea pens':viewTree('bluegum',-200,0,.8,1.3,.08,.5),
 'Tower ash':viewTree('towerash',1400,0,1.4,3,.7,.3),
 'Grass trees and banksia':viewTree('grasstree',1500,0,4,2,.5,.3),
 'Crag pines':viewTree('cragpine',1900,0,2.5,8,.6,.3),
 'The tower':[40-150,terrainH(-110,-560)+40,-470-90,40,110,-470],
 'From the foothills':viewAxis(2400,100,90,-1500,-100,0),
 'From afar':viewAxis(3000,2200,420,-400,0,0),
 'Krator rising':viewAxis(-400,-200,30,1200,1400,900),
};
const ui=document.getElementById('ui');const sel=document.createElement('select');sel.id='viewsel';for(const k in VIEWS){const o=document.createElement('option');o.textContent=k;sel.appendChild(o);}sel.onchange=()=>setView(...VIEWS[sel.value]);ui.appendChild(sel);
// hidden buttons, one per preset: verify.py drives the views through these
const _hb=document.createElement('div');_hb.style.display='none';ui.appendChild(_hb);for(const k in VIEWS){const b=document.createElement('button');b.textContent=k;b.onclick=()=>setView(...VIEWS[k]);_hb.appendChild(b);}
const insp=document.getElementById('insp');const ray=new THREE.Raycaster();
function inspectAt(cx,cy){const v=new THREE.Vector2(cx/innerWidth*2-1,-(cy/innerHeight)*2+1);ray.setFromCamera(v,camera);
 const hits=ray.intersectObjects(scene.children,true).filter(h=>!h.object.userData.probeSkip||h.object.userData.inspectLabel);
 if(!hits.length){insp.textContent='(nothing)';return;}const p=hits[0].point,o=hits[0].object;
 // the smallest registered volume round the point, ignoring the map-wide one
 let best=null;for(const r of REG){if(r.r>1500)continue;const dx=p.x-r.x,dz=p.z-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p.y>=(r.y||0)-2&&p.y<=(r.y||0)+r.h+5){if(!best||r.r<best.r)best=r;}}
 // a plant names itself (the item's label); a bole or a structure names its registered volume
 const lab=o.userData.inspectLabel||o.name||'mesh',isItem=o.isInstancedMesh&&o.userData.biome;
 let name=isItem?lab+(best?'  (under '+best.name+')':''):(best?best.name+'  ·  '+lab:lab);
 insp.textContent=name+'\n'+p.x.toFixed(0)+', '+p.y.toFixed(0)+', '+p.z.toFixed(0)+'  range '+camera.position.distanceTo(p).toFixed(0)+' m';}
setView(...VIEWS[Object.keys(VIEWS)[0]]);
const cv=renderer.domElement;let drag=null;const keys={};
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,b:e.button};cv.setPointerCapture(e.pointerId);});
cv.addEventListener('pointerup',e=>{if(drag&&drag.b===0&&Math.abs(e.clientX-drag.sx)<4&&Math.abs(e.clientY-drag.sy)<4)inspectAt(e.clientX,e.clientY);drag=null;});cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;
 if(drag.b===0){ctl.theta-=dx*.005;ctl.phi=clamp(ctl.phi-dy*.005,.05,Math.PI-.05);}
 else{const f=ctl.radius*.0015;const rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta));
  ctl.target.addScaledVector(rt,-dx*f).addScaledVector(fw,-dy*f);}});
cv.addEventListener('wheel',e=>{ctl.radius=clamp(ctl.radius*(e.deltaY>0?1.1:.9),3,6000);e.preventDefault();},{passive:false});
addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
const hud=document.getElementById('hud');let last=performance.now(),renderErr=false;
function frame(){const now=performance.now(),dt=Math.min(.1,(now-last)/1000);last=now;
 const sp=ctl.radius*.6*dt;const fw=new THREE.Vector3(-Math.sin(ctl.theta),0,-Math.cos(ctl.theta)),rt=new THREE.Vector3(Math.cos(ctl.theta),0,-Math.sin(ctl.theta));
 if(keys.w)ctl.target.addScaledVector(fw,sp);if(keys.s)ctl.target.addScaledVector(fw,-sp);if(keys.d)ctl.target.addScaledVector(rt,sp);if(keys.a)ctl.target.addScaledVector(rt,-sp);
 if(keys.q)ctl.target.y-=sp;if(keys.e)ctl.target.y+=sp;
 for(let i=0;i<TICKS.length;i++){try{TICKS[i](dt,now/1000);}catch(e){if(!renderErr){renderErr=true;reportErr('tick: '+e.stack);}}}
 applyCam();if(typeof sky!=='undefined'){sky.position.copy(camera.position);if(typeof wallSky!=='undefined')wallSky.position.copy(camera.position);giant.position.copy(camera.position).addScaledVector(giantDir,GIANT_DIST);giantRing.position.copy(giant.position);}
 try{renderer.render(scene,camera);}catch(e){if(!renderErr){renderErr=true;reportErr('render: '+e.stack);}}
 hud.textContent=`cam ${camera.position.x|0},${camera.position.y|0},${camera.position.z|0}  tgt ${ctl.target.x|0},${ctl.target.y|0},${ctl.target.z|0}\ncalls ${renderer.info.render.calls}  tris ${(renderer.info.render.triangles/1e6).toFixed(2)}M  inst ${window._instances}`;
 requestAnimationFrame(frame);}
frame();window._ready=true;

// ==================== 91-host-probe.js
// ================================================================= HOST — probe (window._api)
// What verify.py --assert measures. Budgets per biome pass come from
// BIO.stats (charged by BIO.cur inside the biome).
const BUDGET={
 showcase:{tris:10000000,calls:120},   // raised for the lowlands (Sep 2026): the eastabyss ceilings were 7.6M / 5.6M
 cls:{pass:7500000,host:900000},
 type:{'nwlow/trees':'pass','nwlow/floor':'pass','nwlow/dress':'pass','host':'host'},
};
function _probePoints(){
 const pts=[],m=new THREE.Matrix4(),pos=new THREE.Vector3(),q=new THREE.Quaternion(),sc=new THREE.Vector3(),bb=new THREE.Box3();
 scene.traverse(o=>{if(o.userData&&o.userData.probeSkip)return;
  if(o.isInstancedMesh){for(let i=0;i<o.count;i++){o.getMatrixAt(i,m);m.decompose(pos,q,sc);pts.push([pos.x,pos.y,pos.z]);}return;}
  if(!o.isMesh)return;bb.setFromObject(o);if(!isFinite(bb.min.x)||!isFinite(bb.max.x))return;
  pts.push([(bb.min.x+bb.max.x)/2,(bb.min.y+bb.max.y)/2,(bb.min.z+bb.max.z)/2]);});
 return pts;}
function regOccupancy(){const n=new Array(REG.length).fill(0);const P=_probePoints();
 REG.forEach((r,i)=>{for(const p of P){const dx=p[0]-r.x,dz=p[2]-r.z;if(dx*dx+dz*dz<=r.r*r.r&&p[1]>=(r.y||0)-2&&p[1]<=(r.y||0)+r.h+5)n[i]++;}});
 return REG.map((r,i)=>({name:r.name,type:r.type,n:n[i]}));}
function nanSweep(){const bad=[];let badInst=0;
 scene.traverse(o=>{if(!o.isMesh&&!o.isInstancedMesh)return;if(o.userData&&o.userData.probeSkip)return;
  const p=o.geometry&&o.geometry.attributes&&o.geometry.attributes.position;if(p){const a=p.array;for(let i=0;i<a.length;i++)if(!isFinite(a[i])){bad.push({geo:o.name||o.geometry.type,at:i});break;}}
  if(o.isInstancedMesh){const a=o.instanceMatrix.array;for(let i=0;i<a.length;i++)if(!isFinite(a[i])){badInst++;break;}}});
 return {meshes:bad.length,first:bad.slice(0,8),instances:badInst,firstInstances:[]};}
function typeStats(){const out={};for(const k in BIO.stats){const t=BIO.stats[k],cls=BUDGET.type[k]||'pass';out[k]={tris:t.tris,inst:t.inst,meshes:t.meshes,cls,limit:BUDGET.cls[cls],over:t.tris>BUDGET.cls[cls]};}return out;}
window._api={BUDGET,REG,
 get totals(){const t=BIO.totals();return {tris:t.tris,inst:t.inst,meshes:t.meshes,registered:REG.length,types:Object.keys(BIO.stats).length};},
 typeStats,regOccupancy,nanSweep,
 setView:(cx,cy,cz,tx,ty,tz)=>setView(cx,cy,cz,tx,ty,tz),views:()=>Object.keys(VIEWS),
 biome:()=>window._biome};
window._registered=REG.length;
